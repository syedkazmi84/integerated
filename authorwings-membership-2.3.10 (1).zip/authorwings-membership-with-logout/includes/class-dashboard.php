<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Dashboard {

    /** @var Memberships */
    private $memberships;

    /** @var Usage */
    private $usage;

    /** @var Plans */
    private $plans;

    public function __construct( Memberships $memberships, Usage $usage, Plans $plans ) {
        $this->memberships = $memberships;
        $this->usage       = $usage;
        $this->plans       = $plans;
    }

    /**
     * Render [awg_dashboard] shortcode.
     */
    public function render( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return $this->render_login_prompt();
        }

        $user    = wp_get_current_user();
        $user_id = $user->ID;
        $workspace_owner_id = $this->memberships->get_workspace_owner_id( $user_id );
        $mem     = $this->memberships->get_effective_membership( $user_id );
        $latest  = $this->memberships->get_latest_membership( $workspace_owner_id );
        $limits  = $this->memberships->get_user_limits( $user_id );
        $usage   = $this->usage->get_all_for_user( $user_id );
        $plans   = $this->plans->get_all();
        $plan_slug = $this->memberships->get_user_plan_slug( $user_id );
        $team_context = $this->memberships->get_team_context( $user_id );
        $monthly_breakdown = $this->usage->get_monthly_breakdown( $user_id, 6 );
        $recent_tools = $this->usage->get_recent_tools_used( $user_id, 5 );

        $ai_limit = (int) ( $limits['ai_generations_per_month'] ?? 10 );
        $ai_used  = (int) ( $usage['ai_generation'] ?? 0 );

        /**
         * Filter the dashboard color theme.
         *
         * Return one of:
         *   - 'auto'  (default, follows the user's OS preference via prefers-color-scheme)
         *   - 'light' (force light, ignore OS preference)
         *   - 'dark'  (force dark, ignore OS preference)
         *
         * @since 2.3.9
         */
        $theme = (string) apply_filters( 'awg_mem_dashboard_theme', 'auto' );
        $theme = in_array( $theme, [ 'auto', 'light', 'dark' ], true ) ? $theme : 'auto';

        ob_start();
        ?>
        <div class="awg-mem-dashboard" id="awg-dashboard"
             data-nonce="<?php echo esc_attr( wp_create_nonce( 'awg_mem_nonce' ) ); ?>"
             data-user-id="<?php echo esc_attr( $user_id ); ?>"
             data-plan="<?php echo esc_attr( $plan_slug ); ?>"
             <?php if ( $theme !== 'auto' ) : ?>data-awg-theme="<?php echo esc_attr( $theme ); ?>"<?php endif; ?>>

            <!-- Top bar -->
            <div class="awg-mem-topbar">
                <div class="awg-mem-topbar__left">
                    <div class="awg-mem-avatar">
                        <?php echo get_avatar( $user_id, 40 ); ?>
                    </div>
                    <div>
                        <div class="awg-mem-topbar__name">
                            <?php echo esc_html( $user->display_name ); ?>
                        </div>
                        <div class="awg-mem-topbar__plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?>">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?> <?php esc_html_e( 'Plan', 'authorwings-membership' ); ?>
                        </div>
                    </div>
                </div>
                <div class="awg-mem-topbar__actions">
                    <?php if ( $plan_slug === 'free' || $plan_slug === 'basic' ) : ?>
                        <a href="#account" class="awg-mem-btn awg-mem-btn--primary awg-mem-tab-link" data-tab="account">
                            <?php esc_html_e( 'Upgrade Plan', 'authorwings-membership' ); ?>
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( URLs::logout() ); ?>" class="awg-mem-btn awg-mem-btn--secondary">
                        <?php esc_html_e( 'Logout', 'authorwings-membership' ); ?>
                    </a>
                </div>
            </div>

            <!-- Tab nav -->
            <nav class="awg-mem-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Member dashboard sections', 'authorwings-membership' ); ?>">
                <button class="awg-mem-tab awg-mem-tab--active" data-tab="home" id="awg-mem-tab-home" role="tab" aria-selected="true" aria-controls="awg-mem-panel-home" tabindex="0">
                    <?php esc_html_e( 'Home', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="tools" id="awg-mem-tab-tools" role="tab" aria-selected="false" aria-controls="awg-mem-panel-tools" tabindex="-1">
                    <?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="services" id="awg-mem-tab-services" role="tab" aria-selected="false" aria-controls="awg-mem-panel-services" tabindex="-1">
                    <?php esc_html_e( 'Services', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="quote-requests" id="awg-mem-tab-quote-requests" role="tab" aria-selected="false" aria-controls="awg-mem-panel-quote-requests" tabindex="-1">
                    <?php esc_html_e( 'Quote Requests', 'authorwings-membership' ); ?>
                </button>
                <?php if ( $this->memberships->user_can( $user_id, 'awg_view_history' ) ) : ?>
                    <button class="awg-mem-tab" data-tab="history" id="awg-mem-tab-history" role="tab" aria-selected="false" aria-controls="awg-mem-panel-history" tabindex="-1">
                        <?php esc_html_e( 'History', 'authorwings-membership' ); ?>
                    </button>
                <?php endif; ?>
                <button class="awg-mem-tab" data-tab="account" id="awg-mem-tab-account" role="tab" aria-selected="false" aria-controls="awg-mem-panel-account" tabindex="-1">
                    <?php esc_html_e( 'Account', 'authorwings-membership' ); ?>
                </button>
            </nav>

            <!-- HOME TAB -->
            <div class="awg-mem-panel awg-mem-panel--active" data-panel="home" id="awg-mem-panel-home" role="tabpanel" aria-labelledby="awg-mem-tab-home" tabindex="0">

                <!-- Usage meters -->
                <div class="awg-mem-usage-grid">
                    <div class="awg-mem-usage-card">
                        <?php
                        $pct = ( $ai_limit > 0 ) ? min( 100, round( $ai_used / $ai_limit * 100 ) ) : 0;
                        $color = $pct >= 90 ? '#E24B4A' : ( $pct >= 70 ? '#EF9F27' : '#1D9E75' );
                        ?>
                        <div class="awg-mem-usage-card__title">
                            <?php esc_html_e( 'AI Generations', 'authorwings-membership' ); ?>
                        </div>
                        <div class="awg-mem-usage-donut" role="progressbar" aria-label="<?php esc_attr_e( 'AI generation usage this month', 'authorwings-membership' ); ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( $ai_limit < 0 ? 100 : $pct ); ?>" aria-valuetext="<?php echo esc_attr( $ai_limit < 0 ? __( 'Unlimited plan with no monthly cap', 'authorwings-membership' ) : sprintf( __( '%1$d percent used, %2$d of %3$d generations', 'authorwings-membership' ), $pct, $ai_used, $ai_limit ) ); ?>">
                            <svg viewBox="0 0 64 64" width="96" height="96" role="img" aria-labelledby="awg-mem-usage-donut-title awg-mem-usage-donut-desc">
                                <title id="awg-mem-usage-donut-title"><?php esc_html_e( 'AI generation usage', 'authorwings-membership' ); ?></title>
                                <desc id="awg-mem-usage-donut-desc"><?php echo esc_html( $ai_limit < 0 ? __( 'Unlimited plan with no monthly cap.', 'authorwings-membership' ) : sprintf( __( '%1$d percent used. %2$d of %3$d monthly generations have been used.', 'authorwings-membership' ), $pct, $ai_used, $ai_limit ) ); ?></desc>
                                <circle cx="32" cy="32" r="26" fill="none" stroke="#e5e7eb" stroke-width="8"/>
                                <circle class="awg-mem-usage-donut__progress" cx="32" cy="32" r="26" fill="none"
                                    stroke="<?php echo esc_attr( $color ); ?>"
                                    stroke-width="8"
                                    stroke-dasharray="0 163"
                                    data-target-dasharray="<?php echo esc_attr( $ai_limit < 0 ? '163 163' : round( $pct * 1.63 ) . ' 163' ); ?>"
                                    stroke-linecap="round"
                                    transform="rotate(-90 32 32)"/>
                            </svg>
                            <span class="awg-mem-usage-donut__label" aria-hidden="true">
                                <?php if ( $ai_limit < 0 ) : ?>
                                    ∞
                                <?php else : ?>
                                    <?php echo esc_html( $pct ); ?>%
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="awg-mem-usage-card__sub">
                            <?php if ( $ai_limit < 0 ) : ?>
                                <?php esc_html_e( 'Unlimited usage included in your plan.', 'authorwings-membership' ); ?>
                            <?php else : ?>
                                <?php printf( esc_html__( '%1$d of %2$d used this month', 'authorwings-membership' ), (int) $ai_used, (int) $ai_limit ); ?>
                                <br><?php printf( esc_html__( '%d remaining this month', 'authorwings-membership' ), max( 0, (int) $ai_limit - (int) $ai_used ) ); ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Plan info card -->
                    <div class="awg-mem-usage-card awg-mem-usage-card--plan">
                        <div class="awg-mem-usage-card__title"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                        <div class="awg-mem-plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?> awg-mem-plan-badge--lg">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?>
                        </div>
                        <?php if ( $mem && ! empty( $mem['end_date'] ) && $mem['is_free'] != 1 ) : ?>
                            <div class="awg-mem-usage-card__sub">
                                <?php
                                printf(
                                    /* translators: %s: renewal date */
                                    esc_html__( 'Renews %s', 'authorwings-membership' ),
                                    esc_html( wp_date( get_option( 'date_format' ), strtotime( $mem['end_date'] ) ) )
                                );
                                ?>
                            </div>
                        <?php endif; ?>
                        <a href="#account" class="awg-mem-tab-link awg-mem-link" data-tab="account">
                            <?php esc_html_e( 'Manage plan →', 'authorwings-membership' ); ?>
                        </a>
                    </div>
                </div>

                <!-- Quick actions -->
                <h3 class="awg-mem-section-title"><?php esc_html_e( 'Quick Actions', 'authorwings-membership' ); ?></h3>
                <div class="awg-mem-quick-grid">
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="tools">
                        <span class="dashicons dashicons-lightbulb"></span>
                        <span><?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?></span>
                    </button>
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="services">
                        <span class="dashicons dashicons-book-alt"></span>
                        <span><?php esc_html_e( 'Services', 'authorwings-membership' ); ?></span>
                    </button>
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="quote-requests">
                        <span class="dashicons dashicons-media-text"></span>
                        <span><?php esc_html_e( 'Quote Requests', 'authorwings-membership' ); ?></span>
                    </button>
                    <?php if ( $this->memberships->user_can( $user_id, 'awg_view_history' ) ) : ?>
                        <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="history">
                            <span class="dashicons dashicons-list-view"></span>
                            <span><?php esc_html_e( 'My History', 'authorwings-membership' ); ?></span>
                        </button>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( home_url( '/publishing-guides/' ) ); ?>" class="awg-mem-quick-card">
                        <span class="dashicons dashicons-media-document"></span>
                        <span><?php esc_html_e( 'Guides', 'authorwings-membership' ); ?></span>
                    </a>
                </div>
            </div>

            <!-- TOOLS TAB -->
            <div class="awg-mem-panel" data-panel="tools" id="awg-mem-panel-tools" role="tabpanel" aria-labelledby="awg-mem-tab-tools" tabindex="0" hidden>
                <?php $this->render_tools_panel( $plan_slug, $ai_limit, $ai_used ); ?>
            </div>

            <!-- SERVICES TAB -->
            <div class="awg-mem-panel" data-panel="services" id="awg-mem-panel-services" role="tabpanel" aria-labelledby="awg-mem-tab-services" tabindex="0" hidden>
                <?php $this->render_services_panel( $plan_slug ); ?>
            </div>

            <!-- QUOTE REQUESTS TAB -->
            <div class="awg-mem-panel" data-panel="quote-requests" id="awg-mem-panel-quote-requests" role="tabpanel" aria-labelledby="awg-mem-tab-quote-requests" tabindex="0" hidden>
                <?php $this->render_quote_requests_panel( $user_id ); ?>
            </div>

            <!-- HISTORY TAB -->
            <?php if ( $this->memberships->user_can( $user_id, 'awg_view_history' ) ) : ?>
                <div class="awg-mem-panel" data-panel="history" id="awg-mem-panel-history" role="tabpanel" aria-labelledby="awg-mem-tab-history" tabindex="0" hidden>
                    <?php $this->render_history_panel( $user_id ); ?>
                </div>
            <?php endif; ?>

            <!-- ACCOUNT TAB -->
            <div class="awg-mem-panel" data-panel="account" id="awg-mem-panel-account" role="tabpanel" aria-labelledby="awg-mem-tab-account" tabindex="0" hidden>
                <?php $this->render_account_panel( $user, $mem, $latest, $plan_slug, $plans, $ai_limit, $ai_used, $team_context ); ?>
            </div>

        </div><!-- /.awg-mem-dashboard -->
        <?php
        return ob_get_clean();
    }

    // -------------------------------------------------------
    // Panel renderers
    // -------------------------------------------------------

    private function render_tools_panel( string $plan_slug, int $ai_limit, int $ai_used ): void {
        $tools            = $this->get_tool_definitions();
        $plan_level       = Roles::level( Roles::slug_to_role( $plan_slug ) );
        $limit_reached    = $ai_limit >= 0 && $ai_used >= $ai_limit;
        $usage_percent    = $ai_limit > 0 ? min( 100, (int) round( ( $ai_used / $ai_limit ) * 100 ) ) : 0;
        $remaining_uses   = $ai_limit < 0 ? -1 : max( 0, $ai_limit - $ai_used );

        // Group by category
        $grouped = [];
        foreach ( $tools as $tool ) {
            $grouped[ $tool['category'] ][] = $tool;
        }
        ?>
        <div class="awg-mem-tools-hero">
            <div class="awg-mem-tools-hero__copy">
                <h2><?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?></h2>
                <p class="awg-mem-tools-hero__usage">
                    <?php if ( $ai_limit < 0 ) : ?>
                        <?php esc_html_e( 'Unlimited generations available this month', 'authorwings-membership' ); ?>
                    <?php else : ?>
                        <?php echo esc_html( $ai_used ); ?> / <?php echo esc_html( $ai_limit ); ?>
                        <?php esc_html_e( 'generations used this month', 'authorwings-membership' ); ?>
                    <?php endif; ?>
                </p>
                <div class="awg-mem-tools-hero__note"><?php esc_html_e( 'Use available tools instantly; upgrade for locked ones.', 'authorwings-membership' ); ?></div>
            </div>

            <div class="awg-mem-tools-hero__meter" aria-label="<?php esc_attr_e( 'AI usage status', 'authorwings-membership' ); ?>">
                <?php if ( $ai_limit < 0 ) : ?>
                    <div class="awg-mem-tools-hero__pill awg-mem-tools-hero__pill--unlimited"><?php esc_html_e( 'Unlimited', 'authorwings-membership' ); ?></div>
                <?php else : ?>
                    <div class="awg-mem-tools-progress">
                        <div class="awg-mem-tools-progress__bar" style="width: <?php echo esc_attr( $usage_percent ); ?>%;"></div>
                    </div>
                    <div class="awg-mem-tools-hero__meter-meta">
                        <span><?php echo esc_html( $usage_percent ); ?>% <?php esc_html_e( 'used', 'authorwings-membership' ); ?></span>
                        <span>
                            <?php
                            printf(
                                /* translators: %d: remaining monthly generations */
                                esc_html__( '%d remaining', 'authorwings-membership' ),
                                (int) $remaining_uses
                            );
                            ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ( $limit_reached ) : ?>
            <div class="awg-mem-tools-banner" role="status">
                <div class="awg-mem-tools-banner__icon"><span class="dashicons dashicons-chart-line"></span></div>
                <div class="awg-mem-tools-banner__body">
                    <div class="awg-mem-tools-banner__title"><?php esc_html_e( 'You’ve reached your monthly limit.', 'authorwings-membership' ); ?></div>
                    <div class="awg-mem-tools-banner__text"><?php esc_html_e( 'Upgrade to continue generating and unlock more tools.', 'authorwings-membership' ); ?></div>
                </div>
                <a href="#account" class="awg-mem-btn awg-mem-btn--primary awg-mem-tab-link" data-tab="account"><?php esc_html_e( 'Upgrade Plan', 'authorwings-membership' ); ?></a>
            </div>
        <?php endif; ?>

        <?php foreach ( $grouped as $category => $cat_tools ) : ?>
            <h3 class="awg-mem-section-title"><?php echo esc_html( $category ); ?></h3>
            <div class="awg-mem-tools-grid">
                <?php foreach ( $cat_tools as $tool ) :
                    $required_level = Roles::level( Roles::slug_to_role( $tool['plan'] ) );
                    $locked         = $plan_level < $required_level;
                    $has_template   = ! empty( $tool['template_id'] );
                    $is_exhausted   = ! $locked && $has_template && $limit_reached;
                    $card_classes   = 'awg-mem-tool-card';

                    if ( $locked ) {
                        $card_classes .= ' awg-mem-tool-card--locked';
                    } elseif ( $is_exhausted ) {
                        $card_classes .= ' awg-mem-tool-card--exhausted';
                    } else {
                        $card_classes .= ' awg-mem-tool-card--available';
                    }
                    ?>
                    <div class="<?php echo esc_attr( $card_classes ); ?>"
                         <?php if ( ! $locked && ! $is_exhausted && $has_template ) : ?>
                             data-template-id="<?php echo esc_attr( $tool['template_id'] ); ?>"
                         <?php endif; ?>>
                        <div class="awg-mem-tool-card__top">
                            <div class="awg-mem-tool-card__icon">
                                <span class="dashicons <?php echo esc_attr( $tool['icon'] ); ?>"></span>
                            </div>
                            <div class="awg-mem-tool-card__status">
                                <?php if ( $locked ) : ?>
                                    <?php esc_html_e( 'Locked', 'authorwings-membership' ); ?>
                                <?php elseif ( $is_exhausted ) : ?>
                                    <?php esc_html_e( 'Limit reached', 'authorwings-membership' ); ?>
                                <?php else : ?>
                                    <?php esc_html_e( 'Available', 'authorwings-membership' ); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="awg-mem-tool-card__body">
                            <div class="awg-mem-tool-card__title"><?php echo esc_html( $tool['name'] ); ?></div>
                            <div class="awg-mem-tool-card__desc"><?php echo esc_html( $tool['description'] ); ?></div>

                            <?php if ( $locked ) : ?>
                                <div class="awg-mem-tool-card__lock">
                                    <span class="dashicons dashicons-lock"></span>
                                    <?php
                                    printf(
                                        /* translators: %s: plan name */
                                        esc_html__( 'Unlock with the %s plan.', 'authorwings-membership' ),
                                        esc_html( ucfirst( $tool['plan'] ) )
                                    );
                                    ?>
                                </div>
                                
                                <a href="?tab=account&amp;highlight=<?php echo esc_attr( $tool['plan'] ); ?>" class="awg-mem-btn awg-mem-btn--sm awg-mem-btn--primary awg-mem-tab-link awg-mem-tool-card__action" data-tab="account" data-highlight-plan="<?php echo esc_attr( $tool['plan'] ); ?>">
                                    <?php esc_html_e( 'See Upgrade Options', 'authorwings-membership' ); ?>
                                </a>
                            <?php elseif ( $is_exhausted ) : ?>
                                <div class="awg-mem-tool-card__lock awg-mem-tool-card__lock--warning">
                                    <span class="dashicons dashicons-warning"></span>
                                    <?php esc_html_e( 'You’ve reached your monthly limit.', 'authorwings-membership' ); ?>
                                </div>
                                 
                                <a href="?tab=account&amp;highlight=pro" class="awg-mem-btn awg-mem-btn--sm awg-mem-btn--primary awg-mem-tab-link awg-mem-tool-card__action" data-tab="account" data-highlight-plan="pro">
                                    <?php esc_html_e( 'Upgrade to Continue', 'authorwings-membership' ); ?>
                                </a>
                            <?php elseif ( $has_template ) : ?>
                                <button class="awg-mem-btn awg-mem-btn--sm awg-mem-open-tool awg-mem-tool-card__action"
                                        data-template-id="<?php echo esc_attr( $tool['template_id'] ); ?>">
                                    <?php esc_html_e( 'Use Tool', 'authorwings-membership' ); ?>
                                </button>
                            <?php else : ?>
                                <span class="awg-mem-coming-soon awg-mem-tool-card__action"><?php esc_html_e( 'Coming soon', 'authorwings-membership' ); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>

        <!-- Tool modal — opened by JS when user clicks "Use Tool" -->
        <!-- hoistModalsToBody() in dashboard.js moves this to <body> on init -->
        <div class="awg-mem-modal" id="awg-tool-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box">
                <div class="awg-mem-modal__header">
                    <h3 class="awg-mem-modal__title"></h3>
                    <button class="awg-mem-modal__close" id="awg-tool-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content" id="awg-tool-modal-content">
                    <!-- Generator HTML loaded here via AJAX -->
                </div>
            </div>
        </div>
        <?php
    }

    private function render_empty_state( string $icon, string $title, string $text ): void {
        ?>
        <div class="awg-mem-empty-state" role="status">
            <div class="awg-mem-empty-state__icon"><span class="dashicons <?php echo esc_attr( $icon ); ?>"></span></div>
            <div class="awg-mem-empty-state__title"><?php echo esc_html( $title ); ?></div>
            <p class="awg-mem-empty-state__text"><?php echo esc_html( $text ); ?></p>
        </div>
        <?php
    }


    private function render_services_panel( string $plan_slug ): void {
        $services = new Services();
        $all      = $services->get_all();

        if ( empty( $all ) ) {
            $this->render_empty_state( 'dashicons-book-alt', __( 'No services available yet', 'authorwings-membership' ), __( 'Check back soon for publishing services and new offers.', 'authorwings-membership' ) );
            return;
        }

        // Group by category
        $grouped = [];
        foreach ( $all as $svc ) {
            $grouped[ $svc['category'] ][] = $svc;
        }
        ?>
        <h2><?php esc_html_e( 'Publishing Services', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Browse our professional book publishing services. Submit a request and we\'ll get back to you within 24 hours.', 'authorwings-membership' ); ?></p>

        <?php foreach ( $grouped as $category => $svcs ) : ?>
            <h3 class="awg-mem-section-title"><?php echo esc_html( ucfirst( $category ) ); ?></h3>
            <div class="awg-mem-services-grid">
                <?php foreach ( $svcs as $svc ) : ?>
                    <div class="awg-mem-service-card<?php echo ! empty( $svc['featured'] ) ? ' awg-mem-service-card--featured' : ''; ?>">
                        <div class="awg-mem-service-card__header">
                            <div class="awg-mem-service-card__header-main">
                                <?php if ( ! empty( $svc['image_url'] ) ) : ?>
                                    <div class="awg-mem-service-card__media awg-mem-service-card__media--thumb">
                                        <img src="<?php echo esc_url( $svc['image_url'] ); ?>" alt="<?php echo esc_attr( $svc['title'] ); ?>">
                                    </div>
                                <?php else : ?>
                                    <div class="awg-mem-service-card__icon">
                                        <span class="dashicons <?php echo esc_attr( $svc['icon'] ); ?>"></span>
                                    </div>
                                <?php endif; ?>
                                <div class="awg-mem-service-card__title-wrap">
                                    <div class="awg-mem-service-card__title"><?php echo esc_html( $svc['title'] ); ?></div>
                                </div>
                            </div>
                            <?php if ( ! empty( $svc['featured'] ) ) : ?>
                                <div class="awg-mem-service-card__badge"><?php esc_html_e( 'Featured', 'authorwings-membership' ); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="awg-mem-service-card__body">
                            <div class="awg-mem-service-card__desc"><?php echo esc_html( $svc['description'] ); ?></div>
                            <div class="awg-mem-service-card__meta">
                                <?php if ( $svc['price_from'] ) : ?>
                                    <div class="awg-mem-service-card__price">
                                        <?php esc_html_e( 'From ', 'authorwings-membership' ); ?><?php echo esc_html( $svc['price_from'] ); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ( $svc['turnaround'] ) : ?>
                                    <div class="awg-mem-service-card__turnaround"><?php echo esc_html( $svc['turnaround'] ); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="awg-mem-service-card__actions">
                                <button class="awg-mem-btn awg-mem-btn--sm awg-mem-btn--ghost awg-mem-view-service-details"
                                        data-slug="<?php echo esc_attr( $svc['slug'] ); ?>"
                                        data-name="<?php echo esc_attr( $svc['title'] ); ?>"
                                        data-category="<?php echo esc_attr( $svc['category_label'] ); ?>"
                                        data-description="<?php echo esc_attr( wp_strip_all_tags( $svc['description'] ) ); ?>"
                                        data-price="<?php echo esc_attr( $svc['price_from'] ); ?>"
                                        data-turnaround="<?php echo esc_attr( $svc['turnaround'] ); ?>"
                                        data-button-label="<?php echo esc_attr( $svc['button_label'] ); ?>"
                                        data-button-url="<?php echo esc_attr( $svc['button_url'] ); ?>"
                                        data-full-description="<?php echo esc_attr( $svc['full_description'] ); ?>"
                                        data-image-url="<?php echo esc_attr( $svc['image_url'] ); ?>"
                                        data-icon="<?php echo esc_attr( $svc['icon'] ); ?>">
                                    <?php esc_html_e( 'View Details', 'authorwings-membership' ); ?>
                                </button>
                                <?php if ( ! empty( $svc['button_url'] ) ) : ?>
                                    <a class="awg-mem-btn awg-mem-btn--sm" href="<?php echo esc_url( $svc['button_url'] ); ?>">
                                        <?php echo esc_html( $svc['button_label'] ); ?>
                                    </a>
                                <?php else : ?>
                                    <button class="awg-mem-btn awg-mem-btn--sm awg-mem-request-service"
                                            data-slug="<?php echo esc_attr( $svc['slug'] ); ?>"
                                            data-name="<?php echo esc_attr( $svc['title'] ); ?>">
                                        <?php echo esc_html( $svc['button_label'] ); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>


        <div class="awg-mem-modal" id="awg-service-details-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box awg-mem-service-details-modal__box">
                <div class="awg-mem-modal__header awg-mem-service-modal__header">
                    <div class="awg-mem-service-modal__heading">
                        <span class="awg-mem-service-modal__eyebrow" id="awg-service-details-category"><?php esc_html_e( 'Service Details', 'authorwings-membership' ); ?></span>
                        <h3 class="awg-mem-modal__title" id="awg-service-details-title"><?php esc_html_e( 'Service Details', 'authorwings-membership' ); ?></h3>
                    </div>
                    <button class="awg-mem-modal__close" id="awg-service-details-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content awg-mem-service-details-modal__content">
                    <div class="awg-mem-service-details-modal__hero">
                        <div class="awg-mem-service-details-modal__media" id="awg-service-details-media"></div>
                        <div class="awg-mem-service-details-modal__summary">
                            <p class="awg-mem-muted" id="awg-service-details-summary"></p>
                            <div class="awg-mem-service-details-modal__meta">
                                <div class="awg-mem-service-details-modal__meta-item" id="awg-service-details-price-wrap" style="display:none;">
                                    <span class="awg-mem-service-details-modal__meta-label"><?php esc_html_e( 'Starting From', 'authorwings-membership' ); ?></span>
                                    <span class="awg-mem-service-details-modal__meta-value" id="awg-service-details-price"></span>
                                </div>
                                <div class="awg-mem-service-details-modal__meta-item" id="awg-service-details-turnaround-wrap" style="display:none;">
                                    <span class="awg-mem-service-details-modal__meta-label"><?php esc_html_e( 'Turnaround', 'authorwings-membership' ); ?></span>
                                    <span class="awg-mem-service-details-modal__meta-value" id="awg-service-details-turnaround"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="awg-mem-service-details-modal__body" id="awg-service-details-body"></div>
                    <div class="awg-mem-service-details-modal__actions">
                        <button class="awg-mem-btn awg-mem-btn--ghost" id="awg-service-details-secondary-action" style="display:none;"></button>
                        <button class="awg-mem-btn awg-mem-btn--primary" id="awg-service-details-primary-action"></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Service order modal -->
        <div class="awg-mem-modal" id="awg-service-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box awg-mem-modal__box--sm awg-mem-service-modal__box">
                <div class="awg-mem-modal__header awg-mem-service-modal__header">
                    <div class="awg-mem-service-modal__heading">
                        <span class="awg-mem-service-modal__eyebrow"><?php esc_html_e( 'Request Quote', 'authorwings-membership' ); ?></span>
                        <h3 class="awg-mem-modal__title" id="awg-service-modal-title"><?php esc_html_e( 'Request Quote', 'authorwings-membership' ); ?></h3>
                    </div>
                    <button class="awg-mem-modal__close" id="awg-service-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content awg-mem-service-modal__content">
                    <div id="awg-service-modal-msg" class="awg-mem-alert" role="status" aria-live="polite" style="display:none;"></div>
                    <div id="awg-service-form-wrap" class="awg-mem-service-form">
                        <p class="awg-mem-muted awg-mem-service-help"><?php esc_html_e( 'Tell us about your project so we can prepare the right quote for you.', 'authorwings-membership' ); ?></p>
                        <label class="awg-mem-service-form__label" for="awg-service-notes"><?php esc_html_e( 'Project Details', 'authorwings-membership' ); ?></label>
                        <textarea id="awg-service-notes" class="awg-mem-textarea awg-mem-service-form__textarea" rows="6" aria-describedby="awg-service-notes-hint awg-service-notes-counter"
                              placeholder="<?php esc_attr_e( 'Describe your book, genre, approximate word count, current stage, and the publishing help you need.', 'authorwings-membership' ); ?>"></textarea>
                        <div class="awg-mem-service-form__meta">
                            <p class="awg-mem-service-form__hint" id="awg-service-notes-hint"><?php esc_html_e( 'Include any goals, deadlines, or special requirements that would help us prepare your quote.', 'authorwings-membership' ); ?></p>
                            <p class="awg-mem-service-form__counter" id="awg-service-notes-counter" data-min="20" aria-live="polite"><?php esc_html_e( '0 / 20 min characters', 'authorwings-membership' ); ?></p>
                        </div>
                        <div class="awg-mem-service-form__footer">
                            <span class="awg-mem-service-form__footer-note"><?php esc_html_e( 'We will review your request and contact you soon.', 'authorwings-membership' ); ?></span>
                            <button class="awg-mem-btn awg-mem-btn--primary" id="awg-service-submit">
                                <?php esc_html_e( 'Submit Request', 'authorwings-membership' ); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }


    private function render_quote_requests_panel( int $user_id ): void {
        global $wpdb;
        $table = Database::orders_table();

        $requests = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, service_name, status, created_at FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT 50",
                $user_id
            ),
            ARRAY_A
        );
        ?>
        <h2><?php esc_html_e( 'My Quote Requests', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Track the quote requests you have submitted and their current status.', 'authorwings-membership' ); ?></p>

        <?php if ( empty( $requests ) ) : ?>
            <?php $this->render_empty_state( 'dashicons-media-text', __( 'No quote requests yet', 'authorwings-membership' ), __( 'Browse the Services tab to request a quote for any publishing service.', 'authorwings-membership' ) ); ?>
        <?php else : ?>
            <table class="awg-mem-info-table awg-mem-team-table">
                <tr>
                    <td><?php esc_html_e( 'Request ID', 'authorwings-membership' ); ?></td>
                    <td><?php esc_html_e( 'Service', 'authorwings-membership' ); ?></td>
                    <td><?php esc_html_e( 'Date', 'authorwings-membership' ); ?></td>
                    <td><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></td>
                </tr>
                <?php foreach ( $requests as $request ) : ?>
                    <?php
                    $status = sanitize_key( (string) ( $request['status'] ?? 'pending' ) );
                    if ( 'in_progress' === $status ) {
                        $status = 'responded';
                    } elseif ( 'completed' === $status ) {
                        $status = 'closed';
                    }
                    if ( ! in_array( $status, [ 'pending', 'responded', 'closed' ], true ) ) {
                        $status = 'pending';
                    }
                    $status_label = [
                        'pending'   => __( 'Pending', 'authorwings-membership' ),
                        'responded' => __( 'Responded', 'authorwings-membership' ),
                        'closed'    => __( 'Closed', 'authorwings-membership' ),
                    ][ $status ];
                    ?>
                    <tr>
                        <td>#<?php echo esc_html( (int) $request['id'] ); ?></td>
                        <td><strong><?php echo esc_html( (string) $request['service_name'] ); ?></strong></td>
                        <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( (string) $request['created_at'] ) ) ); ?></td>
                        <td><?php echo esc_html( $status_label ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif;
    }

    private function render_history_panel( int $user_id ): void {
        $history = $this->get_history_page( $user_id, 1, 12 );
        ?>
        <h2><?php esc_html_e( 'My Generation History', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Recent submissions are saved here when submission storage is enabled in the AI plugin.', 'authorwings-membership' ); ?></p>

        <?php if ( ! empty( $history['items'] ) ) : ?>
            <div class="awg-mem-history-summary" id="awg-mem-history-summary" data-total="<?php echo esc_attr( (int) $history['total'] ); ?>" data-visible="<?php echo esc_attr( count( $history['items'] ) ); ?>">
                <?php
                printf(
                    esc_html__( 'Showing %1$d of %2$d submissions', 'authorwings-membership' ),
                    count( $history['items'] ),
                    (int) $history['total']
                );
                ?>
            </div>
        <?php endif; ?>

        <div id="awg-mem-history-wrap">
            <?php $this->render_history_items( $history['items'] ); ?>
        </div>

        <?php if ( ! empty( $history['has_more'] ) ) : ?>
            <div class="awg-mem-history-actions">
                <button type="button" class="awg-mem-btn" id="awg-mem-history-load-more" data-page="1">
                    <span class="awg-mem-btn__label"><?php esc_html_e( 'Load More', 'authorwings-membership' ); ?></span>
                    <span class="awg-mem-btn__spinner" aria-hidden="true"></span>
                </button>
            </div>
        <?php endif; ?>
        <?php
    }

    private function render_history_items( array $items ): void {
        if ( empty( $items ) ) {
            $this->render_empty_state( 'dashicons-lightbulb', __( 'No generations yet', 'authorwings-membership' ), __( 'Head to AI Tools to generate your first result.', 'authorwings-membership' ) );
            return;
        }

        echo '<div class="awg-mem-history-list">';
        foreach ( $items as $item ) {
            echo '<div class="awg-mem-history-item">';
            echo '<div class="awg-mem-history-item__header">';
            echo '<span class="awg-mem-history-item__tool">' . esc_html( $item['tool'] ) . '</span>';
            echo '<span class="awg-mem-history-item__date">' . esc_html( $item['date_label'] ) . '</span>';
            if ( ! empty( $item['model'] ) ) {
                echo '<span class="awg-mem-badge">' . esc_html( $item['model'] ) . '</span>';
            }
            echo '</div>';
            if ( ! empty( $item['output'] ) ) {
                echo '<div class="awg-mem-history-item__output"><pre>' . esc_html( $item['output_preview'] ) . '</pre>';
                echo '<button class="awg-mem-btn awg-mem-btn--xs awg-mem-copy-btn" data-copy="' . esc_attr( $item['output'] ) . '">' . esc_html__( 'Copy', 'authorwings-membership' ) . '</button></div>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

    public static function build_history_query_args( int $user_id, int $owner_id, int $page = 1, int $per_page = 12 ): array {
        $page     = max( 1, $page );
        $per_page = max( 1, min( 50, $per_page ) );

        return [
            'post_type'      => 'awg_ai_submission',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [
                'relation' => 'OR',
                [
                    'key'     => '_awg_aig_user_id',
                    'value'   => $user_id,
                    'compare' => '=',
                    'type'    => 'NUMERIC',
                ],
                [
                    'key'     => '_awg_aig_owner_user_id',
                    'value'   => $owner_id,
                    'compare' => '=',
                    'type'    => 'NUMERIC',
                ],
            ],
        ];
    }

    private function get_history_page( int $user_id, int $page = 1, int $per_page = 12 ): array {
        $owner_id = $this->memberships->get_workspace_owner_id( $user_id );
        $query    = new \WP_Query( self::build_history_query_args( $user_id, $owner_id, $page, $per_page ) );

        $items = [];
        foreach ( (array) $query->posts as $sub ) {
            $template_id = (int) get_post_meta( $sub->ID, '_awg_aig_template_id', true );
            $tool_name   = (string) get_post_meta( $sub->ID, '_awg_aig_template_title', true );
            if ( $tool_name === '' && $template_id > 0 ) {
                $template = get_post( $template_id );
                $tool_name = $template ? $template->post_title : __( 'AI Tool', 'authorwings-membership' );
            }
            if ( $tool_name === '' ) {
                $tool_name = __( 'AI Tool', 'authorwings-membership' );
            }
            $output = (string) get_post_meta( $sub->ID, '_awg_aig_output', true );
            $items[] = [
                'id'             => (int) $sub->ID,
                'tool'           => $tool_name,
                'date'           => $sub->post_date,
                'date_label'     => wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sub->post_date ) ),
                'model'          => (string) get_post_meta( $sub->ID, '_awg_aig_model', true ),
                'output'         => $output,
                'output_preview' => wp_trim_words( $output, 40 ),
            ];
        }

        return [
            'items'      => $items,
            'page'       => $page,
            'has_more'   => $page < (int) $query->max_num_pages,
            'max_pages'  => (int) $query->max_num_pages,
            'total'      => (int) $query->found_posts,
        ];
    }

    private function render_account_panel( \WP_User $user, ?array $mem, ?array $latest, string $plan_slug, array $plans, int $ai_limit, int $ai_used, array $team_context ): void {
        $billing_cycle = 'monthly';
        if ( $mem && ! empty( $mem['billing_cycle'] ) && in_array( $mem['billing_cycle'], [ 'monthly', 'yearly' ], true ) ) {
            $billing_cycle = (string) $mem['billing_cycle'];
        }

        $status = $mem['status'] ?? ( $latest['status'] ?? 'active' );
        $status_labels = [
            'active'         => __( 'Active', 'authorwings-membership' ),
            'trialing'       => __( 'Trialing', 'authorwings-membership' ),
            'cancelled'      => __( 'Cancelled', 'authorwings-membership' ),
            'expired'        => __( 'Expired', 'authorwings-membership' ),
            'payment_failed' => __( 'Payment failed', 'authorwings-membership' ),
        ];
        $status_label = $status_labels[ $status ] ?? ucfirst( str_replace( '_', ' ', (string) $status ) );
        $remaining = $ai_limit < 0 ? __( 'Unlimited', 'authorwings-membership' ) : max( 0, $ai_limit - $ai_used ) . ' ' . __( 'remaining', 'authorwings-membership' );
        $workspace_usage_rows = [];
        if ( ! empty( $team_context['can_manage_team'] ) ) {
            $workspace_usage_rows = $this->usage->get_workspace_usage_breakdown( (int) $team_context['workspace_owner_id'], 25 );
        }
        $renewal_label = __( 'Not applicable', 'authorwings-membership' );
        if ( $mem && ! empty( $mem['end_date'] ) && (int) ( $mem['is_free'] ?? 0 ) !== 1 ) {
            $renewal_label = wp_date( get_option( 'date_format' ), strtotime( $mem['end_date'] ) );
        }
        $billing_health_label = in_array( $status, [ 'active', 'trialing' ], true ) ? __( 'Billing active', 'authorwings-membership' ) : __( 'Billing attention needed', 'authorwings-membership' );
        $renewal_state_label = __( 'No renewal scheduled', 'authorwings-membership' );
        if ( $status === 'cancelled' ) {
            $renewal_state_label = __( 'Cancelled and moved to Free', 'authorwings-membership' );
        } elseif ( $status === 'payment_failed' ) {
            $renewal_state_label = __( 'Payment failed. Paid access inactive.', 'authorwings-membership' );
        } elseif ( $status === 'expired' ) {
            $renewal_state_label = __( 'Expired. Renew to restore paid access.', 'authorwings-membership' );
        } elseif ( in_array( $status, [ 'active', 'trialing' ], true ) && $renewal_label !== __( 'Not applicable', 'authorwings-membership' ) ) {
            $renewal_state_label = sprintf( __( 'Next renewal on %s', 'authorwings-membership' ), $renewal_label );
        }
        $seat_usage_label = __( 'No team seats on this plan', 'authorwings-membership' );
        if ( ! empty( $team_context['is_team_member'] ) ) {
            $seat_usage_label = __( 'Using a shared workspace seat', 'authorwings-membership' );
        } elseif ( ! empty( $team_context['can_manage_team'] ) ) {
            $seat_usage_label = sprintf( __( '%1$d of %2$d seats used', 'authorwings-membership' ), (int) $team_context['seat_count'], (int) $team_context['seat_limit'] );
        }
        $owner_name = ! empty( $team_context['workspace_owner_name'] ) ? (string) $team_context['workspace_owner_name'] : __( 'your account owner', 'authorwings-membership' );
        ?>
        <h2><?php esc_html_e( 'Account & Billing', 'authorwings-membership' ); ?></h2>
        <?php $this->render_account_notices( $mem, $latest ); ?>

        <div class="awg-mem-account-overview awg-mem-account-overview--simplified">
            <div class="awg-mem-account-card awg-mem-account-card--wide awg-mem-account-summary-card">
                <div class="awg-mem-account-summary-card__top">
                    <div>
                        <div class="awg-mem-account-card__label"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                        <div class="awg-mem-plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?> awg-mem-plan-badge--lg">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?>
                        </div>
                    </div>
                    <?php if ( empty( $team_context['is_team_member'] ) ) : ?>
                        <button type="button" class="awg-mem-btn awg-mem-btn--primary awg-mem-account-open-plan-modal"><?php esc_html_e( 'Change Plan', 'authorwings-membership' ); ?></button>
                    <?php endif; ?>
                </div>
                <div class="awg-mem-account-status-row">
                    <span class="awg-mem-status-pill awg-mem-status-pill--<?php echo esc_attr( sanitize_html_class( $status ) ); ?>"><?php echo esc_html( $status_label ); ?></span>
                    <span class="awg-mem-account-card__meta"><?php echo esc_html( ucfirst( $billing_cycle ) ); ?><?php echo $plan_slug === 'free' ? ' · ' . esc_html__( 'No billing', 'authorwings-membership' ) : ''; ?></span>
                </div>
                <div class="awg-mem-account-stats">
                    <div>
                        <strong><?php esc_html_e( 'Usage limit', 'authorwings-membership' ); ?></strong>
                        <span>
                        <?php if ( $ai_limit < 0 ) : ?>
                            <?php esc_html_e( 'Unlimited generations', 'authorwings-membership' ); ?>
                        <?php else : ?>
                            <?php echo esc_html( $ai_limit ); ?> <?php esc_html_e( 'generations / month', 'authorwings-membership' ); ?>
                        <?php endif; ?>
                        </span>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'Used this month', 'authorwings-membership' ); ?></strong>
                        <span><?php echo esc_html( $ai_used ); ?> · <?php echo esc_html( $remaining ); ?></span>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'Renewal date', 'authorwings-membership' ); ?></strong>
                        <span><?php echo esc_html( $renewal_label ); ?></span>
                    </div>
                </div>
                <?php if ( $status === 'payment_failed' ) : ?>
                    <div class="awg-mem-alert awg-mem-alert--error"><?php esc_html_e( 'Payment issue detected. Open plan options to restart billing and restore paid access.', 'authorwings-membership' ); ?></div>
                <?php endif; ?>
                <?php if ( empty( $team_context['is_team_member'] ) && $mem && (int) ( $mem['is_free'] ?? 0 ) !== 1 ) : ?>
                    <div class="awg-mem-account-actions">
                        <button class="awg-mem-btn awg-mem-btn--danger-outline awg-mem-cancel-plan">
                            <?php esc_html_e( 'Cancel and move to Free', 'authorwings-membership' ); ?>
                        </button>
                        <p class="awg-mem-account-help"><?php esc_html_e( 'Need a downgrade instead? Use Change Plan to switch billing without leaving this page.', 'authorwings-membership' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="awg-mem-account-sections awg-mem-account-sections--two-col">

            <section class="awg-mem-account-card awg-mem-account-section awg-mem-account-section--profile">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Profile', 'authorwings-membership' ); ?></div>
                <table class="awg-mem-info-table">
                    <tr>
                        <td><?php esc_html_e( 'Name', 'authorwings-membership' ); ?></td>
                        <td><?php echo esc_html( $user->display_name ); ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'Email', 'authorwings-membership' ); ?></td>
                        <td><?php echo esc_html( $user->user_email ); ?></td>
                    </tr>
                    <tr>
                        <td><?php esc_html_e( 'Member since', 'authorwings-membership' ); ?></td>
                        <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $user->user_registered ) ) ); ?></td>
                    </tr>
                </table>
                <button type="button" class="awg-mem-btn awg-mem-btn--primary awg-mem-profile-open-modal">
                    <?php esc_html_e( 'Edit Profile', 'authorwings-membership' ); ?>
                </button>
            </section>

            <section class="awg-mem-account-card awg-mem-account-section awg-mem-account-section--team">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Team Workspace', 'authorwings-membership' ); ?></div>
                <?php if ( ! empty( $team_context['is_team_member'] ) ) : ?>
                    <p><?php printf( esc_html__( 'You are using the Publisher workspace owned by %s.', 'authorwings-membership' ), esc_html( $owner_name ) ); ?></p>
                    <p class="awg-mem-account-help"><?php esc_html_e( 'AI usage is shared across the whole workspace. Team members can use the tools but cannot manage billing or seats.', 'authorwings-membership' ); ?></p>
                <?php elseif ( ! empty( $team_context['can_manage_team'] ) ) : ?>
                    <p>
                        <strong><?php printf( esc_html__( '%1$d of %2$d seats in use', 'authorwings-membership' ), (int) $team_context['seat_count'], (int) $team_context['seat_limit'] ); ?></strong>
                    </p>
                    <p class="awg-mem-account-help"><?php esc_html_e( 'Usage is tracked per workspace, so all team members share the same monthly AI allowance.', 'authorwings-membership' ); ?></p>
                    <div class="awg-mem-team-invite">
                        <label class="awg-mem-screen-reader-text" for="awg-team-email"><?php esc_html_e( 'Invite team member by email', 'authorwings-membership' ); ?></label>
                        <input type="email" class="awg-mem-input" id="awg-team-email" placeholder="<?php esc_attr_e( 'Invite by email', 'authorwings-membership' ); ?>" aria-describedby="awg-team-email-help awg-team-email-error">
                        <button type="button" class="awg-mem-btn awg-mem-btn--primary" id="awg-team-invite-btn"><?php esc_html_e( 'Invite Seat', 'authorwings-membership' ); ?></button>
                    </div>
                    <p class="awg-mem-account-help awg-mem-team-invite__help" id="awg-team-email-help"><?php esc_html_e( 'Enter a valid email address before sending the invite.', 'authorwings-membership' ); ?></p>
                    <div id="awg-team-email-error" class="awg-mem-inline-error" aria-live="polite" style="display:none;"></div>
                    <div id="awg-team-msg" class="awg-mem-alert" role="status" aria-live="polite" style="display:none;"></div>
                    <?php if ( ! empty( $team_context['members'] ) ) : ?>
                        <table class="awg-mem-info-table awg-mem-team-table">
                            <tr>
                                <td><?php esc_html_e( 'Email', 'authorwings-membership' ); ?></td>
                                <td><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></td>
                                <td><?php esc_html_e( 'Action', 'authorwings-membership' ); ?></td>
                            </tr>
                            <?php foreach ( (array) $team_context['members'] as $seat ) : ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html( $seat['name'] ?: $seat['email'] ); ?></strong>
                                        <?php if ( ! empty( $seat['name'] ) ) : ?><br><span class="awg-mem-account-help"><?php echo esc_html( $seat['email'] ); ?></span><?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html( ucfirst( str_replace( '_', ' ', (string) $seat['status'] ) ) ); ?></td>
                                    <td><button type="button" class="awg-mem-btn awg-mem-btn--xs awg-mem-team-remove" data-seat-id="<?php echo esc_attr( $seat['id'] ); ?>"><?php esc_html_e( 'Remove', 'authorwings-membership' ); ?></button></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    <?php endif; ?>

                    <?php if ( ! empty( $workspace_usage_rows ) ) : ?>
                        <details class="awg-mem-account-disclosure">
                            <summary><span><strong><?php esc_html_e( 'Workspace usage breakdown', 'authorwings-membership' ); ?></strong></span><span class="awg-mem-account-disclosure__hint"><?php esc_html_e( 'Expand', 'authorwings-membership' ); ?></span></summary>
                            <div class="awg-mem-account-disclosure__body">
                                <table class="awg-mem-info-table awg-mem-team-table">
                                    <tr>
                                        <td><?php esc_html_e( 'Member', 'authorwings-membership' ); ?></td>
                                        <td><?php esc_html_e( 'Runs this month', 'authorwings-membership' ); ?></td>
                                        <td><?php esc_html_e( 'Last used', 'authorwings-membership' ); ?></td>
                                    </tr>
                                    <?php foreach ( $workspace_usage_rows as $usage_row ) : ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo esc_html( $usage_row['name'] ); ?></strong>
                                                <?php if ( ! empty( $usage_row['email'] ) ) : ?><br><span class="awg-mem-account-help"><?php echo esc_html( $usage_row['email'] ); ?></span><?php endif; ?>
                                            </td>
                                            <td><?php echo esc_html( (int) $usage_row['run_count'] ); ?></td>
                                            <td><?php echo ! empty( $usage_row['last_used'] ) ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $usage_row['last_used'] ) ) ) : esc_html__( 'Not available', 'authorwings-membership' ); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                            </div>
                        </details>
                    <?php endif; ?>
                <?php else : ?>
                    <p><?php esc_html_e( 'No team seats on this plan.', 'authorwings-membership' ); ?></p>
                    <p class="awg-mem-account-help"><?php esc_html_e( 'Team seats are available on the Publisher plan. Upgrade to invite team members and share a workspace.', 'authorwings-membership' ); ?></p>
                    <a href="<?php echo esc_url( \AWG_MEM\URLs::pricing() ); ?>" class="awg-mem-btn awg-mem-btn--primary"><?php esc_html_e( 'Upgrade to Publisher', 'authorwings-membership' ); ?></a>
                <?php endif; ?>
            </section>

        </div>


        <div class="awg-mem-modal" id="awg-account-profile-modal" aria-hidden="true">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box awg-mem-modal__box--lg awg-mem-account-profile-modal__box">
                <div class="awg-mem-modal__header">
                    <div>
                        <div class="awg-mem-account-card__label"><?php esc_html_e( 'Profile', 'authorwings-membership' ); ?></div>
                        <h3 class="awg-mem-modal__title" id="awg-account-profile-modal-title"><?php esc_html_e( 'Edit your profile', 'authorwings-membership' ); ?></h3>
                    </div>
                    <button class="awg-mem-modal__close" id="awg-account-profile-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content awg-mem-account-profile-modal__content">
                    <div class="awg-mem-profile-notice" id="awg-mem-profile-notice" hidden></div>
                    <form id="awg-mem-profile-form" class="awg-mem-profile-form">
                        <input type="hidden" name="action" value="awg_mem_update_profile" />
                        <input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'awg_mem_nonce' ) ); ?>" />

                        <div class="awg-mem-profile-grid">
                            <div class="awg-mem-field">
                                <label for="awg-mem-profile-first-name"><?php esc_html_e( 'First Name', 'authorwings-membership' ); ?></label>
                                <input type="text" id="awg-mem-profile-first-name" name="first_name" value="<?php echo esc_attr( (string) get_user_meta( $user->ID, 'first_name', true ) ); ?>" />
                            </div>
                            <div class="awg-mem-field">
                                <label for="awg-mem-profile-last-name"><?php esc_html_e( 'Last Name', 'authorwings-membership' ); ?></label>
                                <input type="text" id="awg-mem-profile-last-name" name="last_name" value="<?php echo esc_attr( (string) get_user_meta( $user->ID, 'last_name', true ) ); ?>" />
                            </div>
                        </div>

                        <div class="awg-mem-field">
                            <label for="awg-mem-profile-display-name"><?php esc_html_e( 'Display Name', 'authorwings-membership' ); ?></label>
                            <input type="text" id="awg-mem-profile-display-name" name="display_name" value="<?php echo esc_attr( $user->display_name ); ?>" required />
                        </div>

                        <div class="awg-mem-field">
                            <label for="awg-mem-profile-email"><?php esc_html_e( 'Email', 'authorwings-membership' ); ?></label>
                            <input type="email" id="awg-mem-profile-email" name="user_email" value="<?php echo esc_attr( $user->user_email ); ?>" required />
                        </div>

                        <div class="awg-mem-profile-grid">
                            <div class="awg-mem-field">
                                <label for="awg-mem-profile-current-password"><?php esc_html_e( 'Current Password', 'authorwings-membership' ); ?></label>
                                <input type="password" id="awg-mem-profile-current-password" name="current_password" autocomplete="current-password" />
                                <p class="awg-mem-field__help"><?php esc_html_e( 'Required only when changing your password.', 'authorwings-membership' ); ?></p>
                            </div>
                            <div class="awg-mem-field">
                                <label for="awg-mem-profile-password"><?php esc_html_e( 'New Password', 'authorwings-membership' ); ?></label>
                                <input type="password" id="awg-mem-profile-password" name="password" autocomplete="new-password" minlength="8" />
                                <p class="awg-mem-field__help"><?php esc_html_e( 'Leave blank to keep your current password. Minimum 8 characters.', 'authorwings-membership' ); ?></p>
                            </div>
                            <div class="awg-mem-field">
                                <label for="awg-mem-profile-password-confirm"><?php esc_html_e( 'Confirm Password', 'authorwings-membership' ); ?></label>
                                <input type="password" id="awg-mem-profile-password-confirm" name="password_confirm" autocomplete="new-password" minlength="8" />
                            </div>
                        </div>

                        <div class="awg-mem-profile-actions">
                            <button type="submit" class="awg-mem-btn awg-mem-btn--primary" id="awg-mem-profile-save">
                                <?php esc_html_e( 'Save Profile', 'authorwings-membership' ); ?>
                            </button>
                            <button type="button" class="awg-mem-btn awg-mem-btn--ghost" id="awg-mem-profile-cancel">
                                <?php esc_html_e( 'Cancel', 'authorwings-membership' ); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php if ( empty( $team_context['is_team_member'] ) ) : ?>
            <div class="awg-mem-modal" id="awg-account-plan-modal" aria-hidden="true">
                <div class="awg-mem-modal__backdrop"></div>
                <div class="awg-mem-modal__box awg-mem-modal__box--lg awg-mem-account-plan-modal__box">
                    <div class="awg-mem-modal__header">
                        <div>
                            <div class="awg-mem-account-card__label"><?php esc_html_e( 'Plan & Billing', 'authorwings-membership' ); ?></div>
                            <h3 class="awg-mem-modal__title" id="awg-account-plan-modal-title"><?php esc_html_e( 'Choose your plan', 'authorwings-membership' ); ?></h3>
                        </div>
                        <button class="awg-mem-modal__close" id="awg-account-plan-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                    </div>
                    <div class="awg-mem-modal__content awg-mem-account-plan-modal__content">
                        <p class="awg-mem-account-help"><?php esc_html_e( 'Billing choices are separated here so the account tab stays focused on summary, team, usage, and profile details.', 'authorwings-membership' ); ?></p>
                        <h3 class="awg-mem-section-title awg-mem-section-title--sm"><?php esc_html_e( 'Choose Billing Period', 'authorwings-membership' ); ?></h3>
                        <div class="awg-mem-billing-toggle-wrap">
                            <div class="awg-mem-billing-toggle" role="tablist" aria-label="<?php esc_attr_e( 'Billing period', 'authorwings-membership' ); ?>">
                                <button type="button" class="awg-mem-billing-toggle__btn<?php echo $billing_cycle === 'monthly' ? ' is-active' : ''; ?>" data-billing-toggle="monthly"><?php esc_html_e( 'Monthly', 'authorwings-membership' ); ?></button>
                                <button type="button" class="awg-mem-billing-toggle__btn<?php echo $billing_cycle === 'yearly' ? ' is-active' : ''; ?>" data-billing-toggle="yearly"><?php esc_html_e( 'Yearly', 'authorwings-membership' ); ?></button>
                            </div>
                            <div class="awg-mem-billing-indicator" data-billing-indicator>
                                <?php echo $billing_cycle === 'yearly'
                                    ? esc_html__( 'Billed yearly, save 20%', 'authorwings-membership' )
                                    : esc_html__( 'Billed monthly', 'authorwings-membership' ); ?>
                            </div>
                        </div>

                        <div class="awg-mem-plans-grid awg-mem-plans-grid--account" data-current-billing="<?php echo esc_attr( $billing_cycle ); ?>">
                            <?php foreach ( $plans as $plan ) :
                                $is_current = $plan['slug'] === $plan_slug;
                                $is_popular = $plan['slug'] === 'pro';
                                $monthly    = (float) $plan['price_monthly'];
                                $yearly     = (float) $plan['price_yearly'];
                                $is_free    = (bool) $plan['is_free'];
                                $current_price = $billing_cycle === 'yearly' ? $yearly : $monthly;
                                $sym = \AWG_MEM\Plans::currency_symbol( (string) ( $plan['currency'] ?? 'USD' ) );
                            ?>
                                <div class="awg-mem-plan-card<?php echo $is_popular ? ' awg-mem-plan-card--popular' : ''; ?><?php echo $is_current ? ' awg-mem-plan-card--current' : ''; ?>"
                                     data-monthly-price="<?php echo esc_attr( number_format( $monthly, 2, '.', '' ) ); ?>"
                                     data-yearly-price="<?php echo esc_attr( number_format( $yearly, 2, '.', '' ) ); ?>"
                                     data-currency-symbol="<?php echo esc_attr( $sym ); ?>">
                                    <?php if ( $is_popular ) : ?>
                                        <div class="awg-mem-plan-card__badge"><?php esc_html_e( 'Most Popular', 'authorwings-membership' ); ?></div>
                                    <?php endif; ?>
                                    <div class="awg-mem-plan-card__name"><?php echo esc_html( $plan['name'] ); ?></div>
                                    <div class="awg-mem-plan-card__price" data-plan-price>
                                        <?php if ( $is_free ) : ?>
                                            <?php esc_html_e( 'Free', 'authorwings-membership' ); ?>
                                        <?php else : ?>
                                            <?php echo esc_html( $sym . number_format( $current_price, 0 ) . '/' . ( $billing_cycle === 'yearly' ? 'yr' : 'mo' ) ); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ( ! $is_free && $yearly > 0 ) : ?>
                                        <div class="awg-mem-plan-card__billing-note" data-plan-note>
                                            <?php echo $billing_cycle === 'yearly'
                                                ? esc_html__( 'Charged yearly', 'authorwings-membership' )
                                                : esc_html__( 'Billed monthly', 'authorwings-membership' ); ?>
                                        </div>
                                    <?php endif; ?>
                                    <ul class="awg-mem-plan-card__features">
                                        <?php foreach ( array_slice( (array) $plan['features'], 0, 5 ) as $feat ) : ?>
                                            <li><?php echo esc_html( $feat ); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                    <?php if ( $is_current ) : ?>
                                        <div class="awg-mem-plan-card__current-badge"><?php esc_html_e( 'Current Plan ✓', 'authorwings-membership' ); ?></div>
                                        <button class="awg-mem-btn awg-mem-btn--primary awg-mem-select-plan awg-mem-select-plan--current<?php echo $is_popular ? ' awg-mem-btn--full' : ''; ?>"
                                                type="button"
                                                disabled
                                                aria-disabled="true">
                                            <?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?>
                                        </button>
                                    <?php else : ?>
                                        <button class="awg-mem-btn awg-mem-btn--primary awg-mem-select-plan<?php echo $is_popular ? ' awg-mem-btn--full' : ''; ?>"
                                                type="button"
                                                data-plan="<?php echo esc_attr( $plan['slug'] ); ?>"
                                                data-billing="<?php echo esc_attr( $billing_cycle ); ?>"
                                                data-plan-name="<?php echo esc_attr( $plan['name'] ); ?>"
                                                data-is-free="<?php echo $is_free ? '1' : '0'; ?>">
                                            <?php echo $is_free
                                                ? esc_html__( 'Downgrade to Free', 'authorwings-membership' )
                                                : esc_html__( 'Choose This Plan', 'authorwings-membership' ); ?>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php
    }

    private function render_account_notices( ?array $mem, ?array $latest ): void {
        $notices = [];
        $notice_key = isset( $_GET['awg_notice'] ) ? sanitize_key( wp_unslash( $_GET['awg_notice'] ) ) : '';
        $payment    = isset( $_GET['payment'] ) ? sanitize_key( wp_unslash( $_GET['payment'] ) ) : '';
        $cancelled  = isset( $_GET['cancelled'] ) ? sanitize_key( wp_unslash( $_GET['cancelled'] ) ) : '';

        if ( $notice_key === 'plan-updated' ) {
            $notices[] = [ 'success', __( 'Your plan was updated successfully.', 'authorwings-membership' ) ];
        }

        if ( $notice_key === 'cancelled' ) {
            $notices[] = [ 'success', __( 'Your paid membership was cancelled and your account is now on the free plan.', 'authorwings-membership' ) ];
        }

        if ( $payment === 'success' ) {
            if ( $mem && ! empty( $mem['status'] ) && in_array( $mem['status'], [ 'active', 'trialing' ], true ) ) {
                $notices[] = [ 'success', __( 'Payment completed and your membership is active.', 'authorwings-membership' ) ];
            } else {
                $notices[] = [ 'info', __( 'Payment completed. Your membership update may take a moment to appear after Stripe confirms the subscription.', 'authorwings-membership' ) ];
            }
        }

        if ( $cancelled === '1' ) {
            $notices[] = [ 'warning', __( 'Checkout was cancelled. No changes were made to your membership.', 'authorwings-membership' ) ];
        }

        if ( ! $mem && $latest && ! empty( $latest['status'] ) ) {
            if ( $latest['status'] === 'payment_failed' ) {
                $notices[] = [ 'error', __( 'Your last payment failed, so paid access is no longer active. Please choose a plan again to restart billing.', 'authorwings-membership' ) ];
            } elseif ( $latest['status'] === 'expired' ) {
                $notices[] = [ 'warning', __( 'Your previous paid plan expired. You can renew or choose another plan below.', 'authorwings-membership' ) ];
            }
        }

        foreach ( $notices as $notice ) {
            list( $type, $message ) = $notice;
            echo '<div class="awg-mem-alert awg-mem-alert--' . esc_attr( $type ) . '">' . esc_html( $message ) . '</div>';
        }
    }

    private function render_login_prompt(): string {
        ob_start();
        ?>
        <div class="awg-mem-login-prompt">
            <span class="dashicons dashicons-lock"></span>
            <h2><?php esc_html_e( 'Please log in to access your dashboard', 'authorwings-membership' ); ?></h2>
            <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="awg-mem-btn awg-mem-btn--primary">
                <?php esc_html_e( 'Log In', 'authorwings-membership' ); ?>
            </a>
            <p>
                <?php esc_html_e( 'Don\'t have an account?', 'authorwings-membership' ); ?>
                <a href="<?php echo esc_url( wp_registration_url() ); ?>">
                    <?php esc_html_e( 'Register free', 'authorwings-membership' ); ?>
                </a>
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

    // -------------------------------------------------------
    // AJAX handlers
    // -------------------------------------------------------

    /**
     * AJAX: render the [awg_generator id="X"] shortcode server-side
     * and return the HTML so the tool modal can display it.
     *
     * Also signals the AI plugin's Assets class to enqueue its
     * front-end scripts/styles on this request via the
     * awg_aig_enqueue_assets filter (picked up by wp_footer).
     */
    public function ajax_get_tool_html(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }

        $template_id = (int) ( $_POST['template_id'] ?? 0 );
        if ( $template_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Invalid tool.', 'authorwings-membership' ) ], 400 );
        }

        // Verify the template exists and is an AI plugin template
        $post = get_post( $template_id );
        if ( ! $post || $post->post_type !== 'awg_ai_template' || $post->post_status !== 'publish' ) {
            wp_send_json_error( [ 'message' => __( 'Tool not found.', 'authorwings-membership' ) ], 404 );
        }

        // Standardized visibility check via the AI plugin filter hook
        $user_id   = get_current_user_id();
        $required_plan = get_post_meta( $template_id, '_awg_mem_required_plan', true ) ?: 'free';
        $visible   = apply_filters( 'awg_aig_visible_templates', [ $post ], $user_id );

        if ( empty( $visible ) ) {
            wp_send_json_error( [
                'message' => sprintf(
                    __( 'This tool is locked for your current membership. It requires the %s plan or higher.', 'authorwings-membership' ),
                    ucfirst( $required_plan )
                ),
                'upgrade_url' => URLs::upgrade( $required_plan !== 'free' ? $required_plan : 'basic' ),
                'upgrade_label' => __( 'Upgrade your plan', 'authorwings-membership' ),
            ], 403 );
        }

        // Render shortcode — the AI plugin's Renderer::shortcode() handles this
        $html = do_shortcode( '[awg_generator id="' . $template_id . '"]' );

        if ( empty( trim( $html ) ) ) {
            wp_send_json_error( [ 'message' => __( 'Could not render tool. Is the AuthorWings AI plugin active?', 'authorwings-membership' ) ] );
        }

        // Return the rendered HTML plus any inline scripts the AI plugin needs
        // front.js is already enqueued on the page (via awg_aig_enqueue_assets filter
        // in class-assets.php), so we only need to return the form HTML.
        wp_send_json_success( [
            'html'        => $html,
            'template_id' => $template_id,
            'title'       => get_the_title( $template_id ),
        ] );
    }

    public function ajax_get_data(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 401 );
        }
        $user_id  = get_current_user_id();
        $limits   = $this->memberships->get_user_limits( $user_id );
        $usage    = $this->usage->get_all_for_user( $user_id );
        $plan     = $this->memberships->get_user_plan_slug( $user_id );
        wp_send_json_success( compact( 'limits', 'usage', 'plan' ) );
    }

    public function ajax_get_history(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 401 );
        }

        $user_id  = get_current_user_id();
        $page     = max( 1, (int) ( $_POST['page'] ?? 1 ) );
        $history  = $this->get_history_page( $user_id, $page, 12 );

        ob_start();
        $this->render_history_items( $history['items'] );
        $html = ob_get_clean();

        wp_send_json_success( [
            'html'     => $html,
            'items'    => $history['items'],
            'page'     => $history['page'],
            'has_more' => $history['has_more'],
            'total'    => $history['total'],
        ] );
    }

    // -------------------------------------------------------
    // Helpers
    // -------------------------------------------------------

    /**
     * Fetch all published AI templates from the database and normalise them
     * into the shape render_tools_panel() expects.
     *
     * Reads from the awg_ai_template CPT (AuthorWings AI plugin).
     * Required plan stored as _awg_mem_required_plan post meta (set in AI plugin
     * template editor when membership plugin is active).
     * Category stored as _awg_mem_category post meta (optional — defaults to "AI Tools").
     */
    private function get_tool_definitions(): array {
        // AI plugin CPT must be registered
        if ( ! post_type_exists( 'awg_ai_template' ) ) {
            return [];
        }

        $posts = get_posts( [
            'post_type'      => 'awg_ai_template',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
            'no_found_rows'  => true,
        ] );

        if ( empty( $posts ) ) {
            return [];
        }

        $tools = [];

        foreach ( $posts as $post ) {
            // Read the AI plugin meta blob (_awg_aig_template stores all settings)
            $meta = get_post_meta( $post->ID, '_awg_aig_template', true );
            if ( ! is_array( $meta ) ) {
                $meta = [];
            }

            // Required plan — set via the "Required Membership Plan" field
            // in the AI plugin template editor (added in v5.2.0).
            // Defaults to free so templates without the field are visible to all.
            $required_plan = get_post_meta( $post->ID, '_awg_mem_required_plan', true );
            if ( ! in_array( $required_plan, [ 'free', 'basic', 'pro', 'publisher' ], true ) ) {
                $required_plan = 'free';
            }

            // Name: use the template's form_title, fall back to WordPress post title
            $name = trim( (string) ( $meta['form_title'] ?? '' ) );
            if ( $name === '' ) {
                $name = get_the_title( $post->ID );
            }

            // Description: form_description from the template meta
            $description = trim( (string) ( $meta['form_description'] ?? '' ) );

            // Icon: title_icon_class set in template editor, defaults to lightbulb
            $icon = trim( (string) ( $meta['title_icon_class'] ?? '' ) );
            if ( $icon === '' ) {
                $icon = 'dashicons-lightbulb';
            }

            // Category: optional _awg_mem_category meta for grouping in dashboard.
            // Set it directly in wp-admin via Quick Edit or a custom field.
            // If empty, all templates appear under a single "AI Tools" group.
            $category = trim( (string) get_post_meta( $post->ID, '_awg_mem_category', true ) );
            if ( $category === '' ) {
                $category = __( 'AI Tools', 'authorwings-membership' );
            }

            $tools[] = [
                'template_id' => $post->ID,
                'name'        => $name,
                'description' => $description,
                'icon'        => $icon,
                'plan'        => $required_plan,
                'category'    => $category,
            ];
        }

        return $tools;
    }


    public function ajax_update_profile(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Unauthorized.', 'authorwings-membership' ) ], 401 );
        }

        $user_id      = get_current_user_id();
        $first_name   = sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) );
        $last_name    = sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) );
        $display_name = sanitize_text_field( wp_unslash( $_POST['display_name'] ?? '' ) );
        $user_email   = sanitize_email( wp_unslash( $_POST['user_email'] ?? '' ) );
        $password         = (string) wp_unslash( $_POST['password'] ?? '' );
        $confirm          = (string) wp_unslash( $_POST['password_confirm'] ?? '' );
        $current_password = (string) wp_unslash( $_POST['current_password'] ?? '' );

        if ( $display_name === '' ) {
            wp_send_json_error( [ 'message' => __( 'Display name is required.', 'authorwings-membership' ) ], 400 );
        }

        if ( ! is_email( $user_email ) ) {
            wp_send_json_error( [ 'message' => __( 'Please enter a valid email address.', 'authorwings-membership' ) ], 400 );
        }

        $existing = email_exists( $user_email );
        if ( $existing && (int) $existing !== (int) $user_id ) {
            wp_send_json_error( [ 'message' => __( 'That email address is already in use.', 'authorwings-membership' ) ], 400 );
        }

        if ( $password !== '' && $password !== $confirm ) {
            wp_send_json_error( [ 'message' => __( 'Passwords do not match.', 'authorwings-membership' ) ], 400 );
        }

        // Require current password verification before allowing a password change.
        // Prevents stolen-session / XSS attacks from silently taking over the account.
        if ( $password !== '' ) {
            if ( $current_password === '' ) {
                wp_send_json_error( [ 'message' => __( 'Please enter your current password to change it.', 'authorwings-membership' ) ], 400 );
            }

            if ( strlen( $password ) < 8 ) {
                wp_send_json_error( [ 'message' => __( 'New password must be at least 8 characters long.', 'authorwings-membership' ) ], 400 );
            }

            $current_user = get_userdata( $user_id );
            if ( ! $current_user || ! wp_check_password( $current_password, $current_user->user_pass, $user_id ) ) {
                wp_send_json_error( [ 'message' => __( 'Current password is incorrect.', 'authorwings-membership' ) ], 403 );
            }
        }

        $userdata = [
            'ID'           => $user_id,
            'display_name' => $display_name,
            'user_email'   => $user_email,
            'first_name'   => $first_name,
            'last_name'    => $last_name,
        ];

        if ( $password !== '' ) {
            $userdata['user_pass'] = $password;
        }

        $result = wp_update_user( $userdata );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
        }

        update_user_meta( $user_id, 'first_name', $first_name );
        update_user_meta( $user_id, 'last_name', $last_name );

        wp_send_json_success( [
            'message' => __( 'Profile updated successfully.', 'authorwings-membership' ),
            'user'    => [
                'display_name' => $display_name,
                'user_email'   => $user_email,
                'first_name'   => $first_name,
                'last_name'    => $last_name,
            ],
        ] );
    }

    /**
     * Return true only if the given user is an AuthorWings member (free/basic/
     * pro/publisher) AND has no other WordPress role that would normally need
     * /wp-admin/ access (author, editor, contributor, shop manager, etc.).
     *
     * Without this check, *any* logged-in non-admin (including legitimate
     * editors) gets bounced out of /wp-admin/, which breaks editorial teams
     * and WooCommerce shop staff.
     */
    private function is_awg_member_only( int $user_id ): bool {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return false;
        }
        $awg_roles = [ Roles::FREE, Roles::BASIC, Roles::PRO, Roles::PUBLISHER ];
        $user_roles = (array) $user->roles;
        $has_awg = (bool) array_intersect( $awg_roles, $user_roles );
        if ( ! $has_awg ) {
            return false;
        }
        // If they ALSO have any non-AWG role, let them into wp-admin normally.
        $non_awg = array_diff( $user_roles, $awg_roles );
        return empty( $non_awg );
    }

    public function block_non_admin_dashboard_access(): void {
        if ( ! is_user_logged_in() ) {
            return;
        }

        if ( wp_doing_ajax() ) {
            return;
        }

        if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
            return;
        }

        if ( current_user_can( 'manage_options' ) ) {
            return;
        }

        // Only redirect users whose ONLY role is an AuthorWings membership
        // role. Authors, editors, contributors, shop managers etc. keep
        // their normal access to /wp-admin/.
        if ( ! $this->is_awg_member_only( get_current_user_id() ) ) {
            return;
        }

        if ( is_admin() ) {
            wp_safe_redirect( URLs::dashboard() );
            exit;
        }
    }

    public function maybe_hide_admin_bar(): void {
        if ( ! is_user_logged_in() ) {
            return;
        }
        if ( current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( $this->is_awg_member_only( get_current_user_id() ) ) {
            show_admin_bar( false );
        }
    }

}
