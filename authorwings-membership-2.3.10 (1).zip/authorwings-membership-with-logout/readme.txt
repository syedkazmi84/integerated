=== AuthorWings Membership ===
Author: AuthorWings
Author URI: https://authorwings.com
Requires at least: 6.0
Requires PHP: 7.4
Version: 2.3.10
License: GPLv2 or later

== Description ==
Membership plans, user dashboard, usage gating, and publishing services for AuthorWings.com.

Works alongside the AuthorWings AI plugin (v5.7.0+) to gate AI tool access per plan.

== Features ==
* 4 membership tiers: Free, Basic, Pro, Publisher
* Monthly AI generation limits per plan
* User dashboard with tabs: Home, AI Tools, Services, History, Account
* Professional services listing with quote request form
* Admin panel: member management, orders, plan settings, release self-tests
* Stripe-ready payment integration and webhook handling
* Automatic email notifications
* Pricing page shortcode: [awg_pricing]
* Dashboard shortcode: [awg_dashboard]

== Release Testing ==
A new admin page is included under AW Members → Release Tests.
It runs automated self-tests for:
- usage counting
- membership gate decisions
- history query logic
- plan role mapping

Use RELEASE-CHECKLIST.md and MIGRATION-CHECKLIST.md in this plugin folder for the full pre-release and upgrade process.

== Changelog ==
= 2.3.10 =
* Account tab redesigned. Six cards collapsed to three: Current Plan (full-width), Profile, and Team Workspace (side-by-side). Removed Billing Health, Seat Usage, and Plan & Billing cards because every fact they showed already appeared in Current Plan. Removed standalone Workspace Usage card; the breakdown is now an expandable section inside Team Workspace for Publisher owners.
* Edit Profile button now matches primary button styling instead of a purple link, removing the second accent colour from the page.
* Removed the developer-facing helper text ("Plan cards now live in a dedicated modal so billing choices stay separate...") that was visible to end users.

= 2.3.9 =
* Dashboard and pricing page now follow the user's OS dark-mode preference automatically. Themes can force light or dark via the `awg_mem_dashboard_theme` filter.
* Honors prefers-reduced-motion across all dashboard transitions and animations.
* Tool modal now shows a content-shaped skeleton while loading instead of a generic spinner.
* Pricing page gained a side-by-side feature comparison table beneath the plan cards. Driven by the plans' limits and feature data — no extra configuration needed.
* Removed the artificial 330ms delay on the monthly/yearly billing toggle. Price now swaps instantly.

= 2.3.8 =
* Pricing page and dashboard plan grid now respect each plan's currency setting (USD/EUR/GBP/INR/JPY/etc.) instead of always showing $.
* Performance: AI generation gate check no longer rebuilds the usage counter from logs on every request. A new daily cron (awg_mem_daily_rebuild_usage) reconciles any drift within 24h instead. Removes two DB queries from every generation.
* /wp-admin/ redirect now only applies to users whose ONLY role is an AuthorWings membership role. Authors, editors, contributors, shop managers, and other non-admin staff keep their normal admin access.

= 2.3.7 =
* Removed '0000-00-00 00:00:00' DATETIME defaults from all six plugin tables. Strict MySQL 5.7+ / MySQL 8.0 with NO_ZERO_DATE rejects these as invalid defaults, which could silently fail table creation on strict hosts. Existing data is preserved; dbDelta migrates the column definitions on activation. All write paths in the codebase already supply explicit timestamps so no behaviour changes.

= 2.3.6 =
* Hardened admin "Assign Plan" AJAX endpoint. Billing cycle is now whitelisted against monthly / yearly / free, and the user_id and plan_id are validated against existing records before any membership row is touched.

= 2.3.5 =
* set_user_plan() now wraps the cancel-old-then-insert-new sequence in a database transaction. If the INSERT fails, the previous active membership is rolled back and the user is no longer left with zero active plans. Falls back to the previous behaviour on non-InnoDB engines.

= 2.3.4 =
* Stripe webhook now dedupes events by event ID using a 24-hour transient. Prevents duplicate processing when Stripe retries delivery of the same event (e.g. checkout.session.completed firing twice and re-activating a membership).

= 2.3.3 =
* Hardened the daily expiry check query to use $wpdb->prepare() with placeholders instead of interpolated values. Resolves a Plugin Check / WPCS warning and aligns with WordPress.org coding standards.

= 2.3.2 =
* Security: Account → password change now requires the user's current password before allowing a new password to be saved. Closes a session-hijacking takeover path.
* Added an 8-character minimum length check on new passwords.

= 2.3.1 =
* Phase 8 completed: dashboard tab ARIA wiring, keyboard tab navigation, accessible usage donut labels, team invite field label, live-region status messages, and stronger focus visibility.

= 2.2.4 =
* Phase 1 audit and safe refactor setup
* Added architecture and UI touchpoint audit docs
* Added additive helper scaffolds for future JS and CSS work
* Kept runtime behavior unchanged in this phase

= 2.1.0 =
* Phase 10 release preparation update
* Added admin self-test runner for key membership logic
* Added release and migration checklists
* Updated versioning and packaging metadata

= 2.0.0 =
* Phase 9 UX and content polish update
* Improved dashboard polish, locked-tool prompts, services request flow, and HTML emails

== Shortcodes ==
[awg_dashboard]  — Full user dashboard (put on /member-dashboard/ page)
[awg_pricing]    — Pricing comparison table (put on /pricing/ page)
