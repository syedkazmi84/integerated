# Changelog 2.3.8 — Three usability / performance fixes

## Fixed

### Currency on pricing & dashboard
The `[awg_pricing]` shortcode and the dashboard's plan-grid both ignored the `currency` field on each plan and hardcoded `$`. Admins setting a plan to EUR / GBP / INR / etc. still saw USD on the front-end.

A new `Plans::currency_symbol()` helper maps ISO codes (USD, EUR, GBP, INR, JPY, CAD, AUD, PKR, AED, SAR, BRL, ZAR, MXN, SGD, HKD, KRW, TRY, RUB, PLN, NZD, CHF, SEK, NOK, DKK, CNY) to the right glyph. Unknown codes fall back to the code itself with a trailing space (e.g. `XYZ 19/month`).

The dashboard JS reads the symbol from a new `data-currency-symbol` attribute on each plan card, so the billing-toggle animation also displays the correct symbol.

### Usage gate-check no longer rebuilds counters on every request
`Usage::can_use()` was calling `maybe_rebuild_current_period_totals()` on every AI generation, which fired a `SUM` query plus an `INSERT ... ON DUPLICATE KEY UPDATE` against the usage table. On a busy site that's two extra DB roundtrips per generation — and the logic was a self-heal hack masking deeper concerns about counter drift.

The fix:
- `can_use()` now reads the cached counter directly. The counter is already kept in sync atomically by `increment()`, so this is correct in the normal case.
- A new daily cron `awg_mem_daily_rebuild_usage` (registered in `Plugin::boot_modules()`) calls `Usage::rebuild_all_current_period_totals()` once per day. Any drift from a partial upgrade or manual DB edit self-heals within 24 hours.
- The cron is unscheduled on plugin deactivation.

### /wp-admin/ redirect no longer locks out authors and editors
`block_non_admin_dashboard_access()` redirected *every* logged-in user without `manage_options` away from `/wp-admin/`. That meant authors, editors, contributors, shop managers, and any other non-admin staff were bounced out of the WordPress admin entirely.

A new `is_awg_member_only()` helper checks the user's roles. The redirect (and the `show_admin_bar(false)` call) only fires when the user's *only* role is an AWG membership role (`awg_free_member` / `awg_basic_member` / `awg_pro_member` / `awg_publisher`). Users with mixed roles — common on multi-author sites — keep their normal access.

## Files touched
- `includes/class-plans.php` — new `currency_symbol()` helper, pricing render uses it
- `includes/class-dashboard.php` — plan grid uses currency symbol; new `is_awg_member_only()` helper; `block_non_admin_dashboard_access()` and `maybe_hide_admin_bar()` tightened
- `includes/class-usage.php` — `can_use()` no longer rebuilds; new `rebuild_all_current_period_totals()` cron target
- `includes/class-plugin.php` — new daily cron `awg_mem_daily_rebuild_usage`, registered + unscheduled on deactivation
- `assets/js/dashboard.js` — billing-toggle animation reads `data-currency-symbol`
- `authorwings-membership.php` — version bump 2.3.7 → 2.3.8
- `readme.txt` — version + changelog entry
