# Changelog 2.3.10 — Account tab cleanup

## Removed three duplicate cards
The Account tab previously rendered six cards (Current Plan, Billing Health, Seat Usage, Plan & Billing, Team Workspace, Workspace Usage, Profile). Three of them were pure repetition:

- **Billing Health** said "Billing active" + "No renewal scheduled" — both already present in Current Plan.
- **Seat Usage** said "No team seats on this plan" — already shown in Team Workspace.
- **Plan & Billing** showed Billing period, Renewal status, Current access — all three already in Current Plan.
- **Workspace Usage** showed AI usage, renewal state, seat summary — all three already in Current Plan and Team Workspace.

Workspace usage breakdown (per-member runs this month) was the only unique data on the Workspace Usage card. It's been preserved as an expandable `<details>` section inside the Team Workspace card for Publisher owners.

## New layout
Three cards across two rows:

```
┌─────────────────────────────────────────────────────────┐
│  CURRENT PLAN                          [ Change Plan ]  │
│  Free · Active                                          │
│  Usage limit · Used this month · Renewal date           │
└─────────────────────────────────────────────────────────┘

┌──────────────────────────┬──────────────────────────────┐
│  PROFILE                 │  TEAM WORKSPACE              │
│  Name / Email / Joined   │  No team seats on this plan  │
│  [ Edit Profile ]        │  [ Upgrade to Publisher ]    │
└──────────────────────────┴──────────────────────────────┘
```

Equal-height cards in row 2, with primary buttons aligned at the bottom so the visual weight matches.

## Visual fixes
- **Edit Profile** is now a normal primary button (rectangular, blue) instead of the purple-link "Edit profile →" pill. The Account tab now uses one accent color throughout.
- For free / non-team users, Team Workspace shows an actual "Upgrade to Publisher" CTA pointing at the pricing page instead of just a paragraph.
- Dropped the helper text "Plan cards now live in a dedicated modal so billing choices stay separate from team and profile settings" — it was developer-facing and shouldn't have been on the user-facing page.
- Mobile breakpoint at 768px collapses the 2-column row to 1-column.

## Files touched
- `includes/class-dashboard.php` — `render_account_panel()` body
- `assets/css/dashboard.css` — `.awg-mem-account-overview--simplified` and `.awg-mem-account-sections--two-col` rules appended
- `authorwings-membership.php` — version bump 2.3.9 → 2.3.10
- `readme.txt` — version + changelog entry
