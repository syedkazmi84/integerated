# Changelog 2.3.3 — Coding standards / Plugin Check

## Fixed
- `Memberships::check_expiries()` rebuilt to use `$wpdb->prepare()` with placeholders instead of interpolating the timestamp directly into the SQL string. The previous query was not exploitable in practice (the value came from `current_time('mysql')`, server-generated), but it tripped Plugin Check / WPCS scanners and would block a WordPress.org review.

## Files touched
- `includes/class-memberships.php` — `check_expiries()`
- `authorwings-membership.php` — version bump 2.3.2 → 2.3.3
- `readme.txt` — version + changelog entry
