# Changelog 2.3.5 — Atomic plan changes

## Fixed
- `Memberships::set_user_plan()` now wraps the "cancel old + insert new" sequence in a database transaction. Previously, if the INSERT failed (deadlock, unique constraint, validation error, connection drop), the user was left with **zero** active memberships because the cancel had already committed. This was particularly bad during a Stripe webhook retry storm.

## How it works
- Before mutating the table the method calls `table_supports_transactions()` (cached for the request) which checks `information_schema.TABLES` for the engine.
- On InnoDB it issues `START TRANSACTION` → UPDATE → INSERT → either `COMMIT` or `ROLLBACK` based on the insert result.
- On non-transactional engines (legacy MyISAM hosts) it falls back to the previous unguarded behaviour rather than silently doing nothing.
- Side effects that touch other tables (role assignment, team-seat sync, the `awg_mem_plan_changed` action) run **after** commit, so a transaction rollback no longer leaves the user's WordPress role out of sync with the cancel.

## Logging
- A failed INSERT now logs `set_user_plan_insert_failed` with the user_id, plan_id, billing, and the underlying `$wpdb->last_error` so the cause of any rollback is visible in the error log.

## Files touched
- `includes/class-memberships.php` — `set_user_plan()` plus a new `table_supports_transactions()` helper
- `authorwings-membership.php` — version bump 2.3.4 → 2.3.5
- `readme.txt` — version + changelog entry
