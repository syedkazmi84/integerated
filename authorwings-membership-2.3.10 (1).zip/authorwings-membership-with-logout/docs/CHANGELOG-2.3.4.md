# Changelog 2.3.4 — Stripe webhook idempotency

## Fixed
- Stripe webhook handler now dedupes incoming events by their event ID. Stripe retries delivery if the receiver returns a non-2xx response or if the network ack is lost — without idempotency, the same `checkout.session.completed` could be processed twice and re-activate / re-set a membership.

## How it works
- After signature verification and JSON parsing, the handler checks for a transient keyed on the event ID (`awg_mem_stripe_evt_<md5>`).
- If found, the duplicate is logged and the handler returns a 200 with `{ received: true, duplicate: true }` so Stripe stops retrying.
- Otherwise the transient is set for 24h (`DAY_IN_SECONDS`) BEFORE the event is processed, which closes the race window between two concurrent retry attempts.

## Files touched
- `includes/class-memberships.php` — `rest_webhook()`
- `authorwings-membership.php` — version bump 2.3.3 → 2.3.4
- `readme.txt` — version + changelog entry
