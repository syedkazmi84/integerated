# Changelog 2.3.6 — Admin "Assign Plan" input hardening

## Fixed
- `Admin::ajax_assign_plan()` no longer trusts the `billing` value from `$_POST` blindly. Billing is now whitelisted against `monthly` / `yearly` / `free`. An out-of-range value returns 400 instead of being passed through to `set_user_plan()` and ending up in the DB as a custom string.
- All inputs run through `wp_unslash()` before sanitisation.
- Added existence checks: the target `user_id` must resolve to a real WP user, and the target `plan_id` must be present and active in the plans table. Mismatches now return 404 instead of silently mutating membership rows.

## Notes
- The endpoint was already nonce-protected and `manage_options`-gated, so this is defence-in-depth rather than a remote vulnerability fix. The realistic risk was data-integrity (custom billing strings landing in the DB and breaking downstream renewal date math, or assigning a deleted plan).

## Files touched
- `includes/class-admin.php` — `ajax_assign_plan()`
- `authorwings-membership.php` — version bump 2.3.5 → 2.3.6
- `readme.txt` — version + changelog entry
