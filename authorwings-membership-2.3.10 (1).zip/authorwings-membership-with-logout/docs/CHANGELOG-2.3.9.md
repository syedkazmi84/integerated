# Changelog 2.3.9 — UI polish

Four front-end design improvements rolled together.

## Dark mode + reduced motion
- Dashboard and pricing page now follow `prefers-color-scheme: dark`. All colors come from the existing `--awg-*` tokens, so the change is purely additive (no rules touch component colors directly).
- A `[data-awg-theme="dark"]` / `[data-awg-theme="light"]` attribute on the dashboard root forces a specific theme regardless of OS preference.
- New filter `awg_mem_dashboard_theme` returns `'auto'` (default), `'light'`, or `'dark'`. Themes can hook this to lock the look-and-feel of their site.
- All dashboard and pricing transitions/animations respect `prefers-reduced-motion: reduce` — single global rule.

## Skeleton loader in tool modal
- Replaced the generic spinner with a content-shaped skeleton: title bar, two field labels, two input rectangles, and a button. Matches the actual generator form layout so the perceived load feels instant.
- Skeleton respects reduced-motion (no shimmer animation).
- Skeleton has correct dark-mode tints.

## Pricing comparison table
- New section beneath the pricing cards: side-by-side feature comparison across all plans.
- Driven by `Plans::get_comparison_rows()` which fuses three sources: each plan's `limits` (AI generations, team seats, tools access tier) and the union of all `features` strings. "Everything in X" inheritance is resolved automatically — a Basic feature shows ✓ on Pro and Publisher.
- Sticky header on scroll, horizontal scrolling on mobile, "Most Popular" column highlighted.
- Renders nothing if fewer than 2 plans exist (degrades gracefully on single-plan setups).

## Instant price toggle
- Removed the 110ms delay + 220ms class-flash on monthly/yearly toggle. Price now swaps instantly. The previous animation was long enough to feel like lag on a binary action.

## Files touched
- `assets/css/dashboard.css` — added ~225 lines: dark-mode tokens, reduced-motion guard, skeleton, comparison table styling
- `assets/js/dashboard.js` — skeleton template in `requestToolHtml`, removed setTimeout chain in `applyBillingState`
- `includes/class-plans.php` — `render_comparison_table()` + `get_comparison_rows()` methods
- `includes/class-dashboard.php` — `awg_mem_dashboard_theme` filter, `data-awg-theme` attribute on root
- `authorwings-membership.php` — version bump 2.3.8 → 2.3.9
- `readme.txt` — version + changelog entry
