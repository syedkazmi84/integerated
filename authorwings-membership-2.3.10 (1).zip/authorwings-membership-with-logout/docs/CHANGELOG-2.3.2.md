# Changelog 2.3.2 — Security update

## Fixed
- Account profile form: password change now requires the current password before a new password can be saved. Without this, anyone who briefly gained access to a logged-in session (stolen cookie, XSS, shared computer left unlocked) could silently lock the rightful owner out of their account.

## Added
- 8-character minimum length on new passwords.
- New "Current Password" field on the Account tab profile form (only required when changing the password — leave blank otherwise).

## Files touched
- `includes/class-dashboard.php` — `ajax_update_profile()` plus the profile form markup
- `authorwings-membership.php` — version bump 2.3.1 → 2.3.2
- `readme.txt` — version + changelog entry
