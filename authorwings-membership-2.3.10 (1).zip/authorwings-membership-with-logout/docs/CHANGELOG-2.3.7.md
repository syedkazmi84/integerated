# Changelog 2.3.7 — DB schema strict-MySQL compatibility

## Fixed
- Removed `DEFAULT '0000-00-00 00:00:00'` from every DATETIME column across all six tables: `awg_mem_plans`, `awg_mem_memberships`, `awg_mem_usage`, `awg_mem_usage_logs`, `awg_mem_service_orders`, `awg_mem_team_seats`. Strict MySQL 5.7+ and MySQL 8.0 with the default `NO_ZERO_DATE` SQL mode reject these as `Invalid default value`, which could cause `dbDelta` to silently fail on strict hosts (no tables created → fatal errors throughout the plugin).

## What was kept
- `DEFAULT ''` on TEXT/LONGTEXT columns is intentionally retained. dbDelta and the WordPress codebase tolerate these defaults across all supported MySQL versions, and removing them would require updating every `wpdb->insert()` call to pass empty strings explicitly. The real bug was the zero-dates.

## Migration
- `Plugin::boot_modules()` already re-runs `Database::create_tables()` whenever `awg_mem_db_version` ≠ `AWG_MEM_VERSION`. Bumping the constant triggers `dbDelta` to ALTER the existing tables on next admin page load. Existing rows with zero-dates in `created_at` are preserved untouched — only the column metadata changes.

## Verified write paths (all supply timestamps explicitly)
- `Plans::seed_defaults()` and `Plans::save()` → set `created_at`
- `Memberships::set_user_plan()` → sets `start_date`, `created_at`, `updated_at`
- `Memberships::invite_team_member()` → sets `created_at`, `updated_at`
- `Usage::log_usage()` → sets `created_at`
- `Services::ajax_submit_order()` → sets `created_at`, `updated_at`

## Files touched
- `includes/class-database.php` — all six `CREATE TABLE` statements
- `authorwings-membership.php` — version bump 2.3.6 → 2.3.7
- `readme.txt` — version + changelog entry
