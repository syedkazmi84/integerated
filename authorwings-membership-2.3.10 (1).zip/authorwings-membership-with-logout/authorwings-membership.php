<?php
/**
 * Plugin Name: AuthorWings Membership
 * Description: Membership plans, user dashboard, usage gating, and publishing services for AuthorWings.com.
 * Version: 2.3.10
 * Author: AuthorWings
 * Author URI: https://authorwings.com
 * License: GPLv2 or later
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: authorwings-membership
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'AWG_MEM_VERSION', '2.3.10' );
define( 'AWG_MEM_FILE',    __FILE__ );
define( 'AWG_MEM_PATH',    plugin_dir_path( __FILE__ ) );
define( 'AWG_MEM_URL',     plugin_dir_url( __FILE__ ) );

require_once AWG_MEM_PATH . 'includes/class-plugin.php';

register_activation_hook( AWG_MEM_FILE,   [ '\\AWG_MEM\\Plugin', 'activate' ] );
register_deactivation_hook( AWG_MEM_FILE, [ '\\AWG_MEM\\Plugin', 'deactivate' ] );

add_action( 'plugins_loaded', function () {
    \AWG_MEM\Plugin::instance();
} );
