(function($){
  function getStoredGclid() {
    const params = new URLSearchParams(window.location.search);
    const gclid = params.get('gclid');
    if (gclid) {
      try {
        sessionStorage.setItem('awg_aig_gclid', gclid);
      } catch (e) {}
      return gclid;
    }
    try {
      return sessionStorage.getItem('awg_aig_gclid') || '';
    } catch (e) {
      return '';
    }
  }

  function applyGclid($wrap) {
    const gclid = getStoredGclid();
    if (!gclid) return;
    const $field = $wrap.find('input[name="gclid"]');
    if ($field.length) {
      $field.val(gclid);
    }
  }

  function normalizeName(name){
    return (name || '').replace(/\[\]$/, '');
  }

  function collect($wrap){
    const fields = {};
    $wrap.find('.awg-aig__input, .awg-aig__choice').each(function(){
      const $el = $(this);
      const rawName = $el.attr('name');
      if (!rawName) return;

      const name = normalizeName(rawName);
      const type = (($el.attr('type') || '').toLowerCase());

      if (type === 'checkbox') {
        if (rawName.slice(-2) === '[]') {
          if (!Array.isArray(fields[name])) fields[name] = [];
          if ($el.is(':checked')) fields[name].push($el.val() || '1');
          return;
        }
        fields[name] = $el.is(':checked') ? ($el.val() || '1') : '';
        return;
      }

      if (type === 'radio') {
        if ($el.is(':checked')) {
          fields[name] = $el.val();
        } else if (typeof fields[name] === 'undefined') {
          fields[name] = '';
        }
        return;
      }

      fields[name] = $el.val();
    });
    return fields;
  }

  function status($wrap, msg, err, link){
    const $s = $wrap.find('.awg-aig__status');
    $s.empty();

    const message = String(msg || '');
    if (message) {
      $s.append(document.createTextNode(message));
    }

    if (link && link.url) {
      const anchor = document.createElement('a');
      anchor.href = String(link.url);
      anchor.textContent = String(link.label || 'Upgrade your plan');
      anchor.className = 'awg-aig__status-link';
      anchor.rel = 'noopener noreferrer';
      if (message) {
        $s.append(document.createTextNode(' '));
      }
      $s.append(anchor);
    }

    $s.toggleClass('is-error', !!err);
  }

  function escapeHtml(value){
    return String(value || '').replace(/[&<>"']/g, function(char){
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      }[char] || char;
    });
  }

  function applyInlineFormatting(value){
    let text = escapeHtml(value || '');
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
    text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
    return text;
  }

  function formatPlainTextResult(text){
    const lines = String(text || '').replace(/\r\n/g, '\n').split('\n');
    const parts = [];
    let paragraph = [];
    let listItems = [];
    let listType = '';

    function flushParagraph(){
      if (!paragraph.length) return;
      parts.push('<p>' + applyInlineFormatting(paragraph.join(' ')) + '</p>');
      paragraph = [];
    }

    function flushList(){
      if (!listItems.length || !listType) return;
      const isOrdered = listType === 'ol';
      parts.push('<div class="awg-aig__result-list awg-aig__result-list--' + (isOrdered ? 'ordered' : 'unordered') + '">' + listItems.map(function(item, index){
        return '<div class="awg-aig__result-item">' +
          '<div class="awg-aig__result-badge">' + (isOrdered ? (index + 1) : '•') + '</div>' +
          '<div class="awg-aig__result-item-content">' + applyInlineFormatting(item) + '</div>' +
        '</div>';
      }).join('') + '</div>');
      listItems = [];
      listType = '';
    }

    lines.forEach(function(rawLine){
      const line = String(rawLine || '').trim();

      if (!line) {
        flushParagraph();
        flushList();
        return;
      }

      const headingMatch = line.match(/^(#{2,4})\s+(.+)$/);
      if (headingMatch) {
        flushParagraph();
        flushList();
        const level = Math.min(4, headingMatch[1].length);
        parts.push('<h' + level + '>' + applyInlineFormatting(headingMatch[2]) + '</h' + level + '>');
        return;
      }

      if (/^[-*_]{3,}$/.test(line)) {
        flushParagraph();
        flushList();
        parts.push('<hr>');
        return;
      }

      const orderedMatch = line.match(/^\d+[.)]\s+(.+)$/);
      if (orderedMatch) {
        flushParagraph();
        if (listType && listType !== 'ol') flushList();
        listType = 'ol';
        listItems.push(orderedMatch[1]);
        return;
      }

      const unorderedMatch = line.match(/^[-*•]\s+(.+)$/);
      if (unorderedMatch) {
        flushParagraph();
        if (listType && listType !== 'ul') flushList();
        listType = 'ul';
        listItems.push(unorderedMatch[1]);
        return;
      }

      flushList();
      paragraph.push(line);
    });

    flushParagraph();
    flushList();

    return parts.length ? parts.join('') : '<p>' + applyInlineFormatting(text) + '</p>';
  }


  function enhanceOutputCards($out){
    $out.find('ol, ul').each(function(){
      const $list = $(this);
      if ($list.closest('.awg-aig__result-item-content').length) return;
      if ($list.hasClass('awg-aig__result-list')) return;

      const isOrdered = $list.is('ol');
      const items = [];
      $list.children('li').each(function(index){
        const $li = $(this);
        items.push(
          '<div class="awg-aig__result-item">' +
            '<div class="awg-aig__result-badge">' + (isOrdered ? (index + 1) : '•') + '</div>' +
            '<div class="awg-aig__result-item-content">' + $li.html() + '</div>' +
          '</div>'
        );
      });

      if (!items.length) return;
      $list.replaceWith(
        '<div class="awg-aig__result-list awg-aig__result-list--' + (isOrdered ? 'ordered' : 'unordered') + '">' +
          items.join('') +
        '</div>'
      );
    });
  }

  function renderOutput($wrap, text, format){
    const $res = $wrap.find('.awg-aig__result');
    const $out = $wrap.find('.awg-aig__output');
    const safeText = String(text || '');

    $res.prop('hidden', false).removeClass('is-busy');
    $out.attr('data-format', format || 'text');
    $out.data('raw-text', safeText);
    $out.removeClass('is-formatted');

    if (format === 'html') {
      $out.html(safeText);
    } else {
      $out.html(formatPlainTextResult(safeText));
      $out.addClass('is-formatted');
    }

    enhanceOutputCards($out);

    setTimeout(function(){
      const el = $res.get(0);
      if (!el) return;
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  }


  function setButtonLoading($btn, isLoading, loadingText){
    if (!$btn || !$btn.length) return;

    const stateKey = 'awgLoadingState';
    let state = $btn.data(stateKey);

    if (isLoading) {
      if (!state) {
        const $label = $btn.find('span').last();
        const labelHtml = $label.length ? $label.html() : $btn.html();
        state = {
          disabled: $btn.prop('disabled'),
          labelHtml: labelHtml
        };
        $btn.data(stateKey, state);
      }

      $btn.prop('disabled', true).attr('aria-busy', 'true').addClass('is-loading');

      const $label = $btn.find('span').last();
      if ($label.length) {
        $label.text(loadingText || 'Loading...');
      } else {
        $btn.text(loadingText || 'Loading...');
      }
      return;
    }

    if (!state) {
      $btn.prop('disabled', false).removeAttr('aria-busy').removeClass('is-loading');
      return;
    }

    const $label = $btn.find('span').last();
    if ($label.length) {
      $label.html(state.labelHtml);
    } else {
      $btn.html(state.labelHtml);
    }

    $btn.prop('disabled', !!state.disabled);
    if (state.disabled) {
      $btn.attr('aria-busy', 'false');
    } else {
      $btn.removeAttr('aria-busy');
    }
    $btn.removeClass('is-loading').removeData(stateKey);
  }

  function clearLoadingState($wrap){
    if (!$wrap || !$wrap.length) return;
    setButtonLoading($wrap.find('.awg-aig__btn').first(), false);
    setButtonLoading($wrap.find('.awg-aig__regenerate').first(), false);
  }

  function parseResponse(raw){
    if (!raw) return null;
    if (typeof raw === 'object') return raw;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }


  function clearFieldErrors($wrap){
    $wrap.find('.awg-aig__field').removeClass('is-error');
    $wrap.find('.awg-aig__field-error').remove();
  }

  function addFieldError($field, message){
    const $group = $field.closest('.awg-aig__field');
    if (!$group.length) return;
    $group.addClass('is-error');
    $group.find('.awg-aig__field-error').remove();
    $('<div class="awg-aig__field-error" role="alert"></div>').text(message).appendTo($group);
  }

  function validateClientSide($wrap){
    clearFieldErrors($wrap);
    const missingLabels = [];
    let firstInvalid = null;

    $wrap.find('.awg-aig__field').each(function(){
      const $group = $(this);
      const $input = $group.find('.awg-aig__input, .awg-aig__choice').first();
      if (!$input.length) return;

      const isRequired = $group.find('.awg-aig__req').length > 0;
      if (!isRequired) return;

      const fieldLabel = $.trim($group.find('.awg-aig__label-text').first().text() || $group.find('.awg-aig__label').first().text() || 'This field');
      const type = String(($input.attr('type') || '').toLowerCase());
      const name = $input.attr('name') || '';
      let isValid = true;

      if (type === 'checkbox' && name.slice(-2) === '[]') {
        isValid = $group.find('input[name="' + name.replace(/(["\\])/g, '\\$1') + '"]:checked').length > 0;
      } else if (type === 'checkbox') {
        isValid = $input.is(':checked');
      } else if (type === 'radio') {
        isValid = $group.find('input[name="' + name.replace(/(["\\])/g, '\\$1') + '"]:checked').length > 0;
      } else {
        isValid = $.trim(String($input.val() || '')) !== '';
      }

      if (!isValid) {
        missingLabels.push(fieldLabel);
        addFieldError($input, fieldLabel + ' is required.');
        if (!firstInvalid) firstInvalid = $input;
      }
    });

    if (firstInvalid && firstInvalid.length) {
      firstInvalid.trigger('focus');
    }

    return {
      valid: missingLabels.length === 0,
      missing: missingLabels
    };
  }

  function setOutputLoading($wrap, message){
    const $result = $wrap.find('.awg-aig__result');
    const $output = $wrap.find('.awg-aig__output');
    $result.prop('hidden', true).addClass('is-busy');
    $output
      .attr('data-format', 'text')
      .removeClass('is-formatted')
      .html(
        '<div class="awg-aig__loading-state" aria-live="polite">' +
          '<div class="awg-aig__spinner" aria-hidden="true"></div>' +
          '<div class="awg-aig__loading-copy">' + escapeHtml(message || 'Generating your result...') + '</div>' +
        '</div>'
      );
  }

  function clearPendingOutputLoading($wrap){
    if (!$wrap || !$wrap.length) return;
    const timerId = $wrap.data('awgOutputLoadingTimer');
    if (timerId) {
      window.clearTimeout(timerId);
      $wrap.removeData('awgOutputLoadingTimer');
    }
  }

  function scheduleOutputLoading($wrap, message, delay){
    clearPendingOutputLoading($wrap);
    const timerId = window.setTimeout(function(){
      $wrap.removeData('awgOutputLoadingTimer');
      setOutputLoading($wrap, message);
    }, Math.max(0, parseInt(delay, 10) || 0));
    $wrap.data('awgOutputLoadingTimer', timerId);
  }

  function resetOutputState($wrap, keepVisible){
    clearPendingOutputLoading($wrap);
    const $result = $wrap.find('.awg-aig__result');
    const $output = $wrap.find('.awg-aig__output');
    $result
      .prop('hidden', keepVisible ? false : true)
      .removeClass('is-busy');
    $output
      .attr('data-format', 'text')
      .removeClass('is-formatted')
      .empty()
      .removeData('raw-text');
  }

  function setOutputEmpty($wrap, message){
    const $result = $wrap.find('.awg-aig__result');
    const $output = $wrap.find('.awg-aig__output');
    $result.prop('hidden', true).removeClass('is-busy');
    $output
      .attr('data-format', 'text')
      .removeClass('is-formatted')
      .html('<div class="awg-aig__empty-state">' + escapeHtml(message || 'Complete the form to see your result here.') + '</div>');
  }

  $(document).on('submit', '.awg-aig__form', function(e){
    e.preventDefault();
    const $wrap = $(this).closest('.awg-aig');
    const templateId = parseInt($wrap.data('template-id'), 10);

    if (!templateId) {
      status($wrap, 'Invalid template configuration.', true);
      return;
    }

    applyGclid($wrap);

    const validation = validateClientSide($wrap);
    if (!validation.valid) {
      status($wrap, 'Please complete: ' + validation.missing.join(', '), true);
      setOutputEmpty($wrap, 'Please complete the required fields to generate a result.');
      return;
    }

    status($wrap, 'Generating...', false);
    resetOutputState($wrap, false);
    scheduleOutputLoading($wrap, 'Generating your result...', 450);

    const $submitButton = $(this).find('.awg-aig__btn').first();
    setButtonLoading($submitButton, true, 'Generating...');

    const fields = collect($wrap);

    $.ajax({
      url: AWG_AIG.ajaxurl,
      method: 'POST',
      dataType: 'text',
      timeout: 60000,
      data: {
        action: 'awg_aig_generate',
        nonce: AWG_AIG.nonce,
        template_id: templateId,
        fields: fields,
        fields_json: JSON.stringify(fields)
      }
    })
    .done(function(raw){
      const res = parseResponse(raw);
      if (!res || !res.success) {
        resetOutputState($wrap, false);
        clearLoadingState($wrap);
        status(
          $wrap,
          (res && res.data && res.data.message) ? res.data.message : 'Error',
          true,
          (res && res.data && res.data.upgrade_url) ? {
            url: res.data.upgrade_url,
            label: res.data.upgrade_label || 'Upgrade your plan'
          } : null
        );
        return;
      }
      clearPendingOutputLoading($wrap);
      clearLoadingState($wrap);
      status($wrap, res.data.cached ? 'Done (cached)' : 'Done', false);
      renderOutput($wrap, res.data.text, res.data.format || 'text');
    })
    .fail(function(xhr){
      const res = parseResponse(xhr && xhr.responseText ? xhr.responseText : null);
      const msg = (res && res.data && res.data.message) ? res.data.message : 'Request failed. Try again.';
      resetOutputState($wrap, false);
      clearLoadingState($wrap);
      status(
        $wrap,
        msg,
        true,
        (res && res.data && res.data.upgrade_url) ? {
          url: res.data.upgrade_url,
          label: res.data.upgrade_label || 'Upgrade your plan'
        } : null
      );
    });
  });

  $(document).on('click', '.awg-aig__copy', function(){
    const $wrap = $(this).closest('.awg-aig');
    const $btn = $(this);
    const originalLabel = $btn.text();
    const $out = $wrap.find('.awg-aig__output');
    const text = ($out.data('raw-text') || $out.text() || '').toString();

    function setCopiedLabel(){
      const $label = $btn.find('span').last();
      if ($label.length) {
        const originalHtml = $label.html();
        $label.text('Copied');
        setTimeout(function(){
          $label.html(originalHtml);
        }, 2000);
      } else {
        $btn.text('Copied');
        setTimeout(function(){
          $btn.text(originalLabel);
        }, 2000);
      }
    }

    function legacyCopy(value){
      const $temp = $('<textarea readonly></textarea>');
      $temp.css({ position: 'absolute', left: '-9999px', top: '0' });
      $temp.val(value);
      $('body').append($temp);
      $temp[0].select();
      try {
        document.execCommand('copy');
        status($wrap, 'Copied.', false);
        setCopiedLabel();
      } catch (e) {
        status($wrap, 'Copy failed.', true);
      }
      $temp.remove();
    }

    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function(){
        status($wrap, 'Copied.', false);
        setCopiedLabel();
      }).catch(function(){
        legacyCopy(text);
      });
    } else {
      legacyCopy(text);
    }
  });

  $(document).on('click', '.awg-aig__download', function(){
    const $wrap = $(this).closest('.awg-aig');
    const $out = $wrap.find('.awg-aig__output');
    const format = $out.data('format') || 'text';
    const rawText = ($out.data('raw-text') || '').toString();
    const text = format === 'html' ? (rawText || $out.html() || '') : (rawText || $out.text() || '');
    const filenameBase = $wrap.find('.awg-aig__result').data('filename') || 'generator-output';
    const extension = format === 'json' ? 'json' : (format === 'html' ? 'html' : 'txt');
    const mime = format === 'json' ? 'application/json;charset=utf-8' : 'text/plain;charset=utf-8';
    const blob = new Blob([text], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filenameBase + '.' + extension;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    status($wrap, 'Download started.', false);
  });



  $(document).on('click', '.awg-aig__clear', function(){
    const $wrap = $(this).closest('.awg-aig');
    resetOutputState($wrap, false);
    const formEl = $wrap.find('.awg-aig__form').get(0);
    if (formEl) formEl.reset();
    applyGclid($wrap);
    status($wrap, '', false);
    setTimeout(function(){
      const form = $wrap.find('.awg-aig__form').get(0);
      if (!form) return;
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  });

  $(document).on('click', '.awg-aig__regenerate', function(){
    const $wrap = $(this).closest('.awg-aig');
    const $form = $wrap.find('.awg-aig__form');
    if (!$form.length) return;
    setButtonLoading($(this), true, 'Regenerating...');
    status($wrap, 'Regenerating...', false);
    $form.trigger('submit');
  });


  $(document).on('input change', '.awg-aig__input, .awg-aig__choice', function(){
    const $group = $(this).closest('.awg-aig__field');
    $group.removeClass('is-error');
    $group.find('.awg-aig__field-error').remove();
  });

 $(document).ready(function(){
  $('.awg-aig').each(function(){
    const $wrap = $(this);
    applyGclid($wrap);

    // keep result hidden on initial load
    $wrap.find('.awg-aig__result')
      .prop('hidden', true)
      .removeClass('is-busy');
  });
});
})(jQuery);
