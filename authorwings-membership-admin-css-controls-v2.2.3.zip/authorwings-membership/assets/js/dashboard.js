/* AuthorWings Membership — Dashboard JS v1.1.0 */
(function ($) {
    'use strict';

    const cfg   = window.AWG_MEM || {};
    const ajax  = cfg.ajax_url;
    const nonce = cfg.nonce;
    const s     = cfg.strings || {};

    // ── Helpers ──────────────────────────────────────────────

    /**
     * Move modals to <body> so position:fixed works in every theme.
     * CSS transforms or overflow:hidden on ancestors break fixed positioning —
     * appending to body bypasses all of that.
     */
    function hoistModalsToBody() {
        $('.awg-mem-modal').each(function () {
            if ( $(this).parent().is('body') ) { return; }
            $(this).appendTo('body');
        });
    }

    function openModal($modal) {
        $modal.addClass('is-open');
        $('body').addClass('awg-modal-open');
    }

    function closeModal($modal) {
        $modal.removeClass('is-open');
        // Only remove scroll lock if no other modals are open
        if ( ! $('.awg-mem-modal.is-open').length ) {
            $('body').removeClass('awg-modal-open');
        }
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function injectSpinStyle() {
        if ( document.getElementById('awg-spin-style') ) { return; }
        var el = document.createElement('style');
        el.id  = 'awg-spin-style';
        el.textContent = '@keyframes awg-spin{to{transform:rotate(360deg)}}';
        document.head.appendChild(el);
    }

    // ── Tab switching ────────────────────────────────────────
    function initTabs() {
        var $tabs   = $('.awg-mem-tab');
        var $panels = $('.awg-mem-panel');

        function activateTab(tab) {
            $tabs.removeClass('awg-mem-tab--active');
            $panels.removeClass('awg-mem-panel--active');
            $tabs.filter('[data-tab="' + tab + '"]').addClass('awg-mem-tab--active');
            $panels.filter('[data-panel="' + tab + '"]').addClass('awg-mem-panel--active');
            if (history.replaceState) {
                history.replaceState(null, '', '#' + tab);
            }
        }

        $tabs.on('click', function () { activateTab($(this).data('tab')); });

        $(document).on('click', '.awg-mem-tab-link', function (e) {
            e.preventDefault();
            activateTab($(this).data('tab'));
        });

        var hash = window.location.hash.replace('#', '');
        if (hash && $('.awg-mem-tab[data-tab="' + hash + '"]').length) {
            activateTab(hash);
        }
        var params = new URLSearchParams(window.location.search);
        var tabParam = params.get('tab');
        if (tabParam && $('.awg-mem-tab[data-tab="' + tabParam + '"]').length) {
            activateTab(tabParam);
        }
        if (params.get('upgrade') || params.get('payment') || params.get('cancelled') || params.get('awg_notice')) {
            activateTab('account');
        }
    }


    function initHistoryLoadMore() {
        $(document).on('click', '#awg-mem-history-load-more', function () {
            var $btn = $(this);
            var nextPage = parseInt($btn.attr('data-page') || '1', 10) + 1;
            $btn.prop('disabled', true).text('Loading…');

            $.post(ajax, {
                action: 'awg_mem_get_history',
                nonce: nonce,
                page: nextPage
            })
            .done(function (res) {
                if (!res.success || !res.data) {
                    $btn.prop('disabled', false).text('Load More');
                    return;
                }
                $('#awg-mem-history-wrap .awg-mem-history-list').append($(res.data.html).find('.awg-mem-history-item'));
                $btn.attr('data-page', res.data.page);
                if (res.data.has_more) {
                    $btn.prop('disabled', false).text('Load More');
                } else {
                    $btn.remove();
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).text('Load More');
            });
        });
    }

    // ── Tool modal ───────────────────────────────────────────
    function initToolModal() {
        var $modal   = $('#awg-tool-modal');
        var $content = $('#awg-tool-modal-content');

        $(document).on('click', '.awg-mem-open-tool', function () {
            var templateId = $(this).data('template-id');
            if ( ! templateId ) { return; }

            // Loading state
            $content.html(
                '<div style="padding:48px 24px;text-align:center;color:#6b7280;">' +
                '<span class="dashicons dashicons-update-alt" style="font-size:36px;width:36px;height:36px;' +
                'display:inline-block;animation:awg-spin 1s linear infinite;"></span>' +
                '<p style="margin:14px 0 0;font-size:14px;">' + escHtml(s.tool_loading || 'Loading tool…') + '</p>' +
                '</div>'
            );
            openModal($modal);

            $.post(ajax, {
                action:      'awg_mem_get_tool_html',
                nonce:       nonce,
                template_id: templateId,
            })
            .done(function (res) {
                if (res.success && res.data && res.data.html) {
                    // Update modal title if element exists
                    $modal.find('.awg-mem-modal__title').text(res.data.title || '');
                    $content.html(res.data.html);
                    // Notify AI plugin that new generator HTML was injected
                    $(document).trigger('awg_aig_modal_loaded', [$content]);
                } else {
                    var msg = (res.data && res.data.message) || (s.tool_error || 'Could not load tool.');
                    var upgrade = res.data && res.data.upgrade_url ? '<p style="margin:14px 0 0;"><a href="' + escHtml(res.data.upgrade_url) + '" class="awg-mem-btn awg-mem-btn--primary">' + escHtml((res.data.upgrade_label || 'View plans')) + '</a></p>' : '';
                    $content.html(
                        '<div style="padding:28px 24px;">' +
                        '<p style="color:#991b1b;font-size:14px;margin:0 0 12px;">' + escHtml(msg) + '</p>' +
                        upgrade +
                        '<p style="font-size:13px;color:#6b7280;margin:14px 0 0;">You can also add this tool to any page with the shortcode:<br>' +
                        '<code style="background:#f3f4f6;padding:3px 7px;border-radius:4px;font-size:12px;">' +
                        '[awg_generator id="' + parseInt(templateId, 10) + '"]</code></p>' +
                        '</div>'
                    );
                }
            })
            .fail(function () {
                $content.html(
                    '<p style="padding:28px 24px;color:#991b1b;font-size:14px;margin:0;">' +
                    escHtml(s.tool_error || 'Could not load tool. Please try again.') + '</p>'
                );
            });
        });

        // Close handlers
        $(document).on('click', '#awg-tool-modal-close', function () {
            closeModal($modal);
            $content.html('');
            $modal.find('.awg-mem-modal__title').text('');
        });
        $(document).on('click', '#awg-tool-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
            $content.html('');
            $modal.find('.awg-mem-modal__title').text('');
        });
        $(document).on('keydown.awg-tool-modal', function (e) {
            if (e.key === 'Escape' && $modal.hasClass('is-open')) {
                closeModal($modal);
                $content.html('');
            }
        });
    }

    // ── Service order modal ──────────────────────────────────
    function initServiceModal() {
        var $modal        = $('#awg-service-modal');
        var $detailsModal = $('#awg-service-details-modal');
        var currentSlug   = '';
        var currentName   = '';

        function escapeHtml(text) {
            return $('<div>').text(text || '').html();
        }

        function fillDetailsModal($trigger) {
            var name = $trigger.data('name') || '';
            var category = $trigger.data('category') || (s.service_details || 'Service Details');
            var description = $trigger.data('description') || '';
            var fullDescription = $trigger.data('full-description') || '';
            var price = $trigger.data('price') || '';
            var turnaround = $trigger.data('turnaround') || '';
            var buttonLabel = $trigger.data('button-label') || (s.request_quote || 'Request Quote');
            var buttonUrl = $trigger.data('button-url') || '';
            var imageUrl = $trigger.data('image-url') || '';
            var icon = $trigger.data('icon') || 'dashicons-star-filled';
            var slug = $trigger.data('slug') || '';
            var bodyHtml = fullDescription ? fullDescription : ('<p>' + escapeHtml(description) + '</p>');

            $('#awg-service-details-title').text(name || (s.service_details || 'Service Details'));
            $('#awg-service-details-category').text(category);
            $('#awg-service-details-summary').text(description);
            $('#awg-service-details-body').html(bodyHtml);
            $('#awg-service-details-price').text(price);
            $('#awg-service-details-turnaround').text(turnaround);
            $('#awg-service-details-price-wrap').toggle(!!price);
            $('#awg-service-details-turnaround-wrap').toggle(!!turnaround);

            if (imageUrl) {
                $('#awg-service-details-media').html('<img src="' + escapeHtml(imageUrl) + '" alt="' + escapeHtml(name) + '">');
            } else {
                $('#awg-service-details-media').html('<div class="awg-mem-service-details-modal__icon"><span class="dashicons ' + escapeHtml(icon) + '"></span></div>');
            }

            $('#awg-service-details-primary-action')
                .text(buttonLabel)
                .data('slug', slug)
                .data('name', name)
                .data('button-url', buttonUrl);

            if (buttonUrl) {
                $('#awg-service-details-secondary-action').hide();
            } else {
                $('#awg-service-details-secondary-action')
                    .text(s.close || 'Close')
                    .show();
            }
        }

        function safeVal(selector) {
            var $field = $(selector);
            if (!$field.length) {
                return '';
            }
            var value = $field.val();
            return typeof value === 'string' ? value.trim() : '';
        }

        function showServiceMsg(type, text) {
            var $msg = $('#awg-service-modal-msg');
            $msg.removeClass('awg-mem-alert--success awg-mem-alert--error')
                .addClass('awg-mem-alert awg-mem-alert--' + type)
                .text(text)
                .show();
        }


        $(document).on('click', '.awg-mem-view-service-details', function () {
            fillDetailsModal($(this));
            openModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-modal-close, #awg-service-details-secondary-action', function () {
            closeModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-modal .awg-mem-modal__backdrop', function () {
            closeModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-primary-action', function () {
            var buttonUrl = $(this).data('button-url') || '';
            var slug = $(this).data('slug') || '';
            var name = $(this).data('name') || '';

            if (buttonUrl) {
                window.location.href = buttonUrl;
                return;
            }

            currentSlug = slug;
            currentName = name;
            closeModal($detailsModal);
            $('#awg-service-modal-title').text(currentName || (s.request_quote || 'Request Quote'));
            $('#awg-service-modal-msg').hide().removeClass('awg-mem-alert--success awg-mem-alert--error').text('');
            $('#awg-service-form-wrap').show();
            $('#awg-service-notes').val('').removeClass('awg-mem-textarea--invalid');
            openModal($modal);
        });

        $(document).on('click', '.awg-mem-request-service', function () {
            currentSlug = $(this).data('slug') || '';
            currentName = $(this).data('name') || '';
            $('#awg-service-modal-title').text(currentName || (s.request_quote || 'Request Quote'));
            $('#awg-service-modal-msg').hide().removeClass('awg-mem-alert--success awg-mem-alert--error').text('');
            $('#awg-service-form-wrap').show();
            $('#awg-service-notes').val('').removeClass('awg-mem-textarea--invalid');
            openModal($modal);
        });

        $(document).on('click', '#awg-service-modal-close', function () { closeModal($modal); });
        $(document).on('click', '#awg-service-modal .awg-mem-modal__backdrop', function () { closeModal($modal); });
        $(document).on('keydown.awg-service-modal', function (e) {
            if (e.key === 'Escape') {
                if ($detailsModal.hasClass('is-open')) {
                    closeModal($detailsModal);
                } else if ($modal.hasClass('is-open')) {
                    closeModal($modal);
                }
            }
        });

        $(document).on('click', '#awg-service-submit', function () {
            var notes = safeVal('#awg-service-notes');
            var $notes = $('#awg-service-notes');
            var $btn  = $(this);
            var minLength = parseInt(s.service_details_min || '20', 10);

            if (!notes || notes.length < minLength) {
                showServiceMsg('error', s.service_details_required || 'Please add a few project details so we can prepare the right quote.');
                $notes.addClass('awg-mem-textarea--invalid').trigger('focus');
                return;
            }

            $notes.removeClass('awg-mem-textarea--invalid');
            $btn.prop('disabled', true).text(s.submitting || 'Submitting…');

            $.post(ajax, {
                action:       'awg_mem_submit_order',
                nonce:        nonce,
                service_slug: currentSlug,
                service_name: currentName,
                notes:        notes,
            })
            .done(function (res) {
                $btn.prop('disabled', false).text(s.submit_request || 'Submit Request');
                if (res && res.success) {
                    showServiceMsg('success', (res.data && res.data.message) || 'Your request has been submitted.');
                    $('#awg-service-form-wrap').hide();
                    setTimeout(function () {
                        closeModal($modal);
                        $('#awg-service-modal-msg').hide().removeClass('awg-mem-alert--success awg-mem-alert--error').text('');
                        $('#awg-service-form-wrap').show();
                        $('#awg-service-notes').val('').removeClass('awg-mem-textarea--invalid');
                    }, 1400);
                } else {
                    showServiceMsg('error', (res && res.data && res.data.message) || s.error_generic || 'Something went wrong. Please try again.');
                }
            })
            .fail(function (xhr) {
                $btn.prop('disabled', false).text(s.submit_request || 'Submit Request');
                var message = s.error_generic || 'Something went wrong. Please try again.';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    message = xhr.responseJSON.data.message;
                }
                console.error('Service request failed', xhr);
                showServiceMsg('error', message);
            });
        });
    }

    // ── Plan upgrade ─────────────────────────────────────────
    function initPlanUpgrade() {
        function applyBillingState(billing) {
            $('[data-billing-toggle]').removeClass('is-active');
            $('[data-billing-toggle="' + billing + '"]').addClass('is-active');
            $('.awg-mem-select-plan').attr('data-billing', billing);
            $('.awg-mem-plan-card').each(function () {
                var $card = $(this);
                var monthly = parseFloat($card.attr('data-monthly-price') || '0');
                var yearly = parseFloat($card.attr('data-yearly-price') || '0');
                var $price = $card.find('[data-plan-price]');
                var $note = $card.find('[data-plan-note]');
                if (!$price.length || monthly === 0 && yearly === 0) { return; }
                if (billing === 'yearly' && yearly > 0) {
                    $price.text('$' + Math.round(yearly) + '/yr');
                    if ($note.length) { $note.text('Charged yearly'); }
                } else {
                    $price.text('$' + Math.round(monthly) + '/mo');
                    if ($note.length) { $note.text('Billed monthly'); }
                }
            });
        }

        $(document).on('click', '[data-billing-toggle]', function () {
            applyBillingState($(this).attr('data-billing-toggle'));
        });

        var initialBilling = $('.awg-mem-plans-grid--account').attr('data-current-billing') || 'monthly';
        applyBillingState(initialBilling);

        $(document).on('click', '.awg-mem-select-plan', function () {
            var $btn     = $(this);
            var plan     = $btn.data('plan');
            var billing  = $btn.attr('data-billing') || 'monthly';
            var planName = $btn.data('plan-name') || 'this plan';
            var isFree   = String($btn.data('is-free')) === '1';
            var origText = $btn.text().trim();

            if (isFree && ! window.confirm(s.confirm_downgrade || 'Switch to the free plan right now?')) {
                return;
            }

            $btn.prop('disabled', true).text(s.upgrading || 'Processing…');

            $.post(ajax, { action: 'awg_mem_upgrade_plan', nonce: nonce, plan: plan, billing: billing })
            .done(function (res) {
                if (res.success) {
                    if (res.data && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else {
                    $btn.prop('disabled', false).text(origText);
                    alert((res.data && res.data.message) || (isFree ? 'Could not switch to the free plan.' : 'Could not start checkout for ' + planName + '.'));
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).text(origText);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }

    // ── Cancel plan ──────────────────────────────────────────
    function initCancelPlan() {
        $(document).on('click', '.awg-mem-cancel-plan', function () {
            if ( ! confirm(s.confirm_cancel || 'Cancel your membership? You will be moved to the free plan.') ) { return; }
            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(ajax, { action: 'awg_mem_cancel_plan', nonce: nonce })
            .done(function (res) {
                if (res.success) {
                    if (res.data && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else {
                    alert((res.data && res.data.message) || (isFree ? 'Could not switch to the free plan.' : 'Could not start checkout for ' + planName + '.'));
                    $btn.prop('disabled', false);
                }
            })
            .fail(function () {
                $btn.prop('disabled', false);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }


    // ── Team seats ───────────────────────────────────────────
    function initTeamSeats() {
        function showTeamMsg(type, message) {
            var $msg = $('#awg-team-msg');
            if (!$msg.length) { return; }
            $msg.removeClass('awg-mem-alert--success awg-mem-alert--error awg-mem-alert--info')
                .addClass('awg-mem-alert awg-mem-alert--' + type)
                .text(message)
                .show();
        }

        $(document).on('click', '#awg-team-invite-btn', function () {
            var email = ($('#awg-team-email').val() || '').trim();
            var $btn = $(this);
            if (!email) {
                showTeamMsg('error', 'Please enter an email address.');
                return;
            }
            $btn.prop('disabled', true);
            $.post(ajax, { action: 'awg_mem_invite_team_member', nonce: nonce, email: email })
                .done(function (res) {
                    if (res.success) {
                        showTeamMsg('success', (res.data && res.data.message) || 'Seat invitation saved.');
                        window.location.reload();
                    } else {
                        showTeamMsg('error', (res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                    }
                })
                .fail(function () {
                    showTeamMsg('error', s.error_generic || 'Something went wrong.');
                })
                .always(function () {
                    $btn.prop('disabled', false);
                });
        });

        $(document).on('click', '.awg-mem-team-remove', function () {
            var seatId = $(this).data('seat-id');
            var $btn = $(this);
            if (!seatId) { return; }
            if (!window.confirm('Remove this team seat?')) { return; }
            $btn.prop('disabled', true);
            $.post(ajax, { action: 'awg_mem_remove_team_member', nonce: nonce, seat_id: seatId })
                .done(function (res) {
                    if (res.success) {
                        window.location.reload();
                    } else {
                        showTeamMsg('error', (res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                        $btn.prop('disabled', false);
                    }
                })
                .fail(function () {
                    showTeamMsg('error', s.error_generic || 'Something went wrong.');
                    $btn.prop('disabled', false);
                });
        });
    }

    // ── Copy to clipboard ────────────────────────────────────
    function initCopyButtons() {
        $(document).on('click', '.awg-mem-copy-btn', function () {
            var text = $(this).data('copy');
            var $btn = $(this);
            var orig = $btn.text();

            function done() {
                $btn.text(s.copied || 'Copied!');
                setTimeout(function () { $btn.text(orig); }, 2000);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () {
                    fallbackCopy(text); done();
                });
            } else {
                fallbackCopy(text); done();
            }
        });

        function fallbackCopy(text) {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
            document.body.appendChild(ta);
            ta.focus(); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta);
        }
    }

    // ── Init ─────────────────────────────────────────────────
    $(function () {
        if ( ! $('.awg-mem-dashboard').length ) { return; }

        hoistModalsToBody(); // Must run first
        injectSpinStyle();
        initTabs();
        initToolModal();
        initServiceModal();
        initPlanUpgrade();
        initCancelPlan();
        initTeamSeats();
        initCopyButtons();
    });

}(jQuery));
