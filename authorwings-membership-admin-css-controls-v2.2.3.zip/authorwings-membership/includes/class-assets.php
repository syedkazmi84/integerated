<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function frontend(): void {
        global $post;
        $has_dashboard = is_a( $post, 'WP_Post' ) && (
            has_shortcode( $post->post_content, 'awg_dashboard' ) ||
            has_shortcode( $post->post_content, 'awg_pricing' )
        );

        if ( ! $has_dashboard ) { return; }

        // ── Membership plugin assets ────────────────────────
        wp_enqueue_style(
            'awg-mem-front',
            AWG_MEM_URL . 'assets/css/dashboard.css',
            [ 'dashicons' ],
            AWG_MEM_VERSION
        );

        $settings         = get_option( Plugin::OPT, [] );
        $primary          = sanitize_hex_color( $settings['dashboard_primary_color'] ?? '#1a73e8' ) ?: '#1a73e8';
        $bg               = sanitize_hex_color( $settings['dashboard_bg_color'] ?? '#f7f9fc' ) ?: '#f7f9fc';
        $card_bg          = sanitize_hex_color( $settings['dashboard_card_bg'] ?? '#ffffff' ) ?: '#ffffff';
        $text             = sanitize_hex_color( $settings['dashboard_text_color'] ?? '#1a1a2e' ) ?: '#1a1a2e';
        $border           = sanitize_hex_color( $settings['dashboard_border_color'] ?? '#e0e7ef' ) ?: '#e0e7ef';
        $font_family      = sanitize_text_field( $settings['dashboard_font_family'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $heading_font     = sanitize_text_field( $settings['dashboard_heading_font'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $font_size        = isset( $settings['dashboard_font_size'] ) ? max( 12, (int) $settings['dashboard_font_size'] ) : 16;
        $button_bg        = sanitize_hex_color( $settings['dashboard_button_bg'] ?? '#1a73e8' ) ?: '#1a73e8';
        $button_text      = sanitize_hex_color( $settings['dashboard_button_text'] ?? '#ffffff' ) ?: '#ffffff';
        $button_hover     = sanitize_hex_color( $settings['dashboard_button_hover'] ?? '#1558b0' ) ?: '#1558b0';
        $button_radius    = isset( $settings['dashboard_button_radius'] ) ? max( 0, (int) $settings['dashboard_button_radius'] ) : 12;
        $card_padding     = isset( $settings['dashboard_card_padding'] ) ? max( 0, (int) $settings['dashboard_card_padding'] ) : 20;
        $card_shadow      = sanitize_text_field( $settings['dashboard_card_shadow'] ?? '0 10px 28px rgba(3,12,23,.04)' );
        $card_hover_shadow= sanitize_text_field( $settings['dashboard_card_hover_shadow'] ?? '0 12px 30px rgba(26,115,232,.12)' );
        $card_border_width= isset( $settings['dashboard_card_border_width'] ) ? max( 0, (float) $settings['dashboard_card_border_width'] ) : 1;
        $radius           = isset( $settings['dashboard_radius'] ) ? max( 0, (int) $settings['dashboard_radius'] ) : 12;
        $max_width        = isset( $settings['dashboard_max_width'] ) ? max( 320, (int) $settings['dashboard_max_width'] ) : 960;
        $container_padding= isset( $settings['dashboard_container_padding'] ) ? max( 0, (int) $settings['dashboard_container_padding'] ) : 0;
        $grid_gap         = isset( $settings['dashboard_grid_gap'] ) ? max( 0, (int) $settings['dashboard_grid_gap'] ) : 16;
        $section_spacing  = isset( $settings['dashboard_section_spacing'] ) ? max( 0, (int) $settings['dashboard_section_spacing'] ) : 28;
        $custom_css       = trim( str_replace( [ '<', '>' ], '', (string) ( $settings['dashboard_custom_css'] ?? '' ) ) );

        $inline_css = ":root {
"
            . "    --awg-primary: {$primary};
"
            . "    --awg-bg: {$bg};
"
            . "    --awg-card-bg: {$card_bg};
"
            . "    --awg-text: {$text};
"
            . "    --awg-border: {$border};
"
            . "    --awg-font: {$font_family};
"
            . "    --awg-heading-font: {$heading_font};
"
            . "    --awg-base-font-size: {$font_size}px;
"
            . "    --awg-button-bg: {$button_bg};
"
            . "    --awg-button-text: {$button_text};
"
            . "    --awg-button-hover: {$button_hover};
"
            . "    --awg-button-radius: {$button_radius}px;
"
            . "    --awg-card-padding: {$card_padding}px;
"
            . "    --awg-card-shadow: {$card_shadow};
"
            . "    --awg-card-hover-shadow: {$card_hover_shadow};
"
            . "    --awg-card-border-width: {$card_border_width}px;
"
            . "    --awg-radius: {$radius}px;
"
            . "    --awg-grid-gap: {$grid_gap}px;
"
            . "    --awg-section-spacing: {$section_spacing}px;
"
            . "}
"
            . ".awg-mem-dashboard { max-width: {$max_width}px; padding: 0 {$container_padding}px 48px; font-size: var(--awg-base-font-size); }
"
            . ".awg-mem-dashboard h1, .awg-mem-dashboard h2, .awg-mem-dashboard h3, .awg-mem-dashboard h4, .awg-mem-dashboard h5, .awg-mem-dashboard h6 { font-family: var(--awg-heading-font); }
"
            . ".awg-mem-usage-grid, .awg-mem-quick-grid { gap: var(--awg-grid-gap); }
"
            . ".awg-mem-tools-grid, .awg-mem-plan-grid, .awg-mem-history-grid { gap: var(--awg-grid-gap); }
"
            . ".awg-mem-section-title { margin-top: var(--awg-section-spacing); }
"
            . ".awg-mem-usage-card, .awg-mem-quick-card, .awg-mem-tools-hero, .awg-mem-tools-banner, .awg-mem-plan-card, .awg-mem-history-card, .awg-mem-team-card, .awg-mem-service-card { border-width: var(--awg-card-border-width); box-shadow: var(--awg-card-shadow); }
"
            . ".awg-mem-usage-card, .awg-mem-quick-card, .awg-mem-plan-card, .awg-mem-history-card, .awg-mem-team-card, .awg-mem-service-card { padding: var(--awg-card-padding); }
"
            . ".awg-mem-quick-card:hover, .awg-mem-plan-card:hover, .awg-mem-service-card:hover { box-shadow: var(--awg-card-hover-shadow); }
"
            . ".awg-mem-dashboard .button, .awg-mem-dashboard button:not(.awg-mem-tab):not(.components-button), .awg-mem-dashboard input[type=submit], .awg-mem-dashboard input[type=button] { background: var(--awg-button-bg); color: var(--awg-button-text); border-radius: var(--awg-button-radius); border-color: var(--awg-button-bg); }
"
            . ".awg-mem-dashboard .button:hover, .awg-mem-dashboard button:not(.awg-mem-tab):not(.components-button):hover, .awg-mem-dashboard input[type=submit]:hover, .awg-mem-dashboard input[type=button]:hover { background: var(--awg-button-hover); border-color: var(--awg-button-hover); color: var(--awg-button-text); }
";

        if ( '' !== $custom_css ) {
            $inline_css .= "
" . $custom_css;
        }

        wp_add_inline_style( 'awg-mem-front', $inline_css );

        wp_enqueue_script(
            'awg-mem-front',
            AWG_MEM_URL . 'assets/js/dashboard.js',
            [ 'jquery' ],
            AWG_MEM_VERSION,
            true
        );

        wp_localize_script( 'awg-mem-front', 'AWG_MEM', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'awg_mem_nonce' ),
            'strings'  => [
                'confirm_cancel'  => __( 'Are you sure you want to cancel your paid membership and move back to the free plan?', 'authorwings-membership' ),
                'confirm_downgrade' => __( 'Are you sure you want to switch to the free plan right now?', 'authorwings-membership' ),
                'upgrading'       => __( 'Processing…', 'authorwings-membership' ),
                'copied'          => __( 'Copied!', 'authorwings-membership' ),
                'submitting'      => __( 'Submitting…', 'authorwings-membership' ),
                'error_generic'   => __( 'Something went wrong. Please try again.', 'authorwings-membership' ),
                'tool_loading'    => __( 'Loading tool…', 'authorwings-membership' ),
                'tool_error'      => __( 'Could not load tool. Please try again.', 'authorwings-membership' ),
                'service_details_required' => __( 'Please add a few project details so we can prepare the right quote.', 'authorwings-membership' ),
                'submit_request'  => __( 'Submit Request', 'authorwings-membership' ),
                'request_sent'    => __( 'Request sent', 'authorwings-membership' ),
                'request_quote'   => __( 'Request Quote', 'authorwings-membership' ),
                'service_details_min' => '20',
                'service_details' => __( 'Service Details', 'authorwings-membership' ),
                'close'           => __( 'Close', 'authorwings-membership' ),
            ],
        ] );

        // ── Force-load AI plugin front assets on dashboard ──
        // The AI plugin's Assets::maybe_enqueue_front_assets() only loads
        // when it detects [awg_generator] in page content. The dashboard
        // uses [awg_dashboard], so we must signal the AI plugin manually.
        // The filter 'awg_aig_enqueue_assets' is checked by class-assets.php
        // in the AI plugin — returning true forces its front.js + front.css.
        add_filter( 'awg_aig_enqueue_assets', '__return_true' );

        // Fallback: if the AI plugin version doesn't have the filter yet,
        // enqueue its assets directly by calling its enqueue method.
        add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_ai_assets' ], 20 );
    }

    /**
     * Fallback: directly call the AI plugin's asset enqueue method
     * if the filter approach didn't work (older AI plugin version).
     * Runs at priority 20 — after the AI plugin's own priority-10 hook.
     */
    public function maybe_enqueue_ai_assets(): void {
        // Already enqueued via filter — nothing to do
        if ( wp_script_is( 'awg-aig-front', 'enqueued' ) ) {
            return;
        }

        // AI plugin is active — call its enqueue directly
        if ( class_exists( '\\AWG_AIG\\Assets' ) ) {
            $ai_assets = new \AWG_AIG\Assets();
            $ai_assets->enqueue_front_assets();
            return;
        }

        // Last resort: enqueue by known paths if AI plugin is active
        if ( defined( 'AWG_AIG_URL' ) && defined( 'AWG_AIG_VERSION' ) ) {
            wp_enqueue_style( 'dashicons' );
            wp_enqueue_style(
                'awg-aig-front',
                AWG_AIG_URL . 'assets/front.css',
                [],
                AWG_AIG_VERSION
            );
            wp_enqueue_script(
                'awg-aig-front',
                AWG_AIG_URL . 'assets/front.js',
                [ 'jquery' ],
                AWG_AIG_VERSION,
                true
            );
            wp_localize_script( 'awg-aig-front', 'AWG_AIG', [
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'awg_aig_nonce_front' ),
            ] );
        }
    }

    public function admin( string $hook ): void {
        if ( strpos( $hook, 'awg-membership' ) === false ) { return; }

        wp_enqueue_style(
            'awg-mem-admin',
            AWG_MEM_URL . 'assets/css/admin.css',
            [],
            AWG_MEM_VERSION
        );

        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_add_inline_script(
            'wp-color-picker',
            "jQuery(function($){ $('.awg-color-field').wpColorPicker(); });"
        );
    }
}
