<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Dashboard {

    /** @var Memberships */
    private $memberships;

    /** @var Usage */
    private $usage;

    /** @var Plans */
    private $plans;

    public function __construct( Memberships $memberships, Usage $usage, Plans $plans ) {
        $this->memberships = $memberships;
        $this->usage       = $usage;
        $this->plans       = $plans;
    }

    /**
     * Render [awg_dashboard] shortcode.
     */
    public function render( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return $this->render_login_prompt();
        }

        $user    = wp_get_current_user();
        $user_id = $user->ID;
        $workspace_owner_id = $this->memberships->get_workspace_owner_id( $user_id );
        $mem     = $this->memberships->get_effective_membership( $user_id );
        $latest  = $this->memberships->get_latest_membership( $workspace_owner_id );
        $limits  = $this->memberships->get_user_limits( $user_id );
        $usage   = $this->usage->get_all_for_user( $user_id );
        $plans   = $this->plans->get_all();
        $plan_slug = $this->memberships->get_user_plan_slug( $user_id );
        $team_context = $this->memberships->get_team_context( $user_id );
        $monthly_breakdown = $this->usage->get_monthly_breakdown( $user_id, 6 );
        $recent_tools = $this->usage->get_recent_tools_used( $user_id, 5 );

        $ai_limit = (int) ( $limits['ai_generations_per_month'] ?? 10 );
        $ai_used  = (int) ( $usage['ai_generation'] ?? 0 );

        ob_start();
        ?>
        <div class="awg-mem-dashboard" id="awg-dashboard"
             data-nonce="<?php echo esc_attr( wp_create_nonce( 'awg_mem_nonce' ) ); ?>"
             data-user-id="<?php echo esc_attr( $user_id ); ?>"
             data-plan="<?php echo esc_attr( $plan_slug ); ?>">

            <!-- Top bar -->
            <div class="awg-mem-topbar">
                <div class="awg-mem-topbar__left">
                    <div class="awg-mem-avatar">
                        <?php echo get_avatar( $user_id, 40 ); ?>
                    </div>
                    <div>
                        <div class="awg-mem-topbar__name">
                            <?php echo esc_html( $user->display_name ); ?>
                        </div>
                        <div class="awg-mem-topbar__plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?>">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?> <?php esc_html_e( 'Plan', 'authorwings-membership' ); ?>
                        </div>
                    </div>
                </div>
                <?php if ( $plan_slug === 'free' || $plan_slug === 'basic' ) : ?>
                    <a href="#account" class="awg-mem-btn awg-mem-btn--primary awg-mem-tab-link" data-tab="account">
                        <?php esc_html_e( 'Upgrade Plan', 'authorwings-membership' ); ?>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Tab nav -->
            <nav class="awg-mem-tabs">
                <button class="awg-mem-tab awg-mem-tab--active" data-tab="home">
                    <?php esc_html_e( 'Home', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="tools">
                    <?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="services">
                    <?php esc_html_e( 'Services', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="quote-requests">
                    <?php esc_html_e( 'Quote Requests', 'authorwings-membership' ); ?>
                </button>
                <?php if ( $this->memberships->user_can( $user_id, 'awg_view_history' ) ) : ?>
                    <button class="awg-mem-tab" data-tab="history">
                        <?php esc_html_e( 'History', 'authorwings-membership' ); ?>
                    </button>
                <?php endif; ?>
                <button class="awg-mem-tab" data-tab="account">
                    <?php esc_html_e( 'Account', 'authorwings-membership' ); ?>
                </button>
            </nav>

            <!-- HOME TAB -->
            <div class="awg-mem-panel awg-mem-panel--active" data-panel="home">

                <!-- Usage meters -->
                <div class="awg-mem-usage-grid">
                    <div class="awg-mem-usage-card">
                        <?php
                        $pct = ( $ai_limit > 0 ) ? min( 100, round( $ai_used / $ai_limit * 100 ) ) : 0;
                        $color = $pct >= 90 ? '#E24B4A' : ( $pct >= 70 ? '#EF9F27' : '#1D9E75' );
                        ?>
                        <div class="awg-mem-usage-card__title">
                            <?php esc_html_e( 'AI Generations', 'authorwings-membership' ); ?>
                        </div>
                        <div class="awg-mem-usage-donut">
                            <svg viewBox="0 0 64 64" width="64" height="64">
                                <circle cx="32" cy="32" r="26" fill="none" stroke="#e5e7eb" stroke-width="8"/>
                                <circle cx="32" cy="32" r="26" fill="none"
                                    stroke="<?php echo esc_attr( $color ); ?>"
                                    stroke-width="8"
                                    stroke-dasharray="<?php echo esc_attr( $ai_limit < 0 ? 163 : round( $pct * 1.63 ) ); ?> 163"
                                    stroke-linecap="round"
                                    transform="rotate(-90 32 32)"/>
                            </svg>
                            <span class="awg-mem-usage-donut__label">
                                <?php if ( $ai_limit < 0 ) : ?>
                                    ∞
                                <?php else : ?>
                                    <?php echo esc_html( $ai_used . '/' . $ai_limit ); ?>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="awg-mem-usage-card__sub">
                            <?php if ( $ai_limit < 0 ) : ?>
                                <?php esc_html_e( 'Unlimited', 'authorwings-membership' ); ?>
                            <?php else : ?>
                                <?php echo esc_html( $ai_limit - $ai_used ); ?>
                                <?php esc_html_e( 'remaining this month', 'authorwings-membership' ); ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Plan info card -->
                    <div class="awg-mem-usage-card awg-mem-usage-card--plan">
                        <div class="awg-mem-usage-card__title"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                        <div class="awg-mem-plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?> awg-mem-plan-badge--lg">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?>
                        </div>
                        <?php if ( $mem && ! empty( $mem['end_date'] ) && $mem['is_free'] != 1 ) : ?>
                            <div class="awg-mem-usage-card__sub">
                                <?php
                                printf(
                                    /* translators: %s: renewal date */
                                    esc_html__( 'Renews %s', 'authorwings-membership' ),
                                    esc_html( wp_date( get_option( 'date_format' ), strtotime( $mem['end_date'] ) ) )
                                );
                                ?>
                            </div>
                        <?php endif; ?>
                        <a href="#account" class="awg-mem-tab-link awg-mem-link" data-tab="account">
                            <?php esc_html_e( 'Manage plan →', 'authorwings-membership' ); ?>
                        </a>
                    </div>
                </div>

                <!-- Quick actions -->
                <h3 class="awg-mem-section-title"><?php esc_html_e( 'Quick Actions', 'authorwings-membership' ); ?></h3>
                <div class="awg-mem-quick-grid">
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="tools">
                        <span class="dashicons dashicons-lightbulb"></span>
                        <span><?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?></span>
                    </button>
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="services">
                        <span class="dashicons dashicons-book-alt"></span>
                        <span><?php esc_html_e( 'Services', 'authorwings-membership' ); ?></span>
                    </button>
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="quote-requests">
                        <span class="dashicons dashicons-media-text"></span>
                        <span><?php esc_html_e( 'Quote Requests', 'authorwings-membership' ); ?></span>
                    </button>
                    <?php if ( $this->memberships->user_can( $user_id, 'awg_view_history' ) ) : ?>
                        <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="history">
                            <span class="dashicons dashicons-list-view"></span>
                            <span><?php esc_html_e( 'My History', 'authorwings-membership' ); ?></span>
                        </button>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( home_url( '/publishing-guides/' ) ); ?>" class="awg-mem-quick-card">
                        <span class="dashicons dashicons-media-document"></span>
                        <span><?php esc_html_e( 'Guides', 'authorwings-membership' ); ?></span>
                    </a>
                </div>
            </div>

            <!-- TOOLS TAB -->
            <div class="awg-mem-panel" data-panel="tools">
                <?php $this->render_tools_panel( $plan_slug, $ai_limit, $ai_used ); ?>
            </div>

            <!-- SERVICES TAB -->
            <div class="awg-mem-panel" data-panel="services">
                <?php $this->render_services_panel( $plan_slug ); ?>
            </div>

            <!-- QUOTE REQUESTS TAB -->
            <div class="awg-mem-panel" data-panel="quote-requests">
                <?php $this->render_quote_requests_panel( $user_id ); ?>
            </div>

            <!-- HISTORY TAB -->
            <?php if ( $this->memberships->user_can( $user_id, 'awg_view_history' ) ) : ?>
                <div class="awg-mem-panel" data-panel="history">
                    <?php $this->render_history_panel( $user_id ); ?>
                </div>
            <?php endif; ?>

            <!-- ACCOUNT TAB -->
            <div class="awg-mem-panel" data-panel="account">
                <?php $this->render_account_panel( $user, $mem, $latest, $plan_slug, $plans, $ai_limit, $ai_used, $team_context ); ?>
            </div>

        </div><!-- /.awg-mem-dashboard -->
        <?php
        return ob_get_clean();
    }

    // -------------------------------------------------------
    // Panel renderers
    // -------------------------------------------------------

    private function render_tools_panel( string $plan_slug, int $ai_limit, int $ai_used ): void {
        $tools            = $this->get_tool_definitions();
        $plan_level       = Roles::level( Roles::slug_to_role( $plan_slug ) );
        $limit_reached    = $ai_limit >= 0 && $ai_used >= $ai_limit;
        $usage_percent    = $ai_limit > 0 ? min( 100, (int) round( ( $ai_used / $ai_limit ) * 100 ) ) : 0;
        $remaining_uses   = $ai_limit < 0 ? -1 : max( 0, $ai_limit - $ai_used );

        // Group by category
        $grouped = [];
        foreach ( $tools as $tool ) {
            $grouped[ $tool['category'] ][] = $tool;
        }
        ?>
        <div class="awg-mem-tools-hero">
            <div class="awg-mem-tools-hero__copy">
                <h2><?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?></h2>
                <p class="awg-mem-tools-hero__usage">
                    <?php if ( $ai_limit < 0 ) : ?>
                        <?php esc_html_e( 'Unlimited generations available this month', 'authorwings-membership' ); ?>
                    <?php else : ?>
                        <?php echo esc_html( $ai_used ); ?> / <?php echo esc_html( $ai_limit ); ?>
                        <?php esc_html_e( 'generations used this month', 'authorwings-membership' ); ?>
                    <?php endif; ?>
                </p>
                <div class="awg-mem-tools-hero__note"><?php esc_html_e( 'Open any available tool instantly. Locked tools show the required plan and a direct path to upgrade.', 'authorwings-membership' ); ?></div>
            </div>

            <div class="awg-mem-tools-hero__meter" aria-label="<?php esc_attr_e( 'AI usage status', 'authorwings-membership' ); ?>">
                <?php if ( $ai_limit < 0 ) : ?>
                    <div class="awg-mem-tools-hero__pill awg-mem-tools-hero__pill--unlimited"><?php esc_html_e( 'Unlimited', 'authorwings-membership' ); ?></div>
                <?php else : ?>
                    <div class="awg-mem-tools-progress">
                        <div class="awg-mem-tools-progress__bar" style="width: <?php echo esc_attr( $usage_percent ); ?>%;"></div>
                    </div>
                    <div class="awg-mem-tools-hero__meter-meta">
                        <span><?php echo esc_html( $usage_percent ); ?>% <?php esc_html_e( 'used', 'authorwings-membership' ); ?></span>
                        <span>
                            <?php
                            printf(
                                /* translators: %d: remaining monthly generations */
                                esc_html__( '%d remaining', 'authorwings-membership' ),
                                (int) $remaining_uses
                            );
                            ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ( $limit_reached ) : ?>
            <div class="awg-mem-tools-banner" role="status">
                <div class="awg-mem-tools-banner__icon"><span class="dashicons dashicons-chart-line"></span></div>
                <div class="awg-mem-tools-banner__body">
                    <div class="awg-mem-tools-banner__title"><?php esc_html_e( 'You have reached your monthly AI limit', 'authorwings-membership' ); ?></div>
                    <div class="awg-mem-tools-banner__text"><?php esc_html_e( 'Upgrade your plan to keep generating and unlock additional tools from the same dashboard.', 'authorwings-membership' ); ?></div>
                </div>
                <a href="#account" class="awg-mem-btn awg-mem-btn--primary awg-mem-tab-link" data-tab="account"><?php esc_html_e( 'Upgrade Plan', 'authorwings-membership' ); ?></a>
            </div>
        <?php endif; ?>

        <?php foreach ( $grouped as $category => $cat_tools ) : ?>
            <h3 class="awg-mem-section-title"><?php echo esc_html( $category ); ?></h3>
            <div class="awg-mem-tools-grid">
                <?php foreach ( $cat_tools as $tool ) :
                    $required_level = Roles::level( Roles::slug_to_role( $tool['plan'] ) );
                    $locked         = $plan_level < $required_level;
                    $has_template   = ! empty( $tool['template_id'] );
                    $is_exhausted   = ! $locked && $has_template && $limit_reached;
                    $card_classes   = 'awg-mem-tool-card';

                    if ( $locked ) {
                        $card_classes .= ' awg-mem-tool-card--locked';
                    } elseif ( $is_exhausted ) {
                        $card_classes .= ' awg-mem-tool-card--exhausted';
                    } else {
                        $card_classes .= ' awg-mem-tool-card--available';
                    }
                    ?>
                    <div class="<?php echo esc_attr( $card_classes ); ?>"
                         <?php if ( ! $locked && ! $is_exhausted && $has_template ) : ?>
                             data-template-id="<?php echo esc_attr( $tool['template_id'] ); ?>"
                         <?php endif; ?>>
                        <div class="awg-mem-tool-card__top">
                            <div class="awg-mem-tool-card__icon">
                                <span class="dashicons <?php echo esc_attr( $tool['icon'] ); ?>"></span>
                            </div>
                            <div class="awg-mem-tool-card__status">
                                <?php if ( $locked ) : ?>
                                    <?php esc_html_e( 'Locked', 'authorwings-membership' ); ?>
                                <?php elseif ( $is_exhausted ) : ?>
                                    <?php esc_html_e( 'Limit reached', 'authorwings-membership' ); ?>
                                <?php else : ?>
                                    <?php esc_html_e( 'Included', 'authorwings-membership' ); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="awg-mem-tool-card__body">
                            <div class="awg-mem-tool-card__title"><?php echo esc_html( $tool['name'] ); ?></div>
                            <div class="awg-mem-tool-card__desc"><?php echo esc_html( $tool['description'] ); ?></div>

                            <?php if ( $locked ) : ?>
                                <div class="awg-mem-tool-card__lock">
                                    <span class="dashicons dashicons-lock"></span>
                                    <?php
                                    printf(
                                        /* translators: %s: plan name */
                                        esc_html__( 'Unlock with the %s plan.', 'authorwings-membership' ),
                                        esc_html( ucfirst( $tool['plan'] ) )
                                    );
                                    ?>
                                </div>
                                <div class="awg-mem-tool-card__lock-help">
                                    <?php esc_html_e( 'Upgrade to make this generator available from your dashboard.', 'authorwings-membership' ); ?>
                                </div>
                                <a href="#account" class="awg-mem-btn awg-mem-btn--sm awg-mem-btn--primary awg-mem-tab-link awg-mem-tool-card__action" data-tab="account">
                                    <?php esc_html_e( 'See Upgrade Options', 'authorwings-membership' ); ?>
                                </a>
                            <?php elseif ( $is_exhausted ) : ?>
                                <div class="awg-mem-tool-card__lock awg-mem-tool-card__lock--warning">
                                    <span class="dashicons dashicons-warning"></span>
                                    <?php esc_html_e( 'Your monthly generation allowance has been used.', 'authorwings-membership' ); ?>
                                </div>
                                <div class="awg-mem-tool-card__lock-help">
                                    <?php esc_html_e( 'Upgrade to continue using this generator right away.', 'authorwings-membership' ); ?>
                                </div>
                                <a href="#account" class="awg-mem-btn awg-mem-btn--sm awg-mem-btn--primary awg-mem-tab-link awg-mem-tool-card__action" data-tab="account">
                                    <?php esc_html_e( 'Upgrade to Continue', 'authorwings-membership' ); ?>
                                </a>
                            <?php elseif ( $has_template ) : ?>
                                <button class="awg-mem-btn awg-mem-btn--sm awg-mem-open-tool awg-mem-tool-card__action"
                                        data-template-id="<?php echo esc_attr( $tool['template_id'] ); ?>">
                                    <?php esc_html_e( 'Use Tool', 'authorwings-membership' ); ?>
                                </button>
                            <?php else : ?>
                                <span class="awg-mem-coming-soon awg-mem-tool-card__action"><?php esc_html_e( 'Coming soon', 'authorwings-membership' ); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>

        <!-- Tool modal — opened by JS when user clicks "Use Tool" -->
        <!-- hoistModalsToBody() in dashboard.js moves this to <body> on init -->
        <div class="awg-mem-modal" id="awg-tool-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box">
                <div class="awg-mem-modal__header">
                    <h3 class="awg-mem-modal__title"></h3>
                    <button class="awg-mem-modal__close" id="awg-tool-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content" id="awg-tool-modal-content">
                    <!-- Generator HTML loaded here via AJAX -->
                </div>
            </div>
        </div>
        <?php
    }

    private function render_services_panel( string $plan_slug ): void {
        $services = new Services();
        $all      = $services->get_all();

        if ( empty( $all ) ) {
            echo '<p class="awg-mem-muted">' . esc_html__( 'No services available yet. Check back soon.', 'authorwings-membership' ) . '</p>';
            return;
        }

        // Group by category
        $grouped = [];
        foreach ( $all as $svc ) {
            $grouped[ $svc['category'] ][] = $svc;
        }
        ?>
        <h2><?php esc_html_e( 'Publishing Services', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Browse our professional book publishing services. Submit a request and we\'ll get back to you within 24 hours.', 'authorwings-membership' ); ?></p>

        <?php foreach ( $grouped as $category => $svcs ) : ?>
            <h3 class="awg-mem-section-title"><?php echo esc_html( ucfirst( $category ) ); ?></h3>
            <div class="awg-mem-services-grid">
                <?php foreach ( $svcs as $svc ) : ?>
                    <div class="awg-mem-service-card<?php echo ! empty( $svc['featured'] ) ? ' awg-mem-service-card--featured' : ''; ?>">
                        <div class="awg-mem-service-card__header">
                            <div class="awg-mem-service-card__header-main">
                                <?php if ( ! empty( $svc['image_url'] ) ) : ?>
                                    <div class="awg-mem-service-card__media awg-mem-service-card__media--thumb">
                                        <img src="<?php echo esc_url( $svc['image_url'] ); ?>" alt="<?php echo esc_attr( $svc['title'] ); ?>">
                                    </div>
                                <?php else : ?>
                                    <div class="awg-mem-service-card__icon">
                                        <span class="dashicons <?php echo esc_attr( $svc['icon'] ); ?>"></span>
                                    </div>
                                <?php endif; ?>
                                <div class="awg-mem-service-card__title-wrap">
                                    <div class="awg-mem-service-card__title"><?php echo esc_html( $svc['title'] ); ?></div>
                                </div>
                            </div>
                            <?php if ( ! empty( $svc['featured'] ) ) : ?>
                                <div class="awg-mem-service-card__badge"><?php esc_html_e( 'Featured', 'authorwings-membership' ); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="awg-mem-service-card__body">
                            <div class="awg-mem-service-card__desc"><?php echo esc_html( $svc['description'] ); ?></div>
                            <div class="awg-mem-service-card__meta">
                                <?php if ( $svc['price_from'] ) : ?>
                                    <div class="awg-mem-service-card__price">
                                        <?php esc_html_e( 'From ', 'authorwings-membership' ); ?><?php echo esc_html( $svc['price_from'] ); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ( $svc['turnaround'] ) : ?>
                                    <div class="awg-mem-service-card__turnaround"><?php echo esc_html( $svc['turnaround'] ); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="awg-mem-service-card__actions">
                                <button class="awg-mem-btn awg-mem-btn--sm awg-mem-btn--ghost awg-mem-view-service-details"
                                        data-slug="<?php echo esc_attr( $svc['slug'] ); ?>"
                                        data-name="<?php echo esc_attr( $svc['title'] ); ?>"
                                        data-category="<?php echo esc_attr( $svc['category_label'] ); ?>"
                                        data-description="<?php echo esc_attr( wp_strip_all_tags( $svc['description'] ) ); ?>"
                                        data-price="<?php echo esc_attr( $svc['price_from'] ); ?>"
                                        data-turnaround="<?php echo esc_attr( $svc['turnaround'] ); ?>"
                                        data-button-label="<?php echo esc_attr( $svc['button_label'] ); ?>"
                                        data-button-url="<?php echo esc_attr( $svc['button_url'] ); ?>"
                                        data-full-description="<?php echo esc_attr( $svc['full_description'] ); ?>"
                                        data-image-url="<?php echo esc_attr( $svc['image_url'] ); ?>"
                                        data-icon="<?php echo esc_attr( $svc['icon'] ); ?>">
                                    <?php esc_html_e( 'View Details', 'authorwings-membership' ); ?>
                                </button>
                                <?php if ( ! empty( $svc['button_url'] ) ) : ?>
                                    <a class="awg-mem-btn awg-mem-btn--sm" href="<?php echo esc_url( $svc['button_url'] ); ?>">
                                        <?php echo esc_html( $svc['button_label'] ); ?>
                                    </a>
                                <?php else : ?>
                                    <button class="awg-mem-btn awg-mem-btn--sm awg-mem-request-service"
                                            data-slug="<?php echo esc_attr( $svc['slug'] ); ?>"
                                            data-name="<?php echo esc_attr( $svc['title'] ); ?>">
                                        <?php echo esc_html( $svc['button_label'] ); ?>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>


        <div class="awg-mem-modal" id="awg-service-details-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box awg-mem-service-details-modal__box">
                <div class="awg-mem-modal__header awg-mem-service-modal__header">
                    <div class="awg-mem-service-modal__heading">
                        <span class="awg-mem-service-modal__eyebrow" id="awg-service-details-category"><?php esc_html_e( 'Service Details', 'authorwings-membership' ); ?></span>
                        <h3 class="awg-mem-modal__title" id="awg-service-details-title"><?php esc_html_e( 'Service Details', 'authorwings-membership' ); ?></h3>
                    </div>
                    <button class="awg-mem-modal__close" id="awg-service-details-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content awg-mem-service-details-modal__content">
                    <div class="awg-mem-service-details-modal__hero">
                        <div class="awg-mem-service-details-modal__media" id="awg-service-details-media"></div>
                        <div class="awg-mem-service-details-modal__summary">
                            <p class="awg-mem-muted" id="awg-service-details-summary"></p>
                            <div class="awg-mem-service-details-modal__meta">
                                <div class="awg-mem-service-details-modal__meta-item" id="awg-service-details-price-wrap" style="display:none;">
                                    <span class="awg-mem-service-details-modal__meta-label"><?php esc_html_e( 'Starting From', 'authorwings-membership' ); ?></span>
                                    <span class="awg-mem-service-details-modal__meta-value" id="awg-service-details-price"></span>
                                </div>
                                <div class="awg-mem-service-details-modal__meta-item" id="awg-service-details-turnaround-wrap" style="display:none;">
                                    <span class="awg-mem-service-details-modal__meta-label"><?php esc_html_e( 'Turnaround', 'authorwings-membership' ); ?></span>
                                    <span class="awg-mem-service-details-modal__meta-value" id="awg-service-details-turnaround"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="awg-mem-service-details-modal__body" id="awg-service-details-body"></div>
                    <div class="awg-mem-service-details-modal__actions">
                        <button class="awg-mem-btn awg-mem-btn--ghost" id="awg-service-details-secondary-action" style="display:none;"></button>
                        <button class="awg-mem-btn awg-mem-btn--primary" id="awg-service-details-primary-action"></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Service order modal -->
        <div class="awg-mem-modal" id="awg-service-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box awg-mem-modal__box--sm awg-mem-service-modal__box">
                <div class="awg-mem-modal__header awg-mem-service-modal__header">
                    <div class="awg-mem-service-modal__heading">
                        <span class="awg-mem-service-modal__eyebrow"><?php esc_html_e( 'Request Quote', 'authorwings-membership' ); ?></span>
                        <h3 class="awg-mem-modal__title" id="awg-service-modal-title"><?php esc_html_e( 'Request Quote', 'authorwings-membership' ); ?></h3>
                    </div>
                    <button class="awg-mem-modal__close" id="awg-service-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content awg-mem-service-modal__content">
                    <div id="awg-service-modal-msg" class="awg-mem-alert" style="display:none;"></div>
                    <div id="awg-service-form-wrap" class="awg-mem-service-form">
                        <p class="awg-mem-muted awg-mem-service-help"><?php esc_html_e( 'Tell us about your project so we can prepare the right quote for you.', 'authorwings-membership' ); ?></p>
                        <label class="awg-mem-service-form__label" for="awg-service-notes"><?php esc_html_e( 'Project Details', 'authorwings-membership' ); ?></label>
                        <textarea id="awg-service-notes" class="awg-mem-textarea awg-mem-service-form__textarea" rows="6"
                              placeholder="<?php esc_attr_e( 'Describe your book, genre, approximate word count, current stage, and the publishing help you need.', 'authorwings-membership' ); ?>"></textarea>
                        <p class="awg-mem-service-form__hint"><?php esc_html_e( 'Include any goals, deadlines, or special requirements that would help us prepare your quote.', 'authorwings-membership' ); ?></p>
                        <div class="awg-mem-service-form__footer">
                            <span class="awg-mem-service-form__footer-note"><?php esc_html_e( 'We will review your request and contact you soon.', 'authorwings-membership' ); ?></span>
                            <button class="awg-mem-btn awg-mem-btn--primary" id="awg-service-submit">
                                <?php esc_html_e( 'Submit Request', 'authorwings-membership' ); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }


    private function render_quote_requests_panel( int $user_id ): void {
        global $wpdb;
        $table = Database::orders_table();

        $requests = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, service_name, status, created_at FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT 50",
                $user_id
            ),
            ARRAY_A
        );
        ?>
        <h2><?php esc_html_e( 'My Quote Requests', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Track the quote requests you have submitted and their current status.', 'authorwings-membership' ); ?></p>

        <?php if ( empty( $requests ) ) : ?>
            <div class="awg-mem-account-card awg-mem-account-card--wide">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'No quote requests yet', 'authorwings-membership' ); ?></div>
                <p class="awg-mem-account-help"><?php esc_html_e( 'Browse the Services tab to request a quote for any publishing service.', 'authorwings-membership' ); ?></p>
            </div>
        <?php else : ?>
            <table class="awg-mem-info-table awg-mem-team-table">
                <tr>
                    <td><?php esc_html_e( 'Request ID', 'authorwings-membership' ); ?></td>
                    <td><?php esc_html_e( 'Service', 'authorwings-membership' ); ?></td>
                    <td><?php esc_html_e( 'Date', 'authorwings-membership' ); ?></td>
                    <td><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></td>
                </tr>
                <?php foreach ( $requests as $request ) : ?>
                    <?php
                    $status = sanitize_key( (string) ( $request['status'] ?? 'pending' ) );
                    if ( 'in_progress' === $status ) {
                        $status = 'responded';
                    } elseif ( 'completed' === $status ) {
                        $status = 'closed';
                    }
                    if ( ! in_array( $status, [ 'pending', 'responded', 'closed' ], true ) ) {
                        $status = 'pending';
                    }
                    $status_label = [
                        'pending'   => __( 'Pending', 'authorwings-membership' ),
                        'responded' => __( 'Responded', 'authorwings-membership' ),
                        'closed'    => __( 'Closed', 'authorwings-membership' ),
                    ][ $status ];
                    ?>
                    <tr>
                        <td>#<?php echo esc_html( (int) $request['id'] ); ?></td>
                        <td><strong><?php echo esc_html( (string) $request['service_name'] ); ?></strong></td>
                        <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( (string) $request['created_at'] ) ) ); ?></td>
                        <td><?php echo esc_html( $status_label ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif;
    }

    private function render_history_panel( int $user_id ): void {
        $history = $this->get_history_page( $user_id, 1, 12 );
        ?>
        <h2><?php esc_html_e( 'My Generation History', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Recent submissions are saved here when submission storage is enabled in the AI plugin.', 'authorwings-membership' ); ?></p>

        <div id="awg-mem-history-wrap">
            <?php $this->render_history_items( $history['items'] ); ?>
        </div>

        <?php if ( ! empty( $history['has_more'] ) ) : ?>
            <div style="margin-top:16px;">
                <button type="button" class="awg-mem-btn" id="awg-mem-history-load-more" data-page="1"><?php esc_html_e( 'Load More', 'authorwings-membership' ); ?></button>
            </div>
        <?php endif; ?>
        <?php
    }

    private function render_history_items( array $items ): void {
        if ( empty( $items ) ) {
            echo '<p class="awg-mem-muted">' . esc_html__( 'No generations yet. Head to AI Tools to get started.', 'authorwings-membership' ) . '</p>';
            return;
        }

        echo '<div class="awg-mem-history-list">';
        foreach ( $items as $item ) {
            echo '<div class="awg-mem-history-item">';
            echo '<div class="awg-mem-history-item__header">';
            echo '<span class="awg-mem-history-item__tool">' . esc_html( $item['tool'] ) . '</span>';
            echo '<span class="awg-mem-history-item__date">' . esc_html( $item['date_label'] ) . '</span>';
            if ( ! empty( $item['model'] ) ) {
                echo '<span class="awg-mem-badge">' . esc_html( $item['model'] ) . '</span>';
            }
            echo '</div>';
            if ( ! empty( $item['output'] ) ) {
                echo '<div class="awg-mem-history-item__output"><pre>' . esc_html( $item['output_preview'] ) . '</pre>';
                echo '<button class="awg-mem-btn awg-mem-btn--xs awg-mem-copy-btn" data-copy="' . esc_attr( $item['output'] ) . '">' . esc_html__( 'Copy', 'authorwings-membership' ) . '</button></div>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

    public static function build_history_query_args( int $user_id, int $owner_id, int $page = 1, int $per_page = 12 ): array {
        $page     = max( 1, $page );
        $per_page = max( 1, min( 50, $per_page ) );

        return [
            'post_type'      => 'awg_ai_submission',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [
                'relation' => 'OR',
                [
                    'key'     => '_awg_aig_user_id',
                    'value'   => $user_id,
                    'compare' => '=',
                    'type'    => 'NUMERIC',
                ],
                [
                    'key'     => '_awg_aig_owner_user_id',
                    'value'   => $owner_id,
                    'compare' => '=',
                    'type'    => 'NUMERIC',
                ],
            ],
        ];
    }

    private function get_history_page( int $user_id, int $page = 1, int $per_page = 12 ): array {
        $owner_id = $this->memberships->get_workspace_owner_id( $user_id );
        $query    = new \WP_Query( self::build_history_query_args( $user_id, $owner_id, $page, $per_page ) );

        $items = [];
        foreach ( (array) $query->posts as $sub ) {
            $template_id = (int) get_post_meta( $sub->ID, '_awg_aig_template_id', true );
            $tool_name   = (string) get_post_meta( $sub->ID, '_awg_aig_template_title', true );
            if ( $tool_name === '' && $template_id > 0 ) {
                $template = get_post( $template_id );
                $tool_name = $template ? $template->post_title : __( 'AI Tool', 'authorwings-membership' );
            }
            if ( $tool_name === '' ) {
                $tool_name = __( 'AI Tool', 'authorwings-membership' );
            }
            $output = (string) get_post_meta( $sub->ID, '_awg_aig_output', true );
            $items[] = [
                'id'             => (int) $sub->ID,
                'tool'           => $tool_name,
                'date'           => $sub->post_date,
                'date_label'     => wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sub->post_date ) ),
                'model'          => (string) get_post_meta( $sub->ID, '_awg_aig_model', true ),
                'output'         => $output,
                'output_preview' => wp_trim_words( $output, 40 ),
            ];
        }

        return [
            'items'      => $items,
            'page'       => $page,
            'has_more'   => $page < (int) $query->max_num_pages,
            'max_pages'  => (int) $query->max_num_pages,
            'total'      => (int) $query->found_posts,
        ];
    }

    private function render_account_panel( \WP_User $user, ?array $mem, ?array $latest, string $plan_slug, array $plans, int $ai_limit, int $ai_used, array $team_context ): void {
        $billing_cycle = 'monthly';
        if ( $mem && ! empty( $mem['billing_cycle'] ) && in_array( $mem['billing_cycle'], [ 'monthly', 'yearly' ], true ) ) {
            $billing_cycle = (string) $mem['billing_cycle'];
        }

        $status = $mem['status'] ?? ( $latest['status'] ?? 'active' );
        $status_labels = [
            'active'         => __( 'Active', 'authorwings-membership' ),
            'trialing'       => __( 'Trialing', 'authorwings-membership' ),
            'cancelled'      => __( 'Cancelled', 'authorwings-membership' ),
            'expired'        => __( 'Expired', 'authorwings-membership' ),
            'payment_failed' => __( 'Payment failed', 'authorwings-membership' ),
        ];
        $status_label = $status_labels[ $status ] ?? ucfirst( str_replace( '_', ' ', (string) $status ) );
        $remaining = $ai_limit < 0 ? __( 'Unlimited', 'authorwings-membership' ) : max( 0, $ai_limit - $ai_used ) . ' ' . __( 'remaining', 'authorwings-membership' );
        $workspace_usage_rows = [];
        if ( ! empty( $team_context['can_manage_team'] ) ) {
            $workspace_usage_rows = $this->usage->get_workspace_usage_breakdown( (int) $team_context['workspace_owner_id'], 25 );
        }
        $renewal_label = __( 'Not applicable', 'authorwings-membership' );
        if ( $mem && ! empty( $mem['end_date'] ) && (int) ( $mem['is_free'] ?? 0 ) !== 1 ) {
            $renewal_label = wp_date( get_option( 'date_format' ), strtotime( $mem['end_date'] ) );
        }
        $billing_health_label = in_array( $status, [ 'active', 'trialing' ], true ) ? __( 'Billing active', 'authorwings-membership' ) : __( 'Billing attention needed', 'authorwings-membership' );
        $renewal_state_label = __( 'No renewal scheduled', 'authorwings-membership' );
        if ( $status === 'cancelled' ) {
            $renewal_state_label = __( 'Cancelled and moved to Free', 'authorwings-membership' );
        } elseif ( $status === 'payment_failed' ) {
            $renewal_state_label = __( 'Payment failed. Paid access inactive.', 'authorwings-membership' );
        } elseif ( $status === 'expired' ) {
            $renewal_state_label = __( 'Expired. Renew to restore paid access.', 'authorwings-membership' );
        } elseif ( in_array( $status, [ 'active', 'trialing' ], true ) && $renewal_label !== __( 'Not applicable', 'authorwings-membership' ) ) {
            $renewal_state_label = sprintf( __( 'Next renewal on %s', 'authorwings-membership' ), $renewal_label );
        }
        $seat_usage_label = __( 'No team seats on this plan', 'authorwings-membership' );
        if ( ! empty( $team_context['is_team_member'] ) ) {
            $seat_usage_label = __( 'Using a shared workspace seat', 'authorwings-membership' );
        } elseif ( ! empty( $team_context['can_manage_team'] ) ) {
            $seat_usage_label = sprintf( __( '%1$d of %2$d seats used', 'authorwings-membership' ), (int) $team_context['seat_count'], (int) $team_context['seat_limit'] );
        }
        ?>
        <h2><?php esc_html_e( 'Account & Billing', 'authorwings-membership' ); ?></h2>
        <?php $this->render_account_notices( $mem, $latest ); ?>

        <div class="awg-mem-account-overview">
            <div class="awg-mem-account-card awg-mem-account-card--wide">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                <div class="awg-mem-plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?> awg-mem-plan-badge--lg">
                    <?php echo esc_html( ucfirst( $plan_slug ) ); ?>
                </div>
                <div class="awg-mem-account-status-row">
                    <span class="awg-mem-status-pill awg-mem-status-pill--<?php echo esc_attr( sanitize_html_class( $status ) ); ?>"><?php echo esc_html( $status_label ); ?></span>
                    <span class="awg-mem-account-card__meta"><?php echo esc_html( ucfirst( $billing_cycle ) ); ?><?php echo $plan_slug === 'free' ? ' · ' . esc_html__( 'No billing', 'authorwings-membership' ) : ''; ?></span>
                </div>
                <div class="awg-mem-account-stats">
                    <div>
                        <strong><?php esc_html_e( 'Usage limit', 'authorwings-membership' ); ?></strong>
                        <span>
                        <?php if ( $ai_limit < 0 ) : ?>
                            <?php esc_html_e( 'Unlimited generations', 'authorwings-membership' ); ?>
                        <?php else : ?>
                            <?php echo esc_html( $ai_limit ); ?> <?php esc_html_e( 'generations / month', 'authorwings-membership' ); ?>
                        <?php endif; ?>
                        </span>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'Used this month', 'authorwings-membership' ); ?></strong>
                        <span><?php echo esc_html( $ai_used ); ?> · <?php echo esc_html( $remaining ); ?></span>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'Renewal date', 'authorwings-membership' ); ?></strong>
                        <span><?php echo esc_html( $renewal_label ); ?></span>
                    </div>
                </div>
                <?php if ( $status === 'payment_failed' ) : ?>
                    <div class="awg-mem-alert awg-mem-alert--error"><?php esc_html_e( 'Payment issue detected. Choose a plan below to restart billing and restore paid access.', 'authorwings-membership' ); ?></div>
                <?php endif; ?>
                <?php if ( empty( $team_context['is_team_member'] ) && $mem && (int) ( $mem['is_free'] ?? 0 ) !== 1 ) : ?>
                    <div class="awg-mem-account-actions">
                        <button class="awg-mem-btn awg-mem-btn--danger-outline awg-mem-cancel-plan">
                            <?php esc_html_e( 'Cancel and move to Free', 'authorwings-membership' ); ?>
                        </button>
                        <p class="awg-mem-account-help"><?php esc_html_e( 'Need a downgrade instead? Select another plan below and we will send you to the correct checkout or apply the free plan directly.', 'authorwings-membership' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="awg-mem-account-card">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Billing Health', 'authorwings-membership' ); ?></div>
                <div class="awg-mem-account-card__value"><?php echo esc_html( $billing_health_label ); ?></div>
                <p class="awg-mem-account-help"><?php echo esc_html( $renewal_state_label ); ?></p>
            </div>
            <div class="awg-mem-account-card">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Seat Usage', 'authorwings-membership' ); ?></div>
                <div class="awg-mem-account-card__value"><?php echo esc_html( $seat_usage_label ); ?></div>
                <p class="awg-mem-account-help"><?php esc_html_e( 'Workspace seats and monthly AI usage are shown here so owners and members can quickly understand account status.', 'authorwings-membership' ); ?></p>
            </div>
        </div>

        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Choose Billing Period', 'authorwings-membership' ); ?></h3>
        <div class="awg-mem-billing-toggle" role="tablist" aria-label="<?php esc_attr_e( 'Billing period', 'authorwings-membership' ); ?>">
            <button type="button" class="awg-mem-billing-toggle__btn<?php echo $billing_cycle === 'monthly' ? ' is-active' : ''; ?>" data-billing-toggle="monthly"><?php esc_html_e( 'Monthly', 'authorwings-membership' ); ?></button>
            <button type="button" class="awg-mem-billing-toggle__btn<?php echo $billing_cycle === 'yearly' ? ' is-active' : ''; ?>" data-billing-toggle="yearly"><?php esc_html_e( 'Yearly', 'authorwings-membership' ); ?></button>
        </div>

        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Available Plans', 'authorwings-membership' ); ?></h3>
        <div class="awg-mem-plans-grid awg-mem-plans-grid--account" data-current-billing="<?php echo esc_attr( $billing_cycle ); ?>">
            <?php foreach ( $plans as $plan ) :
                $is_current = $plan['slug'] === $plan_slug;
                $is_popular = $plan['slug'] === 'pro';
                $monthly    = (float) $plan['price_monthly'];
                $yearly     = (float) $plan['price_yearly'];
                $is_free    = (bool) $plan['is_free'];
                $current_price = $billing_cycle === 'yearly' ? $yearly : $monthly;
            ?>
                <div class="awg-mem-plan-card<?php echo $is_popular ? ' awg-mem-plan-card--popular' : ''; ?><?php echo $is_current ? ' awg-mem-plan-card--current' : ''; ?>"
                     data-monthly-price="<?php echo esc_attr( number_format( $monthly, 2, '.', '' ) ); ?>"
                     data-yearly-price="<?php echo esc_attr( number_format( $yearly, 2, '.', '' ) ); ?>">
                    <?php if ( $is_popular ) : ?>
                        <div class="awg-mem-plan-card__badge"><?php esc_html_e( 'Most Popular', 'authorwings-membership' ); ?></div>
                    <?php endif; ?>
                    <div class="awg-mem-plan-card__name"><?php echo esc_html( $plan['name'] ); ?></div>
                    <div class="awg-mem-plan-card__price" data-plan-price>
                        <?php if ( $is_free ) : ?>
                            <?php esc_html_e( 'Free', 'authorwings-membership' ); ?>
                        <?php else : ?>
                            $<?php echo esc_html( number_format( $current_price, 0 ) ); ?>/<?php echo esc_html( $billing_cycle === 'yearly' ? 'yr' : 'mo' ); ?>
                        <?php endif; ?>
                    </div>
                    <?php if ( ! $is_free && $yearly > 0 ) : ?>
                        <div class="awg-mem-plan-card__billing-note" data-plan-note>
                            <?php echo $billing_cycle === 'yearly'
                                ? esc_html__( 'Charged yearly', 'authorwings-membership' )
                                : esc_html__( 'Billed monthly', 'authorwings-membership' ); ?>
                        </div>
                    <?php endif; ?>
                    <ul class="awg-mem-plan-card__features">
                        <?php foreach ( array_slice( (array) $plan['features'], 0, 5 ) as $feat ) : ?>
                            <li><?php echo esc_html( $feat ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ( $is_current ) : ?>
                        <div class="awg-mem-plan-card__current-label"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                    <?php elseif ( ! empty( $team_context['is_team_member'] ) ) : ?>
                        <div class="awg-mem-plan-card__billing-note"><?php esc_html_e( 'Managed by workspace owner', 'authorwings-membership' ); ?></div>
                    <?php else : ?>
                        <button class="awg-mem-btn awg-mem-btn--primary awg-mem-select-plan<?php echo $is_popular ? ' awg-mem-btn--full' : ''; ?>"
                                data-plan="<?php echo esc_attr( $plan['slug'] ); ?>"
                                data-billing="<?php echo esc_attr( $billing_cycle ); ?>"
                                data-plan-name="<?php echo esc_attr( $plan['name'] ); ?>"
                                data-is-free="<?php echo $is_free ? '1' : '0'; ?>">
                            <?php echo $is_free
                                ? esc_html__( 'Downgrade to Free', 'authorwings-membership' )
                                : esc_html__( 'Choose This Plan', 'authorwings-membership' ); ?>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Team Workspace', 'authorwings-membership' ); ?></h3>
        <?php if ( ! empty( $team_context['is_team_member'] ) ) : ?>
            <div class="awg-mem-account-card awg-mem-account-card--wide">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Workspace Access', 'authorwings-membership' ); ?></div>
                <p><?php printf( esc_html__( 'You are using the Publisher workspace owned by %s.', 'authorwings-membership' ), esc_html( $team_context['workspace_owner_name'] ?: __( 'your account owner', 'authorwings-membership' ) ) ); ?></p>
                <p class="awg-mem-account-help"><?php esc_html_e( 'AI usage is shared across the whole workspace. Team members can use the tools but cannot manage billing or seats.', 'authorwings-membership' ); ?></p>
            </div>
        <?php elseif ( ! empty( $team_context['can_manage_team'] ) ) : ?>
            <div class="awg-mem-account-card awg-mem-account-card--wide">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Publisher Team Seats', 'authorwings-membership' ); ?></div>
                <p><?php printf( esc_html__( '%1$d of %2$d seats in use. Usage is tracked per workspace, so all team members share the same monthly AI allowance.', 'authorwings-membership' ), (int) $team_context['seat_count'], (int) $team_context['seat_limit'] ); ?></p>
                <div class="awg-mem-team-invite">
                    <input type="email" class="awg-mem-input" id="awg-team-email" placeholder="<?php esc_attr_e( 'Invite by email', 'authorwings-membership' ); ?>">
                    <button type="button" class="awg-mem-btn awg-mem-btn--primary" id="awg-team-invite-btn"><?php esc_html_e( 'Invite Seat', 'authorwings-membership' ); ?></button>
                </div>
                <div id="awg-team-msg" class="awg-mem-alert" style="display:none;"></div>
                <?php if ( ! empty( $team_context['members'] ) ) : ?>
                    <table class="awg-mem-info-table awg-mem-team-table">
                        <tr>
                            <td><?php esc_html_e( 'Email', 'authorwings-membership' ); ?></td>
                            <td><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></td>
                            <td><?php esc_html_e( 'Action', 'authorwings-membership' ); ?></td>
                        </tr>
                        <?php foreach ( (array) $team_context['members'] as $seat ) : ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html( $seat['name'] ?: $seat['email'] ); ?></strong>
                                    <?php if ( ! empty( $seat['name'] ) ) : ?><br><span class="awg-mem-account-help"><?php echo esc_html( $seat['email'] ); ?></span><?php endif; ?>
                                </td>
                                <td><?php echo esc_html( ucfirst( str_replace( '_', ' ', (string) $seat['status'] ) ) ); ?></td>
                                <td><button type="button" class="awg-mem-btn awg-mem-btn--xs awg-mem-team-remove" data-seat-id="<?php echo esc_attr( $seat['id'] ); ?>"><?php esc_html_e( 'Remove', 'authorwings-membership' ); ?></button></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endif; ?>
            </div>
        <?php else : ?>
            <div class="awg-mem-account-card awg-mem-account-card--wide">
                <div class="awg-mem-account-card__label"><?php esc_html_e( 'Team Workspace', 'authorwings-membership' ); ?></div>
                <p class="awg-mem-account-help"><?php esc_html_e( 'Team seats are available on the Publisher plan. Upgrade to Publisher to invite team members by email and manage a shared workspace.', 'authorwings-membership' ); ?></p>
            </div>
        <?php endif; ?>

        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Usage Snapshot', 'authorwings-membership' ); ?></h3>
        <div class="awg-mem-account-card awg-mem-account-card--wide">
            <div class="awg-mem-account-card__label"><?php esc_html_e( 'This Month', 'authorwings-membership' ); ?></div>
            <table class="awg-mem-info-table">
                <tr>
                    <td><?php esc_html_e( 'AI generations used', 'authorwings-membership' ); ?></td>
                    <td><?php echo esc_html( $ai_limit < 0 ? sprintf( __( '%d used · unlimited plan', 'authorwings-membership' ), $ai_used ) : sprintf( __( '%1$d of %2$d used', 'authorwings-membership' ), $ai_used, $ai_limit ) ); ?></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Renewal state', 'authorwings-membership' ); ?></td>
                    <td><?php echo esc_html( $renewal_state_label ); ?></td>
                </tr>
                <tr>
                    <td><?php esc_html_e( 'Seat summary', 'authorwings-membership' ); ?></td>
                    <td><?php echo esc_html( $seat_usage_label ); ?></td>
                </tr>
            </table>
            <?php if ( ! empty( $workspace_usage_rows ) ) : ?>
                <div class="awg-mem-account-card__label" style="margin-top:18px;"><?php esc_html_e( 'Workspace usage breakdown', 'authorwings-membership' ); ?></div>
                <table class="awg-mem-info-table awg-mem-team-table">
                    <tr>
                        <td><?php esc_html_e( 'Member', 'authorwings-membership' ); ?></td>
                        <td><?php esc_html_e( 'Runs this month', 'authorwings-membership' ); ?></td>
                        <td><?php esc_html_e( 'Last used', 'authorwings-membership' ); ?></td>
                    </tr>
                    <?php foreach ( $workspace_usage_rows as $usage_row ) : ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html( $usage_row['name'] ); ?></strong>
                                <?php if ( ! empty( $usage_row['email'] ) ) : ?><br><span class="awg-mem-account-help"><?php echo esc_html( $usage_row['email'] ); ?></span><?php endif; ?>
                            </td>
                            <td><?php echo esc_html( (int) $usage_row['run_count'] ); ?></td>
                            <td><?php echo ! empty( $usage_row['last_used'] ) ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $usage_row['last_used'] ) ) ) : esc_html__( 'Not available', 'authorwings-membership' ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
            <?php if ( ! empty( $GLOBALS['awg_mem_recent_tools_placeholder'] ) ) : ?><?php endif; ?>
        </div>

        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Your Info', 'authorwings-membership' ); ?></h3>
        <table class="awg-mem-info-table">
            <tr>
                <td><?php esc_html_e( 'Name', 'authorwings-membership' ); ?></td>
                <td><?php echo esc_html( $user->display_name ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Email', 'authorwings-membership' ); ?></td>
                <td><?php echo esc_html( $user->user_email ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Member since', 'authorwings-membership' ); ?></td>
                <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $user->user_registered ) ) ); ?></td>
            </tr>
        </table>
        <a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>" class="awg-mem-link">
            <?php esc_html_e( 'Edit profile →', 'authorwings-membership' ); ?>
        </a>
        <?php
    }

    private function render_account_notices( ?array $mem, ?array $latest ): void {
        $notices = [];
        $notice_key = isset( $_GET['awg_notice'] ) ? sanitize_key( wp_unslash( $_GET['awg_notice'] ) ) : '';
        $payment    = isset( $_GET['payment'] ) ? sanitize_key( wp_unslash( $_GET['payment'] ) ) : '';
        $cancelled  = isset( $_GET['cancelled'] ) ? sanitize_key( wp_unslash( $_GET['cancelled'] ) ) : '';

        if ( $notice_key === 'plan-updated' ) {
            $notices[] = [ 'success', __( 'Your plan was updated successfully.', 'authorwings-membership' ) ];
        }

        if ( $notice_key === 'cancelled' ) {
            $notices[] = [ 'success', __( 'Your paid membership was cancelled and your account is now on the free plan.', 'authorwings-membership' ) ];
        }

        if ( $payment === 'success' ) {
            if ( $mem && ! empty( $mem['status'] ) && in_array( $mem['status'], [ 'active', 'trialing' ], true ) ) {
                $notices[] = [ 'success', __( 'Payment completed and your membership is active.', 'authorwings-membership' ) ];
            } else {
                $notices[] = [ 'info', __( 'Payment completed. Your membership update may take a moment to appear after Stripe confirms the subscription.', 'authorwings-membership' ) ];
            }
        }

        if ( $cancelled === '1' ) {
            $notices[] = [ 'warning', __( 'Checkout was cancelled. No changes were made to your membership.', 'authorwings-membership' ) ];
        }

        if ( ! $mem && $latest && ! empty( $latest['status'] ) ) {
            if ( $latest['status'] === 'payment_failed' ) {
                $notices[] = [ 'error', __( 'Your last payment failed, so paid access is no longer active. Please choose a plan again to restart billing.', 'authorwings-membership' ) ];
            } elseif ( $latest['status'] === 'expired' ) {
                $notices[] = [ 'warning', __( 'Your previous paid plan expired. You can renew or choose another plan below.', 'authorwings-membership' ) ];
            }
        }

        foreach ( $notices as $notice ) {
            list( $type, $message ) = $notice;
            echo '<div class="awg-mem-alert awg-mem-alert--' . esc_attr( $type ) . '">' . esc_html( $message ) . '</div>';
        }
    }

    private function render_login_prompt(): string {
        ob_start();
        ?>
        <div class="awg-mem-login-prompt">
            <span class="dashicons dashicons-lock"></span>
            <h2><?php esc_html_e( 'Please log in to access your dashboard', 'authorwings-membership' ); ?></h2>
            <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="awg-mem-btn awg-mem-btn--primary">
                <?php esc_html_e( 'Log In', 'authorwings-membership' ); ?>
            </a>
            <p>
                <?php esc_html_e( 'Don\'t have an account?', 'authorwings-membership' ); ?>
                <a href="<?php echo esc_url( wp_registration_url() ); ?>">
                    <?php esc_html_e( 'Register free', 'authorwings-membership' ); ?>
                </a>
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

    // -------------------------------------------------------
    // AJAX handlers
    // -------------------------------------------------------

    /**
     * AJAX: render the [awg_generator id="X"] shortcode server-side
     * and return the HTML so the tool modal can display it.
     *
     * Also signals the AI plugin's Assets class to enqueue its
     * front-end scripts/styles on this request via the
     * awg_aig_enqueue_assets filter (picked up by wp_footer).
     */
    public function ajax_get_tool_html(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }

        $template_id = (int) ( $_POST['template_id'] ?? 0 );
        if ( $template_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Invalid tool.', 'authorwings-membership' ) ], 400 );
        }

        // Verify the template exists and is an AI plugin template
        $post = get_post( $template_id );
        if ( ! $post || $post->post_type !== 'awg_ai_template' || $post->post_status !== 'publish' ) {
            wp_send_json_error( [ 'message' => __( 'Tool not found.', 'authorwings-membership' ) ], 404 );
        }

        // Standardized visibility check via the AI plugin filter hook
        $user_id   = get_current_user_id();
        $required_plan = get_post_meta( $template_id, '_awg_mem_required_plan', true ) ?: 'free';
        $visible   = apply_filters( 'awg_aig_visible_templates', [ $post ], $user_id );

        if ( empty( $visible ) ) {
            wp_send_json_error( [
                'message' => sprintf(
                    __( 'This tool is locked for your current membership. It requires the %s plan or higher.', 'authorwings-membership' ),
                    ucfirst( $required_plan )
                ),
                'upgrade_url' => URLs::upgrade( $required_plan !== 'free' ? $required_plan : 'basic' ),
                'upgrade_label' => __( 'Upgrade your plan', 'authorwings-membership' ),
            ], 403 );
        }

        // Render shortcode — the AI plugin's Renderer::shortcode() handles this
        $html = do_shortcode( '[awg_generator id="' . $template_id . '"]' );

        if ( empty( trim( $html ) ) ) {
            wp_send_json_error( [ 'message' => __( 'Could not render tool. Is the AuthorWings AI plugin active?', 'authorwings-membership' ) ] );
        }

        // Return the rendered HTML plus any inline scripts the AI plugin needs
        // front.js is already enqueued on the page (via awg_aig_enqueue_assets filter
        // in class-assets.php), so we only need to return the form HTML.
        wp_send_json_success( [
            'html'        => $html,
            'template_id' => $template_id,
            'title'       => get_the_title( $template_id ),
        ] );
    }

    public function ajax_get_data(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 401 );
        }
        $user_id  = get_current_user_id();
        $limits   = $this->memberships->get_user_limits( $user_id );
        $usage    = $this->usage->get_all_for_user( $user_id );
        $plan     = $this->memberships->get_user_plan_slug( $user_id );
        wp_send_json_success( compact( 'limits', 'usage', 'plan' ) );
    }

    public function ajax_get_history(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 401 );
        }

        $user_id  = get_current_user_id();
        $page     = max( 1, (int) ( $_POST['page'] ?? 1 ) );
        $history  = $this->get_history_page( $user_id, $page, 12 );

        ob_start();
        $this->render_history_items( $history['items'] );
        $html = ob_get_clean();

        wp_send_json_success( [
            'html'     => $html,
            'items'    => $history['items'],
            'page'     => $history['page'],
            'has_more' => $history['has_more'],
            'total'    => $history['total'],
        ] );
    }

    // -------------------------------------------------------
    // Helpers
    // -------------------------------------------------------

    /**
     * Fetch all published AI templates from the database and normalise them
     * into the shape render_tools_panel() expects.
     *
     * Reads from the awg_ai_template CPT (AuthorWings AI plugin).
     * Required plan stored as _awg_mem_required_plan post meta (set in AI plugin
     * template editor when membership plugin is active).
     * Category stored as _awg_mem_category post meta (optional — defaults to "AI Tools").
     */
    private function get_tool_definitions(): array {
        // AI plugin CPT must be registered
        if ( ! post_type_exists( 'awg_ai_template' ) ) {
            return [];
        }

        $posts = get_posts( [
            'post_type'      => 'awg_ai_template',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
            'no_found_rows'  => true,
        ] );

        if ( empty( $posts ) ) {
            return [];
        }

        $tools = [];

        foreach ( $posts as $post ) {
            // Read the AI plugin meta blob (_awg_aig_template stores all settings)
            $meta = get_post_meta( $post->ID, '_awg_aig_template', true );
            if ( ! is_array( $meta ) ) {
                $meta = [];
            }

            // Required plan — set via the "Required Membership Plan" field
            // in the AI plugin template editor (added in v5.2.0).
            // Defaults to free so templates without the field are visible to all.
            $required_plan = get_post_meta( $post->ID, '_awg_mem_required_plan', true );
            if ( ! in_array( $required_plan, [ 'free', 'basic', 'pro', 'publisher' ], true ) ) {
                $required_plan = 'free';
            }

            // Name: use the template's form_title, fall back to WordPress post title
            $name = trim( (string) ( $meta['form_title'] ?? '' ) );
            if ( $name === '' ) {
                $name = get_the_title( $post->ID );
            }

            // Description: form_description from the template meta
            $description = trim( (string) ( $meta['form_description'] ?? '' ) );

            // Icon: title_icon_class set in template editor, defaults to lightbulb
            $icon = trim( (string) ( $meta['title_icon_class'] ?? '' ) );
            if ( $icon === '' ) {
                $icon = 'dashicons-lightbulb';
            }

            // Category: optional _awg_mem_category meta for grouping in dashboard.
            // Set it directly in wp-admin via Quick Edit or a custom field.
            // If empty, all templates appear under a single "AI Tools" group.
            $category = trim( (string) get_post_meta( $post->ID, '_awg_mem_category', true ) );
            if ( $category === '' ) {
                $category = __( 'AI Tools', 'authorwings-membership' );
            }

            $tools[] = [
                'template_id' => $post->ID,
                'name'        => $name,
                'description' => $description,
                'icon'        => $icon,
                'plan'        => $required_plan,
                'category'    => $category,
            ];
        }

        return $tools;
    }
}
