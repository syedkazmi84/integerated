=== AuthorWings Membership ===
Author: AuthorWings
Author URI: https://authorwings.com
Requires at least: 6.0
Requires PHP: 7.4
Version: 2.3.1
License: GPLv2 or later

== Description ==
Membership plans, user dashboard, usage gating, and publishing services for AuthorWings.com.

Works alongside the AuthorWings AI plugin (v5.7.0+) to gate AI tool access per plan.

== Features ==
* 4 membership tiers: Free, Basic, Pro, Publisher
* Monthly AI generation limits per plan
* User dashboard with tabs: Home, AI Tools, Services, History, Account
* Professional services listing with quote request form
* Admin panel: member management, orders, plan settings, release self-tests
* Stripe-ready payment integration and webhook handling
* Automatic email notifications
* Pricing page shortcode: [awg_pricing]
* Dashboard shortcode: [awg_dashboard]

== Release Testing ==
A new admin page is included under AW Members → Release Tests.
It runs automated self-tests for:
- usage counting
- membership gate decisions
- history query logic
- plan role mapping

Use RELEASE-CHECKLIST.md and MIGRATION-CHECKLIST.md in this plugin folder for the full pre-release and upgrade process.

== Changelog ==
= 2.3.1 =
* Phase 8 completed: dashboard tab ARIA wiring, keyboard tab navigation, accessible usage donut labels, team invite field label, live-region status messages, and stronger focus visibility.

= 2.2.4 =
* Phase 1 audit and safe refactor setup
* Added architecture and UI touchpoint audit docs
* Added additive helper scaffolds for future JS and CSS work
* Kept runtime behavior unchanged in this phase

= 2.1.0 =
* Phase 10 release preparation update
* Added admin self-test runner for key membership logic
* Added release and migration checklists
* Updated versioning and packaging metadata

= 2.0.0 =
* Phase 9 UX and content polish update
* Improved dashboard polish, locked-tool prompts, services request flow, and HTML emails

== Shortcodes ==
[awg_dashboard]  — Full user dashboard (put on /member-dashboard/ page)
[awg_pricing]    — Pricing comparison table (put on /pricing/ page)
