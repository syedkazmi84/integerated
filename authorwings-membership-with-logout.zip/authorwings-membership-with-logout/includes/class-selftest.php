<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class SelfTest {

    /** @var Memberships */
    private $memberships;

    /** @var Usage */
    private $usage;

    public function __construct( Memberships $memberships, Usage $usage ) {
        $this->memberships = $memberships;
        $this->usage       = $usage;
    }

    public function run_all( int $admin_user_id = 0 ): array {
        $tests = [];
        $tests[] = $this->test_role_mapping();
        $tests[] = $this->test_history_query_logic();
        $tests[] = $this->test_usage_counting( $admin_user_id );
        $tests[] = $this->test_gate_decisions();

        $passed = true;
        foreach ( $tests as $test ) {
            if ( empty( $test['passed'] ) ) {
                $passed = false;
                break;
            }
        }

        return [
            'passed' => $passed,
            'tests'  => $tests,
        ];
    }

    private function result( string $name, bool $passed, string $message ): array {
        return [
            'name'    => $name,
            'passed'  => $passed,
            'message' => $message,
        ];
    }

    private function test_role_mapping(): array {
        $checks = [
            Roles::slug_to_role( 'free' ) === Roles::FREE,
            Roles::slug_to_role( 'basic' ) === Roles::BASIC,
            Roles::slug_to_role( 'pro' ) === Roles::PRO,
            Roles::slug_to_role( 'publisher' ) === Roles::PUBLISHER,
            Roles::level( Roles::FREE ) < Roles::level( Roles::BASIC ),
            Roles::level( Roles::BASIC ) < Roles::level( Roles::PRO ),
            Roles::level( Roles::PRO ) < Roles::level( Roles::PUBLISHER ),
        ];

        return $this->result(
            __( 'Role mapping and hierarchy', 'authorwings-membership' ),
            ! in_array( false, $checks, true ),
            __( 'Verified plan slug to role mapping and ascending access hierarchy.', 'authorwings-membership' )
        );
    }

    private function test_history_query_logic(): array {
        $args       = Dashboard::build_history_query_args( 123, 456, 2, 15 );
        $meta_query = $args['meta_query'] ?? [];
        $passed     = isset( $args['post_type'], $args['posts_per_page'], $args['paged'] )
            && $args['post_type'] === 'awg_ai_submission'
            && (int) $args['posts_per_page'] === 15
            && (int) $args['paged'] === 2
            && isset( $meta_query[0]['relation'] )
            && $meta_query[0]['relation'] === 'OR';

        if ( isset( $meta_query[1]['key'], $meta_query[1]['value'], $meta_query[2]['key'], $meta_query[2]['value'] ) ) {
            $passed = $passed
                && $meta_query[1]['key'] === '_awg_aig_user_id'
                && (int) $meta_query[1]['value'] === 123
                && $meta_query[2]['key'] === '_awg_aig_owner_user_id'
                && (int) $meta_query[2]['value'] === 456;
        } else {
            $passed = false;
        }

        return $this->result(
            __( 'History query logic', 'authorwings-membership' ),
            $passed,
            __( 'Verified that history queries include both actor and workspace-owner submission keys.', 'authorwings-membership' )
        );
    }

    private function test_usage_counting( int $admin_user_id ): array {
        global $wpdb;

        if ( $admin_user_id <= 0 ) {
            return $this->result(
                __( 'Usage counting', 'authorwings-membership' ),
                false,
                __( 'No valid admin user was available to run the usage counting self-test.', 'authorwings-membership' )
            );
        }

        $table   = Database::usage_table();
        $slug    = 'selftest_' . wp_generate_password( 8, false, false );
        $period  = Usage::current_period();
        $before  = $this->usage->get( $admin_user_id, $slug );
        $this->usage->increment( $admin_user_id, $slug );
        $after   = $this->usage->get( $admin_user_id, $slug );
        $wpdb->delete( $table, [ 'user_id' => $admin_user_id, 'service_slug' => $slug, 'period' => $period ], [ '%d', '%s', '%s' ] );

        return $this->result(
            __( 'Usage counting', 'authorwings-membership' ),
            $after === ( $before + 1 ),
            __( 'Verified that monthly usage increments once and can be cleaned up safely after the test.', 'authorwings-membership' )
        );
    }

    private function test_gate_decisions(): array {
        $memberships = new class extends Memberships {
            public $limits = [ 'ai_generations_per_month' => 2 ];
            public $plan_slug = 'basic';
            public function get_user_limits( int $user_id ): array { return $this->limits; }
            public function get_user_plan_slug( int $user_id ): string { return $this->plan_slug; }
            public function get_usage_owner_id( int $user_id ): int { return $user_id; }
        };

        $usage = new class extends Usage {
            public $allow = true;
            public function can_use( int $user_id, string $service_slug, int $limit ): bool { return $this->allow; }
        };

        $gate = new AI_Gate( $memberships, $usage );
        $allowed = $gate->check_can_generate( true, 99, 55 ) === true;

        $usage->allow = false;
        $blocked = $gate->check_can_generate( true, 99, 55 );
        $blocked_ok = is_wp_error( $blocked ) && $blocked->get_error_code() === 'awg_mem_limit_reached';

        return $this->result(
            __( 'Membership gate decisions', 'authorwings-membership' ),
            $allowed && $blocked_ok,
            __( 'Verified that allowed generations pass through and over-limit requests return the expected blocking error.', 'authorwings-membership' )
        );
    }
}
