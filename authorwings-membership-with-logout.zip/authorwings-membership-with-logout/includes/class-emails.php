<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Emails {

    public function __construct() {
        add_action( 'awg_mem_plan_changed',    [ $this, 'on_plan_changed' ],    10, 2 );
        add_action( 'awg_mem_cancelled',       [ $this, 'on_cancelled' ],       10, 1 );
        add_action( 'awg_mem_payment_failed',  [ $this, 'on_payment_failed' ],  10, 1 );
        add_action( 'awg_mem_expired',         [ $this, 'on_expired' ],         10, 1 );
        add_action( 'awg_mem_service_ordered', [ $this, 'on_service_ordered' ], 10, 3 );
        add_action( 'awg_mem_team_invited',    [ $this, 'on_team_invited' ],    10, 4 );
        add_action( 'user_register',           [ $this, 'on_register' ],        10, 1 );
    }

    public function on_register( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        $subject = sprintf( __( 'Welcome to AuthorWings, %s!', 'authorwings-membership' ), $user->display_name );
        $intro   = sprintf( __( 'Hi %s, your AuthorWings account is ready.', 'authorwings-membership' ), $user->display_name );
        $lines   = [
            __( 'You are now on the Free plan and can start using available tools right away.', 'authorwings-membership' ),
            __( 'Use your dashboard to review your plan, monthly AI usage, services, and upgrade options.', 'authorwings-membership' ),
        ];

        $this->send( $user->user_email, $subject, [
            'eyebrow'     => __( 'Welcome', 'authorwings-membership' ),
            'title'       => __( 'Your account is ready', 'authorwings-membership' ),
            'intro'       => $intro,
            'lines'       => $lines,
            'primary_cta' => [ 'label' => __( 'Open Dashboard', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
            'secondary_cta'=> [ 'label' => __( 'View Pricing', 'authorwings-membership' ), 'url' => URLs::pricing() ],
            'footer_note' => __( 'Need help choosing a plan? Reply to this email or contact support from your dashboard.', 'authorwings-membership' ),
        ] );
    }

    public function on_plan_changed( int $user_id, int $plan_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        global $wpdb;
        $pt   = Database::plans_table();
        $mt   = Database::mems_table();
        $plan = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pt} WHERE id = %d", $plan_id ), ARRAY_A );
        if ( ! $plan ) { return; }
        $mem  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$mt} WHERE user_id = %d ORDER BY id DESC LIMIT 1", $user_id ), ARRAY_A );

        $subject = sprintf( __( 'Your AuthorWings plan is now %s', 'authorwings-membership' ), $plan['name'] );
        $lines   = [
            sprintf( __( 'Current plan: %s', 'authorwings-membership' ), $plan['name'] ),
        ];
        if ( ! empty( $mem['billing_cycle'] ) ) {
            $lines[] = sprintf( __( 'Billing period: %s', 'authorwings-membership' ), ucfirst( (string) $mem['billing_cycle'] ) );
        }
        if ( ! empty( $mem['end_date'] ) && empty( $plan['is_free'] ) ) {
            $lines[] = sprintf( __( 'Next renewal date: %s', 'authorwings-membership' ), wp_date( get_option( 'date_format' ), strtotime( (string) $mem['end_date'] ) ) );
        }
        $lines[] = __( 'You can manage your plan, usage, and billing actions from your dashboard.', 'authorwings-membership' );

        $this->send( $user->user_email, $subject, [
            'eyebrow'     => __( 'Plan updated', 'authorwings-membership' ),
            'title'       => sprintf( __( 'Your plan changed to %s', 'authorwings-membership' ), $plan['name'] ),
            'intro'       => sprintf( __( 'Hi %s, your membership update is complete.', 'authorwings-membership' ), $user->display_name ),
            'lines'       => $lines,
            'primary_cta' => [ 'label' => __( 'Manage Account', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
            'secondary_cta'=> [ 'label' => __( 'View Pricing', 'authorwings-membership' ), 'url' => URLs::pricing() ],
        ] );

        $s = get_option( Plugin::OPT, [] );
        $admin_email = $s['notify_admin_email'] ?? get_option( 'admin_email' );
        $this->send( $admin_email, sprintf( 'Plan upgraded: %s → %s', $user->user_email, $plan['name'] ), [
            'eyebrow' => 'Admin notification',
            'title'   => 'Plan updated',
            'intro'   => sprintf( 'User %s (%s) changed to the %s plan.', $user->display_name, $user->user_email, $plan['name'] ),
            'lines'   => [],
            'primary_cta' => [ 'label' => 'Open dashboard', 'url' => URLs::dashboard() ],
        ] );
    }

    public function on_cancelled( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        $subject = __( 'Your AuthorWings membership has been cancelled', 'authorwings-membership' );
        $this->send( $user->user_email, $subject, [
            'eyebrow'     => __( 'Billing update', 'authorwings-membership' ),
            'title'       => __( 'Your paid plan has been cancelled', 'authorwings-membership' ),
            'intro'       => sprintf( __( 'Hi %s, your paid membership is no longer active.', 'authorwings-membership' ), $user->display_name ),
            'lines'       => [
                __( 'Your account has been moved back to the Free plan.', 'authorwings-membership' ),
                __( 'You can restart a paid plan any time from your dashboard.', 'authorwings-membership' ),
            ],
            'primary_cta' => [ 'label' => __( 'Reactivate from Dashboard', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
            'secondary_cta'=> [ 'label' => __( 'Compare Plans', 'authorwings-membership' ), 'url' => URLs::pricing() ],
        ] );
    }

    public function on_payment_failed( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        $subject = __( 'Payment issue on your AuthorWings membership', 'authorwings-membership' );
        $this->send( $user->user_email, $subject, [
            'eyebrow'     => __( 'Action needed', 'authorwings-membership' ),
            'title'       => __( 'We could not process your last payment', 'authorwings-membership' ),
            'intro'       => sprintf( __( 'Hi %s, your last payment failed, so paid access is no longer active.', 'authorwings-membership' ), $user->display_name ),
            'lines'       => [
                __( 'Please choose a plan again to restart billing and restore paid access.', 'authorwings-membership' ),
                __( 'Your dashboard will also show this payment warning until billing is active again.', 'authorwings-membership' ),
            ],
            'primary_cta' => [ 'label' => __( 'Fix Billing', 'authorwings-membership' ), 'url' => URLs::pricing() ],
            'secondary_cta'=> [ 'label' => __( 'Open Dashboard', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
        ] );
    }

    public function on_expired( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        $subject = __( 'Your AuthorWings membership has expired', 'authorwings-membership' );
        $this->send( $user->user_email, $subject, [
            'eyebrow'     => __( 'Membership expired', 'authorwings-membership' ),
            'title'       => __( 'Your paid access has expired', 'authorwings-membership' ),
            'intro'       => sprintf( __( 'Hi %s, your previous plan has expired.', 'authorwings-membership' ), $user->display_name ),
            'lines'       => [
                __( 'Your account is now on the Free plan.', 'authorwings-membership' ),
                __( 'Renew or select a new plan to restore paid access and higher limits.', 'authorwings-membership' ),
            ],
            'primary_cta' => [ 'label' => __( 'Renew Plan', 'authorwings-membership' ), 'url' => URLs::pricing() ],
            'secondary_cta'=> [ 'label' => __( 'Open Dashboard', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
        ] );
    }

    public function on_team_invited( int $owner_user_id, string $email, int $member_user_id, string $status ): void {
        $owner = get_userdata( $owner_user_id );
        if ( ! is_email( $email ) ) { return; }

        $owner_name = $owner ? $owner->display_name : __( 'A workspace owner', 'authorwings-membership' );
        $intro = $member_user_id > 0
            ? sprintf( __( 'You have been added to %s’s Publisher workspace.', 'authorwings-membership' ), $owner_name )
            : sprintf( __( '%s invited you to join a Publisher workspace on AuthorWings.', 'authorwings-membership' ), $owner_name );

        $lines = [
            __( 'Team members can use the shared AI workspace, but billing and seat management stay with the workspace owner.', 'authorwings-membership' ),
        ];
        if ( $member_user_id > 0 ) {
            $lines[] = __( 'Sign in with this email address to access the workspace from your dashboard.', 'authorwings-membership' );
        } else {
            $lines[] = __( 'Create an account with this email address, or log in with it, to claim the seat automatically.', 'authorwings-membership' );
        }

        $this->send( $email, __( 'You were invited to an AuthorWings Publisher workspace', 'authorwings-membership' ), [
            'eyebrow'     => __( 'Workspace invitation', 'authorwings-membership' ),
            'title'       => __( 'Your team seat is ready', 'authorwings-membership' ),
            'intro'       => $intro,
            'lines'       => array_merge( $lines, [ sprintf( __( 'Invite status: %s', 'authorwings-membership' ), ucfirst( str_replace( '_', ' ', $status ) ) ) ] ),
            'primary_cta' => [ 'label' => __( 'Open Dashboard', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
            'secondary_cta'=> [ 'label' => __( 'Create Account', 'authorwings-membership' ), 'url' => wp_registration_url() ],
        ] );
    }

    public function on_service_ordered( int $order_id, int $user_id, string $service_slug ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        $subject = __( 'We received your service request — AuthorWings', 'authorwings-membership' );
        $this->send( $user->user_email, $subject, [
            'eyebrow'     => __( 'Service request received', 'authorwings-membership' ),
            'title'       => __( 'Your request is in review', 'authorwings-membership' ),
            'intro'       => sprintf( __( 'Hi %s, thank you for your quote request.', 'authorwings-membership' ), $user->display_name ),
            'lines'       => [
                sprintf( __( 'Quote request number: #%d', 'authorwings-membership' ), $order_id ),
                sprintf( __( 'Requested service: %s', 'authorwings-membership' ), str_replace( '-', ' ', ucwords( $service_slug, '-' ) ) ),
                __( 'Our team will review your quote request and get back to you within 24 hours.', 'authorwings-membership' ),
            ],
            'primary_cta' => [ 'label' => __( 'Open Dashboard', 'authorwings-membership' ), 'url' => URLs::dashboard() ],
        ] );

        $s = get_option( Plugin::OPT, [] );
        $admin_email = $s['notify_admin_email'] ?? get_option( 'admin_email' );
        $this->send( $admin_email, sprintf( 'New quote request #%d from %s', $order_id, $user->user_email ), [
            'eyebrow' => 'Admin notification',
            'title'   => 'New quote request',
            'intro'   => sprintf( 'Quote request #%d from %s (%s).', $order_id, $user->display_name, $user->user_email ),
            'lines'   => [ sprintf( 'Service: %s', $service_slug ) ],
            'primary_cta' => [ 'label' => 'View in admin', 'url' => admin_url( 'admin.php?page=awg-membership-orders' ) ],
        ] );
    }

    private function send( string $to, string $subject, array $payload ): void {
        $site  = get_bloginfo( 'name' );
        $brand = home_url( '/' );

        $eyebrow = (string) ( $payload['eyebrow'] ?? '' );
        $title   = (string) ( $payload['title'] ?? $subject );
        $intro   = (string) ( $payload['intro'] ?? '' );
        $lines   = array_values( array_filter( array_map( 'strval', (array) ( $payload['lines'] ?? [] ) ) ) );
        $primary = is_array( $payload['primary_cta'] ?? null ) ? $payload['primary_cta'] : [];
        $secondary = is_array( $payload['secondary_cta'] ?? null ) ? $payload['secondary_cta'] : [];
        $footer_note = (string) ( $payload['footer_note'] ?? '' );

        $body_lines = '';
        foreach ( $lines as $line ) {
            $body_lines .= '<li style="margin:0 0 10px 0;">' . esc_html( $line ) . '</li>';
        }

        $primary_html = '';
        if ( ! empty( $primary['url'] ) && ! empty( $primary['label'] ) ) {
            $primary_html = '<a href="' . esc_url( (string) $primary['url'] ) . '" style="display:inline-block;background:#1d4ed8;color:#ffffff;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:700;">' . esc_html( (string) $primary['label'] ) . '</a>';
        }

        $secondary_html = '';
        if ( ! empty( $secondary['url'] ) && ! empty( $secondary['label'] ) ) {
            $secondary_html = '<a href="' . esc_url( (string) $secondary['url'] ) . '" style="display:inline-block;margin-left:10px;color:#1d4ed8;text-decoration:none;font-weight:600;">' . esc_html( (string) $secondary['label'] ) . '</a>';
        }

        $body = '
        <div style="margin:0;padding:24px;background:#f5f8fc;font-family:Arial,sans-serif;color:#0f172a;">
            <div style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #dbe7f5;border-radius:16px;overflow:hidden;box-shadow:0 12px 30px rgba(15,23,42,.06);">
                <div style="padding:20px 24px;background:#0f172a;color:#ffffff;">
                    <div style="font-size:20px;font-weight:700;">' . esc_html( $site ) . '</div>
                    <div style="font-size:13px;opacity:.82;margin-top:4px;">Author services and member updates</div>
                </div>
                <div style="padding:24px;line-height:1.7;font-size:15px;">
                    ' . ( $eyebrow !== '' ? '<div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#1d4ed8;font-weight:700;margin-bottom:8px;">' . esc_html( $eyebrow ) . '</div>' : '' ) . '
                    <h1 style="margin:0 0 12px 0;font-size:28px;line-height:1.25;color:#0f172a;">' . esc_html( $title ) . '</h1>
                    ' . ( $intro !== '' ? '<p style="margin:0 0 16px 0;">' . esc_html( $intro ) . '</p>' : '' ) . '
                    ' . ( $body_lines !== '' ? '<ul style="padding-left:18px;margin:0 0 20px 0;">' . $body_lines . '</ul>' : '' ) . '
                    ' . ( $primary_html || $secondary_html ? '<div style="margin-top:20px;">' . $primary_html . $secondary_html . '</div>' : '' ) . '
                </div>
                <div style="padding:16px 24px;background:#f8fbff;border-top:1px solid #dbe7f5;font-size:12px;color:#64748b;">
                    ' . ( $footer_note !== '' ? '<div style="margin-bottom:8px;">' . esc_html( $footer_note ) . '</div>' : '' ) . '
                    This message was sent by ' . esc_html( $site ) . '.<br>
                    <a href="' . esc_url( $brand ) . '" style="color:#1d4ed8;text-decoration:none;">Visit website</a>
                </div>
            </div>
        </div>';
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        wp_mail( $to, "[{$site}] {$subject}", $body, $headers );
    }
}
