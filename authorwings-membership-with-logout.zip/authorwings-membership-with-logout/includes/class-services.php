<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Services {

    public const CPT = 'awg_service';
    public const NONCE = 'awg_service_save';

    /**
     * Get normalized service categories used in admin and front-end grouping.
     */
    private function get_category_options(): array {
        return [
            'general'    => __( 'General', 'authorwings-membership' ),
            'editing'    => __( 'Editing', 'authorwings-membership' ),
            'publishing' => __( 'Publishing', 'authorwings-membership' ),
            'marketing'  => __( 'Marketing', 'authorwings-membership' ),
            'design'     => __( 'Design', 'authorwings-membership' ),
            'author'     => __( 'Author Support', 'authorwings-membership' ),
        ];
    }

    /**
     * Normalize legacy or custom category values to controlled keys.
     */
    private function normalize_category( string $category ): string {
        $category = sanitize_key( $category );
        $options  = $this->get_category_options();

        if ( isset( $options[ $category ] ) ) {
            return $category;
        }

        return 'general';
    }

    /**
     * Get the short description to show on service cards.
     */
    private function get_short_description( int $post_id, string $content = '' ): string {
        $short = (string) get_post_meta( $post_id, '_awg_svc_short_description', true );
        $short = trim( wp_strip_all_tags( $short ) );

        if ( $short !== '' ) {
            return $short;
        }

        $content = trim( wp_strip_all_tags( $content ) );
        if ( $content === '' ) {
            return '';
        }

        return wp_trim_words( $content, 28 );
    }


    /**
     * Get the full service details for the details modal.
     */
    private function get_full_description( int $post_id, string $content = '' ): string {
        $content = trim( (string) $content );

        if ( $content === '' ) {
            $content = (string) get_post_field( 'post_content', $post_id );
        }

        $content = trim( $content );
        if ( $content === '' ) {
            $content = (string) get_post_meta( $post_id, '_awg_svc_short_description', true );
        }

        if ( trim( $content ) === '' ) {
            return '';
        }

        return wp_kses_post( wpautop( $content ) );
    }

    /**
     * Get the human label for a category key.
     */
    public function get_category_label( string $category ): string {
        $category = $this->normalize_category( $category );
        $options  = $this->get_category_options();

        return (string) ( $options[ $category ] ?? $options['general'] );
    }

    public function register_cpt(): void {
        register_post_type( self::CPT, [
            'labels' => [
                'name'          => __( 'Publishing Services', 'authorwings-membership' ),
                'singular_name' => __( 'Publishing Service',  'authorwings-membership' ),
                'add_new_item'  => __( 'Add New Service',     'authorwings-membership' ),
                'edit_item'     => __( 'Edit Service',        'authorwings-membership' ),
            ],
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'supports'     => [ 'title', 'editor', 'thumbnail', 'page-attributes' ],
            'menu_icon'    => 'dashicons-book-alt',
        ] );
    }

    public function register_metaboxes(): void {
        add_meta_box(
            'awg-service-details',
            __( 'Service Details', 'authorwings-membership' ),
            [ $this, 'render_metabox' ],
            self::CPT,
            'normal',
            'high'
        );
    }

    public function render_metabox( \WP_Post $post ): void {
        wp_nonce_field( self::NONCE, 'awg_service_nonce' );
        $category          = $this->normalize_category( (string) get_post_meta( $post->ID, '_awg_svc_category', true ) ?: 'general' );
        $short_description = (string) get_post_meta( $post->ID, '_awg_svc_short_description', true );
        $price_from        = (string) get_post_meta( $post->ID, '_awg_svc_price_from', true );
        $turnaround        = (string) get_post_meta( $post->ID, '_awg_svc_turnaround', true );
        $icon              = (string) get_post_meta( $post->ID, '_awg_svc_icon', true ) ?: 'dashicons-star-filled';
        $featured          = (int) get_post_meta( $post->ID, '_awg_svc_featured', true );
        $button_label      = (string) get_post_meta( $post->ID, '_awg_svc_button_label', true ) ?: __( 'Request Quote', 'authorwings-membership' );
        $button_url        = (string) get_post_meta( $post->ID, '_awg_svc_button_url', true );
        $categories        = $this->get_category_options();
        ?>
        <table class="form-table" role="presentation">
            <tr>
                <th><label for="awg-svc-category"><?php esc_html_e( 'Category', 'authorwings-membership' ); ?></label></th>
                <td>
                    <select id="awg-svc-category" name="awg_service_meta[category]">
                        <?php foreach ( $categories as $value => $label ) : ?>
                            <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $category, $value ); ?>><?php echo esc_html( $label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'Use a predefined category to keep service grouping consistent in the dashboard.', 'authorwings-membership' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="awg-svc-short-description"><?php esc_html_e( 'Short Description', 'authorwings-membership' ); ?></label></th>
                <td>
                    <textarea id="awg-svc-short-description" class="large-text" rows="3" name="awg_service_meta[short_description]" placeholder="<?php esc_attr_e( 'Brief card summary shown on the dashboard service card.', 'authorwings-membership' ); ?>"><?php echo esc_textarea( $short_description ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Recommended for service cards. If left empty, the plugin will use a trimmed fallback from the main content.', 'authorwings-membership' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="awg-svc-price"><?php esc_html_e( 'Price From', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-price" type="text" class="regular-text" name="awg_service_meta[price_from]" value="<?php echo esc_attr( $price_from ); ?>" placeholder="$199"></td>
            </tr>
            <tr>
                <th><label for="awg-svc-turnaround"><?php esc_html_e( 'Turnaround', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-turnaround" type="text" class="regular-text" name="awg_service_meta[turnaround]" value="<?php echo esc_attr( $turnaround ); ?>" placeholder="3-5 business days"></td>
            </tr>
            <tr>
                <th><label for="awg-svc-icon"><?php esc_html_e( 'Dashicon Class', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-icon" type="text" class="regular-text" name="awg_service_meta[icon]" value="<?php echo esc_attr( $icon ); ?>" placeholder="dashicons-format-aside"><p class="description"><?php esc_html_e( 'Use any Dashicons class for dashboard service cards.', 'authorwings-membership' ); ?></p></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Featured', 'authorwings-membership' ); ?></th>
                <td><label><input type="checkbox" name="awg_service_meta[featured]" value="1" <?php checked( $featured, 1 ); ?>> <?php esc_html_e( 'Mark this service as featured', 'authorwings-membership' ); ?></label></td>
            </tr>
            <tr>
                <th><label for="awg-svc-button-label"><?php esc_html_e( 'Button Label', 'authorwings-membership' ); ?></label></th>
                <td>
                    <input id="awg-svc-button-label" type="text" class="regular-text" name="awg_service_meta[button_label]" value="<?php echo esc_attr( $button_label ); ?>" placeholder="<?php esc_attr_e( 'Request Quote', 'authorwings-membership' ); ?>">
                    <p class="description"><?php esc_html_e( 'Optional custom button text for this service card.', 'authorwings-membership' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="awg-svc-button-url"><?php esc_html_e( 'Button URL', 'authorwings-membership' ); ?></label></th>
                <td>
                    <input id="awg-svc-button-url" type="url" class="large-text" name="awg_service_meta[button_url]" value="<?php echo esc_attr( $button_url ); ?>" placeholder="https://example.com/service-page">
                    <p class="description"><?php esc_html_e( 'Leave empty to keep the quote request modal. Add a full URL to send users directly to a dedicated page instead.', 'authorwings-membership' ); ?></p>
                </td>
            </tr>
        </table>
        <p class="description" style="margin-top:12px;"><?php esc_html_e( 'Service image uses the Featured Image panel. If no image is set, the service icon will be shown on the card.', 'authorwings-membership' ); ?></p>
        <?php
    }

    public function save_metabox( int $post_id, $post ): void {
        if ( ! is_object( $post ) || $post->post_type !== self::CPT ) {
            return;
        }
        if ( ! isset( $_POST['awg_service_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_service_nonce'] ) ), self::NONCE ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $meta = isset( $_POST['awg_service_meta'] ) && is_array( $_POST['awg_service_meta'] ) ? wp_unslash( $_POST['awg_service_meta'] ) : [];

        update_post_meta( $post_id, '_awg_svc_category', $this->normalize_category( (string) ( $meta['category'] ?? 'general' ) ) );
        update_post_meta( $post_id, '_awg_svc_short_description', sanitize_textarea_field( $meta['short_description'] ?? '' ) );
        update_post_meta( $post_id, '_awg_svc_price_from', sanitize_text_field( $meta['price_from'] ?? '' ) );
        update_post_meta( $post_id, '_awg_svc_turnaround', sanitize_text_field( $meta['turnaround'] ?? '' ) );
        update_post_meta( $post_id, '_awg_svc_icon', sanitize_html_class( $meta['icon'] ?? 'dashicons-star-filled' ) );
        update_post_meta( $post_id, '_awg_svc_featured', ! empty( $meta['featured'] ) ? 1 : 0 );
        update_post_meta( $post_id, '_awg_svc_button_label', sanitize_text_field( $meta['button_label'] ?? '' ) );
        update_post_meta( $post_id, '_awg_svc_button_url', esc_url_raw( $meta['button_url'] ?? '' ) );

        delete_post_meta( $post_id, '_awg_svc_is_free' );
    }

    /**
     * Get all published services.
     */
    public function get_all(): array {
        $posts = get_posts( [
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ] );

        $services = array_map( function( $p ) {
            $image_url = '';
            if ( has_post_thumbnail( $p->ID ) ) {
                $image_url = (string) get_the_post_thumbnail_url( $p->ID, 'medium' );
            }

            $button_label = trim( (string) get_post_meta( $p->ID, '_awg_svc_button_label', true ) );
            if ( $button_label === '' ) {
                $button_label = __( 'Request Quote', 'authorwings-membership' );
            }

            $category = $this->normalize_category( (string) get_post_meta( $p->ID, '_awg_svc_category', true ) ?: 'general' );

            return [
                'id'                => $p->ID,
                'title'             => $p->post_title,
                'description'       => $this->get_short_description( $p->ID, (string) $p->post_content ),
                'full_description'  => $this->get_full_description( $p->ID, (string) $p->post_content ),
                'slug'              => $p->post_name,
                'category'          => $category,
                'category_label'    => $this->get_category_label( $category ),
                'price_from'        => (string) get_post_meta( $p->ID, '_awg_svc_price_from', true ),
                'turnaround'        => (string) get_post_meta( $p->ID, '_awg_svc_turnaround', true ),
                'icon'              => (string) get_post_meta( $p->ID, '_awg_svc_icon', true ) ?: 'dashicons-star-filled',
                'featured'          => (bool) get_post_meta( $p->ID, '_awg_svc_featured', true ),
                'short_description' => $this->get_short_description( $p->ID, (string) $p->post_content ),
                'button_label'      => $button_label,
                'button_url'        => (string) get_post_meta( $p->ID, '_awg_svc_button_url', true ),
                'image_url'         => $image_url,
            ];
        }, $posts );

        usort( $services, function( array $a, array $b ): int {
            if ( $a['featured'] === $b['featured'] ) {
                return strcasecmp( (string) $a['title'], (string) $b['title'] );
            }

            return $a['featured'] ? -1 : 1;
        } );

        return $services;
    }


    public function add_admin_columns( array $columns ): array {
        $new_columns = [];

        foreach ( $columns as $key => $label ) {
            $new_columns[ $key ] = $label;

            if ( 'title' === $key ) {
                $new_columns['awg_svc_category']   = __( 'Category', 'authorwings-membership' );
                $new_columns['awg_svc_price_from'] = __( 'Price From', 'authorwings-membership' );
                $new_columns['awg_svc_turnaround'] = __( 'Turnaround', 'authorwings-membership' );
                $new_columns['awg_svc_featured']   = __( 'Featured', 'authorwings-membership' );
            }
        }

        return $new_columns;
    }

    public function render_admin_column( string $column, int $post_id ): void {
        switch ( $column ) {
            case 'awg_svc_category':
                echo esc_html( $this->get_category_label( (string) get_post_meta( $post_id, '_awg_svc_category', true ) ) );
                break;

            case 'awg_svc_price_from':
                $price = (string) get_post_meta( $post_id, '_awg_svc_price_from', true );
                echo esc_html( $price !== '' ? $price : '—' );
                break;

            case 'awg_svc_turnaround':
                $turnaround = (string) get_post_meta( $post_id, '_awg_svc_turnaround', true );
                echo esc_html( $turnaround !== '' ? $turnaround : '—' );
                break;

            case 'awg_svc_featured':
                echo esc_html( get_post_meta( $post_id, '_awg_svc_featured', true ) ? __( 'Yes', 'authorwings-membership' ) : __( 'No', 'authorwings-membership' ) );
                break;
        }
    }

    public function ajax_submit_order(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in to submit a quote request.', 'authorwings-membership' ) ], 401 );
        }

        $user_id      = get_current_user_id();
        $service_slug = isset( $_POST['service_slug'] ) ? sanitize_key( wp_unslash( (string) $_POST['service_slug'] ) ) : '';
        $service_name = isset( $_POST['service_name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['service_name'] ) ) : '';
        $notes        = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['notes'] ) ) : '';

        if ( ! $service_slug ) {
            wp_send_json_error( [ 'message' => __( 'Please select a service.', 'authorwings-membership' ) ], 422 );
        }

        $service_post = get_page_by_path( $service_slug, OBJECT, self::CPT );
        if ( ! $service_post instanceof \WP_Post ) {
            wp_send_json_error( [ 'message' => __( 'This service could not be found. Please refresh the page and try again.', 'authorwings-membership' ) ], 404 );
        }

        $service_name = $service_post->post_title ?: $service_name;
        $notes        = trim( $notes );

        if ( '' === $notes || strlen( $notes ) < 20 ) {
            wp_send_json_error( [ 'message' => __( 'Please add a few more project details so our team can prepare the right quote.', 'authorwings-membership' ) ], 422 );
        }

        $dedupe_key = 'awg_mem_quote_submit_' . $user_id . '_' . md5( strtolower( $service_slug . '|' . $notes ) );
        if ( get_transient( $dedupe_key ) ) {
            wp_send_json_error( [ 'message' => __( 'This quote request was already submitted very recently. Please wait a moment before trying again.', 'authorwings-membership' ) ], 429 );
        }

        global $wpdb;
        $table = Database::orders_table();
        $now   = current_time( 'mysql' );
        $meta  = wp_json_encode( [
            'user_email' => wp_get_current_user()->user_email,
        ] );

        $inserted = $wpdb->insert(
            $table,
            [
                'user_id'      => $user_id,
                'service_slug' => $service_slug,
                'service_name' => $service_name,
                'status'       => 'pending',
                'notes'        => $notes,
                'meta'         => $meta,
                'created_at'   => $now,
                'updated_at'   => $now,
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        if ( false === $inserted ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( 'AuthorWings Membership order insert failed: ' . $wpdb->last_error );
            }
            wp_send_json_error( [ 'message' => __( 'Could not submit your quote request right now. Please try again in a moment.', 'authorwings-membership' ) ], 500 );
        }

        $order_id = (int) $wpdb->insert_id;
        set_transient( $dedupe_key, $order_id, 60 );

        do_action( 'awg_mem_service_ordered', $order_id, $user_id, $service_slug );

        wp_send_json_success( [
            'order_id' => $order_id,
            'message'  => sprintf(
                /* translators: %d: order ID */
                __( 'Your quote request has been submitted successfully. Our team will contact you soon. Reference #%d.', 'authorwings-membership' ),
                $order_id
            ),
        ] );
    }
}
