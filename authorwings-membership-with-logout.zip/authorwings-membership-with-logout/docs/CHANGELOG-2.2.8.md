# Changelog 2.2.8

## Phase 5
- added persistent billing mode indicator under the monthly/yearly toggle
- added lightweight animated price updates when billing mode changes
- strengthened current plan card with stronger border and top-right badge
- kept current plan button visible in disabled state instead of replacing it with plain text
- improved locked tool upgrade CTA to support plan highlighting
- added auto-open and pulse highlight for requested plan cards from upgrade links
