# AuthorWings Membership 2.3.0

Phase 7 mobile hardening update.

## Included
- Added dedicated `@media (max-width: 360px)` layout hardening for the member dashboard
- Forced plan cards, service cards, tools, pricing, usage, and account grids to single-column layout on very small screens
- Stacked the monthly/yearly billing toggle vertically on narrow devices
- Reduced modal padding and tightened modal sizing for small-screen usability
- Improved button stacking and overflow handling for account, service, and plan actions
- Added safer width and wrapping rules to prevent horizontal overflow on compact devices
