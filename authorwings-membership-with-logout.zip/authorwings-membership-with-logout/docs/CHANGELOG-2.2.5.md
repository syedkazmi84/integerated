# AuthorWings Membership 2.2.5

## Phase 2 completed

This release implements the critical accessibility and modal reliability work scheduled for Phase 2.

### Included
- Added modal focus trapping for keyboard users
- Added focus restore to the triggering control when a modal closes
- Added shared Escape-key close handling for open modals
- Preserved background scroll lock while any modal remains open
- Added tool loader timeout fallback
- Added retry action inside tool load error state
- Reset the tool trigger button state after load failures and timeout paths

### Files updated
- `assets/js/dashboard.js`
- `includes/class-assets.php`
- `authorwings-membership.php`
- `readme.txt`
