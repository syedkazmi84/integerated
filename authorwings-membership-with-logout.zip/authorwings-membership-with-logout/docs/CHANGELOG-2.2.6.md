# AuthorWings Membership 2.2.6

## Phase 3 completed

This release restructures the Account tab without changing plan logic, billing actions, or seat permissions.

### Changes
- Split the Account tab into clearer sections: Plan & Billing, Team Workspace, Workspace Usage, and Profile
- Moved plan selection into a dedicated modal opened from the Account tab
- Collapsed the owner Team Workspace management area behind a disclosure by default
- Kept current plan, billing health, and seat usage summary visible at the top
- Added supporting layout styles and modal wiring for the new structure

### Files updated
- includes/class-dashboard.php
- assets/css/dashboard.css
- assets/js/dashboard.js
- authorwings-membership.php
- readme.txt
