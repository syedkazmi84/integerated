# Phase 8 - Accessibility completion

Version: 2.3.1

- Added ARIA tablist, tab, and tabpanel relationships for dashboard navigation
- Added keyboard arrow, Home, and End support for tab navigation
- Added accessible progressbar semantics and SVG title/description for the usage donut
- Added screen-reader label for the team invite email field
- Added live region roles to service and team status messages
- Added focus-visible styles for key interactive controls
