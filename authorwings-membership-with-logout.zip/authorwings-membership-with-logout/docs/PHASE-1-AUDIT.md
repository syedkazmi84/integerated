# Phase 1 Audit and Safe Refactor Setup

Version checkpoint: 2.2.4
Scope: non-breaking prep work only.

## Goal
Prepare the plugin for later UX and accessibility updates without changing billing logic, plan logic, dashboard routing, or existing AJAX behavior.

## Dashboard render map

### Entry points
- `authorwings-membership.php`
  - defines plugin version and bootstraps the plugin
- `includes/class-plugin.php`
  - registers shortcodes, AJAX handlers, and runtime services
- `includes/class-assets.php`
  - conditionally loads dashboard and pricing assets
- `includes/class-dashboard.php`
  - renders the `[awg_dashboard]` UI and dashboard modals
- `includes/class-plans.php`
  - renders the `[awg_pricing]` UI

### Front-end assets
- `assets/js/dashboard.js`
  - tab switching
  - modals
  - service request interactions
  - history pagination
  - team invite and removal actions
- `assets/css/dashboard.css`
  - dashboard layout
  - tabs
  - cards
  - plan styles
  - modals
  - team UI
  - responsive behavior

## Dashboard tab map
Source: `includes/class-dashboard.php`

- `home`
- `tools`
- `services`
- `quote-requests`
- `history`
- `account`

## Modal map
Source: `includes/class-dashboard.php`

- `#awg-tool-modal`
  - content target: `#awg-tool-modal-content`
  - close trigger: `#awg-tool-modal-close`
- `#awg-service-details-modal`
  - close trigger: `#awg-service-details-modal-close`
  - secondary action: `#awg-service-details-secondary-action`
- `#awg-service-modal`
  - title target: `#awg-service-modal-title`
  - message target: `#awg-service-modal-msg`
  - close trigger: `#awg-service-modal-close`

## AJAX interaction map

### Dashboard JS callers
- `awg_mem_get_history`
  - load more in History tab
- `awg_mem_get_tool_html`
  - loads tool modal content
- `awg_mem_invite_team_member`
  - team invite action
- `awg_mem_remove_team_member`
  - team seat removal
- quote request AJAX is routed through services logic used by the service modal flow

### Related PHP classes
- `includes/class-memberships.php`
- `includes/class-services.php`
- `includes/class-plans.php`

## Phase 1 reusable JS helper registry
Planned helpers are documented and scaffolded in `assets/js/dashboard.js`.

- modal open/close
- modal state reset
- focus trap slot for later phase
- retry/reset state slot for later phase
- tab switching
- validation feedback slot for later phase
- async button state slot for later phase

## Phase 1 reusable CSS component registry
Planned components are documented and scaffolded in `assets/css/dashboard.css`.

- empty state
- current plan badge
- active billing indicator
- mobile 1-column fallback
- tab transition helper
- shared section shell helper

## Safe refactor notes
- No database schema changes.
- No shortcode names changed.
- No AJAX action names changed.
- No plan, billing, or Stripe behavior changed.
- No existing selectors were renamed in this phase.
- New docs and class hooks are additive only.

## Files reviewed for Phase 1
- `authorwings-membership.php`
- `includes/class-assets.php`
- `includes/class-dashboard.php`
- `includes/class-plugin.php`
- `includes/class-memberships.php`
- `includes/class-services.php`
- `includes/class-plans.php`
- `assets/js/dashboard.js`
- `assets/css/dashboard.css`

## Ready for next phases
This checkpoint prepares the plugin for:
- modal accessibility work
- account tab restructuring
- inline validation improvements
- pricing state improvements
- mobile hardening
- admin contrast validation
