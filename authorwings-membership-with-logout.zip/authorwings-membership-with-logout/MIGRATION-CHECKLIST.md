# AuthorWings Membership Migration Checklist

## Before updating
- Back up files and database
- Export a sample of membership rows, usage rows, and service order rows
- Note the current active plan counts for comparison after upgrade

## After updating
- Confirm all plan records still appear in the admin area
- Confirm the member dashboard loads without PHP notices
- Confirm history tab still returns results for existing submissions
- Confirm existing Stripe customer and subscription identifiers remain intact
- Confirm active members keep the correct WordPress role after upgrade
- Confirm team-seat workspaces still map child users to the owner account
- Run the Release Tests page and save the result screenshot for deployment notes
