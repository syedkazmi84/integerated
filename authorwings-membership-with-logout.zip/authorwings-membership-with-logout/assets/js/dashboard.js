/* AuthorWings Membership — Dashboard JS v1.2.0 */
(function ($) {
    'use strict';

    const cfg   = window.AWG_MEM || {};
    const ajax  = cfg.ajax_url;
    const nonce = cfg.nonce;
    const s     = cfg.strings || {};

    /*
     * Phase 1 safe-refactor registry
     * These groups document the shared helper surface that later phases will
     * formalize without forcing a large rewrite of the existing dashboard.
     */
    const helperRegistry = {
        modal: ['hoistModalsToBody', 'openModal', 'closeModal'],
        tabs: ['initTabs'],
        async: ['initHistoryLoadMore'],
        feedback: ['showServiceMsg'],
        future: ['focusTrap', 'resetModalState', 'setButtonBusy', 'clearValidationState']
    };
    void helperRegistry;

    // ── Helpers ──────────────────────────────────────────────

    /**
     * Move modals to <body> so position:fixed works in every theme.
     * CSS transforms or overflow:hidden on ancestors break fixed positioning —
     * appending to body bypasses all of that.
     */
    function hoistModalsToBody() {
        $('.awg-mem-modal').each(function () {
            if ( $(this).parent().is('body') ) { return; }
            $(this).appendTo('body');
        });
    }

    var modalState = {
        activeModalId: '',
        lastTriggerByModal: {},
        lastActiveElement: null
    };

    function getFocusableElements($modal) {
        return $modal.find('a[href], area[href], input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [contenteditable], [tabindex]:not([tabindex="-1"])')
            .filter(':visible');
    }

    function trapFocus($modal, event) {
        var $focusable = getFocusableElements($modal);
        if (! $focusable.length) {
            event.preventDefault();
            return;
        }

        var first = $focusable.get(0);
        var last  = $focusable.get($focusable.length - 1);
        var active = document.activeElement;

        if (event.shiftKey) {
            if (active === first || ! $modal[0].contains(active)) {
                event.preventDefault();
                last.focus();
            }
            return;
        }

        if (active === last || ! $modal[0].contains(active)) {
            event.preventDefault();
            first.focus();
        }
    }

    function focusModal($modal) {
        var $focusable = getFocusableElements($modal);
        if ($focusable.length) {
            $focusable.get(0).focus();
            return;
        }

        var $box = $modal.find('.awg-mem-modal__box').first();
        if ($box.length) {
            if (! $box.attr('tabindex')) {
                $box.attr('tabindex', '-1');
            }
            $box.get(0).focus();
        }
    }

    function getTopOpenModal() {
        return $('.awg-mem-modal.is-open').last();
    }

    function openModal($modal, options) {
        options = options || {};
        var modalId = $modal.attr('id') || '';
        var trigger = options.trigger || document.activeElement;

        if (modalId) {
            modalState.lastTriggerByModal[modalId] = trigger;
            modalState.activeModalId = modalId;
        }
        modalState.lastActiveElement = trigger;

        $modal.attr('aria-hidden', 'false').addClass('is-open');
        $('body').addClass('awg-modal-open');
        $modal.trigger('awg:modalopened');
        focusModal($modal);
    }

    function closeModal($modal, options) {
        options = options || {};
        var modalId = $modal.attr('id') || '';
        var restoreFocus = options.restoreFocus !== false;
        var fallbackFocus = modalId ? modalState.lastTriggerByModal[modalId] : null;

        $modal.attr('aria-hidden', 'true').removeClass('is-open');

        if ( ! $('.awg-mem-modal.is-open').length ) {
            $('body').removeClass('awg-modal-open');
            modalState.activeModalId = '';
        } else {
            modalState.activeModalId = getTopOpenModal().attr('id') || '';
            focusModal(getTopOpenModal());
        }

        $modal.trigger('awg:modalclosed');

        if (restoreFocus && fallbackFocus && typeof fallbackFocus.focus === 'function') {
            window.setTimeout(function () {
                fallbackFocus.focus();
            }, 0);
        }
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function injectSpinStyle() {
        if ( document.getElementById('awg-spin-style') ) { return; }
        var el = document.createElement('style');
        el.id  = 'awg-spin-style';
        el.textContent = '@keyframes awg-spin{to{transform:rotate(360deg)}}';
        document.head.appendChild(el);
    }


    function initModalA11y() {
        $('.awg-mem-modal').each(function () {
            var $modal = $(this);
            var $box = $modal.find('.awg-mem-modal__box').first();
            var $title = $modal.find('.awg-mem-modal__title').first();
            var titleId = $title.attr('id');

            $modal.attr('aria-hidden', $modal.hasClass('is-open') ? 'false' : 'true');
            if (! $box.attr('role')) {
                $box.attr('role', 'dialog');
            }
            $box.attr('aria-modal', 'true');
            if ($title.length) {
                if (! titleId) {
                    titleId = ($modal.attr('id') || 'awg-modal') + '-title';
                    $title.attr('id', titleId);
                }
                $box.attr('aria-labelledby', titleId);
            }
            if (! $box.attr('tabindex')) {
                $box.attr('tabindex', '-1');
            }
        });

        $(document).off('keydown.awg-modal-a11y').on('keydown.awg-modal-a11y', function (e) {
            var $openModal = getTopOpenModal();
            if (! $openModal.length) {
                return;
            }

            if (e.key === 'Escape') {
                e.preventDefault();
                closeModal($openModal);
                return;
            }

            if (e.key === 'Tab') {
                trapFocus($openModal, e);
            }
        });
    }

    // ── Tab switching ────────────────────────────────────────
    function initTabs() {
        var $tabs   = $('.awg-mem-tab');
        var $panels = $('.awg-mem-panel');

        function activateTab(tab, options) {
            options = options || {};
            $tabs.removeClass('awg-mem-tab--active').attr('aria-selected', 'false').attr('tabindex', '-1');
            $panels.removeClass('awg-mem-panel--active').attr('hidden', true);

            var $activeTab = $tabs.filter('[data-tab="' + tab + '"]');
            var $activePanel = $panels.filter('[data-panel="' + tab + '"]');
            $activeTab.addClass('awg-mem-tab--active').attr('aria-selected', 'true').attr('tabindex', '0');
            $activePanel.addClass('awg-mem-panel--active').removeAttr('hidden');

            if (options.focusTab) {
                $activeTab.trigger('focus');
            }
            if (history.replaceState) {
                history.replaceState(null, '', '#' + tab);
            }
            $(document).trigger('awg:tabchange', [tab]);
        }

        $tabs.on('click', function () { activateTab($(this).data('tab')); });
        $tabs.on('keydown', function (e) {
            var index = $tabs.index(this);
            var nextIndex = index;
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                nextIndex = (index + 1) % $tabs.length;
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                nextIndex = (index - 1 + $tabs.length) % $tabs.length;
            } else if (e.key === 'Home') {
                nextIndex = 0;
            } else if (e.key === 'End') {
                nextIndex = $tabs.length - 1;
            } else {
                return;
            }
            e.preventDefault();
            activateTab($tabs.eq(nextIndex).data('tab'), { focusTab: true });
        });

        $(document).on('click', '.awg-mem-tab-link', function (e) {
            e.preventDefault();
            activateTab($(this).data('tab'));
        });

        var hash = window.location.hash.replace('#', '');
        if (hash && $('.awg-mem-tab[data-tab="' + hash + '"]').length) {
            activateTab(hash);
        }
        var params = new URLSearchParams(window.location.search);
        var tabParam = params.get('tab');
        if (tabParam && $('.awg-mem-tab[data-tab="' + tabParam + '"]').length) {
            activateTab(tabParam);
        }
        if (params.get('upgrade') || params.get('payment') || params.get('cancelled') || params.get('awg_notice')) {
            activateTab('account');
        }
    }


    function initHistoryLoadMore() {
        function setHistorySummary(visible, total) {
            var $summary = $('#awg-mem-history-summary');
            if (!$summary.length || !total) {
                return;
            }
            $summary.attr('data-visible', visible).attr('data-total', total).text('Showing ' + visible + ' of ' + total + ' submissions');
        }

        $(document).on('click', '#awg-mem-history-load-more', function () {
            var $btn = $(this);
            var $label = $btn.find('.awg-mem-btn__label');
            var nextPage = parseInt($btn.attr('data-page') || '1', 10) + 1;
            $btn.prop('disabled', true).addClass('is-loading');
            if ($label.length) {
                $label.text('Loading…');
            }

            $.post(ajax, {
                action: 'awg_mem_get_history',
                nonce: nonce,
                page: nextPage
            })
            .done(function (res) {
                if (!res.success || !res.data) {
                    $btn.prop('disabled', false).removeClass('is-loading');
                    if ($label.length) {
                        $label.text('Load More');
                    }
                    return;
                }

                var $items = $(res.data.html).find('.awg-mem-history-item');
                $('#awg-mem-history-wrap .awg-mem-history-list').append($items);
                $btn.attr('data-page', res.data.page);

                var visible = $('#awg-mem-history-wrap .awg-mem-history-item').length;
                setHistorySummary(visible, parseInt(res.data.total || visible, 10));

                if (res.data.has_more) {
                    $btn.prop('disabled', false).removeClass('is-loading');
                    if ($label.length) {
                        $label.text('Load More');
                    }
                } else {
                    $btn.remove();
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).removeClass('is-loading');
                if ($label.length) {
                    $label.text('Load More');
                }
            });
        });
    }

    // ── Tool modal ───────────────────────────────────────────
    function initToolModal() {
        var $modal   = $('#awg-tool-modal');
        var $content = $('#awg-tool-modal-content');
        var $title   = $modal.find('.awg-mem-modal__title');
        var pendingRequest = null;
        var pendingTimeout = 0;
        var currentTemplateId = 0;
        var currentTrigger = null;

        function resetToolButton($btn) {
            if (! $btn || ! $btn.length) {
                return;
            }
            var originalText = $btn.data('original-text') || 'Use Tool';
            $btn.prop('disabled', false).removeAttr('aria-busy').text(originalText);
        }

        function setToolButtonBusy($btn) {
            if (! $btn || ! $btn.length) {
                return;
            }
            if (! $btn.data('original-text')) {
                $btn.data('original-text', $.trim($btn.text()) || 'Use Tool');
            }
            $btn.prop('disabled', true).attr('aria-busy', 'true').text(s.tool_loading || 'Loading tool…');
        }

        function clearToolRequestState() {
            if (pendingTimeout) {
                window.clearTimeout(pendingTimeout);
                pendingTimeout = 0;
            }
            if (pendingRequest && typeof pendingRequest.abort === 'function') {
                pendingRequest.abort();
            }
            pendingRequest = null;
        }

        function buildRetryMarkup(message, includeShortcode) {
            var retryLabel = escHtml(s.try_again || 'Try Again');
            var html =
                '<div class="awg-mem-tool-error" style="padding:28px 24px;">' +
                '<p style="color:#991b1b;font-size:14px;margin:0 0 12px;">' + escHtml(message) + '</p>' +
                '<p style="margin:0;"><a href="#" class="awg-mem-tool-retry">' + retryLabel + '</a></p>';

            if (includeShortcode && currentTemplateId > 0) {
                html += '<p style="font-size:13px;color:#6b7280;margin:14px 0 0;">You can also add this tool to any page with the shortcode:<br>' +
                    '<code style="background:#f3f4f6;padding:3px 7px;border-radius:4px;font-size:12px;">[awg_generator id="' + parseInt(currentTemplateId, 10) + '"]</code></p>';
            }

            html += '</div>';
            return html;
        }

        function renderToolError(message, extraHtml) {
            var html = buildRetryMarkup(message, true);
            if (extraHtml) {
                html = html.replace('</div>', extraHtml + '</div>');
            }
            $content.html(html);
            resetToolButton(currentTrigger);
        }

        function resetToolModal(options) {
            options = options || {};
            clearToolRequestState();
            $content.html('');
            $title.text('');
            if (options.resetButton !== false) {
                resetToolButton(currentTrigger);
            }
        }

        function requestToolHtml(templateId, $trigger) {
            currentTemplateId = parseInt(templateId, 10) || 0;
            currentTrigger = $trigger && $trigger.length ? $trigger : currentTrigger;
            if (! currentTemplateId) {
                return;
            }

            clearToolRequestState();
            setToolButtonBusy(currentTrigger);

            $content.html(
                '<div style="padding:48px 24px;text-align:center;color:#6b7280;">' +
                '<span class="dashicons dashicons-update-alt" style="font-size:36px;width:36px;height:36px;display:inline-block;animation:awg-spin 1s linear infinite;"></span>' +
                '<p style="margin:14px 0 0;font-size:14px;">' + escHtml(s.tool_loading || 'Loading tool…') + '</p>' +
                '</div>'
            );
            openModal($modal, { trigger: currentTrigger && currentTrigger.length ? currentTrigger.get(0) : document.activeElement });

            pendingRequest = $.post(ajax, {
                action: 'awg_mem_get_tool_html',
                nonce: nonce,
                template_id: currentTemplateId
            })
            .done(function (res) {
                clearToolRequestState();

                if (res.success && res.data && res.data.html) {
                    $title.text(res.data.title || '');
                    $content.html(res.data.html);
                    $(document).trigger('awg_aig_modal_loaded', [$content]);
                    focusModal($modal);
                    resetToolButton(currentTrigger);
                    return;
                }

                var msg = (res.data && res.data.message) || (s.tool_error || 'Could not load tool. Please try again.');
                var upgrade = res.data && res.data.upgrade_url
                    ? '<p style="margin:14px 0 0;"><a href="' + escHtml(res.data.upgrade_url) + '" class="awg-mem-btn awg-mem-btn--primary">' + escHtml((res.data.upgrade_label || 'View plans')) + '</a></p>'
                    : '';
                renderToolError(msg, upgrade);
            })
            .fail(function (xhr, status) {
                clearToolRequestState();
                if (status === 'abort') {
                    return;
                }
                renderToolError(s.tool_error || 'Could not load tool. Please try again.');
            });

            pendingTimeout = window.setTimeout(function () {
                clearToolRequestState();
                renderToolError(s.tool_timeout || 'This tool is taking longer than expected. Please try again.');
            }, parseInt(s.tool_timeout_ms || '15000', 10));
        }

        $(document).on('click', '.awg-mem-open-tool', function () {
            var templateId = $(this).data('template-id');
            if (! templateId) {
                return;
            }
            requestToolHtml(templateId, $(this));
        });

        $(document).on('click', '.awg-mem-tool-retry', function (e) {
            e.preventDefault();
            if (! currentTemplateId) {
                return;
            }
            requestToolHtml(currentTemplateId, currentTrigger);
        });

        $modal.on('awg:modalclosed', function () {
            resetToolModal();
        });

        $(document).on('click', '#awg-tool-modal-close', function () {
            closeModal($modal);
        });
        $(document).on('click', '#awg-tool-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
        });
    }

    // ── Service order modal ──────────────────────────────────
    function initServiceModal() {
        var $modal        = $('#awg-service-modal');
        var $detailsModal = $('#awg-service-details-modal');
        var currentSlug   = '';
        var currentName   = '';

        function escapeHtml(text) {
            return $('<div>').text(text || '').html();
        }

        function fillDetailsModal($trigger) {
            var name = $trigger.data('name') || '';
            var category = $trigger.data('category') || (s.service_details || 'Service Details');
            var description = $trigger.data('description') || '';
            var fullDescription = $trigger.data('full-description') || '';
            var price = $trigger.data('price') || '';
            var turnaround = $trigger.data('turnaround') || '';
            var buttonLabel = $trigger.data('button-label') || (s.request_quote || 'Request Quote');
            var buttonUrl = $trigger.data('button-url') || '';
            var imageUrl = $trigger.data('image-url') || '';
            var icon = $trigger.data('icon') || 'dashicons-star-filled';
            var slug = $trigger.data('slug') || '';
            var bodyHtml = fullDescription ? fullDescription : ('<p>' + escapeHtml(description) + '</p>');

            $('#awg-service-details-title').text(name || (s.service_details || 'Service Details'));
            $('#awg-service-details-category').text(category);
            $('#awg-service-details-summary').text(description);
            $('#awg-service-details-body').html(bodyHtml);
            $('#awg-service-details-price').text(price);
            $('#awg-service-details-turnaround').text(turnaround);
            $('#awg-service-details-price-wrap').toggle(!!price);
            $('#awg-service-details-turnaround-wrap').toggle(!!turnaround);

            if (imageUrl) {
                $('#awg-service-details-media').html('<img src="' + escapeHtml(imageUrl) + '" alt="' + escapeHtml(name) + '">');
            } else {
                $('#awg-service-details-media').html('<div class="awg-mem-service-details-modal__icon"><span class="dashicons ' + escapeHtml(icon) + '"></span></div>');
            }

            $('#awg-service-details-primary-action')
                .text(buttonLabel)
                .data('slug', slug)
                .data('name', name)
                .data('button-url', buttonUrl);

            if (buttonUrl) {
                $('#awg-service-details-secondary-action').hide();
            } else {
                $('#awg-service-details-secondary-action')
                    .text(s.close || 'Close')
                    .show();
            }
        }

        function safeVal(selector) {
            var $field = $(selector);
            if (!$field.length) {
                return '';
            }
            var value = $field.val();
            return typeof value === 'string' ? value.trim() : '';
        }

        function showServiceMsg(type, text) {
            var $msg = $('#awg-service-modal-msg');
            $msg.removeClass('awg-mem-alert--success awg-mem-alert--error')
                .addClass('awg-mem-alert awg-mem-alert--' + type)
                .attr('role', type === 'error' ? 'alert' : 'status')
                .text(text)
                .show();
        }


        function serviceMinLength() {
            return parseInt(s.service_details_min || '20', 10);
        }

        function updateServiceCounter() {
            var $notes = $('#awg-service-notes');
            var $counter = $('#awg-service-notes-counter');
            if (!$notes.length || !$counter.length) { return; }

            var value = $notes.val() || '';
            var length = $.trim(value).length;
            var minLength = serviceMinLength();
            var isValid = length >= minLength;

            $counter.text(length + ' / ' + minLength + ' min characters')
                .toggleClass('is-valid', isValid)
                .toggleClass('is-invalid', length > 0 && !isValid);

            if (isValid) {
                $notes.removeClass('awg-mem-textarea--invalid');
                var $msg = $('#awg-service-modal-msg');
                if ($msg.hasClass('awg-mem-alert--error')) {
                    $msg.hide().removeClass('awg-mem-alert--error').text('');
                }
            }
        }

        function resetServiceForm() {
            $('#awg-service-modal-msg').hide().removeClass('awg-mem-alert--success awg-mem-alert--error').text('');
            $('#awg-service-form-wrap').show();
            $('#awg-service-notes').val('').removeClass('awg-mem-textarea--invalid');
            updateServiceCounter();
        }


        $(document).on('click', '.awg-mem-view-service-details', function () {
            fillDetailsModal($(this));
            openModal($detailsModal, { trigger: this });
        });

        $(document).on('click', '#awg-service-details-modal-close, #awg-service-details-secondary-action', function () {
            closeModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-modal .awg-mem-modal__backdrop', function () {
            closeModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-primary-action', function () {
            var buttonUrl = $(this).data('button-url') || '';
            var slug = $(this).data('slug') || '';
            var name = $(this).data('name') || '';

            if (buttonUrl) {
                window.location.href = buttonUrl;
                return;
            }

            currentSlug = slug;
            currentName = name;
            closeModal($detailsModal, { restoreFocus: false });
            $('#awg-service-modal-title').text(currentName || (s.request_quote || 'Request Quote'));
            resetServiceForm();
            openModal($modal, { trigger: this });
        });

        $(document).on('click', '.awg-mem-request-service', function () {
            currentSlug = $(this).data('slug') || '';
            currentName = $(this).data('name') || '';
            $('#awg-service-modal-title').text(currentName || (s.request_quote || 'Request Quote'));
            resetServiceForm();
            openModal($modal, { trigger: this });
        });


        $(document).on('input', '#awg-service-notes', function () {
            updateServiceCounter();
        });

        $modal.on('awg:modalclosed', function () {
            resetServiceForm();
        });

        $(document).on('click', '#awg-service-modal-close', function () { closeModal($modal); });
        $(document).on('click', '#awg-service-modal .awg-mem-modal__backdrop', function () { closeModal($modal); });
        $(document).on('click', '#awg-service-submit', function () {
            var notes = safeVal('#awg-service-notes');
            var $notes = $('#awg-service-notes');
            var $btn  = $(this);
            var minLength = serviceMinLength();

            if (!notes || notes.length < minLength) {
                showServiceMsg('error', s.service_details_required || 'Please add a few project details so we can prepare the right quote.');
                $notes.addClass('awg-mem-textarea--invalid').trigger('focus');
                return;
            }

            $notes.removeClass('awg-mem-textarea--invalid');
            $btn.prop('disabled', true).text(s.submitting || 'Submitting…');

            $.post(ajax, {
                action:       'awg_mem_submit_order',
                nonce:        nonce,
                service_slug: currentSlug,
                service_name: currentName,
                notes:        notes,
            })
            .done(function (res) {
                $btn.prop('disabled', false).text(s.submit_request || 'Submit Request');
                if (res && res.success) {
                    showServiceMsg('success', (res.data && res.data.message) || 'Your request has been submitted.');
                    $('#awg-service-form-wrap').hide();
                    setTimeout(function () {
                        closeModal($modal);
                        resetServiceForm();
                    }, 1400);
                } else {
                    showServiceMsg('error', (res && res.data && res.data.message) || s.error_generic || 'Something went wrong. Please try again.');
                }
            })
            .fail(function (xhr) {
                $btn.prop('disabled', false).text(s.submit_request || 'Submit Request');
                var message = s.error_generic || 'Something went wrong. Please try again.';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    message = xhr.responseJSON.data.message;
                }
                console.error('Service request failed', xhr);
                showServiceMsg('error', message);
            });
        });
    }


    function initAccountPlanModal() {
        var $modal = $('#awg-account-plan-modal');
        if (!$modal.length) { return; }

        $(document).on('click', '.awg-mem-account-open-plan-modal', function () {
            openModal($modal, { trigger: this });
        });

        $(document).on('click', '#awg-account-plan-modal-close', function () {
            closeModal($modal);
        });

        $(document).on('click', '#awg-account-plan-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
        });
    }

    // ── Plan upgrade ─────────────────────────────────────────
    function initPlanUpgrade() {
        function pulsePlanCard(planSlug) {
            if (!planSlug) { return; }
            var $card = $('.awg-mem-plan-card').filter(function () {
                var $button = $(this).find('.awg-mem-select-plan[data-plan]');
                if ($button.length && $button.attr('data-plan') === planSlug) {
                    return true;
                }
                return $(this).find('.awg-mem-plan-card__name').text().trim().toLowerCase() === String(planSlug).toLowerCase();
            }).first();

            if (!$card.length) { return; }

            $card[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            $card.addClass('awg-mem-plan-card--pulse');
            window.setTimeout(function () {
                $card.removeClass('awg-mem-plan-card--pulse');
            }, 1800);
        }

        function openPlanModalAndHighlight(planSlug) {
            var $modal = $('#awg-account-plan-modal');
            if (!$modal.length) { return; }
            openModal($modal);
            window.setTimeout(function () {
                pulsePlanCard(planSlug);
            }, 180);
        }

        function applyBillingState(billing) {
            $('[data-billing-toggle]').removeClass('is-active');
            $('[data-billing-toggle="' + billing + '"]').addClass('is-active');
            $('.awg-mem-select-plan').attr('data-billing', billing);
            $('[data-billing-indicator]').text(billing === 'yearly' ? 'Billed yearly, save 20%' : 'Billed monthly');
            $('.awg-mem-plan-card').each(function () {
                var $card = $(this);
                var monthly = parseFloat($card.attr('data-monthly-price') || '0');
                var yearly = parseFloat($card.attr('data-yearly-price') || '0');
                var $price = $card.find('[data-plan-price]');
                var $note = $card.find('[data-plan-note]');
                if (!$price.length || monthly === 0 && yearly === 0) { return; }
                $price.addClass('is-updating');
                window.setTimeout(function () {
                    if (billing === 'yearly' && yearly > 0) {
                        $price.text('$' + Math.round(yearly) + '/yr');
                        if ($note.length) { $note.text('Billed yearly, save 20%'); }
                    } else {
                        $price.text('$' + Math.round(monthly) + '/mo');
                        if ($note.length) { $note.text('Billed monthly'); }
                    }
                    $price.removeClass('is-updating').addClass('is-updated');
                    window.setTimeout(function () {
                        $price.removeClass('is-updated');
                    }, 220);
                }, 110);
            });
        }

        $(document).on('click', '[data-billing-toggle]', function () {
            applyBillingState($(this).attr('data-billing-toggle'));
        });

        $(document).on('click', '.awg-mem-tab-link[data-highlight-plan]', function () {
            var planSlug = $(this).attr('data-highlight-plan') || '';
            window.setTimeout(function () {
                openPlanModalAndHighlight(planSlug);
            }, 80);
        });

        var initialBilling = $('.awg-mem-plans-grid--account').attr('data-current-billing') || 'monthly';
        applyBillingState(initialBilling);

        var params = new URLSearchParams(window.location.search);
        var highlightPlan = params.get('highlight');
        if (highlightPlan && $('#awg-account-plan-modal').length) {
            window.setTimeout(function () {
                openPlanModalAndHighlight(highlightPlan);
            }, 220);
        }

        $(document).on('click', '.awg-mem-select-plan', function () {
            var $btn     = $(this);
            var plan     = $btn.data('plan');
            var billing  = $btn.attr('data-billing') || 'monthly';
            var planName = $btn.data('plan-name') || 'this plan';
            var isFree   = String($btn.data('is-free')) === '1';
            var origText = $btn.text().trim();

            if (isFree && ! window.confirm(s.confirm_downgrade || 'Switch to the free plan right now?')) {
                return;
            }

            $btn.prop('disabled', true).text(s.upgrading || 'Processing…');

            $.post(ajax, { action: 'awg_mem_upgrade_plan', nonce: nonce, plan: plan, billing: billing })
            .done(function (res) {
                if (res.success) {
                    if (res.data && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else {
                    $btn.prop('disabled', false).text(origText);
                    alert((res.data && res.data.message) || (isFree ? 'Could not switch to the free plan.' : 'Could not start checkout for ' + planName + '.'));
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).text(origText);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }

    // ── Cancel plan ──────────────────────────────────────────
    function initCancelPlan() {
        $(document).on('click', '.awg-mem-cancel-plan', function () {
            if ( ! confirm(s.confirm_cancel || 'Cancel your membership? You will be moved to the free plan.') ) { return; }
            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(ajax, { action: 'awg_mem_cancel_plan', nonce: nonce })
            .done(function (res) {
                if (res.success) {
                    if (res.data && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else {
                    alert((res.data && res.data.message) || (isFree ? 'Could not switch to the free plan.' : 'Could not start checkout for ' + planName + '.'));
                    $btn.prop('disabled', false);
                }
            })
            .fail(function () {
                $btn.prop('disabled', false);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }


    // ── Team seats ───────────────────────────────────────────
    function initTeamSeats() {
        function showTeamMsg(type, message) {
            var $msg = $('#awg-team-msg');
            if (!$msg.length) { return; }
            $msg.removeClass('awg-mem-alert--success awg-mem-alert--error awg-mem-alert--info')
                .addClass('awg-mem-alert awg-mem-alert--' + type)
                .text(message)
                .show();
        }

        function teamInviteElements() {
            return {
                input: $('#awg-team-email'),
                error: $('#awg-team-email-error'),
                message: $('#awg-team-msg')
            };
        }

        function isValidInviteEmail(email) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
        }

        function clearTeamInviteError() {
            var els = teamInviteElements();
            els.input.removeClass('awg-mem-input--invalid').attr('aria-invalid', 'false');
            els.error.hide().text('');
        }

        function showTeamInviteError(message) {
            var els = teamInviteElements();
            els.input.addClass('awg-mem-input--invalid').attr('aria-invalid', 'true');
            els.error.text(message).show();
        }

        $(document).on('input', '#awg-team-email', function () {
            var email = ($(this).val() || '').trim();
            if (!email) {
                clearTeamInviteError();
                return;
            }
            if (isValidInviteEmail(email)) {
                clearTeamInviteError();
                var els = teamInviteElements();
                if (els.message.hasClass('awg-mem-alert--error')) {
                    els.message.hide().removeClass('awg-mem-alert--error').text('');
                }
            } else {
                showTeamInviteError('Please enter a valid email address.');
            }
        });

        $(document).on('click', '#awg-team-invite-btn', function () {
            var email = ($('#awg-team-email').val() || '').trim();
            var $btn = $(this);
            if (!email) {
                showTeamInviteError('Please enter an email address.');
                showTeamMsg('error', 'Please enter an email address.');
                return;
            }
            if (!isValidInviteEmail(email)) {
                showTeamInviteError('Please enter a valid email address.');
                showTeamMsg('error', 'Please enter a valid email address.');
                return;
            }
            clearTeamInviteError();
            $btn.prop('disabled', true);
            $.post(ajax, { action: 'awg_mem_invite_team_member', nonce: nonce, email: email })
                .done(function (res) {
                    if (res.success) {
                        clearTeamInviteError();
                        showTeamMsg('success', (res.data && res.data.message) || 'Seat invitation saved.');
                        window.location.reload();
                    } else {
                        showTeamMsg('error', (res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                    }
                })
                .fail(function () {
                    showTeamMsg('error', s.error_generic || 'Something went wrong.');
                })
                .always(function () {
                    $btn.prop('disabled', false);
                });
        });

        $(document).on('click', '.awg-mem-team-remove', function () {
            var seatId = $(this).data('seat-id');
            var $btn = $(this);
            if (!seatId) { return; }
            if (!window.confirm('Remove this team seat?')) { return; }
            $btn.prop('disabled', true);
            $.post(ajax, { action: 'awg_mem_remove_team_member', nonce: nonce, seat_id: seatId })
                .done(function (res) {
                    if (res.success) {
                        window.location.reload();
                    } else {
                        showTeamMsg('error', (res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                        $btn.prop('disabled', false);
                    }
                })
                .fail(function () {
                    showTeamMsg('error', s.error_generic || 'Something went wrong.');
                    $btn.prop('disabled', false);
                });
        });
    }


    function initDashboardVisuals() {
        $('.awg-mem-usage-donut__progress').each(function () {
            var $circle = $(this);
            var target = $circle.attr('data-target-dasharray');
            if (!target) { return; }
            window.setTimeout(function () {
                $circle.attr('stroke-dasharray', target);
            }, 120);
        });
    }

    // ── Copy to clipboard ────────────────────────────────────
    function initCopyButtons() {
        $(document).on('click', '.awg-mem-copy-btn', function () {
            var text = $(this).data('copy');
            var $btn = $(this);
            var orig = $btn.text();

            function done() {
                $btn.text(s.copied || 'Copied!');
                setTimeout(function () { $btn.text(orig); }, 2000);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () {
                    fallbackCopy(text); done();
                });
            } else {
                fallbackCopy(text); done();
            }
        });

        function fallbackCopy(text) {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
            document.body.appendChild(ta);
            ta.focus(); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta);
        }
    }


    function initProfileModal() {
        var $modal = $('#awg-account-profile-modal');
        if (!$modal.length) { return; }

        function showProfileNotice(type, message) {
            var $notice = $('#awg-mem-profile-notice');
            if (!$notice.length) { return; }
            $notice.removeClass('is-error is-success').addClass(type === 'success' ? 'is-success' : 'is-error');
            $notice.text(message || '').prop('hidden', !message);
        }

        $(document).on('click', '.awg-mem-profile-open-modal', function () {
            showProfileNotice('error', '');
            openModal($modal, { trigger: this });
        });

        $(document).on('click', '#awg-account-profile-modal-close, #awg-mem-profile-cancel', function () {
            closeModal($modal);
        });

        $(document).on('click', '#awg-account-profile-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
        });

        $(document).on('submit', '#awg-mem-profile-form', function (e) {
            e.preventDefault();

            var $form = $(this);
            var $btn = $('#awg-mem-profile-save');
            var original = $btn.text();

            showProfileNotice('error', '');

            $btn.prop('disabled', true).text(s.submitting || 'Saving…');

            $.post(ajax, $form.serialize())
                .done(function (res) {
                    if (!res || !res.success || !res.data) {
                        showProfileNotice('error', (res && res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                        return;
                    }

                    showProfileNotice('success', res.data.message || 'Profile updated successfully.');

                    if (res.data.user) {
                        $('.awg-mem-topbar__name').text(res.data.user.display_name || '');
                        $('.awg-mem-account-section--profile .awg-mem-info-table tr:nth-child(1) td:last-child').text(res.data.user.display_name || '');
                        $('.awg-mem-account-section--profile .awg-mem-info-table tr:nth-child(2) td:last-child').text(res.data.user.user_email || '');
                    }

                    $('#awg-mem-profile-password, #awg-mem-profile-password-confirm').val('');

                    window.setTimeout(function () {
                        closeModal($modal);
                    }, 700);
                })
                .fail(function (xhr) {
                    var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || (s.error_generic || 'Something went wrong.');
                    showProfileNotice('error', msg);
                })
                .always(function () {
                    $btn.prop('disabled', false).text(original);
                });
        });
    }


    // ── Init ─────────────────────────────────────────────────
    $(function () {
        if ( ! $('.awg-mem-dashboard').length ) { return; }

        hoistModalsToBody(); // Must run first
        injectSpinStyle();
        initModalA11y();
        initTabs();
        initToolModal();
        initServiceModal();
        initHistoryLoadMore();
        initDashboardVisuals();
        initAccountPlanModal();
        initProfileModal();
        initPlanUpgrade();
        initCancelPlan();
        initTeamSeats();
        initCopyButtons();
    });

}(jQuery));
