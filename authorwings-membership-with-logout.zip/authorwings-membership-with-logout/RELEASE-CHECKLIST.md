# AuthorWings Membership Release Checklist

## Automated self-tests
Run **AW Members → Release Tests** and confirm all tests pass:
- Role mapping and hierarchy
- History query logic
- Usage counting
- Membership gate decisions

## Manual functional checks
- Guest generation: confirm guest-allowed tools behave correctly
- Logged-in generation: confirm successful generations increment usage once
- Usage limits: confirm over-limit requests are blocked and upgrade prompts show
- Plan gating: confirm locked tools show required plan and direct upgrade CTA
- History display: confirm actor-owned and workspace-owned submissions appear
- Upgrade checkout: confirm free plan applies directly and paid plans go to Stripe
- Webhook updates: confirm checkout completion updates membership state correctly
- Cancellation: confirm cancel action downgrades to Free and updates role access
- Expiry cron: trigger expiry check on a test membership and verify downgrade
- Service request flow: confirm requests save all Phase 9 fields correctly

## Release packaging
- Confirm plugin header version matches readme version
- Confirm Stripe keys are not hard-coded in plugin files
- Confirm no debug output, var_dump, or development-only code remains
- Confirm the packaged ZIP contains one top-level plugin folder only
- Install the final ZIP on a staging site and repeat the smoke tests
