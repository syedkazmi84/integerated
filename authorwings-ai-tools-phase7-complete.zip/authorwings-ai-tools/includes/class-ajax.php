<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Ajax {
    /** @var string */
    private $cpt;
    /** @var Settings */
    private $settings;
    /** @var Renderer */
    private $renderer;

    public function __construct(string $cpt, Settings $settings, Renderer $renderer) {
        $this->cpt = $cpt;
        $this->settings = $settings;
        $this->renderer = $renderer;
    }

    private function ip(): string {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        return preg_replace('/[^0-9a-fA-F:\.]/', '', $ip);
    }

    private function rate_ok(int $template_limit, int $global_limit): bool {
        $ip_hash = md5($this->ip());
        $min = (int) floor(time() / 60);
        $key = "awg_aig_rl_{$ip_hash}_{$min}";
        $count = (int) get_transient($key);

        $limit = max(1, (int) min($template_limit, $global_limit));
        if ($count >= $limit) return false;

        set_transient($key, $count + 1, 120);
        return true;
    }

    private function get_required_plan_slug(int $template_id): string {
        $required_plan = get_post_meta($template_id, '_awg_mem_required_plan', true) ?: 'free';
        $required_plan = sanitize_key((string) $required_plan);
        return in_array($required_plan, ['free', 'basic', 'pro', 'publisher'], true) ? $required_plan : 'free';
    }

    private function guest_access_allowed(array $template_meta, array $settings, int $template_id): bool {
        if ($this->get_required_plan_slug($template_id) !== 'free') {
            return false;
        }

        $template_allow = (int) ($template_meta['allow_guests'] ?? -1);
        if ($template_allow === 1) {
            return true;
        }
        if ($template_allow === 0) {
            return false;
        }

        $guest_mode = sanitize_key((string) ($settings['guest_access_mode'] ?? 'all'));
        if (!in_array($guest_mode, ['all', 'selected', 'none'], true)) {
            $guest_mode = !empty($settings['allow_guests']) ? 'all' : 'none';
        }

        return $guest_mode === 'all';
    }

    private function sanitize_html_output(string $html): string {
        $allowed = [
            'p' => [],
            'br' => [],
            'strong' => [],
            'em' => [],
            'ul' => [],
            'ol' => [],
            'li' => [],
            'h2' => [],
            'h3' => [],
            'h4' => [],
            'blockquote' => [],
            'code' => [],
            'pre' => [],
            'a' => [
                'href' => true,
                'target' => true,
                'rel' => true,
            ],
        ];

        return wp_kses($html, $allowed);
    }

    private function openai_call(string $api_key, string $model, string $system, string $user, int $max_tokens, float $temp, int $timeout): array {
        $url = 'https://api.openai.com/v1/responses';

        $payload = [
            'model' => $model,
            'input' => [
                [
                    'role' => 'system',
                    'content' => [['type' => 'input_text', 'text' => $system]],
                ],
                [
                    'role' => 'user',
                    'content' => [['type' => 'input_text', 'text' => $user]],
                ],
            ],
            'max_output_tokens' => $max_tokens,
            'temperature' => $temp,
        ];

        $res = wp_remote_post($url, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => wp_json_encode($payload),
            'timeout' => $timeout,
        ]);

        if (is_wp_error($res)) {
            Logger::log('openai_http_error', ['message' => $res->get_error_message(), 'model' => $model]);
            return ['ok' => false, 'error' => $res->get_error_message()];
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);

        if ($code < 200 || $code >= 300) {
            $msg = 'OpenAI error';
            if (is_array($json) && isset($json['error']['message'])) $msg = (string) $json['error']['message'];
            Logger::log('openai_api_error', ['message' => $msg, 'model' => $model, 'http_code' => (string) $code]);
            return ['ok' => false, 'error' => $msg, 'raw' => $json ?: $body];
        }

        $text = '';
        if (is_array($json) && isset($json['output']) && is_array($json['output'])) {
            foreach ($json['output'] as $out) {
                if (!is_array($out)) continue;
                if (($out['type'] ?? '') === 'message' && isset($out['content']) && is_array($out['content'])) {
                    foreach ($out['content'] as $c) {
                        if (($c['type'] ?? '') === 'output_text') $text .= (string) ($c['text'] ?? '');
                    }
                }
            }
        }

        $text = trim($text);
        if ($text === '') {
            Logger::log('openai_empty_text_fallback', ['model' => $model]);
            $text = trim(wp_strip_all_tags($body));
        }
        return ['ok' => true, 'text' => $text, 'raw' => $json];
    }

    private function parse_field_options($raw_options): array {
        $options = preg_split('/[\r\n,]+/', (string) $raw_options);
        $options = array_values(array_filter(array_map('trim', $options), static function ($option) {
            return $option !== '';
        }));

        return array_map('sanitize_text_field', $options);
    }

    private function normalize_checkbox_scalar($value): string {
        $value = is_scalar($value) ? strtolower(trim((string) $value)) : '';
        return in_array($value, ['1', 'true', 'yes', 'on'], true) ? '1' : '';
    }

    private function validate_submission(array $schema, array $submitted): array {
        $clean = [];
        $errors = [];

        foreach ($schema as $field) {
            $key = sanitize_key($field['key'] ?? '');
            if (!$key) {
                continue;
            }

            $label = sanitize_text_field($field['label'] ?? $key);
            $type = $field['type'] ?? 'text';
            $options = $this->parse_field_options($field['options'] ?? '');
            $raw_value = $submitted[$key] ?? '';

            if ($type === 'checkbox') {
                if (!empty($options)) {
                    $raw_values = is_array($raw_value) ? $raw_value : [$raw_value];
                    $raw_values = array_values(array_filter(array_map('sanitize_text_field', $raw_values), static function ($item) {
                        return $item !== '';
                    }));
                    $valid_values = array_values(array_intersect($raw_values, $options));

                    if (count($valid_values) !== count($raw_values)) {
                        $errors[] = sprintf(
                            /* translators: %s: field label */
                            __('Invalid selection for %s.', 'authorwings-ai-tools'),
                            $label
                        );
                    }

                    $clean[$key] = implode(', ', $valid_values);
                } else {
                    $clean[$key] = $this->normalize_checkbox_scalar($raw_value);
                }
                continue;
            }

            if (is_array($raw_value)) {
                $raw_value = implode(', ', array_filter(array_map('sanitize_text_field', $raw_value)));
            }

            $value = sanitize_text_field((string) $raw_value);

            if ($value === '') {
                $clean[$key] = '';
                continue;
            }

            if ($type === 'email') {
                $value = sanitize_email($value);
                if ($value === '' || !is_email($value)) {
                    $errors[] = sprintf(
                        /* translators: %s: field label */
                        __('Please enter a valid email for %s.', 'authorwings-ai-tools'),
                        $label
                    );
                    $clean[$key] = '';
                    continue;
                }
                $clean[$key] = $value;
                continue;
            }

            if ($type === 'number') {
                $normalized = str_replace(',', '.', $value);
                if (!is_numeric($normalized)) {
                    $errors[] = sprintf(
                        /* translators: %s: field label */
                        __('Please enter a valid number for %s.', 'authorwings-ai-tools'),
                        $label
                    );
                    $clean[$key] = '';
                    continue;
                }
                $clean[$key] = (string) (0 + $normalized);
                continue;
            }

            if ($type === 'select' || $type === 'radio') {
                if (!empty($options) && !in_array($value, $options, true)) {
                    $errors[] = sprintf(
                        /* translators: %s: field label */
                        __('Invalid selection for %s.', 'authorwings-ai-tools'),
                        $label
                    );
                    $clean[$key] = '';
                    continue;
                }
            }

            $clean[$key] = $value;
        }

        return [
            'clean' => $clean,
            'errors' => array_values(array_unique($errors)),
        ];
    }

    private function required_missing(array $schema, array $submitted): array {
        $missing = [];
        foreach ($schema as $field) {
            $key = sanitize_key($field['key'] ?? '');
            if (!$key) {
                continue;
            }
            $required = !empty($field['required']);
            if (!$required) {
                continue;
            }
            $value = $submitted[$key] ?? '';
            $type = $field['type'] ?? 'text';
            if ($type === 'checkbox') {
                if (is_array($value)) {
                    $value = array_values(array_filter(array_map('sanitize_text_field', $value), static function($item){
                        return $item !== '';
                    }));
                    if (empty($value)) {
                        $missing[] = $field['label'] ?? $key;
                    }
                } elseif (empty($value)) {
                    $missing[] = $field['label'] ?? $key;
                }
                continue;
            }
            if (is_array($value)) {
                $value = implode(', ', array_filter($value));
            }
            $value = trim((string) $value);
            if ($value === '') {
                $missing[] = $field['label'] ?? $key;
            }
        }
        return $missing;
    }

    private function bump_usage(int $template_id): void {
        $count = (int) get_post_meta($template_id, '_awg_aig_usage_count', true);
        $count++;
        update_post_meta($template_id, '_awg_aig_usage_count', $count);
        update_post_meta($template_id, '_awg_aig_last_generated', current_time('mysql'));
    }

    private function store_submission(int $template_id, array $fields, string $output, string $model, bool $cached, array $settings): void {
        // Global toggle
        if (empty($settings['store_submissions'])) {
            return;
        }

        // Keep gclid out of the "fields" bucket and store separately
        $gclid = '';
        if (isset($fields['gclid'])) {
            $gclid = sanitize_text_field((string) $fields['gclid']);
            unset($fields['gclid']);
        }

        $title = sprintf(
            /* translators: %d: template id */
            __('Submission (Template #%d)', 'authorwings-ai-tools'),
            $template_id
        );

        $post_id = wp_insert_post([
            'post_type' => Plugin::SUB_CPT,
            'post_status' => 'publish',
            'post_title' => $title,
            'post_author' => max( 0, get_current_user_id() ),
        ], true);

        if (is_wp_error($post_id) || !$post_id) {
            return;
        }

        $actor_user_id = max(0, get_current_user_id());
        $owner_user_id = (int) apply_filters('awg_mem_usage_owner_user_id', $actor_user_id, $actor_user_id);

        update_post_meta($post_id, '_awg_aig_template_id', $template_id);
        update_post_meta($post_id, '_awg_aig_template_title', get_the_title($template_id));
        update_post_meta($post_id, '_awg_aig_user_id', $actor_user_id);
        update_post_meta($post_id, '_awg_aig_owner_user_id', max(0, $owner_user_id));
        update_post_meta($post_id, '_awg_aig_fields', $fields);
        update_post_meta($post_id, '_awg_aig_output', $output);
        update_post_meta($post_id, '_awg_aig_model', $model);
        update_post_meta($post_id, '_awg_aig_cached', $cached ? '1' : '0');
        if ($gclid !== '') update_post_meta($post_id, '_awg_aig_gclid', $gclid);

        // Privacy sensitive: only store if enabled globally
        if (!empty($settings['store_ip'])) {
            update_post_meta($post_id, '_awg_aig_ip', $this->ip());
            $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field((string) $_SERVER['HTTP_USER_AGENT']) : '';
            if ($ua !== '') update_post_meta($post_id, '_awg_aig_ua', $ua);
        }
    }

    public function generate(): void {
        $s = $this->settings->get();

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_aig_nonce_front')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }

        $template_id = isset($_POST['template_id']) ? (int) wp_unslash((string) $_POST['template_id']) : 0;
        if ($template_id <= 0) wp_send_json_error(['message' => __('Invalid template.', 'authorwings-ai-tools')], 400);

        $p = get_post($template_id);
        if (!$p || $p->post_type !== $this->cpt) {
            wp_send_json_error(['message' => __('Template not found.', 'authorwings-ai-tools')], 404);
        }

        $can_use_unpublished = is_user_logged_in() && current_user_can('edit_post', $template_id);
        if ($p->post_status !== 'publish' && !$can_use_unpublished) {
            wp_send_json_error(['message' => __('Template not found.', 'authorwings-ai-tools')], 404);
        }

        $m = $this->renderer->get_template_meta($template_id);

        // Guests?
        $required_plan = $this->get_required_plan_slug($template_id);
        if (!is_user_logged_in() && !$this->guest_access_allowed($m, $s, $template_id)) {
            $payload = [
                'message' => $required_plan === 'free'
                    ? __('Please log in to use this generator.', 'authorwings-ai-tools')
                    : sprintf(__('This generator requires the %s plan or higher. Please log in or view plans to continue.', 'authorwings-ai-tools'), ucfirst($required_plan)),
                'login_url' => function_exists('awg_mem_get_login_url') ? awg_mem_get_login_url(get_permalink($template_id) ?: home_url('/')) : wp_login_url(get_permalink($template_id) ?: home_url('/')),
            ];

            if ($required_plan !== 'free') {
                $payload['upgrade_url'] = function_exists('awg_mem_get_upgrade_url') ? awg_mem_get_upgrade_url($required_plan) : (function_exists('awg_mem_get_pricing_url') ? awg_mem_get_pricing_url() : home_url('/pricing/'));
                $payload['upgrade_label'] = __('View plans', 'authorwings-ai-tools');
            }

            wp_send_json_error($payload, 403);
        }

        // Rate limit
        $template_rl = (int) $m['rate_per_min'];
        $global_rl = (int) $s['global_rate_per_min'];
        if (!$this->rate_ok($template_rl, $global_rl)) {
            wp_send_json_error(['message' => __('Rate limit exceeded. Try again in a minute.', 'authorwings-ai-tools')], 429);
        }

        // Hook 1 — allow external plugins (e.g. membership) to block generation.
        // Return a WP_Error to send a custom message, or false to send a generic block.
        // The membership plugin hooks awg_aig_can_generate to enforce monthly plan limits.
        $can_generate = apply_filters('awg_aig_can_generate', true, get_current_user_id(), $template_id);
        if (is_wp_error($can_generate)) {
            $error_data = $can_generate->get_error_data();
            $payload = [
                'message' => $can_generate->get_error_message(),
            ];

            if (is_array($error_data)) {
                if (!empty($error_data['upgrade_url'])) {
                    $payload['upgrade_url'] = esc_url_raw((string) $error_data['upgrade_url']);
                }
                if (!empty($error_data['upgrade_label'])) {
                    $payload['upgrade_label'] = sanitize_text_field((string) $error_data['upgrade_label']);
                }
            }

            wp_send_json_error($payload, 429);
        }
        if ($can_generate === false) {
            $account_url = function_exists('awg_mem_get_account_url') ? awg_mem_get_account_url() : add_query_arg('tab', 'account', home_url('/member-dashboard/'));
            wp_send_json_error(['message' => __('This generator is not available for your current plan. Please review your account or upgrade to continue.', 'authorwings-ai-tools'), 'upgrade_url' => $account_url, 'upgrade_label' => __('Review my account', 'authorwings-ai-tools')], 403);
        }

        // Cache seconds (template overrides global)
        $cache_seconds = (int) $m['cache_seconds'];
        if ($cache_seconds <= 0) $cache_seconds = (int) $s['global_cache_seconds'];

        $submitted = isset($_POST['fields']) ? $_POST['fields'] : [];
        if (!is_array($submitted)) {
            $submitted = [];
        }

        if (isset($_POST['fields_json'])) {
            $raw_json = wp_unslash((string) $_POST['fields_json']);
            $decoded = json_decode($raw_json, true);
            if (is_array($decoded)) {
                $submitted = $decoded;
            }
        }

        $submitted = wp_unslash($submitted);

        $validated = $this->validate_submission($m['fields'], $submitted);
        $submitted = $validated['clean'];

        if (!empty($validated['errors'])) {
            wp_send_json_error([
                'message' => implode(' ', array_map('sanitize_text_field', $validated['errors'])),
            ], 422);
        }

        $missing = $this->required_missing($m['fields'], $submitted);
        if (!empty($missing)) {
            wp_send_json_error([
                'message' => sprintf(
                    /* translators: %s: list of missing required fields */
                    __('Please complete required fields: %s', 'authorwings-ai-tools'),
                    implode(', ', array_map('sanitize_text_field', $missing))
                ),
            ], 422);
        }

        $fields_text = $this->renderer->fields_to_text($m['fields'], $submitted);
        if ($fields_text === '') $fields_text = '(No inputs provided)';

        $system = (string) $m['system_prompt'];
        $user_tpl = (string) $m['user_prompt'];

        $user_prompt = str_replace(
            ['{{task}}','{{count}}','{{fields}}','{{rules}}'],
            [(string) $m['task'], (string) (int) $m['count'], $fields_text, (string) $m['rules']],
            $user_tpl
        );

        $cache_key = '';
        if ($cache_seconds > 0) {
            $cache_key = 'awg_aig_cache_' . md5($template_id . '|' . $system . '|' . $user_prompt . '|' . wp_json_encode($submitted));
            $cached = get_transient($cache_key);
            if (is_array($cached) && isset($cached['text'])) {
                $this->store_submission($template_id, $submitted, (string) $cached['text'], (string) ($m['model'] ?: $s['default_model']), true, $s);
                wp_send_json_success(['text' => $cached['text'], 'cached' => true, 'format' => $m['output_format']]);
            }
        }

        $api_key = trim((string) $s['api_key']);
        if ($api_key === '') {
            Logger::log('missing_api_key', ['template_id' => (string) $template_id, 'user_id' => (string) get_current_user_id()]);
            wp_send_json_error(['message' => __('API key missing in settings.', 'authorwings-ai-tools')], 500);
        }

        $model = trim((string) $m['model']);
        if ($model === '') $model = (string) $s['default_model'];

        $timeout = (int) $s['timeout'];
        $temp = (float) $m['temperature'];
        $max_tokens = (int) $m['max_output_tokens'];

        $resp = $this->openai_call($api_key, $model, $system, $user_prompt, $max_tokens, $temp, $timeout);

        if (empty($resp['ok'])) {
            $debug = (current_user_can('manage_options') && !empty($m['debug_admin'])) ? ($resp['raw'] ?? null) : null;
            Logger::log('generation_failed', ['template_id' => (string) $template_id, 'user_id' => (string) get_current_user_id(), 'model' => $model, 'message' => (string) ($resp['error'] ?? 'OpenAI error')]);
            wp_send_json_error(['message' => $resp['error'] ?? 'OpenAI error', 'debug' => $debug], 500);
        }

        $text = (string) ($resp['text'] ?? '');

        if ($m['output_format'] === 'json') {
            $maybe = json_decode($text, true);
            if (is_array($maybe)) $text = wp_json_encode($maybe, JSON_PRETTY_PRINT);
        } elseif ($m['output_format'] === 'html') {
            $text = $this->sanitize_html_output($text);
        }

        if ($cache_seconds > 0 && $cache_key) {
            set_transient($cache_key, ['text' => $text], $cache_seconds);
        }

        $this->bump_usage($template_id);

        // Hook 2 — notify external plugins that a generation succeeded.
        // The membership plugin hooks awg_aig_generated to increment the
        // user's monthly usage counter. Passes user_id, template_id, output text.
        do_action('awg_aig_generated', get_current_user_id(), $template_id, $text);

        $this->store_submission($template_id, $submitted, $text, (string) $model, false, $s);

        wp_send_json_success(['text' => $text, 'cached' => false, 'format' => $m['output_format']]);
    }
}
