# AuthorWings AI Migration Checklist

- Back up the site files and database before replacing the plugin
- Confirm existing templates still render after update
- Confirm membership-required template metadata is preserved
- Confirm cached responses and saved submission history still load as expected
- Re-test one high-traffic generator after deploy
- Re-test one membership-gated generator after deploy
