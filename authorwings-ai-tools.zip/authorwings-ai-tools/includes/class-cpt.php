<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class CPT {
    /** @var string */
    private $cpt;

    public function __construct(string $cpt) {
        $this->cpt = $cpt;
    }

    public function register(): void {
        register_post_type($this->cpt, [
            'labels' => [
                'name' => __('AuthorWings AI Templates', 'authorwings-ai-tools'),
                'singular_name' => __('AuthorWings AI Template', 'authorwings-ai-tools'),
                'add_new_item' => __('Add New AuthorWings AI Template', 'authorwings-ai-tools'),
                'edit_item' => __('Edit AuthorWings AI Template', 'authorwings-ai-tools'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => true,
            // We attach this CPT under the top-level "AuthorWings AI" menu via custom submenus.
            'show_in_menu' => false,
            'supports' => ['title'],
        ]);
    }

    public function columns(array $columns): array {
        $new = [];
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ($key === 'title') {
                $new['awg_aig_usage'] = __('Usage', 'authorwings-ai-tools');
                $new['awg_aig_last_generated'] = __('Last Generated', 'authorwings-ai-tools');
            }
        }
        return $new;
    }

    public function column_data(string $column, int $post_id): void {
        if ($column === 'awg_aig_usage') {
            $count = (int) get_post_meta($post_id, '_awg_aig_usage_count', true);
            echo esc_html($count);
        }

        if ($column === 'awg_aig_last_generated') {
            $raw = get_post_meta($post_id, '_awg_aig_last_generated', true);
            if (!$raw) {
                echo esc_html__('—', 'authorwings-ai-tools');
                return;
            }
            $time = strtotime($raw);
            if (!$time) {
                echo esc_html__('—', 'authorwings-ai-tools');
                return;
            }
            echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), $time));
        }
    }

    public function sortable_columns(array $columns): array {
        $columns['awg_aig_usage'] = 'awg_aig_usage';
        $columns['awg_aig_last_generated'] = 'awg_aig_last_generated';
        return $columns;
    }

    public function sort_columns(\WP_Query $query): void {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->post_type !== $this->cpt) {
            return;
        }
        $orderby = $query->get('orderby');
        if ($orderby === 'awg_aig_usage') {
            $query->set('meta_key', '_awg_aig_usage_count');
            $query->set('orderby', 'meta_value_num');
        }
        if ($orderby === 'awg_aig_last_generated') {
            $query->set('meta_key', '_awg_aig_last_generated');
            $query->set('orderby', 'meta_value');
        }
    }
}
