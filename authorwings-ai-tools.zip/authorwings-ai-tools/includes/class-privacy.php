<?php
namespace AWG_AIG;
if (!defined('ABSPATH')) { exit; }
final class Privacy {
    private $submission_cpt;
    public function __construct(string $submission_cpt) { $this->submission_cpt = $submission_cpt; }
    public function register(): void {
        add_filter('wp_privacy_personal_data_exporters', [$this, 'register_exporter']);
        add_filter('wp_privacy_personal_data_erasers', [$this, 'register_eraser']);
    }
    public function register_exporter(array $exporters): array {
        $exporters['authorwings-ai-tools'] = ['exporter_friendly_name' => __('AuthorWings AI submissions', 'authorwings-ai-tools'), 'callback' => [$this, 'exporter']];
        return $exporters;
    }
    public function register_eraser(array $erasers): array {
        $erasers['authorwings-ai-tools'] = ['eraser_friendly_name' => __('AuthorWings AI submissions', 'authorwings-ai-tools'), 'callback' => [$this, 'eraser']];
        return $erasers;
    }
    public function exporter(string $email_address, int $page = 1): array {
        $user = get_user_by('email', $email_address);
        if (!$user) { return ['data' => [], 'done' => true]; }
        $query = new \WP_Query(['post_type' => $this->submission_cpt,'post_status' => 'publish','posts_per_page' => 20,'paged' => max(1, $page),'meta_key' => '_awg_aig_user_id','meta_value' => (int) $user->ID,'orderby' => 'date','order' => 'DESC']);
        $data = [];
        foreach ((array) $query->posts as $post) {
            $post_id = (int) $post->ID;
            $fields = get_post_meta($post_id, '_awg_aig_fields', true);
            if (!is_array($fields)) { $fields = []; }
            $items = [
                ['name' => __('Submission ID', 'authorwings-ai-tools'), 'value' => (string) $post_id],
                ['name' => __('Created', 'authorwings-ai-tools'), 'value' => (string) $post->post_date],
                ['name' => __('Tool', 'authorwings-ai-tools'), 'value' => (string) get_post_meta($post_id, '_awg_aig_template_title', true)],
                ['name' => __('Model', 'authorwings-ai-tools'), 'value' => (string) get_post_meta($post_id, '_awg_aig_model', true)],
                ['name' => __('Cached', 'authorwings-ai-tools'), 'value' => get_post_meta($post_id, '_awg_aig_cached', true) === '1' ? 'Yes' : 'No'],
                ['name' => __('Fields', 'authorwings-ai-tools'), 'value' => wp_json_encode($fields)],
                ['name' => __('Output', 'authorwings-ai-tools'), 'value' => (string) get_post_meta($post_id, '_awg_aig_output', true)],
            ];
            $gclid = (string) get_post_meta($post_id, '_awg_aig_gclid', true);
            if ($gclid !== '') { $items[] = ['name' => __('GCLID', 'authorwings-ai-tools'), 'value' => $gclid]; }
            $ip = (string) get_post_meta($post_id, '_awg_aig_ip', true);
            if ($ip !== '') { $items[] = ['name' => __('IP address', 'authorwings-ai-tools'), 'value' => $ip]; }
            $ua = (string) get_post_meta($post_id, '_awg_aig_ua', true);
            if ($ua !== '') { $items[] = ['name' => __('User agent', 'authorwings-ai-tools'), 'value' => $ua]; }
            $data[] = ['group_id' => 'authorwings-ai-tools', 'group_label' => __('AuthorWings AI', 'authorwings-ai-tools'), 'item_id' => 'awg-aig-submission-' . $post_id, 'data' => $items];
        }
        return ['data' => $data, 'done' => $page >= (int) $query->max_num_pages];
    }
    public function eraser(string $email_address, int $page = 1): array {
        $user = get_user_by('email', $email_address);
        if (!$user) { return ['items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true]; }
        $query = new \WP_Query(['post_type' => $this->submission_cpt,'post_status' => 'publish','posts_per_page' => 20,'paged' => max(1, $page),'fields' => 'ids','meta_key' => '_awg_aig_user_id','meta_value' => (int) $user->ID]);
        $removed = false;
        foreach ((array) $query->posts as $post_id) { wp_delete_post((int) $post_id, true); $removed = true; }
        return ['items_removed' => $removed,'items_retained' => false,'messages' => [],'done' => $page >= (int) $query->max_num_pages];
    }
    public static function cleanup_retention(): void {
        $settings = get_option(Plugin::OPT, []);
        $days = isset($settings['submission_retention_days']) ? (int) $settings['submission_retention_days'] : 0;
        if ($days > 0) {
            $cutoff = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
            $query = new \WP_Query(['post_type' => Plugin::SUB_CPT,'post_status' => 'publish','posts_per_page' => 100,'fields' => 'ids','date_query' => [[ 'before' => $cutoff, 'inclusive' => true, 'column' => 'post_date_gmt' ]]]);
            foreach ((array) $query->posts as $post_id) { wp_delete_post((int) $post_id, true); }
        }
        Logger::cleanup();
    }
}
