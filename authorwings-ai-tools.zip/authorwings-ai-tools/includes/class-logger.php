<?php
namespace AWG_AIG;
if (!defined('ABSPATH')) { exit; }
final class Logger {
    public const OPTION_KEY = 'awg_aig_error_logs';
    private const MAX_ITEMS = 200;
    public static function log(string $event, array $context = []): void {
        $settings = get_option(Plugin::OPT, []);
        if (!is_array($settings) || empty($settings['enable_error_logging'])) { return; }
        $entry = ['time' => current_time('mysql'), 'event' => sanitize_key($event), 'context' => self::sanitize_context($context)];
        $logs = get_option(self::OPTION_KEY, []);
        if (!is_array($logs)) { $logs = []; }
        array_unshift($logs, $entry);
        if (count($logs) > self::MAX_ITEMS) { $logs = array_slice($logs, 0, self::MAX_ITEMS); }
        update_option(self::OPTION_KEY, $logs, false);
    }
    public static function cleanup(): void {
        $settings = get_option(Plugin::OPT, []);
        $days = isset($settings['log_retention_days']) ? (int) $settings['log_retention_days'] : 30;
        if ($days <= 0) { return; }
        $logs = get_option(self::OPTION_KEY, []);
        if (!is_array($logs) || empty($logs)) { return; }
        $cutoff = time() - ($days * DAY_IN_SECONDS);
        $kept = [];
        foreach ($logs as $log) {
            $stamp = isset($log['time']) ? strtotime((string) $log['time']) : false;
            if ($stamp === false || $stamp >= $cutoff) { $kept[] = $log; }
        }
        update_option(self::OPTION_KEY, array_values($kept), false);
    }
    private static function sanitize_context(array $context): array {
        $clean = [];
        foreach ($context as $key => $value) {
            $key = sanitize_key((string) $key);
            if ($key === '') { continue; }
            if (is_array($value)) { $clean[$key] = self::sanitize_context($value); continue; }
            $value = (string) $value;
            $value = preg_replace('/(sk|pk|rk)_(live|test)_[A-Za-z0-9]+/', '[redacted_key]', $value);
            $value = preg_replace('/Bearer\s+[A-Za-z0-9_\-]+/i', 'Bearer [redacted]', $value);
            $clean[$key] = sanitize_text_field($value);
        }
        return $clean;
    }
}
