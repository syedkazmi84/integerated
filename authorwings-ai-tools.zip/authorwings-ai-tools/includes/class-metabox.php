<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Metabox {
    /** @var string */
    private $cpt;

    /** @var Renderer */
    private $renderer;

    public function __construct(string $cpt, Renderer $renderer) {
        $this->cpt = $cpt;
        $this->renderer = $renderer;
    }

    public function register(): void {
        add_meta_box('awg_aig_builder', __('Template Builder', 'authorwings-ai-tools'), [$this, 'html'], $this->cpt, 'normal', 'high');
    }

    public function html($post): void {
        wp_nonce_field('awg_aig_save', 'awg_aig_nonce');
        $m = $this->renderer->get_template_meta($post->ID);
        $palette = [
            '030c17' => '#030c17',
            'e8f1fd' => '#e8f1fd',
            'ffffff' => '#ffffff',
            '1a73e8' => '#1a73e8',
            'd1e3fa' => '#d1e3fa',
            'fbbf24' => '#fbbf24',
        ];
        ?>
        <div class="awg-aig-wrap">

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Form Title', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[form_title]" value="<?php echo esc_attr($m['form_title']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title Icon Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[title_icon_class]" value="<?php echo esc_attr($m['title_icon_class'] ?? ''); ?>" placeholder="dashicons dashicons-book">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title Icon Size (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="10" max="40" name="awg_aig[title_icon_size]" value="<?php echo esc_attr((int) ($m['title_icon_size'] ?? 20)); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title Icon Position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[title_icon_position]">
                        <option value="before" <?php selected(($m['title_icon_position'] ?? 'before'), 'before'); ?>><?php echo esc_html__('Before Title', 'authorwings-ai-tools'); ?></option>
                        <option value="after" <?php selected(($m['title_icon_position'] ?? 'before'), 'after'); ?>><?php echo esc_html__('After Title', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Form Description', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[form_description]" value="<?php echo esc_attr($m['form_description']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Task (used in prompt)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[task]" value="<?php echo esc_attr($m['task']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Label', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[button_label]" value="<?php echo esc_attr($m['button_label']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('How many results? ({{count}})', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="1" max="50" name="awg_aig[count]" value="<?php echo esc_attr($m['count']); ?>">
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Disclaimer / Helper Text', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[disclaimer_text]" value="<?php echo esc_attr($m['disclaimer_text']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Result Actions', 'authorwings-ai-tools'); ?></label>
                    <div class="awg-checks">
                        <label>
                            <input type="checkbox" name="awg_aig[show_copy]" value="1" <?php checked($m['show_copy'], 1); ?>>
                            <?php echo esc_html__('Show Copy', 'authorwings-ai-tools'); ?>
                        </label>
                        <label>
                            <input type="checkbox" name="awg_aig[show_download]" value="1" <?php checked($m['show_download'], 1); ?>>
                            <?php echo esc_html__('Show Download', 'authorwings-ai-tools'); ?>
                        </label>
                        <label>
                            <input type="checkbox" name="awg_aig[show_clear]" value="1" <?php checked($m['show_clear'], 1); ?>>
                            <?php echo esc_html__('Show Clear', 'authorwings-ai-tools'); ?>
                        </label>
                    </div>
                </div>
            </div>

            <p style="margin:0 0 12px;">
                <label class="awg-label" style="display:flex;align-items:center;gap:8px;">
                    <input type="checkbox" name="awg_aig[use_global_styles]" value="1" <?php checked((int) ($m['use_global_styles'] ?? 1), 1); ?>>
                    <?php echo esc_html__('Use global style settings from AuthorWings AI → Settings', 'authorwings-ai-tools'); ?>
                </label>
            </p>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label" style="display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" name="awg_aig[use_global_field_sizes]" value="1" <?php checked((int) ($m['use_global_field_sizes'] ?? 1), 1); ?>>
                        <?php echo esc_html__('Use global field sizes', 'authorwings-ai-tools'); ?>
                    </label>
                    <p class="description"><?php echo esc_html__('Turn this off to override the default input height and textarea rows for this template only.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Input Height (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="32" max="80" name="awg_aig[style_input_height]" value="<?php echo esc_attr((int) $m['style_input_height']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Textarea Rows', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="2" max="20" name="awg_aig[style_textarea_rows]" value="<?php echo esc_attr((int) $m['style_textarea_rows']); ?>">
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Background Color', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_bg_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_bg_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Text Color', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_text_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_text_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Border Color', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_border_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_border_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Accent Color', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_accent_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_accent_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Padding (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="80" name="awg_aig[style_padding]" value="<?php echo esc_attr((int) $m['style_padding']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Margin (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="80" name="awg_aig[style_margin]" value="<?php echo esc_attr((int) $m['style_margin']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Border Radius (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="40" name="awg_aig[style_radius]" value="<?php echo esc_attr((int) $m['style_radius']); ?>">
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[button_icon_class]" value="<?php echo esc_attr($m['button_icon_class'] ?? ''); ?>" placeholder="dashicons dashicons-admin-tools">
                    <p class="description"><?php echo esc_html__('Use Dashicons classes. Leave empty to hide icon.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Size (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="10" max="40" name="awg_aig[button_icon_size]" value="<?php echo esc_attr((int) ($m['button_icon_size'] ?? 18)); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[button_icon_position]">
                        <option value="before" <?php selected(($m['button_icon_position'] ?? 'before'), 'before'); ?>><?php echo esc_html__('Before Label', 'authorwings-ai-tools'); ?></option>
                        <option value="after" <?php selected(($m['button_icon_position'] ?? 'before'), 'after'); ?>><?php echo esc_html__('After Label', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Extra CSS Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[button_icon_css_class]" value="<?php echo esc_attr($m['button_icon_css_class'] ?? ''); ?>" placeholder="my-custom-icon">
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Background', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_button_bg_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_button_bg_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Text Color', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_button_text_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_button_text_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Border Color', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[style_button_border_color]">
                        <?php foreach ($palette as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($m['style_button_border_color'], $value); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Padding Y (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="6" max="30" name="awg_aig[style_button_padding_y]" value="<?php echo esc_attr((int) $m['style_button_padding_y']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Padding X (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="8" max="40" name="awg_aig[style_button_padding_x]" value="<?php echo esc_attr((int) $m['style_button_padding_x']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Radius (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="20" name="awg_aig[style_button_radius]" value="<?php echo esc_attr((int) $m['style_button_radius']); ?>">
                </div>
            </div>

            <hr>

            <h3 style="margin:0 0 10px;"><?php echo esc_html__('Fields (Add unlimited inputs)', 'authorwings-ai-tools'); ?></h3>
            <p class="description"><?php echo esc_html__('Supported types: text, textarea, select, number, email, checkbox, radio. For checkbox, select, and radio, provide options one per line or comma-separated. Checkbox without options works as a single yes/no field.', 'authorwings-ai-tools'); ?></p>

            <div id="awg-fields" class="awg-fields">
                <?php foreach ($m['fields'] as $i => $f): ?>
                    <?php $this->render_field_row($i, $f); ?>
                <?php endforeach; ?>
            </div>

            <button type="button" class="button" id="awg-add-field"><?php echo esc_html__('+ Add Field', 'authorwings-ai-tools'); ?></button>

            <hr>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Model (optional)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[model]" value="<?php echo esc_attr($m['model']); ?>" placeholder="<?php echo esc_attr__('Leave empty to use global default', 'authorwings-ai-tools'); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Temperature', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" step="0.1" min="0" max="2" name="awg_aig[temperature]" value="<?php echo esc_attr($m['temperature']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Max Output Tokens', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="1" max="8000" name="awg_aig[max_output_tokens]" value="<?php echo esc_attr($m['max_output_tokens']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Output Format', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[output_format]">
                        <option value="text" <?php selected($m['output_format'], 'text'); ?>><?php echo esc_html__('Text', 'authorwings-ai-tools'); ?></option>
                        <option value="html" <?php selected($m['output_format'], 'html'); ?>><?php echo esc_html__('HTML', 'authorwings-ai-tools'); ?></option>
                        <option value="json" <?php selected($m['output_format'], 'json'); ?>><?php echo esc_html__('JSON', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Template Rate Limit (per minute per IP)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="1" max="99999" name="awg_aig[rate_per_min]" value="<?php echo esc_attr($m['rate_per_min']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Template Cache Seconds (0=off)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="86400" name="awg_aig[cache_seconds]" value="<?php echo esc_attr($m['cache_seconds']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Allow Guests', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[allow_guests]">
                        <option value="-1" <?php selected($m['allow_guests'], -1); ?>><?php echo esc_html__('Inherit Global', 'authorwings-ai-tools'); ?></option>
                        <option value="1" <?php selected($m['allow_guests'], 1); ?>><?php echo esc_html__('Allow Guests', 'authorwings-ai-tools'); ?></option>
                        <option value="0" <?php selected($m['allow_guests'], 0); ?>><?php echo esc_html__('Login Required', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label">
                        <input type="checkbox" name="awg_aig[debug_admin]" value="1" <?php checked($m['debug_admin'], 1); ?>>
                        <?php echo esc_html__('Debug (admins only)', 'authorwings-ai-tools'); ?>
                    </label>
                </div>
            </div>

            <?php
            // Required Membership Plan field — only shown when the AuthorWings
            // Membership plugin is active. The field saves to _awg_mem_required_plan
            // post meta, which the membership plugin reads to lock/unlock tools per plan.
            if (defined('AWG_MEM_VERSION')) :
                $required_plan = get_post_meta($post->ID, '_awg_mem_required_plan', true) ?: 'free';
                $plan_options  = [
                    'free'      => __('Free — everyone can use', 'authorwings-ai-tools'),
                    'basic'     => __('Basic and above', 'authorwings-ai-tools'),
                    'pro'       => __('Pro and above', 'authorwings-ai-tools'),
                    'publisher' => __('Publisher only', 'authorwings-ai-tools'),
                ];
            ?>
            <div class="awg-grid" style="margin-top:12px;padding:12px;background:#f0f7ff;border:1px solid #d1e3fa;border-radius:6px;">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Required Membership Plan', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[required_plan]">
                        <?php foreach ($plan_options as $slug => $label) : ?>
                            <option value="<?php echo esc_attr($slug); ?>" <?php selected($required_plan, $slug); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description" style="margin-top:4px;">
                        <?php echo esc_html__('Controls which membership plan is needed to access this tool in the member dashboard.', 'authorwings-ai-tools'); ?>
                    </p>
                </div>
            </div>
            <?php endif; ?>

            <hr>

            <h3 style="margin:0 0 8px;"><?php echo esc_html__('Usage Insights', 'authorwings-ai-tools'); ?></h3>
            <p class="description">
                <?php
                    $usage_count = (int) get_post_meta($post->ID, '_awg_aig_usage_count', true);
                    $last_generated = (string) get_post_meta($post->ID, '_awg_aig_last_generated', true);
                    $last_label = $last_generated ? wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_generated)) : __('—', 'authorwings-ai-tools');
                    echo esc_html(sprintf(__('Total runs: %1$s | Last generated: %2$s', 'authorwings-ai-tools'), $usage_count, $last_label));
                ?>
            </p>

            <hr>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('System Prompt', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-textarea" name="awg_aig[system_prompt]"><?php echo esc_textarea($m['system_prompt']); ?></textarea>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Rules (used in prompt as {{rules}})', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-textarea" name="awg_aig[rules]"><?php echo esc_textarea($m['rules']); ?></textarea>
                </div>
            </div>

            <label class="awg-label" style="margin-top:12px;"><?php echo esc_html__('User Prompt Template', 'authorwings-ai-tools'); ?></label>
            <textarea class="awg-textarea" name="awg_aig[user_prompt]"><?php echo esc_textarea($m['user_prompt']); ?></textarea>
            <p class="description">
                <?php echo esc_html__('Placeholders: {{task}}, {{count}}, {{fields}}, {{rules}}.', 'authorwings-ai-tools'); ?>
                <br><?php echo esc_html__('All field inputs are automatically converted into {{fields}} and sent to GPT.', 'authorwings-ai-tools'); ?>
            </p>

            <hr>
            <p class="description">
                <?php echo esc_html__('Shortcode for this template:', 'authorwings-ai-tools'); ?>
                <code>[awg_generator id="<?php echo intval($post->ID); ?>"]</code>
            </p>

            <template id="awg-field-template">
                <?php $this->render_field_row('__INDEX__', [
                    'key' => '',
                    'label' => '',
                    'type' => 'text',
                    'required' => 0,
                    'placeholder' => '',
                    'options' => '',
                    'default' => '',
                    'icon_class' => '',
                    'icon_size' => 16,
                    'icon_position' => 'before_label',
                ], true); ?>
            </template>
        </div>
        <?php
    }

    private function render_field_row($i, array $f, bool $is_template = false): void {
        $idx = $i;
        $name = function ($k) use ($idx) {
            return "awg_aig[fields][{$idx}][{$k}]";
        };

        $key = sanitize_key($f['key'] ?? '');
        $label = $f['label'] ?? '';
        $type = $f['type'] ?? 'text';
        $required = !empty($f['required']) ? 1 : 0;
        $placeholder = $f['placeholder'] ?? '';
        $options = $f['options'] ?? '';
        $default = $f['default'] ?? '';
        $icon_class = $f['icon_class'] ?? '';
        $icon_size = max(10, min(30, intval($f['icon_size'] ?? 16)));
        $icon_position = in_array(($f['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true) ? $f['icon_position'] : 'before_label';
        ?>
        <div class="awg-field-row" data-index="<?php echo esc_attr($idx); ?>">
            <div class="awg-field-row__top">
                <strong><?php echo esc_html__('Field', 'authorwings-ai-tools'); ?></strong>
                <button type="button" class="button-link-delete awg-remove-field"><?php echo esc_html__('Remove', 'authorwings-ai-tools'); ?></button>
            </div>

            <div class="awg-grid awg-grid--fields">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Key (unique)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('key')); ?>" value="<?php echo esc_attr($key); ?>" placeholder="e.g., genre" <?php echo $is_template ? '' : 'required'; ?>>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Label', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('label')); ?>" value="<?php echo esc_attr($label); ?>" placeholder="e.g., Genre">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Type', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('type')); ?>">
                        <?php foreach (['text','textarea','select','number','email','checkbox','radio'] as $t): ?>
                            <option value="<?php echo esc_attr($t); ?>" <?php selected($type, $t); ?>><?php echo esc_html($t); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Required', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('required')); ?>">
                        <option value="0" <?php selected($required, 0); ?>><?php echo esc_html__('No', 'authorwings-ai-tools'); ?></option>
                        <option value="1" <?php selected($required, 1); ?>><?php echo esc_html__('Yes', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
            </div>

            <div class="awg-grid awg-grid--fields">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Placeholder', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('placeholder')); ?>" value="<?php echo esc_attr($placeholder); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Default Value', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('default')); ?>" value="<?php echo esc_attr($default); ?>">
                </div>
                <div class="awg-col awg-col--wide">
                    <label class="awg-label"><?php echo esc_html__('Options (for checkbox/select/radio) — one per line', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-textarea awg-textarea--small" name="<?php echo esc_attr($name('options')); ?>"><?php echo esc_textarea($options); ?></textarea>
                </div>
            </div>

            <div class="awg-grid awg-grid--fields">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Field Icon Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('icon_class')); ?>" value="<?php echo esc_attr($icon_class); ?>" placeholder="dashicons dashicons-edit">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Field Icon Size (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="10" max="30" name="<?php echo esc_attr($name('icon_size')); ?>" value="<?php echo esc_attr($icon_size); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Field Icon Position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('icon_position')); ?>">
                        <option value="before_label" <?php selected($icon_position, 'before_label'); ?>><?php echo esc_html__('Before Label', 'authorwings-ai-tools'); ?></option>
                        <option value="after_label" <?php selected($icon_position, 'after_label'); ?>><?php echo esc_html__('After Label', 'authorwings-ai-tools'); ?></option>
                        <option value="before_input" <?php selected($icon_position, 'before_input'); ?>><?php echo esc_html__('Before Input', 'authorwings-ai-tools'); ?></option>
                        <option value="after_input" <?php selected($icon_position, 'after_input'); ?>><?php echo esc_html__('After Input', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
            </div>
        </div>
        <?php
    }

    public function save(int $post_id, $post): void {
        if (!is_object($post) || $post->post_type !== $this->cpt) { return; }
        if (!isset($_POST['awg_aig_nonce']) || !wp_verify_nonce($_POST['awg_aig_nonce'], 'awg_aig_save')) { return; }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (!current_user_can('edit_post', $post_id)) { return; }

        $in = $_POST['awg_aig'] ?? [];
        if (!is_array($in)) { $in = []; }

        $m = $this->renderer->get_template_meta($post_id);

        $m['form_title'] = sanitize_text_field($in['form_title'] ?? $m['form_title']);
        $m['form_description'] = sanitize_text_field($in['form_description'] ?? $m['form_description']);
        $m['task'] = sanitize_text_field($in['task'] ?? $m['task']);
        $m['button_label'] = sanitize_text_field($in['button_label'] ?? $m['button_label']);
        $m['title_icon_class'] = $this->sanitize_icon_class($in['title_icon_class'] ?? '');
        $m['title_icon_size'] = max(10, min(40, intval($in['title_icon_size'] ?? 20)));
        $m['title_icon_position'] = in_array(($in['title_icon_position'] ?? 'before'), ['before', 'after'], true) ? $in['title_icon_position'] : 'before';
        $m['count'] = max(1, min(50, intval($in['count'] ?? $m['count'])));
        $m['disclaimer_text'] = sanitize_text_field($in['disclaimer_text'] ?? $m['disclaimer_text']);
        $m['show_copy'] = isset($in['show_copy']) ? 1 : 0;
        $m['show_download'] = isset($in['show_download']) ? 1 : 0;
        $m['show_clear'] = isset($in['show_clear']) ? 1 : 0;
        $m['use_global_styles'] = isset($in['use_global_styles']) ? 1 : 0;
        $m['use_global_field_sizes'] = isset($in['use_global_field_sizes']) ? 1 : 0;
        $allowed_colors = ['030c17','e8f1fd','ffffff','1a73e8','d1e3fa','fbbf24'];
        $m['style_bg_color'] = in_array(($in['style_bg_color'] ?? $m['style_bg_color']), $allowed_colors, true) ? $in['style_bg_color'] : $m['style_bg_color'];
        $m['style_text_color'] = in_array(($in['style_text_color'] ?? $m['style_text_color']), $allowed_colors, true) ? $in['style_text_color'] : $m['style_text_color'];
        $m['style_border_color'] = in_array(($in['style_border_color'] ?? $m['style_border_color']), $allowed_colors, true) ? $in['style_border_color'] : $m['style_border_color'];
        $m['style_accent_color'] = in_array(($in['style_accent_color'] ?? $m['style_accent_color']), $allowed_colors, true) ? $in['style_accent_color'] : $m['style_accent_color'];
        $m['style_padding'] = max(0, min(80, intval($in['style_padding'] ?? $m['style_padding'])));
        $m['style_margin'] = max(0, min(80, intval($in['style_margin'] ?? $m['style_margin'])));
        $m['style_radius'] = max(0, min(40, intval($in['style_radius'] ?? $m['style_radius'])));
        $m['style_button_bg_color'] = in_array(($in['style_button_bg_color'] ?? $m['style_button_bg_color']), $allowed_colors, true) ? $in['style_button_bg_color'] : $m['style_button_bg_color'];
        $m['style_button_text_color'] = in_array(($in['style_button_text_color'] ?? $m['style_button_text_color']), $allowed_colors, true) ? $in['style_button_text_color'] : $m['style_button_text_color'];
        $m['style_button_border_color'] = in_array(($in['style_button_border_color'] ?? $m['style_button_border_color']), $allowed_colors, true) ? $in['style_button_border_color'] : $m['style_button_border_color'];
        $m['style_button_padding_y'] = max(6, min(30, intval($in['style_button_padding_y'] ?? $m['style_button_padding_y'])));
        $m['style_button_padding_x'] = max(8, min(40, intval($in['style_button_padding_x'] ?? $m['style_button_padding_x'])));
        $m['style_button_radius'] = max(0, min(20, intval($in['style_button_radius'] ?? $m['style_button_radius'])));
        $m['button_icon_class'] = $this->sanitize_icon_class($in['button_icon_class'] ?? '');
        $m['button_icon_size'] = max(10, min(40, intval($in['button_icon_size'] ?? 18)));
        $m['button_icon_position'] = in_array(($in['button_icon_position'] ?? 'before'), ['before', 'after'], true) ? $in['button_icon_position'] : 'before';
        $m['button_icon_css_class'] = $this->sanitize_icon_class($in['button_icon_css_class'] ?? '');
        $m['style_input_height'] = max(32, min(80, intval($in['style_input_height'] ?? $m['style_input_height'])));
        $m['style_textarea_rows'] = max(2, min(20, intval($in['style_textarea_rows'] ?? $m['style_textarea_rows'])));

        $m['model'] = sanitize_text_field($in['model'] ?? '');
        $m['temperature'] = max(0, min(2, floatval($in['temperature'] ?? $m['temperature'])));
        $m['max_output_tokens'] = max(1, min(4096, intval($in['max_output_tokens'] ?? $m['max_output_tokens'])));

        $m['output_format'] = in_array(($in['output_format'] ?? 'text'), ['text','html','json'], true) ? $in['output_format'] : 'text';

        $m['rate_per_min'] = max(1, intval($in['rate_per_min'] ?? $m['rate_per_min']));
        $m['cache_seconds'] = max(0, intval($in['cache_seconds'] ?? $m['cache_seconds']));
        $m['allow_guests'] = in_array((int) ($in['allow_guests'] ?? $m['allow_guests']), [-1, 0, 1], true) ? (int) ($in['allow_guests'] ?? $m['allow_guests']) : -1;
        $m['debug_admin'] = isset($in['debug_admin']) ? 1 : 0;

        // Required Membership Plan — saved to its own meta key (not inside $m blob)
        // so the membership plugin can read it without depending on the renderer.
        // Only save when the membership plugin is active (AWG_MEM_VERSION defined).
        if (defined('AWG_MEM_VERSION')) {
            $allowed_plans   = ['free', 'basic', 'pro', 'publisher'];
            $submitted_plan  = sanitize_key($in['required_plan'] ?? 'free');
            $required_plan   = in_array($submitted_plan, $allowed_plans, true) ? $submitted_plan : 'free';
            $dashboard_category = sanitize_text_field($in['dashboard_category'] ?? 'AI Tools');
            $usage_cost = max(1, min(100, intval($in['usage_cost'] ?? 1)));
            update_post_meta($post_id, '_awg_mem_required_plan', $required_plan);
            update_post_meta($post_id, '_awg_mem_category', $dashboard_category ?: 'AI Tools');
            update_post_meta($post_id, '_awg_mem_usage_cost', $usage_cost);
        }

        $m['system_prompt'] = wp_kses_post($in['system_prompt'] ?? $m['system_prompt']);
        $m['rules'] = wp_kses_post($in['rules'] ?? $m['rules']);
        $m['user_prompt'] = wp_kses_post($in['user_prompt'] ?? $m['user_prompt']);

        // Fields
        $fields_in = $in['fields'] ?? [];
        $fields_out = [];
        if (is_array($fields_in)) {
            foreach ($fields_in as $f) {
                if (!is_array($f)) continue;
                $key = sanitize_key($f['key'] ?? '');
                if (!$key) continue;

                $fields_out[] = [
                    'key' => $key,
                    'label' => sanitize_text_field($f['label'] ?? $key),
                    'type' => in_array(($f['type'] ?? 'text'), ['text','textarea','select','number','email','checkbox','radio'], true) ? $f['type'] : 'text',
                    'required' => !empty($f['required']) ? 1 : 0,
                    'placeholder' => sanitize_text_field($f['placeholder'] ?? ''),
                    'options' => isset($f['options']) ? (string)$f['options'] : '',
                    'default' => sanitize_text_field($f['default'] ?? ''),
                    'icon_class' => $this->sanitize_icon_class($f['icon_class'] ?? ''),
                    'icon_size' => max(10, min(30, intval($f['icon_size'] ?? 16))),
                    'icon_position' => in_array(($f['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true) ? $f['icon_position'] : 'before_label',
                ];
            }
        }
        if (empty($fields_out)) {
            $fields_out = $this->renderer->template_defaults()['fields'];
        }
        $m['fields'] = $fields_out;

        update_post_meta($post_id, '_awg_aig_template', $m);
    }

    private function sanitize_icon_class($value): string {
        $class = trim((string) $value);
        if ($class === '') {
            return '';
        }
        $parts = preg_split('/\s+/', $class);
        $parts = array_map('sanitize_html_class', array_filter($parts, static function ($part) {
            return is_string($part) && $part !== '';
        }));
        return trim(implode(' ', $parts));
    }
}
