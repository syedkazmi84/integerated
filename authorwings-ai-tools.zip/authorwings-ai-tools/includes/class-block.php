<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Block {
    /** @var Renderer */
    private $renderer;

    public function __construct(Renderer $renderer) {
        $this->renderer = $renderer;
    }

    public function register(): void {
        add_action('rest_api_init', [$this, 'register_rest_routes']);

        wp_register_script(
            'awg-aig-block',
            plugins_url('assets/block.js', AWG_AIG_FILE),
            ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-api-fetch', 'wp-i18n'],
            AWG_AIG_VERSION,
            true
        );

        wp_set_script_translations('awg-aig-block', 'authorwings-ai-tools', plugin_dir_path(AWG_AIG_FILE) . 'languages');

        register_block_type('awg/generator', [
            'editor_script'   => 'awg-aig-block',
            'render_callback' => [$this, 'render'],
            'attributes'      => [
                'templateId' => ['type' => 'number', 'default' => 0],
            ],
        ]);
    }

    public function register_rest_routes(): void {
        register_rest_route('awg-aig/v1', '/templates', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_templates'],
            'permission_callback' => static function (): bool {
                return current_user_can('edit_posts');
            },
        ]);
    }

    public function render(array $attrs): string {
        $id = intval($attrs['templateId'] ?? 0);
        if ($id <= 0) {
            return '<div class="awg-aig awg-aig--empty">' . esc_html__('Select a generator template.', 'authorwings-ai-tools') . '</div>';
        }
        return $this->renderer->render_form($id);
    }

    public function rest_templates(\WP_REST_Request $request): \WP_REST_Response {
        $templates = get_posts([
            'post_type'      => Plugin::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
            'no_found_rows'  => true,
        ]);

        $visible = apply_filters('awg_aig_visible_templates', $templates, get_current_user_id());
        $items = [];

        foreach ((array) $visible as $template) {
            if ($template instanceof \WP_Post) {
                $items[] = [
                    'id'    => (int) $template->ID,
                    'title' => get_the_title($template->ID),
                ];
            }
        }

        return new \WP_REST_Response($items, 200);
    }
}
