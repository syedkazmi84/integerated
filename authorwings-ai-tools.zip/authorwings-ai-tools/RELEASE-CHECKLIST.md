# AuthorWings AI Release Checklist

## Automated checks
- Confirm plugin activates without fatal errors
- Confirm one generator works on a fresh install after entering a valid API key
- Confirm required fields block empty submission
- Confirm loading, success, empty, and error states display correctly
- Confirm response caching still works after the latest changes

## Manual checks
- Test one guest-allowed generator
- Test one logged-in generator
- Test one locked premium tool from the membership dashboard modal
- Test copy, clear, and download actions on desktop and mobile widths
- Verify output blocks and action buttons wrap correctly on small screens
- Verify history records still save when submission storage is enabled

## Packaging
- Confirm plugin header version matches stable tag and package version
- Remove temporary files, OS metadata files, and old build artifacts
- Zip only the plugin folder
- Smoke test the final ZIP on a clean WordPress install before production upload
