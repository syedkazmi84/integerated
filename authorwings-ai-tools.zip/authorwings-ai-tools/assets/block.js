(function (wp) {
  if (!wp || !wp.blocks) return;

  const { registerBlockType } = wp.blocks;
  const { InspectorControls } = wp.blockEditor || wp.editor;
  const { PanelBody, SelectControl, Notice } = wp.components;
  const { createElement: el, Fragment, useEffect, useState } = wp.element;
  const apiFetch = wp.apiFetch;
  const __ = (wp.i18n && wp.i18n.__) ? wp.i18n.__ : function (text) { return text; };

  registerBlockType("awg/generator", {
    title: __("AuthorWings AI", "authorwings-ai-tools"),
    icon: "lightbulb",
    category: "widgets",
    attributes: {
      templateId: { type: "number", default: 0 },
    },

    edit: function (props) {
      const templateId = props.attributes.templateId;
      const [templates, setTemplates] = useState(null);
      const [loadError, setLoadError] = useState(false);

      useEffect(function () {
        apiFetch({ path: '/awg-aig/v1/templates' })
          .then(function (items) {
            setTemplates(Array.isArray(items) ? items : []);
          })
          .catch(function () {
            setLoadError(true);
            setTemplates([]);
          });
      }, []);

      let options = [{ label: __("Select a template…", "authorwings-ai-tools"), value: 0 }];

      if (templates && Array.isArray(templates)) {
        options = options.concat(
          templates.map(function (p) {
            return { label: p.title || (__("Template #", "authorwings-ai-tools") + p.id), value: p.id };
          })
        );
      }

      return el(
        Fragment,
        {},
        el(
          InspectorControls,
          {},
          el(
            PanelBody,
            { title: __("Generator Settings", "authorwings-ai-tools"), initialOpen: true },
            templates === null
              ? el(Notice, { status: "warning", isDismissible: false }, __("Loading templates…", "authorwings-ai-tools"))
              : null,
            loadError
              ? el(Notice, { status: "error", isDismissible: false }, __("Could not load templates.", "authorwings-ai-tools"))
              : null,
            el(SelectControl, {
              label: __("Template", "authorwings-ai-tools"),
              value: templateId,
              options: options,
              onChange: function (val) {
                props.setAttributes({ templateId: parseInt(val, 10) || 0 });
              },
            })
          )
        ),
        el(
          "div",
          { className: "awg-block-preview" },
          templateId
            ? __("AuthorWings AI selected:", "authorwings-ai-tools") + " #" + templateId
            : __("Select a template from the block sidebar settings.", "authorwings-ai-tools")
        )
      );
    },

    save: function () {
      return null;
    },
  });
})(window.wp);
