(function($){
  function nextIndex($wrap){
    const $rows = $wrap.find('.awg-field-row');
    if ($rows.length === 0) return 0;
    let max = -1;
    $rows.each(function(){
      const idx = parseInt($(this).attr('data-index'), 10);
      if (!isNaN(idx)) max = Math.max(max, idx);
    });
    return max + 1;
  }

  function ensureSortable() {
    if (!$.fn.sortable) return;
    $("#awg-fields").sortable({
      handle: ".awg-field-row__top",
      placeholder: "awg-sort-placeholder",
      forcePlaceholderSize: true
    });
  }

  $(document).ready(function(){
    ensureSortable();
  });

  $(document).on('click', '#awg-add-field', function(){
    const $fields = $('#awg-fields');
    const tpl = document.getElementById('awg-field-template');
    if (!tpl) return;

    const html = tpl.innerHTML;
    const idx = nextIndex($fields);
    const row = html.split('__INDEX__').join(String(idx));
    $fields.append(row);
    ensureSortable();
  });

  $(document).on('click', '.awg-remove-field', function(){
    $(this).closest('.awg-field-row').remove();
  });

})(jQuery);
