<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Admin {

    /** @var Memberships */
    private $memberships;

    /** @var Plans */
    private $plans;

    /** @var Usage */
    private $usage;

    public function __construct( Memberships $memberships, Plans $plans, Usage $usage ) {
        $this->memberships = $memberships;
        $this->plans       = $plans;
        $this->usage       = $usage;
    }

    public function menu(): void {
        add_menu_page(
            __( 'AuthorWings Members', 'authorwings-membership' ),
            __( 'AW Members', 'authorwings-membership' ),
            'manage_options',
            'awg-membership',
            [ $this, 'page_members' ],
            'dashicons-groups',
            57
        );

        add_submenu_page(
            'awg-membership',
            __( 'Members', 'authorwings-membership' ),
            __( 'Members', 'authorwings-membership' ),
            'manage_options',
            'awg-membership',
            [ $this, 'page_members' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Plans', 'authorwings-membership' ),
            __( 'Plans', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-plans',
            [ $this, 'page_plans' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Quote Requests', 'authorwings-membership' ),
            __( 'Quote Requests', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-orders',
            [ $this, 'page_orders' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Services', 'authorwings-membership' ),
            __( 'Services', 'authorwings-membership' ),
            'manage_options',
            'edit.php?post_type=awg_service'
        );

        add_submenu_page(
            'awg-membership',
            __( 'Settings', 'authorwings-membership' ),
            __( 'Settings', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-settings',
            [ $this, 'page_settings' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Release Tests', 'authorwings-membership' ),
            __( 'Release Tests', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-release-tests',
            [ $this, 'page_release_tests' ]
        );
    }


    public function page_release_tests(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        $results = null;
        if ( isset( $_POST['awg_mem_run_selftests'] ) && check_admin_referer( 'awg_mem_run_selftests_action', 'awg_mem_run_selftests_nonce' ) ) {
            $results = Plugin::instance()->selftest->run_all( get_current_user_id() );
        }
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Release Tests', 'authorwings-membership' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Run automated plugin self-tests before packaging or deploying updates. Then complete the manual release checklist included in the plugin package.', 'authorwings-membership' ); ?></p>
            <form method="post" class="awg-plan-form">
                <?php wp_nonce_field( 'awg_mem_run_selftests_action', 'awg_mem_run_selftests_nonce' ); ?>
                <p><button type="submit" name="awg_mem_run_selftests" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Run Self-Tests', 'authorwings-membership' ); ?></button></p>
            </form>
            <?php if ( is_array( $results ) ) : ?>
                <?php $all_passed = ! empty( $results['passed'] ); ?>
                <div class="notice <?php echo $all_passed ? 'notice-success' : 'notice-error'; ?>"><p><?php echo esc_html( $all_passed ? __( 'All automated self-tests passed.', 'authorwings-membership' ) : __( 'One or more self-tests failed. Review the results below before release.', 'authorwings-membership' ) ); ?></p></div>
                <table class="widefat striped awg-table-compact">
                    <thead><tr><th><?php esc_html_e( 'Test', 'authorwings-membership' ); ?></th><th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th><th><?php esc_html_e( 'Details', 'authorwings-membership' ); ?></th></tr></thead>
                    <tbody>
                    <?php foreach ( (array) $results['tests'] as $test ) : ?>
                        <tr>
                            <td><strong><?php echo esc_html( $test['name'] ); ?></strong></td>
                            <td><?php echo esc_html( ! empty( $test['passed'] ) ? __( 'Passed', 'authorwings-membership' ) : __( 'Failed', 'authorwings-membership' ) ); ?></td>
                            <td><?php echo esc_html( $test['message'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    public function register_settings(): void {
        register_setting( 'awg_mem_settings_group', Plugin::OPT, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_settings' ],
        ] );
    }

    public function sanitize_settings( $input ): array {
        $input = is_array( $input ) ? wp_unslash( $input ) : [];
        $out = [];
        $out['notify_admin_email'] = sanitize_email( $input['notify_admin_email'] ?? get_option( 'admin_email' ) );
        $out['stripe_secret_key']  = sanitize_text_field( $input['stripe_secret_key']  ?? '' );
        $out['stripe_public_key']  = sanitize_text_field( $input['stripe_public_key']  ?? '' );
        $out['stripe_webhook_secret'] = sanitize_text_field( $input['stripe_webhook_secret'] ?? '' );
        $out['dashboard_page_id']  = (int) ( $input['dashboard_page_id'] ?? 0 );
        $out['pricing_page_id']    = (int) ( $input['pricing_page_id'] ?? 0 );
        $out['enable_error_logging'] = isset( $input['enable_error_logging'] ) ? 1 : 0;
        $out['log_retention_days'] = max( 0, (int) ( $input['log_retention_days'] ?? 30 ) );
        $out['usage_retention_days'] = max( 0, (int) ( $input['usage_retention_days'] ?? 0 ) );
        $out['order_retention_days'] = max( 0, (int) ( $input['order_retention_days'] ?? 0 ) );
        $out['membership_retention_days'] = max( 0, (int) ( $input['membership_retention_days'] ?? 0 ) );
        $out['dashboard_primary_color'] = sanitize_hex_color( $input['dashboard_primary_color'] ?? '#1a73e8' ) ?: '#1a73e8';
        $out['dashboard_bg_color']      = sanitize_hex_color( $input['dashboard_bg_color'] ?? '#f7f9fc' ) ?: '#f7f9fc';
        $out['dashboard_card_bg']       = sanitize_hex_color( $input['dashboard_card_bg'] ?? '#ffffff' ) ?: '#ffffff';
        $out['dashboard_text_color']    = sanitize_hex_color( $input['dashboard_text_color'] ?? '#1a1a2e' ) ?: '#1a1a2e';
        $out['dashboard_border_color']  = sanitize_hex_color( $input['dashboard_border_color'] ?? '#e0e7ef' ) ?: '#e0e7ef';

        $out['dashboard_font_family']   = sanitize_text_field( $input['dashboard_font_family'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $out['dashboard_heading_font']  = sanitize_text_field( $input['dashboard_heading_font'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $out['dashboard_font_size']     = max( 12, (int) ( $input['dashboard_font_size'] ?? 16 ) );

        $out['dashboard_button_bg']     = sanitize_hex_color( $input['dashboard_button_bg'] ?? '#1a73e8' ) ?: '#1a73e8';
        $out['dashboard_button_text']   = sanitize_hex_color( $input['dashboard_button_text'] ?? '#ffffff' ) ?: '#ffffff';
        $out['dashboard_button_hover']  = sanitize_hex_color( $input['dashboard_button_hover'] ?? '#1558b0' ) ?: '#1558b0';
        $out['dashboard_button_radius'] = max( 0, (int) ( $input['dashboard_button_radius'] ?? 12 ) );

        $out['dashboard_card_padding']      = max( 0, (int) ( $input['dashboard_card_padding'] ?? 20 ) );
        $out['dashboard_card_shadow']       = sanitize_text_field( $input['dashboard_card_shadow'] ?? '0 10px 28px rgba(3,12,23,.04)' );
        $out['dashboard_card_hover_shadow'] = sanitize_text_field( $input['dashboard_card_hover_shadow'] ?? '0 12px 30px rgba(26,115,232,.12)' );
        $out['dashboard_card_border_width'] = max( 0, (float) ( $input['dashboard_card_border_width'] ?? 1 ) );

        $out['dashboard_radius']            = max( 0, (int) ( $input['dashboard_radius'] ?? 12 ) );
        $out['dashboard_max_width']         = max( 320, (int) ( $input['dashboard_max_width'] ?? 960 ) );
        $out['dashboard_container_padding'] = max( 0, (int) ( $input['dashboard_container_padding'] ?? 0 ) );
        $out['dashboard_grid_gap']          = max( 0, (int) ( $input['dashboard_grid_gap'] ?? 16 ) );
        $out['dashboard_section_spacing']   = max( 0, (int) ( $input['dashboard_section_spacing'] ?? 28 ) );

        $custom_css = trim( (string) ( $input['dashboard_custom_css'] ?? '' ) );
        $out['dashboard_custom_css'] = str_replace( [ '<', '>' ], '', $custom_css );
        return $out;
    }


    private function get_status_badge_markup( string $status ): string {
        $status = sanitize_key( $status );
        if ( 'in_progress' === $status ) {
            $status = 'responded';
        } elseif ( 'completed' === $status ) {
            $status = 'closed';
        }
        $map = [
            'active'    => [ 'label' => __( 'Active', 'authorwings-membership' ), 'bg' => '#dcfce7', 'color' => '#166534' ],
            'cancelled' => [ 'label' => __( 'Cancelled', 'authorwings-membership' ), 'bg' => '#e5e7eb', 'color' => '#374151' ],
            'pending'   => [ 'label' => __( 'Pending', 'authorwings-membership' ), 'bg' => '#fef3c7', 'color' => '#92400e' ],
            'trialing'  => [ 'label' => __( 'Trialing', 'authorwings-membership' ), 'bg' => '#dbeafe', 'color' => '#1d4ed8' ],
            'expired'   => [ 'label' => __( 'Expired', 'authorwings-membership' ), 'bg' => '#fee2e2', 'color' => '#991b1b' ],
            'payment_failed' => [ 'label' => __( 'Payment Failed', 'authorwings-membership' ), 'bg' => '#fee2e2', 'color' => '#991b1b' ],
            'responded' => [ 'label' => __( 'Responded', 'authorwings-membership' ), 'bg' => '#dbeafe', 'color' => '#1d4ed8' ],
            'closed' => [ 'label' => __( 'Closed', 'authorwings-membership' ), 'bg' => '#e5e7eb', 'color' => '#374151' ],
            
        ];

        $badge = $map[ $status ] ?? [
            'label' => ucwords( str_replace( '_', ' ', $status ?: 'unknown' ) ),
            'bg'    => '#f3f4f6',
            'color' => '#374151',
        ];

        return sprintf(
            '<span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;background:%1$s;color:%2$s;">%3$s</span>',
            esc_attr( $badge['bg'] ),
            esc_attr( $badge['color'] ),
            esc_html( $badge['label'] )
        );
    }

    private function get_member_usage_display( int $user_id, array $limits ): string {
        $used  = $this->usage->get_total_for_user( $user_id );
        $limit = isset( $limits['ai_generations_per_month'] ) ? (int) $limits['ai_generations_per_month'] : 0;

        if ( $limit < 0 ) {
            return sprintf( __( '%1$d / Unlimited', 'authorwings-membership' ), $used );
        }

        return sprintf( __( '%1$d / %2$d', 'authorwings-membership' ), $used, max( 0, $limit ) );
    }

    public function page_members(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        global $wpdb;
        $mems_table  = Database::mems_table();
        $plans_table = Database::plans_table();

        if ( isset( $_POST['awg_assign_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['awg_assign_plan_nonce'] ) ), 'awg_assign_plan' ) ) {
            $uid     = isset( $_POST['awg_uid'] ) ? (int) wp_unslash( (string) $_POST['awg_uid'] ) : 0;
            $plan_id = isset( $_POST['awg_plan_id'] ) ? (int) wp_unslash( (string) $_POST['awg_plan_id'] ) : 0;
            $billing_raw = isset( $_POST['awg_billing'] ) ? wp_unslash( (string) $_POST['awg_billing'] ) : '';
            $billing = in_array( $billing_raw, [ 'monthly', 'yearly', 'free' ], true )
                       ? sanitize_key( $billing_raw )
                       : 'monthly';
            if ( $uid && $plan_id ) {
                $this->memberships->set_user_plan( $uid, $plan_id, $billing );
                echo '<div class="notice notice-success"><p>' . esc_html__( 'Plan updated.', 'authorwings-membership' ) . '</p></div>';
            }
        }

        $search_term   = isset( $_GET['member_search'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['member_search'] ) ) : '';
        $status_filter = isset( $_GET['member_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['member_status'] ) ) : '';
        $plan_filter   = isset( $_GET['member_plan'] ) ? (int) wp_unslash( (string) $_GET['member_plan'] ) : 0;
        $edit_user_id  = isset( $_GET['edit_member'] ) ? (int) wp_unslash( (string) $_GET['edit_member'] ) : 0;

        $where = [ "m.id = (SELECT MAX(m2.id) FROM {$mems_table} m2 WHERE m2.user_id = m.user_id)" ];
        $query_args = [];

        if ( $status_filter && in_array( $status_filter, [ 'active', 'cancelled', 'trialing', 'expired', 'payment_failed' ], true ) ) {
            $where[] = 'm.status = %s';
            $query_args[] = $status_filter;
        } else {
            $where[] = "m.status IN ('active','cancelled','trialing','expired','payment_failed')";
        }

        if ( $plan_filter > 0 ) {
            $where[] = 'm.plan_id = %d';
            $query_args[] = $plan_filter;
        }

        if ( $search_term !== '' ) {
            $like = '%' . $wpdb->esc_like( $search_term ) . '%';
            $where[] = '(u.display_name LIKE %s OR u.user_email LIKE %s)';
            $query_args[] = $like;
            $query_args[] = $like;
        }

        $sql = "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, u.display_name, u.user_email
             FROM {$mems_table} m
             LEFT JOIN {$plans_table} p ON p.id = m.plan_id
             LEFT JOIN {$wpdb->users} u ON u.ID = m.user_id
             WHERE " . implode( ' AND ', $where ) . "
             ORDER BY m.id DESC
             LIMIT 100";

        if ( ! empty( $query_args ) ) {
            $members = $wpdb->get_results( $wpdb->prepare( $sql, $query_args ), ARRAY_A );
        } else {
            $members = $wpdb->get_results( $sql, ARRAY_A );
        }

        $all_plans = $this->plans->get_all_for_admin();
        $activity_summary = $this->usage->get_member_activity_summary( 15 );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'AuthorWings Members', 'authorwings-membership' ); ?></h1>
            <?php
            $total_active  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$mems_table} WHERE status = 'active'" );
            $total_paid    = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT m.user_id) FROM {$mems_table} m LEFT JOIN {$plans_table} p ON p.id = m.plan_id WHERE m.status = 'active' AND p.is_free = 0" );
            $total_free    = max( 0, $total_active - $total_paid );
            ?>
            <div style="display:flex;gap:16px;margin:16px 0;flex-wrap:wrap;">
                <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 24px;min-width:150px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;"><?php echo esc_html( $total_active ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Active Members', 'authorwings-membership' ); ?></div>
                </div>
                <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 24px;min-width:150px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;color:#1D9E75;"><?php echo esc_html( $total_paid ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Paid Members', 'authorwings-membership' ); ?></div>
                </div>
                <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 24px;min-width:150px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;color:#475569;"><?php echo esc_html( $total_free ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Free Members', 'authorwings-membership' ); ?></div>
                </div>
            </div>

            <div class="awg-card">
                <h2 style="margin-top:0;"><?php esc_html_e( 'Member Activity Summary', 'authorwings-membership' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Shows one row per member with current-month total usage and latest recorded AI activity.', 'authorwings-membership' ); ?></p>
                <table class="widefat striped awg-table-compact">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Member', 'authorwings-membership' ); ?></th>
                            <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                            <th><?php esc_html_e( 'Total Usage', 'authorwings-membership' ); ?></th>
                            <th><?php esc_html_e( 'Last Activity', 'authorwings-membership' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( empty( $activity_summary ) ) : ?>
                            <tr><td colspan="4"><?php esc_html_e( 'No member activity recorded yet.', 'authorwings-membership' ); ?></td></tr>
                        <?php else : ?>
                            <?php foreach ( $activity_summary as $row ) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html( $row['display_name'] ); ?></strong><br><small><?php echo esc_html( $row['user_email'] ); ?></small></td>
                                    <td><?php echo esc_html( $row['plan_name'] ); ?></td>
                                    <td><?php echo esc_html( (string) $row['month_used'] ); ?></td>
                                    <td><?php echo ! empty( $row['last_activity'] ) ? esc_html( wp_date( 'd M Y g:i a', strtotime( $row['last_activity'] ) ) ) : '—'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="awg-card">
                <form method="get" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end;">
                    <input type="hidden" name="page" value="awg-membership">
                    <div>
                        <label for="awg-member-search" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Search', 'authorwings-membership' ); ?></label>
                        <input id="awg-member-search" type="search" name="member_search" value="<?php echo esc_attr( $search_term ); ?>" placeholder="<?php esc_attr_e( 'Name or email', 'authorwings-membership' ); ?>" class="regular-text">
                    </div>
                    <div>
                        <label for="awg-member-plan" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></label>
                        <select id="awg-member-plan" name="member_plan">
                            <option value="0"><?php esc_html_e( 'All plans', 'authorwings-membership' ); ?></option>
                            <?php foreach ( $all_plans as $plan ) : ?>
                                <option value="<?php echo esc_attr( $plan['id'] ); ?>" <?php selected( $plan_filter, (int) $plan['id'] ); ?>><?php echo esc_html( $plan['name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="awg-member-status" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></label>
                        <select id="awg-member-status" name="member_status">
                            <option value=""><?php esc_html_e( 'All statuses', 'authorwings-membership' ); ?></option>
                            <option value="active" <?php selected( $status_filter, 'active' ); ?>><?php esc_html_e( 'Active', 'authorwings-membership' ); ?></option>
                            <option value="cancelled" <?php selected( $status_filter, 'cancelled' ); ?>><?php esc_html_e( 'Cancelled', 'authorwings-membership' ); ?></option>
                            <option value="trialing" <?php selected( $status_filter, 'trialing' ); ?>><?php esc_html_e( 'Trialing', 'authorwings-membership' ); ?></option>
                            <option value="expired" <?php selected( $status_filter, 'expired' ); ?>><?php esc_html_e( 'Expired', 'authorwings-membership' ); ?></option>
                            <option value="payment_failed" <?php selected( $status_filter, 'payment_failed' ); ?>><?php esc_html_e( 'Payment Failed', 'authorwings-membership' ); ?></option>
                        </select>
                    </div>
                    <div class="awg-actions-inline">
                        <button class="button button-primary awg-btn-primary" type="submit"><?php esc_html_e( 'Filter', 'authorwings-membership' ); ?></button>
                        <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership' ) ); ?>"><?php esc_html_e( 'Reset', 'authorwings-membership' ); ?></a>
                    </div>
                </form>
            </div>

            <table class="widefat striped awg-table-compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Member', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Billing', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Usage', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Ends', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Action', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $members ) ) : ?>
                        <tr><td colspan="8"><?php esc_html_e( 'No memberships found for the current filters.', 'authorwings-membership' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $members as $m ) : ?>
                            <?php $limits = json_decode( $m['limits'] ?? '{}', true ) ?: []; ?>
                            <tr>
                                <td><?php echo esc_html( $m['id'] ); ?></td>
                                <td><strong><?php echo esc_html( $m['display_name'] ); ?></strong><br><small><?php echo esc_html( $m['user_email'] ); ?></small></td>
                                <td><?php echo esc_html( $m['plan_name'] ?: '—' ); ?></td>
                                <td><?php echo esc_html( ucfirst( $m['billing_cycle'] ) ); ?></td>
                                <td><?php echo esc_html( $this->get_member_usage_display( (int) $m['user_id'], $limits ) ); ?></td>
                                <td><?php echo wp_kses_post( $this->get_status_badge_markup( (string) $m['status'] ) ); ?></td>
                                <td><?php echo ! empty( $m['end_date'] ) ? esc_html( wp_date( 'd M Y', strtotime( $m['end_date'] ) ) ) : '—'; ?></td>
                                <td>
                                    <?php if ( $edit_user_id === (int) $m['user_id'] ) : ?>
                                        <form method="post" class="awg-actions-inline">
                                            <?php wp_nonce_field( 'awg_assign_plan', 'awg_assign_plan_nonce' ); ?>
                                            <input type="hidden" name="awg_uid" value="<?php echo esc_attr( $m['user_id'] ); ?>">
                                            <select name="awg_plan_id">
                                                <?php foreach ( $all_plans as $plan ) : ?>
                                                    <option value="<?php echo esc_attr( $plan['id'] ); ?>" <?php selected( (int) $plan['id'], (int) $m['plan_id'] ); ?>><?php echo esc_html( $plan['name'] ); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <select name="awg_billing">
                                                <option value="monthly" <?php selected( $m['billing_cycle'], 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'authorwings-membership' ); ?></option>
                                                <option value="yearly" <?php selected( $m['billing_cycle'], 'yearly' ); ?>><?php esc_html_e( 'Yearly', 'authorwings-membership' ); ?></option>
                                                <option value="free" <?php selected( $m['billing_cycle'], 'free' ); ?>><?php esc_html_e( 'Free', 'authorwings-membership' ); ?></option>
                                            </select>
                                            <button class="button button-primary button-small awg-btn-save" type="submit"><?php esc_html_e( 'Save', 'authorwings-membership' ); ?></button>
                                            <a class="button button-small awg-btn-edit" href="<?php echo esc_url( remove_query_arg( 'edit_member' ) ); ?>"><?php esc_html_e( 'Cancel', 'authorwings-membership' ); ?></a>
                                        </form>
                                    <?php else : ?>
                                        <a class="button button-small awg-btn-edit" href="<?php echo esc_url( add_query_arg( 'edit_member', (int) $m['user_id'] ) ); ?>"><?php esc_html_e( 'Edit', 'authorwings-membership' ); ?></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_plans(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        $notice = '';
        $editing_plan = null;

        if ( isset( $_GET['plan_action'], $_GET['plan_id'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'awg_plan_action' ) ) {
            $plan_action = sanitize_key( wp_unslash( $_GET['plan_action'] ) );
            $plan_id     = (int) $_GET['plan_id'];
            $plan        = $this->plans->get( $plan_id );

            if ( $plan ) {
                if ( 'delete' === $plan_action ) {
                    $assigned_count = $this->plans->count_members_assigned( $plan_id );
                    if ( $assigned_count > 0 ) {
                        $notice = '<div class="notice notice-error"><p>' . sprintf( esc_html__( 'Plan cannot be deleted because %d members are assigned to it.', 'authorwings-membership' ), $assigned_count ) . '</p></div>';
                    } elseif ( $this->plans->delete_plan( $plan_id ) ) {
                        $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Plan deleted.', 'authorwings-membership' ) . '</p></div>';
                    } else {
                        $notice = '<div class="notice notice-error"><p>' . esc_html__( 'Plan could not be deleted.', 'authorwings-membership' ) . '</p></div>';
                    }
                } elseif ( in_array( $plan_action, [ 'activate', 'deactivate' ], true ) ) {
                    $plan['is_active'] = 'activate' === $plan_action ? 1 : 0;
                    $this->plans->save_plan( $plan );
                    $notice = '<div class="notice notice-success"><p>' . ( 'activate' === $plan_action ? esc_html__( 'Plan activated.', 'authorwings-membership' ) : esc_html__( 'Plan deactivated.', 'authorwings-membership' ) ) . '</p></div>';
                }
            }
        }

        if ( isset( $_POST['awg_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_plan_nonce'] ) ), 'awg_save_plan' ) ) {
            $plan_id         = (int) ( $_POST['plan_id'] ?? 0 );
            $is_unlimited    = ! empty( $_POST['limit_ai_unlimited'] );
            $raw_limit_value = isset( $_POST['limit_ai_generations'] ) ? wp_unslash( (string) $_POST['limit_ai_generations'] ) : '0';
            $usage_limit     = $is_unlimited ? -1 : max( 0, (int) $raw_limit_value );

            $feature_lines = preg_split( '/
|
|
/', (string) wp_unslash( $_POST['features'] ?? '' ) ) ?: [];
            $plan_payload = [
                'id'                      => $plan_id,
                'name'                    => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
                'slug'                    => sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) ),
                'description'             => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
                'price_monthly'           => (float) ( $_POST['price_monthly'] ?? 0 ),
                'price_yearly'            => (float) ( $_POST['price_yearly'] ?? 0 ),
                'currency'                => sanitize_text_field( wp_unslash( $_POST['currency'] ?? 'USD' ) ),
                'sort_order'              => (int) ( $_POST['sort_order'] ?? 0 ),
                'stripe_monthly_price_id' => sanitize_text_field( wp_unslash( $_POST['stripe_monthly_price_id'] ?? '' ) ),
                'stripe_yearly_price_id'  => sanitize_text_field( wp_unslash( $_POST['stripe_yearly_price_id'] ?? '' ) ),
                'features'                => array_values( array_filter( array_map( 'sanitize_text_field', $feature_lines ), static function ( $feature ) {
                    return '' !== trim( (string) $feature );
                } ) ),
                'is_active'               => ! empty( $_POST['is_active'] ) ? 1 : 0,
                'is_free'                 => ! empty( $_POST['is_free'] ) ? 1 : 0,
                'limits'                  => [
                    'ai_generations_per_month' => $usage_limit,
                    'tools_access'             => sanitize_key( $_POST['limit_tools_access'] ?? 'free' ),
                    'team_seats'               => max( 0, (int) ( $_POST['limit_team_seats'] ?? 0 ) ),
                ],
            ];

            $validation = $this->plans->validate_plan_input( $plan_payload );
            if ( $validation['valid'] ) {
                $saved_id = $this->plans->save_plan( $validation['data'] );
                $editing_plan = $this->plans->get( $saved_id );
                $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Plan saved.', 'authorwings-membership' ) . '</p></div>';
            } else {
                $editing_plan = array_merge( [ 'limits' => [] ], $plan_payload );
                $error_lines = '';
                foreach ( (array) $validation['errors'] as $error ) {
                    $error_lines .= '<li>' . esc_html( $error ) . '</li>';
                }
                $notice = '<div class="notice notice-error"><p>' . esc_html__( 'Plan could not be saved.', 'authorwings-membership' ) . '</p><ul style="margin:8px 0 0 18px;list-style:disc;">' . $error_lines . '</ul></div>';
            }
        }

        if ( ! $editing_plan && isset( $_GET['edit_plan'] ) ) {
            $editing_plan = $this->plans->get( (int) $_GET['edit_plan'] );
        }

        if ( ! $editing_plan ) {
            $editing_plan = [
                'id'            => 0,
                'name'          => '',
                'slug'          => '',
                'price_monthly' => '0.00',
                'price_yearly'  => '0.00',
                'is_free'       => 0,
                'description'   => '',
                'currency'      => 'USD',
                'is_active'     => 1,
                'sort_order'    => 0,
                'features'      => [],
                'limits'        => [
                    'ai_generations_per_month' => 0,
                    'tools_access'             => 'free',
                    'team_seats'               => 0,
                ],
                'stripe_monthly_price_id' => '',
                'stripe_yearly_price_id'  => '',
            ];
        }

        $plans = $this->plans->get_all_for_admin();
        $current_limit = (int) ( $editing_plan['limits']['ai_generations_per_month'] ?? 0 );
        $is_unlimited  = $current_limit < 0;
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Membership Plans', 'authorwings-membership' ); ?></h1>
            <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

            <div style="display:grid;grid-template-columns:minmax(320px,430px) 1fr;gap:22px;align-items:start;">
                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:18px;">
                    <h2 style="margin-top:0;"><?php echo $editing_plan['id'] ? esc_html__( 'Edit Plan', 'authorwings-membership' ) : esc_html__( 'Add Plan', 'authorwings-membership' ); ?></h2>
                    <p class="description" style="margin-top:-4px;"><?php esc_html_e( 'Edit plan pricing, limits, front-end description, and feature list from one place.', 'authorwings-membership' ); ?></p>
                    <form method="post" class="awg-plan-form">
                        <?php wp_nonce_field( 'awg_save_plan', 'awg_plan_nonce' ); ?>
                        <input type="hidden" name="plan_id" value="<?php echo esc_attr( $editing_plan['id'] ); ?>">
                        <table class="form-table awg-plan-form-table" role="presentation">
                            <tr><th><label for="awg-plan-name"><?php esc_html_e( 'Plan Name', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-name" class="regular-text" type="text" name="name" value="<?php echo esc_attr( $editing_plan['name'] ); ?>" required></td></tr>
                            <tr><th><label for="awg-plan-slug"><?php esc_html_e( 'Slug', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-slug" class="regular-text" type="text" name="slug" value="<?php echo esc_attr( $editing_plan['slug'] ); ?>" required><p class="description"><?php esc_html_e( 'Used internally for access checks and links.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><?php esc_html_e( 'Monthly Price', 'authorwings-membership' ); ?></th><td><input type="number" step="0.01" min="0" name="price_monthly" value="<?php echo esc_attr( $editing_plan['price_monthly'] ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Yearly Price', 'authorwings-membership' ); ?></th><td><input type="number" step="0.01" min="0" name="price_yearly" value="<?php echo esc_attr( $editing_plan['price_yearly'] ); ?>"></td></tr>
                            <tr><th><label for="awg-plan-description"><?php esc_html_e( 'Description', 'authorwings-membership' ); ?></label></th><td><textarea id="awg-plan-description" class="large-text" rows="3" name="description"><?php echo esc_textarea( $editing_plan['description'] ?? '' ); ?></textarea><p class="description"><?php esc_html_e( 'Shown on pricing and membership screens.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-features"><?php esc_html_e( 'Plan Features', 'authorwings-membership' ); ?></label></th><td><textarea id="awg-plan-features" class="large-text" rows="8" name="features"><?php echo esc_textarea( implode( "
", (array) ( $editing_plan['features'] ?? [] ) ) ); ?></textarea><p class="description"><?php esc_html_e( 'One feature per line. These are the items shown on the member dashboard cards.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr>
                                <th><?php esc_html_e( 'Usage Limit', 'authorwings-membership' ); ?></th>
                                <td>
                                    <label style="display:inline-flex;align-items:center;gap:6px;margin-bottom:8px;">
                                        <input type="checkbox" name="limit_ai_unlimited" value="1" <?php checked( $is_unlimited ); ?>>
                                        <?php esc_html_e( 'Unlimited', 'authorwings-membership' ); ?>
                                    </label><br>
                                    <input type="number" min="0" name="limit_ai_generations" value="<?php echo esc_attr( $is_unlimited ? 0 : $current_limit ); ?>" <?php disabled( $is_unlimited ); ?>>
                                    <p class="description"><?php esc_html_e( 'Monthly AI generations for this plan.', 'authorwings-membership' ); ?></p>
                                </td>
                            </tr>
                            <tr><th><?php esc_html_e( 'Access Level', 'authorwings-membership' ); ?></th><td><select class="regular-text" name="limit_tools_access"><option value="free" <?php selected( $editing_plan['limits']['tools_access'] ?? 'free', 'free' ); ?>>Free</option><option value="basic" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'basic' ); ?>>Basic</option><option value="pro" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'pro' ); ?>>Pro</option><option value="publisher" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'publisher' ); ?>>Publisher</option></select></td></tr>
                            <tr><th><label for="awg-plan-team-seats"><?php esc_html_e( 'Team Seats', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-team-seats" type="number" min="0" name="limit_team_seats" value="<?php echo esc_attr( (int) ( $editing_plan['limits']['team_seats'] ?? 0 ) ); ?>"><p class="description"><?php esc_html_e( 'Used for the Publisher workspace seat limit.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-sort-order"><?php esc_html_e( 'Sort Order', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-sort-order" type="number" min="0" name="sort_order" value="<?php echo esc_attr( (int) ( $editing_plan['sort_order'] ?? 0 ) ); ?>"><p class="description"><?php esc_html_e( 'Controls plan order in admin and front view.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-currency"><?php esc_html_e( 'Currency', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-currency" class="regular-text" type="text" name="currency" value="<?php echo esc_attr( $editing_plan['currency'] ?? 'USD' ); ?>"><p class="description"><?php esc_html_e( 'Usually USD.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-stripe-monthly"><?php esc_html_e( 'Stripe Monthly Price ID', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-stripe-monthly" class="regular-text" type="text" name="stripe_monthly_price_id" value="<?php echo esc_attr( $editing_plan['stripe_monthly_price_id'] ?? '' ); ?>"></td></tr>
                            <tr><th><label for="awg-plan-stripe-yearly"><?php esc_html_e( 'Stripe Yearly Price ID', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-stripe-yearly" class="regular-text" type="text" name="stripe_yearly_price_id" value="<?php echo esc_attr( $editing_plan['stripe_yearly_price_id'] ?? '' ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th><td><label><input type="checkbox" name="is_active" value="1" <?php checked( ! empty( $editing_plan['is_active'] ) ); ?>> <?php esc_html_e( 'Active', 'authorwings-membership' ); ?></label><br><label><input type="checkbox" name="is_free" value="1" <?php checked( ! empty( $editing_plan['is_free'] ) ); ?>> <?php esc_html_e( 'Free plan', 'authorwings-membership' ); ?></label></td></tr>
                        </table>
                        <p>
                            <button type="submit" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Save Plan', 'authorwings-membership' ); ?></button>
                            <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-plans' ) ); ?>"><?php esc_html_e( 'Add New', 'authorwings-membership' ); ?></a>
                        </p>
                    </form>
                    <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        var checkbox = document.querySelector('input[name="limit_ai_unlimited"]');
                        var input = document.querySelector('input[name="limit_ai_generations"]');
                        var nameInput = document.getElementById('awg-plan-name');
                        var slugInput = document.getElementById('awg-plan-slug');
                        if (checkbox && input) {
                            var syncState = function () {
                                input.disabled = checkbox.checked;
                            };
                            checkbox.addEventListener('change', syncState);
                            syncState();
                        }
                        if (nameInput && slugInput) {
                            var slugTouched = slugInput.value.trim() !== '';
                            slugInput.addEventListener('input', function () {
                                slugTouched = slugInput.value.trim() !== '';
                            });
                            nameInput.addEventListener('input', function () {
                                if (slugTouched) { return; }
                                slugInput.value = nameInput.value
                                    .toLowerCase()
                                    .trim()
                                    .replace(/[^a-z0-9\s-]/g, '')
                                    .replace(/\s+/g, '-')
                                    .replace(/-+/g, '-');
                            });
                        }
                    });
                    </script>
                </div>

                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:18px;">
                    <h2 style="margin-top:0;"><?php esc_html_e( 'All Plans', 'authorwings-membership' ); ?></h2>
                    <table class="widefat striped awg-table-compact">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Prices', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Usage Limit', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Access Level', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( empty( $plans ) ) : ?>
                                <tr><td colspan="6"><?php esc_html_e( 'No plans found.', 'authorwings-membership' ); ?></td></tr>
                            <?php else : ?>
                                <?php foreach ( $plans as $plan ) : ?>
                                    <?php $limit = (int) ( $plan['limits']['ai_generations_per_month'] ?? 0 ); ?>
                                    <tr>
                                        <?php $assigned_count = $this->plans->count_members_assigned( (int) $plan['id'] ); ?>
                                        <?php $toggle_action = ! empty( $plan['is_active'] ) ? 'deactivate' : 'activate'; ?>
                                        <?php $toggle_label  = ! empty( $plan['is_active'] ) ? __( 'Deactivate', 'authorwings-membership' ) : __( 'Activate', 'authorwings-membership' ); ?>
                                        <?php $edit_url = admin_url( 'admin.php?page=awg-membership-plans&edit_plan=' . (int) $plan['id'] ); ?>
                                        <?php $toggle_url = wp_nonce_url( admin_url( 'admin.php?page=awg-membership-plans&plan_action=' . $toggle_action . '&plan_id=' . (int) $plan['id'] ), 'awg_plan_action' ); ?>
                                        <?php $delete_url = wp_nonce_url( admin_url( 'admin.php?page=awg-membership-plans&plan_action=delete&plan_id=' . (int) $plan['id'] ), 'awg_plan_action' ); ?>
                                        <td><?php echo esc_html( $plan['id'] ); ?></td>
                                        <td>
                                            <strong><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $plan['name'] ); ?></a></strong>
                                            <div class="row-actions visible">
                                                <span class="edit"><a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'authorwings-membership' ); ?></a></span> | 
                                                <span class="toggle"><a href="<?php echo esc_url( $toggle_url ); ?>"><?php echo esc_html( $toggle_label ); ?></a></span> | 
                                                <?php if ( $assigned_count > 0 ) : ?>
                                                    <span class="trash"><span class="submitdelete" style="cursor:not-allowed;opacity:.7;"><?php esc_html_e( 'Delete', 'authorwings-membership' ); ?></span></span>
                                                <?php else : ?>
                                                    <span class="trash"><a class="submitdelete" href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this plan?', 'authorwings-membership' ) ); ?>');"><?php esc_html_e( 'Delete', 'authorwings-membership' ); ?></a></span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="description awg-plan-assigned"><?php echo esc_html( sprintf( _n( '%d member assigned', '%d members assigned', $assigned_count, 'authorwings-membership' ), $assigned_count ) ); ?></p>
                                        </td>
                                        <td>
                                            <?php if ( ! empty( $plan['is_free'] ) ) : ?>
                                                <?php esc_html_e( 'Free', 'authorwings-membership' ); ?>
                                            <?php else : ?>
                                                $<?php echo esc_html( number_format( (float) $plan['price_monthly'], 2 ) ); ?> / <?php esc_html_e( 'month', 'authorwings-membership' ); ?><br>
                                                $<?php echo esc_html( number_format( (float) $plan['price_yearly'], 2 ) ); ?> / <?php esc_html_e( 'year', 'authorwings-membership' ); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo esc_html( $limit < 0 ? __( 'Unlimited', 'authorwings-membership' ) : $limit . '/month' ); ?></td>
                                        <td><?php echo esc_html( ucfirst( (string) ( $plan['limits']['tools_access'] ?? 'free' ) ) ); ?></td>
                                        <td><?php echo ! empty( $plan['is_active'] ) ? esc_html__( 'Active', 'authorwings-membership' ) : esc_html__( 'Inactive', 'authorwings-membership' ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public function page_orders(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        global $wpdb;
        $table = Database::orders_table();

        if ( isset( $_POST['awg_order_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['awg_order_nonce'] ) ), 'awg_update_order' ) ) {
            $order_id = isset( $_POST['awg_order_id'] ) ? (int) wp_unslash( (string) $_POST['awg_order_id'] ) : 0;
            $status   = isset( $_POST['awg_order_status'] ) ? sanitize_key( wp_unslash( (string) $_POST['awg_order_status'] ) ) : 'pending';
            $notes    = isset( $_POST['awg_order_notes'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['awg_order_notes'] ) ) : '';

            if ( 'in_progress' === $status ) {
                $status = 'responded';
            } elseif ( 'completed' === $status ) {
                $status = 'closed';
            }

            if ( ! in_array( $status, [ 'pending', 'responded', 'closed' ], true ) ) {
                $status = 'pending';
            }

            if ( $order_id > 0 ) {
                $updated = $wpdb->update(
                    $table,
                    [
                        'status'      => $status,
                        'admin_notes' => $notes,
                        'updated_at'  => current_time( 'mysql' ),
                    ],
                    [ 'id' => $order_id ],
                    [ '%s', '%s', '%s' ],
                    [ '%d' ]
                );

                if ( false !== $updated ) {
                    echo '<div class="notice notice-success"><p>' . esc_html__( 'Quote request updated.', 'authorwings-membership' ) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>' . esc_html__( 'Could not update this quote request.', 'authorwings-membership' ) . '</p></div>';
                }
            }
        }

        $edit_order_id   = isset( $_GET['edit_order'] ) ? (int) wp_unslash( (string) $_GET['edit_order'] ) : 0;
        $view_order_id   = isset( $_GET['view_order'] ) ? (int) wp_unslash( (string) $_GET['view_order'] ) : 0;
        $search_query    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['s'] ) ) : '';
        $status_filter   = isset( $_GET['request_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['request_status'] ) ) : '';
        if ( 'in_progress' === $status_filter ) {
            $status_filter = 'responded';
        } elseif ( 'completed' === $status_filter ) {
            $status_filter = 'closed';
        }
        if ( ! in_array( $status_filter, [ '', 'pending', 'responded', 'closed' ], true ) ) {
            $status_filter = '';
        }

        $where = [];
        $args  = [];

        if ( '' !== $status_filter ) {
            $where[] = 'o.status = %s';
            $args[]  = $status_filter;
        }

        if ( '' !== $search_query ) {
            $like = '%' . $wpdb->esc_like( $search_query ) . '%';
            $where[] = '(o.service_name LIKE %s OR o.service_slug LIKE %s OR o.notes LIKE %s OR o.admin_notes LIKE %s OR u.display_name LIKE %s OR u.user_email LIKE %s)';
            array_push( $args, $like, $like, $like, $like, $like, $like );
        }

        $sql = "SELECT o.*, u.display_name, u.user_email FROM {$table} o LEFT JOIN {$wpdb->users} u ON u.ID = o.user_id";
        if ( ! empty( $where ) ) {
            $sql .= ' WHERE ' . implode( ' AND ', $where );
        }
        $sql .= ' ORDER BY o.id DESC LIMIT 100';

        if ( ! empty( $args ) ) {
            $orders = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        } else {
            $orders = $wpdb->get_results( $sql, ARRAY_A );
        }

        $count_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $count_pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'pending'" );
        $count_responded = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status IN ('responded','in_progress')" );
        $count_closed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status IN ('closed','completed')" );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Quote Requests', 'authorwings-membership' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Basic workflow only: Pending, Responded, Closed.', 'authorwings-membership' ); ?></p>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;max-width:900px;margin:18px 0 20px;">
                <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;"><div style="font-size:12px;color:#6b7280;margin-bottom:6px;"><?php esc_html_e( 'Total Requests', 'authorwings-membership' ); ?></div><div style="font-size:24px;font-weight:700;"><?php echo esc_html( $count_total ); ?></div></div>
                <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;"><div style="font-size:12px;color:#6b7280;margin-bottom:6px;"><?php esc_html_e( 'Pending', 'authorwings-membership' ); ?></div><div style="font-size:24px;font-weight:700;"><?php echo esc_html( $count_pending ); ?></div></div>
                <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;"><div style="font-size:12px;color:#6b7280;margin-bottom:6px;"><?php esc_html_e( 'Responded', 'authorwings-membership' ); ?></div><div style="font-size:24px;font-weight:700;"><?php echo esc_html( $count_responded ); ?></div></div>
                <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:16px;"><div style="font-size:12px;color:#6b7280;margin-bottom:6px;"><?php esc_html_e( 'Closed', 'authorwings-membership' ); ?></div><div style="font-size:24px;font-weight:700;"><?php echo esc_html( $count_closed ); ?></div></div>
            </div>

            <form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:0 0 16px;">
                <input type="hidden" name="page" value="awg-membership-orders">
                <div>
                    <label for="awg-quote-search" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Search', 'authorwings-membership' ); ?></label>
                    <input type="search" id="awg-quote-search" name="s" value="<?php echo esc_attr( $search_query ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Service, user, email, notes', 'authorwings-membership' ); ?>">
                </div>
                <div>
                    <label for="awg-request-status" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></label>
                    <select id="awg-request-status" name="request_status">
                        <option value=""><?php esc_html_e( 'All statuses', 'authorwings-membership' ); ?></option>
                        <option value="pending" <?php selected( $status_filter, 'pending' ); ?>><?php esc_html_e( 'Pending', 'authorwings-membership' ); ?></option>
                        <option value="responded" <?php selected( $status_filter, 'responded' ); ?>><?php esc_html_e( 'Responded', 'authorwings-membership' ); ?></option>
                        <option value="closed" <?php selected( $status_filter, 'closed' ); ?>><?php esc_html_e( 'Closed', 'authorwings-membership' ); ?></option>
                    </select>
                </div>
                <div class="awg-actions-inline">
                    <button type="submit" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Filter', 'authorwings-membership' ); ?></button>
                    <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders' ) ); ?>"><?php esc_html_e( 'Reset', 'authorwings-membership' ); ?></a>
                </div>
            </form>

            <table class="widefat striped awg-table-compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Service', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'User', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Request Details', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Admin Notes', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $orders ) ) : ?>
                        <tr><td colspan="8"><?php esc_html_e( 'No quote requests found.', 'authorwings-membership' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $orders as $o ) : ?>
                            <?php
                            $row_status = sanitize_key( (string) ( $o['status'] ?? 'pending' ) );
                            if ( 'in_progress' === $row_status ) {
                                $row_status = 'responded';
                            } elseif ( 'completed' === $row_status ) {
                                $row_status = 'closed';
                            }
                            if ( ! in_array( $row_status, [ 'pending', 'responded', 'closed' ], true ) ) {
                                $row_status = 'pending';
                            }
                            ?>
                            <tr>
                                <td><?php echo esc_html( (int) $o['id'] ); ?></td>
                                <td><strong><?php echo esc_html( (string) $o['service_name'] ); ?></strong></td>
                                <td><?php echo esc_html( (string) $o['display_name'] ); ?><br><small><?php echo esc_html( (string) $o['user_email'] ); ?></small></td>
                                <td><?php echo wp_kses_post( $this->get_status_badge_markup( $row_status ) ); ?></td>
                                <td><?php echo esc_html( wp_trim_words( (string) $o['notes'], 18 ) ); ?></td>
                                <td><?php echo esc_html( wp_trim_words( (string) $o['admin_notes'], 18 ) ?: '—' ); ?></td>
                                <td><?php echo esc_html( wp_date( 'd M Y', strtotime( (string) $o['created_at'] ) ) ); ?></td>
                                <td>
                                    <a class="button button-small awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders&view_order=' . (int) $o['id'] ) ); ?>"><?php esc_html_e( 'View', 'authorwings-membership' ); ?></a>
                                    <a class="button button-small awg-btn-edit" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders&edit_order=' . (int) $o['id'] ) ); ?>"><?php esc_html_e( 'Edit', 'authorwings-membership' ); ?></a>
                                </td>
                            </tr>
                            <?php if ( $view_order_id === (int) $o['id'] ) : ?>
                                <tr>
                                    <td colspan="8" style="background:#f8fafc;">
                                        <div style="display:grid;gap:14px;max-width:900px;padding:8px 0;">
                                            <div><strong><?php esc_html_e( 'Full Request Details', 'authorwings-membership' ); ?></strong><div style="margin-top:6px;white-space:pre-wrap;"><?php echo esc_html( (string) $o['notes'] ); ?></div></div>
                                            <div><strong><?php esc_html_e( 'Admin Notes', 'authorwings-membership' ); ?></strong><div style="margin-top:6px;white-space:pre-wrap;"><?php echo esc_html( (string) ( $o['admin_notes'] ?: '—' ) ); ?></div></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php if ( $edit_order_id === (int) $o['id'] ) : ?>
                                <tr>
                                    <td colspan="8" style="background:#f8fafc;">
                                        <form method="post" style="display:grid;gap:14px;max-width:760px;padding:8px 0;">
                                            <?php wp_nonce_field( 'awg_update_order', 'awg_order_nonce' ); ?>
                                            <input type="hidden" name="awg_order_id" value="<?php echo esc_attr( $o['id'] ); ?>">
                                            <div>
                                                <label for="awg-order-status-<?php echo esc_attr( $o['id'] ); ?>" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Request Status', 'authorwings-membership' ); ?></label>
                                                <select id="awg-order-status-<?php echo esc_attr( $o['id'] ); ?>" name="awg_order_status">
                                                    <option value="pending" <?php selected( $row_status, 'pending' ); ?>><?php esc_html_e( 'Pending', 'authorwings-membership' ); ?></option>
                                                    <option value="responded" <?php selected( $row_status, 'responded' ); ?>><?php esc_html_e( 'Responded', 'authorwings-membership' ); ?></option>
                                                    <option value="closed" <?php selected( $row_status, 'closed' ); ?>><?php esc_html_e( 'Closed', 'authorwings-membership' ); ?></option>
                                                </select>
                                            </div>
                                            <div>
                                                <label for="awg-order-notes-<?php echo esc_attr( $o['id'] ); ?>" style="display:block;font-weight:600;margin-bottom:6px;"><?php esc_html_e( 'Admin Notes', 'authorwings-membership' ); ?></label>
                                                <textarea id="awg-order-notes-<?php echo esc_attr( $o['id'] ); ?>" name="awg_order_notes" rows="5" class="large-text"><?php echo esc_textarea( (string) $o['admin_notes'] ); ?></textarea>
                                            </div>
                                            <div class="awg-actions-inline">
                                                <button type="submit" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Save', 'authorwings-membership' ); ?></button>
                                                <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders' ) ); ?>"><?php esc_html_e( 'Cancel', 'authorwings-membership' ); ?></a>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $s = get_option( Plugin::OPT, [] );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'AuthorWings Membership Settings', 'authorwings-membership' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'awg_mem_settings_group' ); ?>

                <h2><?php esc_html_e( 'General Settings', 'authorwings-membership' ); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Admin Notification Email', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="email" name="<?php echo esc_attr( Plugin::OPT ); ?>[notify_admin_email]"
                                   value="<?php echo esc_attr( $s['notify_admin_email'] ?? get_option( 'admin_email' ) ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Secret Key', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_secret_key]"
                                   value="<?php echo esc_attr( $s['stripe_secret_key'] ?? '' ); ?>"
                                   class="regular-text" autocomplete="off">
                            <p class="description"><?php esc_html_e( 'Your Stripe secret key (sk_live_... or sk_test_...)', 'authorwings-membership' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Publishable Key', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_public_key]"
                                   value="<?php echo esc_attr( $s['stripe_public_key'] ?? '' ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Webhook Secret', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_webhook_secret]"
                                   value="<?php echo esc_attr( $s['stripe_webhook_secret'] ?? '' ); ?>"
                                   class="regular-text" autocomplete="off">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Dashboard Page', 'authorwings-membership' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[dashboard_page_id]',
                                'selected'         => (int) ( $s['dashboard_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (member-dashboard)', 'authorwings-membership' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Pricing Page', 'authorwings-membership' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[pricing_page_id]',
                                'selected'         => (int) ( $s['pricing_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (pricing)', 'authorwings-membership' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Enable sanitized error logging', 'authorwings-membership' ); ?></th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr( Plugin::OPT ); ?>[enable_error_logging]" value="1" <?php checked( ! empty( $s['enable_error_logging'] ) ); ?>> <?php esc_html_e( 'Keep billing and membership errors in an internal log without exposing secrets.', 'authorwings-membership' ); ?></label></td>
                    </tr>
                    <tr><th><?php esc_html_e( 'Error log retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[log_retention_days]" value="<?php echo esc_attr( $s['log_retention_days'] ?? 30 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps logs until manually cleared. Positive values remove older logs during daily cleanup.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Usage retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[usage_retention_days]" value="<?php echo esc_attr( $s['usage_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps usage records indefinitely.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Quote request retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[order_retention_days]" value="<?php echo esc_attr( $s['order_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps quote request records indefinitely.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Cancelled membership retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[membership_retention_days]" value="<?php echo esc_attr( $s['membership_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'Only cancelled, expired, or erased membership rows are auto-removed. 0 disables automatic deletion.', 'authorwings-membership' ); ?></p></td></tr>
                </table>

                <h2><?php esc_html_e( 'Dashboard Design Settings', 'authorwings-membership' ); ?></h2>

                <h3><?php esc_html_e( 'Colors', 'authorwings-membership' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Primary', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_primary_color]" value="<?php echo esc_attr( $s['dashboard_primary_color'] ?? '#1a73e8' ); ?>" class="regular-text awg-color-field" data-default-color="#1a73e8"></td></tr>
                    <tr><th><?php esc_html_e( 'Background', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_bg_color]" value="<?php echo esc_attr( $s['dashboard_bg_color'] ?? '#f7f9fc' ); ?>" class="regular-text awg-color-field" data-default-color="#f7f9fc"></td></tr>
                    <tr><th><?php esc_html_e( 'Card Background', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_bg]" value="<?php echo esc_attr( $s['dashboard_card_bg'] ?? '#ffffff' ); ?>" class="regular-text awg-color-field" data-default-color="#ffffff"></td></tr>
                    <tr><th><?php esc_html_e( 'Text', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_text_color]" value="<?php echo esc_attr( $s['dashboard_text_color'] ?? '#1a1a2e' ); ?>" class="regular-text awg-color-field" data-default-color="#1a1a2e"></td></tr>
                    <tr><th><?php esc_html_e( 'Border', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_border_color]" value="<?php echo esc_attr( $s['dashboard_border_color'] ?? '#e0e7ef' ); ?>" class="regular-text awg-color-field" data-default-color="#e0e7ef"></td></tr>
                </table>

                <h3><?php esc_html_e( 'Typography', 'authorwings-membership' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Font Family', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_font_family]" value="<?php echo esc_attr( $s['dashboard_font_family'] ?? '-apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, sans-serif' ); ?>" class="regular-text"><p class="description"><?php esc_html_e( 'Example: Roboto, Arial, sans-serif', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Heading Font', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_heading_font]" value="<?php echo esc_attr( $s['dashboard_heading_font'] ?? '-apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, sans-serif' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Base Size', 'authorwings-membership' ); ?></th><td><input type="number" min="12" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_font_size]" value="<?php echo esc_attr( $s['dashboard_font_size'] ?? 16 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Buttons', 'authorwings-membership' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Background', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_bg]" value="<?php echo esc_attr( $s['dashboard_button_bg'] ?? '#1a73e8' ); ?>" class="regular-text awg-color-field" data-default-color="#1a73e8"></td></tr>
                    <tr><th><?php esc_html_e( 'Text', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_text]" value="<?php echo esc_attr( $s['dashboard_button_text'] ?? '#ffffff' ); ?>" class="regular-text awg-color-field" data-default-color="#ffffff"></td></tr>
                    <tr><th><?php esc_html_e( 'Hover', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_hover]" value="<?php echo esc_attr( $s['dashboard_button_hover'] ?? '#1558b0' ); ?>" class="regular-text awg-color-field" data-default-color="#1558b0"></td></tr>
                    <tr><th><?php esc_html_e( 'Radius', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_radius]" value="<?php echo esc_attr( $s['dashboard_button_radius'] ?? 12 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Cards', 'authorwings-membership' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Padding', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_padding]" value="<?php echo esc_attr( $s['dashboard_card_padding'] ?? 20 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Shadow', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_shadow]" value="<?php echo esc_attr( $s['dashboard_card_shadow'] ?? '0 10px 28px rgba(3,12,23,.04)' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Hover Shadow', 'authorwings-membership' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_hover_shadow]" value="<?php echo esc_attr( $s['dashboard_card_hover_shadow'] ?? '0 12px 30px rgba(26,115,232,.12)' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Border Width', 'authorwings-membership' ); ?></th><td><input type="number" min="0" step="0.5" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_border_width]" value="<?php echo esc_attr( $s['dashboard_card_border_width'] ?? 1 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Layout', 'authorwings-membership' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Max Width', 'authorwings-membership' ); ?></th><td><input type="number" min="320" step="10" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_max_width]" value="<?php echo esc_attr( $s['dashboard_max_width'] ?? 960 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Container Padding', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_container_padding]" value="<?php echo esc_attr( $s['dashboard_container_padding'] ?? 0 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Grid Gap', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_grid_gap]" value="<?php echo esc_attr( $s['dashboard_grid_gap'] ?? 16 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Section Spacing', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_section_spacing]" value="<?php echo esc_attr( $s['dashboard_section_spacing'] ?? 28 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Global Radius', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_radius]" value="<?php echo esc_attr( $s['dashboard_radius'] ?? 12 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Advanced', 'authorwings-membership' ); ?></h3>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Custom CSS', 'authorwings-membership' ); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_custom_css]" rows="12" class="large-text code"><?php echo esc_textarea( $s['dashboard_custom_css'] ?? '' ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Target selectors like .awg-mem-dashboard, .awg-mem-tools-hero, .awg-mem-quick-card, .awg-mem-usage-card, and .awg-mem-tab.', 'authorwings-membership' ); ?></p>
                        </td>
                    </tr>
                    <tr><th><?php esc_html_e( 'Stored data summary', 'authorwings-membership' ); ?></th><td><p class="description"><?php esc_html_e( 'This plugin stores membership plan records, Stripe customer and subscription identifiers, usage counts, quote request notes, and team-seat invite data.', 'authorwings-membership' ); ?></p></td></tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }


    public function ajax_assign_plan(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 403 );
        }
        $uid     = (int) ( $_POST['user_id'] ?? 0 );
        $plan_id = (int) ( $_POST['plan_id'] ?? 0 );
        $billing = sanitize_text_field( $_POST['billing'] ?? 'monthly' );
        if ( ! $uid || ! $plan_id ) {
            wp_send_json_error( [ 'message' => 'Missing params' ] );
        }
        $this->memberships->set_user_plan( $uid, $plan_id, $billing );
        wp_send_json_success( [ 'message' => 'Plan updated.' ] );
    }

    public function ajax_get_stats(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 403 );
        }
        global $wpdb;
        $mt = Database::mems_table();
        $pt = Database::plans_table();
        $ut = Database::usage_table();
        $period = Usage::current_period();

        $total_members = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$mt} WHERE status='active'" );
        $paid_members  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$mt} m LEFT JOIN {$pt} p ON p.id=m.plan_id WHERE m.status='active' AND p.is_free=0" );
        $total_gen     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(used) FROM {$ut} WHERE period=%s AND service_slug='ai_generation'", $period ) );

        wp_send_json_success( [
            'total_members' => $total_members,
            'paid_members'  => $paid_members,
            'free_members'  => $total_members - $paid_members,
            'generations'   => $total_gen,
            'period'        => $period,
        ] );
    }
}
