<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class URLs {

    public static function get_settings(): array {
        $settings = get_option( Plugin::OPT, [] );
        return is_array( $settings ) ? $settings : [];
    }

    public static function dashboard(): string {
        $settings = self::get_settings();
        $page_id  = isset( $settings['dashboard_page_id'] ) ? (int) $settings['dashboard_page_id'] : 0;
        $url      = $page_id > 0 ? get_permalink( $page_id ) : '';

        if ( ! $url ) {
            $page = get_page_by_path( 'member-dashboard' );
            if ( $page instanceof \WP_Post ) {
                $url = get_permalink( $page );
            }
        }

        if ( ! $url ) {
            $url = home_url( '/member-dashboard/' );
        }

        return (string) $url;
    }

    public static function account(): string {
        return add_query_arg( 'tab', 'account', self::dashboard() );
    }

    public static function pricing(): string {
        $settings = self::get_settings();
        $page_id  = isset( $settings['pricing_page_id'] ) ? (int) $settings['pricing_page_id'] : 0;
        $url      = $page_id > 0 ? get_permalink( $page_id ) : '';

        if ( ! $url ) {
            $page = get_page_by_path( 'pricing' );
            if ( $page instanceof \WP_Post ) {
                $url = get_permalink( $page );
            }
        }

        if ( ! $url ) {
            $url = home_url( '/pricing/' );
        }

        return (string) $url;
    }

    public static function upgrade( string $plan_slug = '' ): string {
        $url = self::account();
        if ( $plan_slug !== '' ) {
            $url = add_query_arg( 'upgrade', sanitize_key( $plan_slug ), $url );
        }
        return $url;
    }

    public static function login( string $redirect = '' ): string {
        $redirect_to = $redirect !== '' ? $redirect : self::dashboard();
        return wp_login_url( $redirect_to );
    }
}


if ( ! function_exists( 'awg_mem_get_dashboard_url' ) ) {
    function awg_mem_get_dashboard_url(): string {
        return URLs::dashboard();
    }
}

if ( ! function_exists( 'awg_mem_get_account_url' ) ) {
    function awg_mem_get_account_url(): string {
        return URLs::account();
    }
}

if ( ! function_exists( 'awg_mem_get_pricing_url' ) ) {
    function awg_mem_get_pricing_url(): string {
        return URLs::pricing();
    }
}

if ( ! function_exists( 'awg_mem_get_upgrade_url' ) ) {
    function awg_mem_get_upgrade_url( string $plan_slug = '' ): string {
        return URLs::upgrade( $plan_slug );
    }
}

if ( ! function_exists( 'awg_mem_get_login_url' ) ) {
    function awg_mem_get_login_url( string $redirect = '' ): string {
        return URLs::login( $redirect );
    }
}
