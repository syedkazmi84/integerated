=== AuthorWings AI ===
Contributors: Syed Kazmi
Tags: ai, openai, generator, shortcode, gutenberg
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 5.7.1
License: GPLv2 or later

== Description ==
Create customizable AI generator templates and render them via shortcode or Gutenberg block. Includes professional front-end actions (copy, download, clear), usage insights, stronger required-field validation, and Phase 10 release-prep docs for safer rollouts. Owner: AuthorWings (authorwings.com). Private use only. Unauthorized use is not permitted.

== Installation ==
1. Upload the plugin folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Go to Settings → AuthorWings AI and add your OpenAI API key.
4. Go to AuthorWings AI Templates → Add New to create a template.

== Usage ==
Shortcode:
[awg_generator id="123"]

Gutenberg:
Add block “AuthorWings AI” and select a template.

== Release Preparation ==
See RELEASE-CHECKLIST.md for the manual verification flow used before packaging and deployment.

== Changelog ==
= 5.7.1 =
* Security: AI Submissions CSV export now neutralises spreadsheet formula injection. Cells beginning with =, +, -, @, tab, or carriage return are prefixed with a single quote so Excel and Google Sheets render them as literal text instead of executing them as formulas.

= 5.7.0 =
* Phase 10 release preparation update
* Added release checklist and migration notes for safer deployments
* Updated versioning and packaging metadata for clean rollout

= 5.6.0 =
* Phase 9 UX and content polish update
* Improved front-end validation, loading states, error states, and mobile layout

== Uninstall ==
Removing the plugin deactivates it and leaves existing data in place unless you manually remove it.
