<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

/**
 * Stores generator runs as admin-only records.
 */
final class Submissions {
    /** @var string */
    private $cpt;
    /** @var string */
    private $template_cpt;

    private const FILTER_TEMPLATE = 'awg_aig_filter_template';
    private const FILTER_USER     = 'awg_aig_filter_user';
    private const FILTER_MODEL    = 'awg_aig_filter_model';
    private const FILTER_CACHED   = 'awg_aig_filter_cached';
    private const FILTER_MONTH    = 'awg_aig_filter_month';

    public function __construct(string $cpt, string $template_cpt) {
        $this->cpt = $cpt;
        $this->template_cpt = $template_cpt;
    }

    public function register(): void {
        register_post_type($this->cpt, [
            'labels' => [
                'name' => __('AI Submissions', 'authorwings-ai-tools'),
                'singular_name' => __('AI Submission', 'authorwings-ai-tools'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => false,
            // We attach this CPT under the top-level "AuthorWings AI" menu via custom submenus.
            'show_in_menu' => false,
            'supports' => ['title'],
            'capabilities' => [
                'edit_post'          => 'manage_options',
                'read_post'          => 'manage_options',
                'delete_post'        => 'manage_options',
                'edit_posts'         => 'manage_options',
                'edit_others_posts'  => 'manage_options',
                'publish_posts'      => 'manage_options',
                'read_private_posts' => 'manage_options',
                'delete_posts'       => 'manage_options',
                'delete_private_posts' => 'manage_options',
                'delete_published_posts' => 'manage_options',
                'delete_others_posts' => 'manage_options',
                'edit_private_posts' => 'manage_options',
                'edit_published_posts' => 'manage_options',
                'create_posts'       => 'manage_options',
            ],
        ]);
    }



    public function columns(array $columns): array {
        return [
            'cb'         => $columns['cb'] ?? '<input type="checkbox" />',
            'title'      => __('Submission', 'authorwings-ai-tools'),
            'template'   => __('Tool', 'authorwings-ai-tools'),
            'user'       => __('User', 'authorwings-ai-tools'),
            'model'      => __('Model', 'authorwings-ai-tools'),
            'cached'     => __('Cached', 'authorwings-ai-tools'),
            'date'       => __('Date', 'authorwings-ai-tools'),
        ];
    }

    public function column_data(string $column, int $post_id): void {
        if ($column === 'template') {
            $template_id = (int) get_post_meta($post_id, '_awg_aig_template_id', true);
            $template_title = (string) get_post_meta($post_id, '_awg_aig_template_title', true);
            if ($template_id > 0) {
                $post = get_post($template_id);
                $label = $post ? $post->post_title : ($template_title ?: __('Unknown', 'authorwings-ai-tools'));
                if ($post) {
                    echo '<a href="' . esc_url(get_edit_post_link($template_id)) . '">' . esc_html($label) . '</a>';
                } else {
                    echo esc_html($label);
                }
            } else {
                echo esc_html($template_title ?: __('Unknown', 'authorwings-ai-tools'));
            }
            return;
        }

        if ($column === 'user') {
            $user_id = (int) get_post_meta($post_id, '_awg_aig_user_id', true);
            if ($user_id > 0) {
                $user = get_user_by('id', $user_id);
                if ($user) {
                    echo esc_html($user->display_name . ' (' . $user->user_email . ')');
                    return;
                }
                echo '#' . esc_html((string) $user_id);
                return;
            }
            echo esc_html__('Guest', 'authorwings-ai-tools');
            return;
        }

        if ($column === 'model') {
            echo esc_html((string) get_post_meta($post_id, '_awg_aig_model', true));
            return;
        }

        if ($column === 'cached') {
            echo esc_html(get_post_meta($post_id, '_awg_aig_cached', true) === '1' ? __('Yes', 'authorwings-ai-tools') : __('No', 'authorwings-ai-tools'));
        }
    }

    public function sortable_columns(array $columns): array {
        $columns['model'] = 'model';
        $columns['cached'] = 'cached';
        return $columns;
    }

    public function sort_columns($query): void {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        if (($query->get('post_type') !== $this->cpt)) {
            return;
        }

        foreach ($this->get_filtered_query_args((string) $query->get('orderby')) as $key => $value) {
            $query->set($key, $value);
        }
    }

    private function get_filtered_query_args(string $orderby = ''): array {
        $args = [];

        if ($orderby === 'model') {
            $args['meta_key'] = '_awg_aig_model';
            $args['orderby'] = 'meta_value';
        } elseif ($orderby === 'cached') {
            $args['meta_key'] = '_awg_aig_cached';
            $args['orderby'] = 'meta_value';
        }

        $meta_query = [];

        $template_id = isset($_GET[self::FILTER_TEMPLATE]) ? absint($_GET[self::FILTER_TEMPLATE]) : 0;
        if ($template_id > 0) {
            $meta_query[] = ['key' => '_awg_aig_template_id', 'value' => $template_id, 'compare' => '=', 'type' => 'NUMERIC'];
        }

        $user_filter_raw = isset($_GET[self::FILTER_USER]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_USER])) : '';
        if ($user_filter_raw !== '') {
            $user_id = absint($user_filter_raw);
            if ($user_id === 0) {
                $meta_query[] = [
                    'relation' => 'OR',
                    ['key' => '_awg_aig_user_id', 'value' => '0', 'compare' => '='],
                    ['key' => '_awg_aig_user_id', 'compare' => 'NOT EXISTS'],
                ];
            } else {
                $meta_query[] = ['key' => '_awg_aig_user_id', 'value' => $user_id, 'compare' => '=', 'type' => 'NUMERIC'];
            }
        }

        $model = isset($_GET[self::FILTER_MODEL]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_MODEL])) : '';
        if ($model !== '') {
            $meta_query[] = ['key' => '_awg_aig_model', 'value' => $model, 'compare' => '='];
        }

        $cached = isset($_GET[self::FILTER_CACHED]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_CACHED])) : '';
        if ($cached === '1' || $cached === '0') {
            $meta_query[] = ['key' => '_awg_aig_cached', 'value' => $cached, 'compare' => '='];
        }

        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }

        $month = isset($_GET[self::FILTER_MONTH]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_MONTH])) : '';
        if ($month && preg_match('/^(\d{4})-(\d{2})$/', $month, $m)) {
            $start = sprintf('%04d-%02d-01', (int) $m[1], (int) $m[2]);
            $end = gmdate('Y-m-d', strtotime($start . ' +1 month'));
            $args['date_query'] = [[ 'after' => $start, 'before' => $end, 'inclusive' => true ]];
        }

        return $args;
    }

    public function restrict_manage_posts(): void {
        global $typenow, $wpdb;
        if ($typenow !== $this->cpt) {
            return;
        }

        $templates = get_posts([
            'post_type' => $this->template_cpt,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'fields' => 'ids',
        ]);

        $models = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = %s AND pm.meta_key = %s AND pm.meta_value <> '' ORDER BY pm.meta_value ASC",
            $this->cpt,
            '_awg_aig_model'
        ));

        $selected_template = isset($_GET[self::FILTER_TEMPLATE]) ? absint($_GET[self::FILTER_TEMPLATE]) : 0;
        $selected_user = isset($_GET[self::FILTER_USER]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_USER])) : '';
        $selected_model = isset($_GET[self::FILTER_MODEL]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_MODEL])) : '';
        $selected_cached = isset($_GET[self::FILTER_CACHED]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_CACHED])) : '';
        $selected_month = isset($_GET[self::FILTER_MONTH]) ? sanitize_text_field(wp_unslash((string) $_GET[self::FILTER_MONTH])) : '';

        echo '<select name="' . esc_attr(self::FILTER_TEMPLATE) . '"><option value="">' . esc_html__('All tools', 'authorwings-ai-tools') . '</option>';
        foreach ($templates as $template_id) {
            echo '<option value="' . esc_attr((string) $template_id) . '" ' . selected($selected_template, $template_id, false) . '>' . esc_html(get_the_title($template_id)) . '</option>';
        }
        echo '</select>';

        echo '<input type="number" min="0" name="' . esc_attr(self::FILTER_USER) . '" value="' . esc_attr($selected_user) . '" placeholder="' . esc_attr__('User ID (0 = guest)', 'authorwings-ai-tools') . '" style="width:150px;margin-left:6px;">';

        echo '<select name="' . esc_attr(self::FILTER_MODEL) . '"><option value="">' . esc_html__('All models', 'authorwings-ai-tools') . '</option>';
        foreach ((array) $models as $model) {
            echo '<option value="' . esc_attr((string) $model) . '" ' . selected($selected_model, (string) $model, false) . '>' . esc_html((string) $model) . '</option>';
        }
        echo '</select>';

        echo '<select name="' . esc_attr(self::FILTER_CACHED) . '"><option value="">' . esc_html__('Cached + live', 'authorwings-ai-tools') . '</option>';
        echo '<option value="1" ' . selected($selected_cached, '1', false) . '>' . esc_html__('Cached only', 'authorwings-ai-tools') . '</option>';
        echo '<option value="0" ' . selected($selected_cached, '0', false) . '>' . esc_html__('Live only', 'authorwings-ai-tools') . '</option>';
        echo '</select>';

        echo '<input type="month" name="' . esc_attr(self::FILTER_MONTH) . '" value="' . esc_attr($selected_month) . '" style="margin-left:6px;">';

        $url = add_query_arg(array_filter([
            'post_type' => $this->cpt,
            self::FILTER_TEMPLATE => $selected_template ?: null,
            self::FILTER_USER => $selected_user !== '' ? $selected_user : null,
            self::FILTER_MODEL => $selected_model ?: null,
            self::FILTER_CACHED => $selected_cached !== '' ? $selected_cached : null,
            self::FILTER_MONTH => $selected_month ?: null,
            'awg_aig_export_csv' => 1,
        ], static function ($value) { return $value !== null; }), admin_url('edit.php'));

        echo ' <a class="button" href="' . esc_url($url) . '">' . esc_html__('Export CSV', 'authorwings-ai-tools') . '</a>';
    }

    /**
     * Neutralise spreadsheet formula injection.
     *
     * If a cell begins with one of =, +, -, @, TAB, or CR, Excel / Google Sheets
     * may interpret it as a formula. Prepend a single quote so it is rendered as
     * literal text. The leading-quote trick is the OWASP-recommended mitigation.
     *
     * Integers are passed through untouched — formulas cannot begin with a digit.
     */
    private function csv_safe($value): string {
        if (is_int($value) || is_float($value)) {
            return (string) $value;
        }
        $value = (string) $value;
        if ($value === '') {
            return '';
        }
        if (preg_match('/^[=+\-@\t\r]/', $value)) {
            return "'" . $value;
        }
        return $value;
    }

    public function maybe_export_csv(): void {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }
        if (empty($_GET['awg_aig_export_csv']) || empty($_GET['post_type']) || $_GET['post_type'] !== $this->cpt) {
            return;
        }

        $args = array_merge([
            'post_type' => $this->cpt,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
        ], $this->get_filtered_query_args());
        $query = new \WP_Query($args);

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=awg-ai-submissions-' . gmdate('Y-m-d') . '.csv');

        $fh = fopen('php://output', 'w');
        fputcsv($fh, ['submission_id', 'created_at', 'tool', 'template_id', 'user_id', 'workspace_owner_user_id', 'model', 'cached', 'gclid', 'fields', 'output']);

        foreach ((array) $query->posts as $post) {
            $post_id = (int) $post->ID;
            $fields = get_post_meta($post_id, '_awg_aig_fields', true);
            fputcsv($fh, [
                $post_id,
                $this->csv_safe($post->post_date),
                $this->csv_safe((string) get_post_meta($post_id, '_awg_aig_template_title', true)),
                (int) get_post_meta($post_id, '_awg_aig_template_id', true),
                (int) get_post_meta($post_id, '_awg_aig_user_id', true),
                (int) get_post_meta($post_id, '_awg_aig_owner_user_id', true),
                $this->csv_safe((string) get_post_meta($post_id, '_awg_aig_model', true)),
                $this->csv_safe((string) get_post_meta($post_id, '_awg_aig_cached', true)),
                $this->csv_safe((string) get_post_meta($post_id, '_awg_aig_gclid', true)),
                $this->csv_safe(wp_json_encode(is_array($fields) ? $fields : [])),
                $this->csv_safe((string) get_post_meta($post_id, '_awg_aig_output', true)),
            ]);
        }

        fclose($fh);
        exit;
    }

    public function register_metabox(): void {
        add_meta_box(
            'awg_aig_submission_details',
            __('Submission Details', 'authorwings-ai-tools'),
            [$this, 'metabox_html'],
            $this->cpt,
            'normal',
            'high'
        );
    }

    public function metabox_html($post): void {
        $template_id = (int) get_post_meta($post->ID, '_awg_aig_template_id', true);
        $user_id = (int) get_post_meta($post->ID, '_awg_aig_user_id', true);
        $gclid = (string) get_post_meta($post->ID, '_awg_aig_gclid', true);
        $ip = (string) get_post_meta($post->ID, '_awg_aig_ip', true);
        $ua = (string) get_post_meta($post->ID, '_awg_aig_ua', true);
        $fields = get_post_meta($post->ID, '_awg_aig_fields', true);
        $output = (string) get_post_meta($post->ID, '_awg_aig_output', true);
        $model = (string) get_post_meta($post->ID, '_awg_aig_model', true);
        $cached = (string) get_post_meta($post->ID, '_awg_aig_cached', true);

        if (!is_array($fields)) { $fields = []; }

        $template_title = '';
        if ($template_id > 0) {
            $p = get_post($template_id);
            if ($p && $p->post_type === $this->template_cpt) {
                $template_title = $p->post_title;
            }
        }

        $user_label = $user_id ? ('#' . $user_id) : __('Guest', 'authorwings-ai-tools');
        if ($user_id) {
            $u = get_user_by('id', $user_id);
            if ($u) { $user_label = $u->display_name . ' (' . $u->user_email . ')'; }
        }

        echo '<p><strong>' . esc_html__('Template:', 'authorwings-ai-tools') . '</strong> ';
        if ($template_id && $template_title) {
            echo '<a href="' . esc_url(get_edit_post_link($template_id)) . '">' . esc_html($template_title) . '</a> (ID ' . esc_html((string)$template_id) . ')';
        } else {
            echo esc_html__('Unknown', 'authorwings-ai-tools');
        }
        echo '</p>';

        echo '<p><strong>' . esc_html__('User:', 'authorwings-ai-tools') . '</strong> ' . esc_html($user_label) . '</p>';
        echo '<p><strong>' . esc_html__('Model:', 'authorwings-ai-tools') . '</strong> ' . esc_html($model ?: '');
        echo ' <strong style="margin-left:12px;">' . esc_html__('Cached:', 'authorwings-ai-tools') . '</strong> ' . esc_html($cached === '1' ? 'Yes' : 'No') . '</p>';

        if ($gclid !== '') {
            echo '<p><strong>GCLID:</strong> ' . esc_html($gclid) . '</p>';
        }
        if ($ip !== '') {
            echo '<p><strong>' . esc_html__('IP:', 'authorwings-ai-tools') . '</strong> ' . esc_html($ip) . '</p>';
        }
        if ($ua !== '') {
            echo '<p><strong>' . esc_html__('User Agent:', 'authorwings-ai-tools') . '</strong> ' . esc_html($ua) . '</p>';
        }

        echo '<hr>';

        echo '<h4 style="margin:0 0 8px;">' . esc_html__('Submitted Fields', 'authorwings-ai-tools') . '</h4>';
        if (empty($fields)) {
            echo '<p class="description">' . esc_html__('No fields stored.', 'authorwings-ai-tools') . '</p>';
        } else {
            echo '<table class="widefat striped" style="max-width:980px;">';
            echo '<thead><tr><th>' . esc_html__('Field', 'authorwings-ai-tools') . '</th><th>' . esc_html__('Value', 'authorwings-ai-tools') . '</th></tr></thead><tbody>';
            foreach ($fields as $k => $v) {
                if (is_array($v)) { $v = implode(', ', $v); }
                echo '<tr><td><code>' . esc_html((string)$k) . '</code></td><td>' . esc_html((string)$v) . '</td></tr>';
            }
            echo '</tbody></table>';
        }

        echo '<h4 style="margin:16px 0 8px;">' . esc_html__('AI Output', 'authorwings-ai-tools') . '</h4>';
        echo '<textarea class="large-text code" rows="12" readonly>' . esc_textarea($output) . '</textarea>';
    }
}
