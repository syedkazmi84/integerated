<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Settings {
    /** @var string */
    private $opt_key;

    public function __construct(string $opt_key) {
        $this->opt_key = $opt_key;
    }

    public function defaults(): array {
        return [
            'api_key' => '',
            'default_model' => 'gpt-4o-mini',
            'timeout' => 45,
            'global_rate_per_min' => 60,
            'global_cache_seconds' => 0,
            'enable_gclid' => 1,
            'store_submissions' => 0,
            'store_ip' => 0,
            'enable_error_logging' => 1,
            'submission_retention_days' => 0,
            'log_retention_days' => 30,
            'global_style_bg_color' => 'ffffff',
            'global_style_text_color' => '030c17',
            'global_style_border_color' => 'd1e3fa',
            'global_style_accent_color' => '1a73e8',
            'global_style_padding' => 16,
            'global_style_margin' => 12,
            'global_style_radius' => 14,
            'global_style_button_bg_color' => '1a73e8',
            'global_style_button_text_color' => 'ffffff',
            'global_style_button_border_color' => '1a73e8',
            'global_style_button_padding_y' => 10,
            'global_style_button_padding_x' => 14,
            'global_style_button_radius' => 10,
            'global_style_input_height' => 44,
            'global_style_textarea_rows' => 5,
        ];
    }

    public function get(): array {
        $saved = get_option($this->opt_key, []);
        if (!is_array($saved)) { $saved = []; }
        return array_merge($this->defaults(), $saved);
    }

    public function register(): void {
        register_setting('awg_aig_group', $this->opt_key, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize'],
        ]);
    }

    public function sanitize($input): array {
        $d = $this->defaults();
        if (!is_array($input)) { $input = []; }

        $out = [];
        $out['api_key'] = sanitize_text_field($input['api_key'] ?? $d['api_key']);
        $out['default_model'] = sanitize_text_field($input['default_model'] ?? $d['default_model']);
        $out['timeout'] = max(10, min(120, intval($input['timeout'] ?? $d['timeout'])));
        $out['global_rate_per_min'] = max(1, intval($input['global_rate_per_min'] ?? $d['global_rate_per_min']));
        $out['global_cache_seconds'] = max(0, intval($input['global_cache_seconds'] ?? $d['global_cache_seconds']));
        $out['enable_gclid'] = isset($input['enable_gclid']) ? 1 : 0;
        $out['store_submissions'] = isset($input['store_submissions']) ? 1 : 0;
        $out['store_ip'] = isset($input['store_ip']) ? 1 : 0;
        $out['enable_error_logging'] = isset($input['enable_error_logging']) ? 1 : 0;
        $out['submission_retention_days'] = max(0, intval($input['submission_retention_days'] ?? $d['submission_retention_days']));
        $out['log_retention_days'] = max(0, intval($input['log_retention_days'] ?? $d['log_retention_days']));

        $allowed_colors = ['030c17','e8f1fd','ffffff','1a73e8','d1e3fa','fbbf24'];
        $out['global_style_bg_color'] = in_array(($input['global_style_bg_color'] ?? $d['global_style_bg_color']), $allowed_colors, true) ? $input['global_style_bg_color'] : $d['global_style_bg_color'];
        $out['global_style_text_color'] = in_array(($input['global_style_text_color'] ?? $d['global_style_text_color']), $allowed_colors, true) ? $input['global_style_text_color'] : $d['global_style_text_color'];
        $out['global_style_border_color'] = in_array(($input['global_style_border_color'] ?? $d['global_style_border_color']), $allowed_colors, true) ? $input['global_style_border_color'] : $d['global_style_border_color'];
        $out['global_style_accent_color'] = in_array(($input['global_style_accent_color'] ?? $d['global_style_accent_color']), $allowed_colors, true) ? $input['global_style_accent_color'] : $d['global_style_accent_color'];
        $out['global_style_padding'] = max(0, min(80, intval($input['global_style_padding'] ?? $d['global_style_padding'])));
        $out['global_style_margin'] = max(0, min(80, intval($input['global_style_margin'] ?? $d['global_style_margin'])));
        $out['global_style_radius'] = max(0, min(40, intval($input['global_style_radius'] ?? $d['global_style_radius'])));
        $out['global_style_button_bg_color'] = in_array(($input['global_style_button_bg_color'] ?? $d['global_style_button_bg_color']), $allowed_colors, true) ? $input['global_style_button_bg_color'] : $d['global_style_button_bg_color'];
        $out['global_style_button_text_color'] = in_array(($input['global_style_button_text_color'] ?? $d['global_style_button_text_color']), $allowed_colors, true) ? $input['global_style_button_text_color'] : $d['global_style_button_text_color'];
        $out['global_style_button_border_color'] = in_array(($input['global_style_button_border_color'] ?? $d['global_style_button_border_color']), $allowed_colors, true) ? $input['global_style_button_border_color'] : $d['global_style_button_border_color'];
        $out['global_style_button_padding_y'] = max(6, min(30, intval($input['global_style_button_padding_y'] ?? $d['global_style_button_padding_y'])));
        $out['global_style_button_padding_x'] = max(8, min(40, intval($input['global_style_button_padding_x'] ?? $d['global_style_button_padding_x'])));
        $out['global_style_button_radius'] = max(0, min(20, intval($input['global_style_button_radius'] ?? $d['global_style_button_radius'])));
        $out['global_style_input_height'] = max(32, min(80, intval($input['global_style_input_height'] ?? $d['global_style_input_height'])));
        $out['global_style_textarea_rows'] = max(2, min(20, intval($input['global_style_textarea_rows'] ?? $d['global_style_textarea_rows'])));
        return $out;
    }

    public function menu(): void {
        // Top-level menu: AuthorWings AI
        add_menu_page(
            __('AuthorWings AI', 'authorwings-ai-tools'),
            __('AuthorWings AI', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=awg_ai_template',
            null,
            'dashicons-lightbulb',
            56
        );

        // Templates (list)
        add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('Templates', 'authorwings-ai-tools'),
            __('Templates', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=awg_ai_template'
        );

        // Add New Template
        add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('Add New Template', 'authorwings-ai-tools'),
            __('Add New Template', 'authorwings-ai-tools'),
            'manage_options',
            'post-new.php?post_type=awg_ai_template'
        );

        // AI Submissions
        add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('AI Submissions', 'authorwings-ai-tools'),
            __('AI Submissions', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=awg_ai_submission'
        );

        // Settings (kept available)
        add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('Settings', 'authorwings-ai-tools'),
            __('Settings', 'authorwings-ai-tools'),
            'manage_options',
            'awg-aig-settings',
            [$this, 'page']
        );
    }

    /**
     * Simple landing screen for the top-level menu.
     */
    public function landing(): void {
        if (!current_user_can('manage_options')) { return; }
        // Clicking the top-level menu should land on Templates.
        $templates_url = admin_url('edit.php?post_type=awg_ai_template');
        wp_safe_redirect($templates_url);
        exit;
    }

    public function page(): void {
        if (!current_user_can('manage_options')) { return; }
        $s = $this->get();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('AuthorWings AI — Global Settings', 'authorwings-ai-tools'); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields('awg_aig_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('OpenAI API Key', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="password" style="width:420px"
                                   name="<?php echo esc_attr($this->opt_key); ?>[api_key]"
                                   value="<?php echo esc_attr($s['api_key']); ?>" />
                            <p class="description"><?php echo esc_html__('Stored in WP options. Never exposed to frontend.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Model', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="text" style="width:260px"
                                   name="<?php echo esc_attr($this->opt_key); ?>[default_model]"
                                   value="<?php echo esc_attr($s['default_model']); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('HTTP Timeout (seconds)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="10" max="120"
                                   name="<?php echo esc_attr($this->opt_key); ?>[timeout]"
                                   value="<?php echo esc_attr($s['timeout']); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Global Rate Limit (per minute per IP)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="1" max="99999"
                                   name="<?php echo esc_attr($this->opt_key); ?>[global_rate_per_min]"
                                   value="<?php echo esc_attr($s['global_rate_per_min']); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Global Cache Seconds (0 = off)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="0" max="86400"
                                   name="<?php echo esc_attr($this->opt_key); ?>[global_cache_seconds]"
                                   value="<?php echo esc_attr($s['global_cache_seconds']); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Include GCLID Hidden Field', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[enable_gclid]" value="1" <?php checked($s['enable_gclid'], 1); ?> />
                                <?php echo esc_html__('Capture gclid from URL parameters and attach it to generator submissions.', 'authorwings-ai-tools'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Store Submissions in Admin', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[store_submissions]" value="1" <?php checked($s['store_submissions'], 1); ?> />
                                <?php echo esc_html__('Save each successful generation as an admin-only record.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('This stores inputs and AI output. Use only if you need audit/history.', 'authorwings-ai-tools'); ?></p>
                            <label style="display:block;margin-top:6px;">
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[store_ip]" value="1" <?php checked($s['store_ip'], 1); ?> />
                                <?php echo esc_html__('Also store IP address (privacy sensitive).', 'authorwings-ai-tools'); ?>
                            </label>
                        </td>
                    </tr>
                <tr>
                        <th scope="row" colspan="2"><h2 style="margin:18px 0 0;"><?php echo esc_html__('Global Generator Styles', 'authorwings-ai-tools'); ?></h2></th>
                    </tr>
                    <?php $palette = [
                        '030c17' => '#030c17',
                        'e8f1fd' => '#e8f1fd',
                        'ffffff' => '#ffffff',
                        '1a73e8' => '#1a73e8',
                        'd1e3fa' => '#d1e3fa',
                        'fbbf24' => '#fbbf24',
                    ]; ?>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Background Color', 'authorwings-ai-tools'); ?></th>
                        <td><select name="<?php echo esc_attr($this->opt_key); ?>[global_style_bg_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_bg_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Text Color', 'authorwings-ai-tools'); ?></th>
                        <td><select name="<?php echo esc_attr($this->opt_key); ?>[global_style_text_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_text_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Border Color', 'authorwings-ai-tools'); ?></th>
                        <td><select name="<?php echo esc_attr($this->opt_key); ?>[global_style_border_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_border_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Accent Color', 'authorwings-ai-tools'); ?></th>
                        <td><select name="<?php echo esc_attr($this->opt_key); ?>[global_style_accent_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_accent_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Container Spacing', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label><?php echo esc_html__('Padding', 'authorwings-ai-tools'); ?> <input type="number" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_padding]" value="<?php echo esc_attr($s['global_style_padding']); ?>" /></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Margin', 'authorwings-ai-tools'); ?> <input type="number" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_margin]" value="<?php echo esc_attr($s['global_style_margin']); ?>" /></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Radius', 'authorwings-ai-tools'); ?> <input type="number" min="0" max="40" name="<?php echo esc_attr($this->opt_key); ?>[global_style_radius]" value="<?php echo esc_attr($s['global_style_radius']); ?>" /></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Button Colors', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label><?php echo esc_html__('Background', 'authorwings-ai-tools'); ?> <select name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_bg_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_button_bg_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Text', 'authorwings-ai-tools'); ?> <select name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_text_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_button_text_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Border', 'authorwings-ai-tools'); ?> <select name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_border_color]"><?php foreach ($palette as $value => $label): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($s['global_style_button_border_color'], $value); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Button Spacing', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label><?php echo esc_html__('Padding Y', 'authorwings-ai-tools'); ?> <input type="number" min="6" max="30" name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_padding_y]" value="<?php echo esc_attr($s['global_style_button_padding_y']); ?>" /></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Padding X', 'authorwings-ai-tools'); ?> <input type="number" min="8" max="40" name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_padding_x]" value="<?php echo esc_attr($s['global_style_button_padding_x']); ?>" /></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Radius', 'authorwings-ai-tools'); ?> <input type="number" min="0" max="20" name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_radius]" value="<?php echo esc_attr($s['global_style_button_radius']); ?>" /></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" colspan="2"><h2 style="margin:18px 0 0;"><?php echo esc_html__('Global Field Sizes', 'authorwings-ai-tools'); ?></h2></th>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Input Height (px)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="32" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_input_height]" value="<?php echo esc_attr($s['global_style_input_height']); ?>" />
                            <p class="description"><?php echo esc_html__('Used by all templates when “Use global field sizes” is enabled.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Textarea Rows', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="2" max="20" name="<?php echo esc_attr($this->opt_key); ?>[global_style_textarea_rows]" value="<?php echo esc_attr($s['global_style_textarea_rows']); ?>" />
                            <p class="description"><?php echo esc_html__('Templates can still override these values individually.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"></th>
                        <td>
                            <p class="description"><?php echo esc_html__('Templates can inherit these global style values so you can update the design from one place.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Settings', 'authorwings-ai-tools')); ?>
            </form>

            <hr>
            <h2><?php echo esc_html__('Usage', 'authorwings-ai-tools'); ?></h2>
            <ul>
                <li><?php echo esc_html__('Create template: AuthorWings AI Templates → Add New', 'authorwings-ai-tools'); ?></li>
                <li><?php echo esc_html__('Shortcode:', 'authorwings-ai-tools'); ?> <code>[awg_generator id="123"]</code></li>
                <li><?php echo esc_html__('Gutenberg: Add block “AuthorWings AI” and select template', 'authorwings-ai-tools'); ?></li>
            </ul>
            <p class="description"><?php echo esc_html__('Owner: AuthorWings (authorwings.com)', 'authorwings-ai-tools'); ?></p>
        </div>
        <?php
    }

}
