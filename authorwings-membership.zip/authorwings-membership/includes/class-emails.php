<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Emails {

    public function __construct() {
        add_action( 'awg_mem_plan_changed',    [ $this, 'on_plan_changed' ],    10, 2 );
        add_action( 'awg_mem_cancelled',       [ $this, 'on_cancelled' ],       10, 1 );
        add_action( 'awg_mem_expired',         [ $this, 'on_expired' ],         10, 1 );
        add_action( 'awg_mem_service_ordered', [ $this, 'on_service_ordered' ], 10, 3 );
        add_action( 'user_register',           [ $this, 'on_register' ],        10, 1 );
    }

    public function on_register( int $user_id ): void {
        $user     = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }
        $subject  = sprintf( __( 'Welcome to AuthorWings, %s!', 'authorwings-membership' ), $user->display_name );
        $message  = sprintf(
            __( "Hi %s,\n\nWelcome to AuthorWings! Your free account is ready.\n\nAccess your dashboard here:\n%s\n\nHappy publishing!\n— The AuthorWings Team", 'authorwings-membership' ),
            $user->display_name,
            home_url( '/member-dashboard/' )
        );
        $this->send( $user->user_email, $subject, $message );
    }

    public function on_plan_changed( int $user_id, int $plan_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        global $wpdb;
        $pt   = Database::plans_table();
        $plan = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pt} WHERE id = %d", $plan_id ), ARRAY_A );
        if ( ! $plan ) { return; }

        $subject = sprintf( __( 'Your AuthorWings plan has been updated: %s', 'authorwings-membership' ), $plan['name'] );
        $message = sprintf(
            __( "Hi %s,\n\nYour membership plan has been updated to: %s\n\nAccess your dashboard:\n%s\n\n— The AuthorWings Team", 'authorwings-membership' ),
            $user->display_name,
            $plan['name'],
            home_url( '/member-dashboard/' )
        );
        $this->send( $user->user_email, $subject, $message );

        // Notify admin
        $s = get_option( Plugin::OPT, [] );
        $admin_email = $s['notify_admin_email'] ?? get_option( 'admin_email' );
        $this->send(
            $admin_email,
            sprintf( 'Plan upgraded: %s → %s', $user->user_email, $plan['name'] ),
            sprintf( "User %s (%s) has changed to the %s plan.", $user->display_name, $user->user_email, $plan['name'] )
        );
    }

    public function on_cancelled( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }
        $subject = __( 'Your AuthorWings membership has been cancelled', 'authorwings-membership' );
        $message = sprintf(
            __( "Hi %s,\n\nYour AuthorWings membership has been cancelled. You've been moved to the free plan.\n\nYou can reactivate any time from your dashboard:\n%s\n\n— The AuthorWings Team", 'authorwings-membership' ),
            $user->display_name,
            home_url( '/member-dashboard/' )
        );
        $this->send( $user->user_email, $subject, $message );
    }

    public function on_expired( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }
        $subject = __( 'Your AuthorWings membership has expired', 'authorwings-membership' );
        $message = sprintf(
            __( "Hi %s,\n\nYour AuthorWings membership has expired. You've been moved to the free plan.\n\nRenew your plan here:\n%s\n\n— The AuthorWings Team", 'authorwings-membership' ),
            $user->display_name,
            home_url( '/pricing/' )
        );
        $this->send( $user->user_email, $subject, $message );
    }

    public function on_service_ordered( int $order_id, int $user_id, string $service_slug ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) { return; }

        // User confirmation
        $subject = __( 'We received your service request — AuthorWings', 'authorwings-membership' );
        $message = sprintf(
            __( "Hi %s,\n\nThank you for your service request (#%d: %s).\n\nOur team will review it and get back to you within 24 hours.\n\n— The AuthorWings Team", 'authorwings-membership' ),
            $user->display_name,
            $order_id,
            str_replace( '-', ' ', ucwords( $service_slug, '-' ) )
        );
        $this->send( $user->user_email, $subject, $message );

        // Admin notification
        $s           = get_option( Plugin::OPT, [] );
        $admin_email = $s['notify_admin_email'] ?? get_option( 'admin_email' );
        $this->send(
            $admin_email,
            sprintf( 'New service request #%d from %s', $order_id, $user->user_email ),
            sprintf(
                "New service request:\nOrder #%d\nService: %s\nUser: %s (%s)\n\nView in admin:\n%s",
                $order_id,
                $service_slug,
                $user->display_name,
                $user->user_email,
                admin_url( 'admin.php?page=awg-membership-orders' )
            )
        );
    }

    private function send( string $to, string $subject, string $message ): void {
        $site = get_bloginfo( 'name' );
        $brand = home_url( '/' );
        $html_message = wpautop( wp_kses_post( nl2br( esc_html( $message ) ) ) );
        $body = '
        <div style="margin:0;padding:24px;background:#f5f8fc;font-family:Arial,sans-serif;color:#0f172a;">
            <div style="max-width:640px;margin:0 auto;background:#ffffff;border:1px solid #dbe7f5;border-radius:16px;overflow:hidden;box-shadow:0 12px 30px rgba(15,23,42,.06);">
                <div style="padding:20px 24px;background:#0f172a;color:#ffffff;">
                    <div style="font-size:20px;font-weight:700;">' . esc_html( $site ) . '</div>
                    <div style="font-size:13px;opacity:.82;margin-top:4px;">Author services and member updates</div>
                </div>
                <div style="padding:24px;line-height:1.7;font-size:15px;">' . $html_message . '</div>
                <div style="padding:16px 24px;background:#f8fbff;border-top:1px solid #dbe7f5;font-size:12px;color:#64748b;">
                    This message was sent by ' . esc_html( $site ) . '.<br>
                    <a href="' . esc_url( $brand ) . '" style="color:#1d4ed8;text-decoration:none;">Visit website</a>
                </div>
            </div>
        </div>';
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        wp_mail( $to, "[{$site}] {$subject}", $body, $headers );
    }
}

