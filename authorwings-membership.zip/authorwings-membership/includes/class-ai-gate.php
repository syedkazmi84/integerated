<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Bridges the membership plugin with the AuthorWings AI plugin.
 * Hooks into the AI plugin's generation flow to enforce plan limits.
 */
class AI_Gate {

    /** @var Memberships */
    private $memberships;

    /** @var Usage */
    private $usage;

    public function __construct( Memberships $memberships, Usage $usage ) {
        $this->memberships = $memberships;
        $this->usage       = $usage;
    }

    public function register_hooks(): void {
        // -------------------------------------------------------
        // Hook 1: Before generation — check plan limits.
        // Requires AuthorWings AI v5.2+ which adds this filter.
        // -------------------------------------------------------
        add_filter( 'awg_aig_can_generate', [ $this, 'check_can_generate' ], 10, 3 );

        // Fallback intercept at priority 1 (before AI plugin's handler).
        // Only fires if the AI plugin does NOT have the filter yet.
        add_action( 'wp_ajax_awg_aig_generate',        [ $this, 'early_check' ], 1 );
        add_action( 'wp_ajax_nopriv_awg_aig_generate', [ $this, 'early_check' ], 1 );

        // -------------------------------------------------------
        // Hook 2: After successful generation — increment counter.
        // Primary: fired by AI plugin v5.2+ do_action('awg_aig_generated').
        // -------------------------------------------------------
        add_action( 'awg_aig_generated', [ $this, 'on_generated' ], 10, 3 );
        add_filter( 'awg_mem_usage_owner_user_id', [ $this, 'map_usage_owner_user_id' ], 10, 2 );

        // Fallback counter for AI plugin v5.1.x (no Hook 2 action).
        // Runs at priority 999 — after the AI plugin sends its JSON response
        // (priority 10). We detect success by inspecting the output buffer.
        add_action( 'wp_ajax_awg_aig_generate',        [ $this, 'fallback_increment' ], 999 );
        add_action( 'wp_ajax_nopriv_awg_aig_generate', [ $this, 'fallback_increment' ], 999 );

        // -------------------------------------------------------
        // Hook 3: Filter which templates are visible per user plan.
        // -------------------------------------------------------
        add_filter( 'awg_aig_visible_templates', [ $this, 'filter_templates' ], 10, 2 );
    }

    /**
     * Filter: awg_aig_can_generate
     * Return false (or WP_Error) to block generation.
     */
    public function check_can_generate( $can, int $user_id, int $template_id ) {
        if ( ! $can ) {
            return $can; // Already blocked by something else
        }

        $limits = $this->memberships->get_user_limits( $user_id );
        $max    = isset( $limits['ai_generations_per_month'] )
                  ? (int) $limits['ai_generations_per_month']
                  : 10;

        if ( $max >= 0 && ! $this->usage->can_use( $user_id, 'ai_generation', $max ) ) {
            $plan   = $this->memberships->get_user_plan_slug( $user_id );
            $upgrade = home_url( '/member-dashboard/?tab=account' );
            return new \WP_Error(
                'awg_mem_limit_reached',
                sprintf(
                    /* translators: %s: plan name */
                    __( 'You have reached your %s plan limit for this month.', 'authorwings-membership' ),
                    esc_html( ucfirst( $plan ) )
                ),
                [
                    'upgrade_url'   => $upgrade,
                    'upgrade_label' => __( 'Upgrade your plan', 'authorwings-membership' ),
                ]
            );
        }

        return true;
    }

    /**
     * Early AJAX intercept (fallback when AI plugin doesn't have the filter yet).
     * Runs at priority 1, before the AI plugin's own handler.
     */
    public function early_check(): void {
        // Only act if the filter hook isn't present in the AI plugin
        if ( has_filter( 'awg_aig_can_generate' ) ) {
            return; // Filter exists — let check_can_generate() handle it
        }

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return; // Guest — let AI plugin handle guest logic
        }

        $limits = $this->memberships->get_user_limits( $user_id );
        $max    = (int) ( $limits['ai_generations_per_month'] ?? 10 );

        if ( $max >= 0 && ! $this->usage->can_use( $user_id, 'ai_generation', $max ) ) {
            wp_send_json_error( [
                'message' => __( 'Monthly generation limit reached. Please upgrade your plan.', 'authorwings-membership' ),
            ], 429 );
        }
    }

    /**
     * Action: awg_aig_generated — increment usage counter after successful generation.
     * This fires when the AI plugin has Hook 2 (v5.2+).
     */
    public function on_generated( int $user_id, int $template_id, string $output ): void {
        if ( $user_id > 0 ) {
            $this->usage->increment( $user_id, 'ai_generation' );
        }
    }

    /**
     * Fallback usage incrementor for AI plugin v5.1.x (no Hook 2).
     * Runs at AJAX priority 999 — after the AI plugin's handler (priority 10)
     * has already called wp_send_json_success() and buffered the response.
     *
     * We inspect the output buffer: if it contains "success":true we know
     * a generation succeeded and increment the counter. This method only
     * runs when the awg_aig_generated action has NOT already incremented
     * (i.e. the AI plugin does not fire that action).
     */
    public function fallback_increment(): void {
        // If the AI plugin v5.2+ already fired awg_aig_generated, that
        // action incremented the counter via on_generated(). Skip here.
        // We detect this by checking if the action hook has any callbacks —
        // if it does, the AI plugin added it (Hook 2 exists) so we trust
        // on_generated() handled it.
        if ( did_action( 'awg_aig_generated' ) > 0 ) {
            return;
        }

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return; // Guest — no counter to increment
        }

        // Peek at the buffered output to confirm this was a success response.
        // wp_send_json_success() outputs {"success":true,...} then calls wp_die().
        // At priority 999 the response is in the output buffer if ob_start() is active,
        // or we can check headers_list() for the Content-Type header as a proxy.
        // The most reliable approach: check the PHP output buffer directly.
        $buffered = '';
        if ( ob_get_level() > 0 ) {
            $buffered = ob_get_contents();
        }

        // If we can read the buffer, check for success
        if ( $buffered !== '' ) {
            $decoded = json_decode( $buffered, true );
            if ( ! is_array( $decoded ) || empty( $decoded['success'] ) ) {
                return; // Error response — do not increment
            }
        }
        // If buffer is empty (already flushed), we optimistically increment
        // because early_check() already blocked over-limit requests, so
        // reaching priority 999 means the request was not blocked = success.

        $this->usage->increment( $user_id, 'ai_generation' );
    }


    public function map_usage_owner_user_id( int $mapped_user_id, int $requested_user_id ): int {
        return $this->memberships->get_usage_owner_id( $requested_user_id );
    }

    /**
     * Filter: awg_aig_visible_templates — hide templates the user can't access.
     */
    public function filter_templates( array $templates, int $user_id ): array {
        $plan    = $this->memberships->get_user_plan_slug( $user_id );
        $level   = Roles::level( Roles::slug_to_role( $plan ) );
        $allowed = [];
        foreach ( $templates as $template ) {
            $required = get_post_meta( $template->ID, '_awg_mem_required_plan', true ) ?: 'free';
            $required_level = Roles::level( Roles::slug_to_role( $required ) );
            if ( $level >= $required_level ) {
                $allowed[] = $template;
            }
        }
        return $allowed;
    }
}
