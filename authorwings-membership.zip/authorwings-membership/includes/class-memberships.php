<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Memberships {

    private const STRIPE_API_BASE = 'https://api.stripe.com/v1';

    public function get_user_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d AND m.status IN ('active','trialing')
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    public function get_latest_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    public function get_effective_membership( int $user_id ): ?array {
        $owner_id = $this->get_workspace_owner_id( $user_id );
        return $this->get_user_membership( $owner_id );
    }

    public function get_user_limits( int $user_id ): array {
        $mem = $this->get_effective_membership( $user_id );
        if ( ! $mem ) {
            return [
                'ai_generations_per_month' => 10,
                'tools_access'             => 'free',
            ];
        }
        return json_decode( $mem['limits'] ?? '{}', true ) ?: [];
    }

    public function get_user_plan_slug( int $user_id ): string {
        $mem = $this->get_effective_membership( $user_id );
        return $mem['plan_slug'] ?? 'free';
    }

    public function get_workspace_owner_id( int $user_id ): int {
        $seat = $this->get_team_seat_for_member( $user_id );
        if ( $seat && ! empty( $seat['owner_user_id'] ) && $this->owner_workspace_active( (int) $seat['owner_user_id'] ) ) {
            return (int) $seat['owner_user_id'];
        }
        return $user_id;
    }

    public function is_team_member( int $user_id ): bool {
        return $this->get_workspace_owner_id( $user_id ) !== $user_id;
    }

    public function get_usage_owner_id( int $user_id ): int {
        return $this->get_workspace_owner_id( $user_id );
    }

    public function set_user_plan( int $user_id, int $plan_id, string $billing = 'monthly', string $stripe_sub_id = '', string $stripe_cust_id = '' ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $wpdb->update(
            $table,
            [ 'status' => 'cancelled', 'updated_at' => $now ],
            [ 'user_id' => $user_id, 'status' => 'active' ]
        );

        if ( $billing === 'free' ) {
            $end_date = null;
        } elseif ( $billing === 'yearly' ) {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 year' ) );
        } else {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 month' ) );
        }

        $inserted = $wpdb->insert( $table, [
            'user_id'                => $user_id,
            'plan_id'                => $plan_id,
            'status'                 => 'active',
            'billing_cycle'          => $billing,
            'start_date'             => $now,
            'end_date'               => $end_date,
            'stripe_subscription_id' => $stripe_sub_id,
            'stripe_customer_id'     => $stripe_cust_id,
            'created_at'             => $now,
            'updated_at'             => $now,
        ] );

        if ( $inserted ) {
            $ptable = Database::plans_table();
            $plan   = $wpdb->get_row(
                $wpdb->prepare( "SELECT slug FROM {$ptable} WHERE id = %d", $plan_id ),
                ARRAY_A
            );
            if ( $plan ) {
                Roles::set_user_role( $user_id, Roles::slug_to_role( (string) $plan['slug'] ) );
            }
            $this->sync_team_access_for_owner( $user_id );
            do_action( 'awg_mem_plan_changed', $user_id, $plan_id );
        }

        return (bool) $inserted;
    }

    public function cancel_user_membership( int $user_id, string $status = 'cancelled' ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = %s, updated_at = %s WHERE user_id = %d AND status IN ('active','trialing')",
                $status,
                $now,
                $user_id
            )
        );

        if ( $updated ) {
            Roles::set_user_role( $user_id, Roles::FREE );
            $this->sync_team_access_for_owner( $user_id );
            if ( $status === 'cancelled' ) {
                do_action( 'awg_mem_cancelled', $user_id );
            }
        }

        return (bool) $updated;
    }

    public function on_register( int $user_id ): void {
        global $wpdb;
        $ptable  = Database::plans_table();
        $free_plan = $wpdb->get_row(
            "SELECT id FROM {$ptable} WHERE is_free = 1 AND is_active = 1 LIMIT 1",
            ARRAY_A
        );
        if ( $free_plan ) {
            $this->set_user_plan( $user_id, (int) $free_plan['id'], 'free' );
        } else {
            Roles::set_user_role( $user_id, Roles::FREE );
        }

        $this->claim_pending_team_invites( $user_id );
    }

    public function check_expiries(): void {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $expired = $wpdb->get_results(
            "SELECT user_id FROM {$table}
             WHERE status = 'active' AND end_date IS NOT NULL AND end_date < '{$now}'",
            ARRAY_A
        );

        foreach ( (array) $expired as $row ) {
            $this->cancel_user_membership( (int) $row['user_id'], 'expired' );
            do_action( 'awg_mem_expired', (int) $row['user_id'] );
        }
    }

    private function get_settings(): array {
        $settings = get_option( Plugin::OPT, [] );
        return is_array( $settings ) ? $settings : [];
    }

    private function get_account_url(): string {
        $settings = $this->get_settings();
        $page_id  = isset( $settings['dashboard_page_id'] ) ? (int) $settings['dashboard_page_id'] : 0;
        $url      = $page_id > 0 ? get_permalink( $page_id ) : home_url( '/member-dashboard/' );
        if ( ! $url ) {
            $url = home_url( '/member-dashboard/' );
        }
        return add_query_arg( 'tab', 'account', $url );
    }

    private function create_stripe_checkout_session( array $plan, string $billing, int $user_id ) {
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_secret', __( 'Stripe secret key is missing. Add it in Membership Settings.', 'authorwings-membership' ) );
        }

        $price_key = $billing === 'yearly' ? 'stripe_yearly_price_id' : 'stripe_monthly_price_id';
        $price_id  = trim( (string) ( $plan[ $price_key ] ?? '' ) );
        if ( $price_id === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_price', __( 'This plan is not connected to a Stripe price yet. Please contact support.', 'authorwings-membership' ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new \WP_Error( 'awg_mem_user_not_found', __( 'User account not found.', 'authorwings-membership' ) );
        }

        $account_url = $this->get_account_url();
        $success_url = add_query_arg(
            [
                'tab'        => 'account',
                'payment'    => 'success',
                'session_id' => '{CHECKOUT_SESSION_ID}',
            ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled' ], $account_url )
        );
        $cancel_url  = add_query_arg(
            [
                'tab'       => 'account',
                'cancelled' => '1',
            ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled' ], $account_url )
        );

        $body = [
            'mode'                         => 'subscription',
            'success_url'                  => $success_url,
            'cancel_url'                   => $cancel_url,
            'client_reference_id'          => (string) $user_id,
            'customer_email'               => (string) $user->user_email,
            'line_items[0][price]'         => $price_id,
            'line_items[0][quantity]'      => 1,
            'metadata[user_id]'            => (string) $user_id,
            'metadata[plan_id]'            => (string) (int) $plan['id'],
            'metadata[plan_slug]'          => (string) $plan['slug'],
            'metadata[billing]'            => $billing,
            'subscription_data[metadata][user_id]'   => (string) $user_id,
            'subscription_data[metadata][plan_id]'   => (string) (int) $plan['id'],
            'subscription_data[metadata][plan_slug]' => (string) $plan['slug'],
            'subscription_data[metadata][billing]'   => $billing,
        ];

        $response = wp_remote_post(
            self::STRIPE_API_BASE . '/checkout/sessions',
            [
                'timeout' => 30,
                'headers' => [ 'Authorization' => 'Bearer ' . $secret ],
                'body'    => $body,
            ]
        );

        if ( is_wp_error( $response ) ) {
            Logger::log( 'stripe_request_failed', [ 'message' => $response->get_error_message(), 'user_id' => (string) $user_id, 'billing' => $billing ] );
            return new \WP_Error( 'awg_mem_stripe_request_failed', $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $json = json_decode( (string) wp_remote_retrieve_body( $response ), true );

        if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
            $message = __( 'Unable to start checkout right now. Please try again.', 'authorwings-membership' );
            if ( is_array( $json ) && ! empty( $json['error']['message'] ) ) {
                $message = sanitize_text_field( (string) $json['error']['message'] );
            }
            Logger::log( 'stripe_checkout_failed', [ 'message' => $message, 'user_id' => (string) $user_id, 'billing' => $billing, 'plan_id' => (string) (int) $plan['id'] ] );
            return new \WP_Error( 'awg_mem_stripe_checkout_failed', $message, [ 'raw' => $json ] );
        }

        if ( empty( $json['url'] ) ) {
            return new \WP_Error( 'awg_mem_stripe_missing_url', __( 'Stripe checkout URL was not returned.', 'authorwings-membership' ) );
        }

        return esc_url_raw( (string) $json['url'] );
    }

    public function verify_stripe_signature( string $payload, string $signature_header, string $secret ): bool {
        if ( $payload === '' || $signature_header === '' || $secret === '' ) {
            return false;
        }

        $parts = [];
        foreach ( explode( ',', $signature_header ) as $segment ) {
            $pair = explode( '=', trim( $segment ), 2 );
            if ( count( $pair ) === 2 ) {
                $parts[ $pair[0] ] = $pair[1];
            }
        }

        $timestamp = isset( $parts['t'] ) ? (string) $parts['t'] : '';
        $signature = isset( $parts['v1'] ) ? (string) $parts['v1'] : '';
        if ( $timestamp === '' || $signature === '' ) {
            return false;
        }

        if ( abs( time() - (int) $timestamp ) > 300 ) {
            return false;
        }

        $expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
        return hash_equals( $expected, $signature );
    }

    private function find_user_id_by_customer( string $customer_id ): int {
        if ( $customer_id === '' ) {
            return 0;
        }

        global $wpdb;
        $table = Database::mems_table();
        $user_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE stripe_customer_id = %s ORDER BY id DESC LIMIT 1",
                $customer_id
            )
        );

        return (int) $user_id;
    }

    private function handle_stripe_subscription_event( array $object, string $event_type ): void {
        $metadata        = isset( $object['metadata'] ) && is_array( $object['metadata'] ) ? $object['metadata'] : [];
        $user_id         = isset( $metadata['user_id'] ) ? (int) $metadata['user_id'] : 0;
        $plan_id         = isset( $metadata['plan_id'] ) ? (int) $metadata['plan_id'] : 0;
        $billing         = isset( $metadata['billing'] ) && in_array( $metadata['billing'], [ 'monthly', 'yearly', 'free' ], true ) ? (string) $metadata['billing'] : 'monthly';
        $customer_id     = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );
        $subscription_id = sanitize_text_field( (string) ( $object['id'] ?? '' ) );

        if ( $user_id <= 0 && $customer_id !== '' ) {
            $user_id = $this->find_user_id_by_customer( $customer_id );
        }

        if ( $user_id <= 0 || $plan_id <= 0 ) {
            return;
        }

        if ( $event_type === 'customer.subscription.deleted' ) {
            $this->cancel_user_membership( $user_id, 'cancelled' );
            return;
        }

        if ( $event_type === 'invoice.payment_failed' ) {
            $this->cancel_user_membership( $user_id, 'payment_failed' );
            return;
        }

        $this->set_user_plan( $user_id, $plan_id, $billing, $subscription_id, $customer_id );
    }

    public function rest_webhook( \WP_REST_Request $request ): \WP_REST_Response {
        $payload  = $request->get_body();
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_webhook_secret'] ?? '' ) );
        $sig      = (string) $request->get_header( 'stripe-signature' );

        if ( ! $this->verify_stripe_signature( $payload, $sig, $secret ) ) {
            return new \WP_REST_Response( [ 'received' => false, 'message' => 'Invalid signature.' ], 400 );
        }

        $event = json_decode( $payload, true );
        if ( ! is_array( $event ) || empty( $event['type'] ) || empty( $event['data']['object'] ) || ! is_array( $event['data']['object'] ) ) {
            return new \WP_REST_Response( [ 'received' => false, 'message' => 'Invalid payload.' ], 400 );
        }

        $type   = (string) $event['type'];
        $object = $event['data']['object'];

        switch ( $type ) {
            case 'checkout.session.completed':
                $metadata = isset( $object['metadata'] ) && is_array( $object['metadata'] ) ? $object['metadata'] : [];
                $user_id  = isset( $metadata['user_id'] ) ? (int) $metadata['user_id'] : (int) ( $object['client_reference_id'] ?? 0 );
                $plan_id  = isset( $metadata['plan_id'] ) ? (int) $metadata['plan_id'] : 0;
                $billing  = isset( $metadata['billing'] ) && in_array( $metadata['billing'], [ 'monthly', 'yearly', 'free' ], true ) ? (string) $metadata['billing'] : 'monthly';
                $sub_id   = sanitize_text_field( (string) ( $object['subscription'] ?? '' ) );
                $cust_id  = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );
                if ( $user_id > 0 && $plan_id > 0 ) {
                    $this->set_user_plan( $user_id, $plan_id, $billing, $sub_id, $cust_id );
                }
                break;

            case 'customer.subscription.created':
            case 'customer.subscription.updated':
            case 'customer.subscription.deleted':
            case 'invoice.payment_failed':
                $this->handle_stripe_subscription_event( $object, $type );
                break;
        }

        return new \WP_REST_Response( [ 'received' => true ], 200 );
    }

    public function ajax_upgrade(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot change workspace billing. Please contact the workspace owner.', 'authorwings-membership' ) ], 403 );
        }

        $plan_slug = sanitize_text_field( $_POST['plan'] ?? '' );
        $billing   = in_array( $_POST['billing'] ?? '', [ 'monthly', 'yearly' ], true )
            ? sanitize_text_field( $_POST['billing'] )
            : 'monthly';

        global $wpdb;
        $ptable = Database::plans_table();
        $plan   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$ptable} WHERE slug = %s AND is_active = 1 LIMIT 1", $plan_slug ),
            ARRAY_A
        );

        if ( ! $plan ) {
            wp_send_json_error( [ 'message' => __( 'Plan not found.', 'authorwings-membership' ) ] );
        }

        if ( (bool) $plan['is_free'] ) {
            $this->set_user_plan( get_current_user_id(), (int) $plan['id'], 'free' );
            wp_send_json_success( [ 'message' => __( 'Plan updated.', 'authorwings-membership' ), 'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'plan-updated' ], $this->get_account_url() ) ] );
            return;
        }

        $checkout_url = $this->create_stripe_checkout_session( $plan, $billing, get_current_user_id() );
        if ( is_wp_error( $checkout_url ) ) {
            wp_send_json_error( [ 'message' => $checkout_url->get_error_message() ], 400 );
        }

        wp_send_json_success( [ 'redirect' => $checkout_url ] );
    }

    public function ajax_cancel(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot cancel workspace billing. Please contact the workspace owner.', 'authorwings-membership' ) ], 403 );
        }
        $this->cancel_user_membership( get_current_user_id(), 'cancelled' );
        wp_send_json_success( [
            'message'  => __( 'Membership cancelled.', 'authorwings-membership' ),
            'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'cancelled' ], $this->get_account_url() ),
        ] );
    }

    public function ajax_invite_team_member(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        $email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
        if ( ! is_email( $email ) ) {
            wp_send_json_error( [ 'message' => __( 'Please enter a valid email address.', 'authorwings-membership' ) ], 400 );
        }

        $result = $this->invite_team_member( get_current_user_id(), $email );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
        }

        wp_send_json_success( [
            'message' => __( 'Seat invitation saved.', 'authorwings-membership' ),
            'team'    => $this->get_team_context( get_current_user_id() ),
        ] );
    }

    public function ajax_remove_team_member(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }

        $seat_id = (int) ( $_POST['seat_id'] ?? 0 );
        if ( $seat_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Invalid seat.', 'authorwings-membership' ) ], 400 );
        }

        $ok = $this->remove_team_member( get_current_user_id(), $seat_id );
        if ( ! $ok ) {
            wp_send_json_error( [ 'message' => __( 'Could not remove that seat.', 'authorwings-membership' ) ], 400 );
        }

        wp_send_json_success( [
            'message' => __( 'Seat removed.', 'authorwings-membership' ),
            'team'    => $this->get_team_context( get_current_user_id() ),
        ] );
    }

    public function get_team_context( int $user_id ): array {
        $workspace_owner_id = $this->get_workspace_owner_id( $user_id );
        $owner_mem          = $this->get_user_membership( $workspace_owner_id );
        $limits             = $owner_mem ? ( json_decode( $owner_mem['limits'] ?? '{}', true ) ?: [] ) : [];
        $seat_limit         = max( 0, (int) ( $limits['team_seats'] ?? 0 ) );
        $is_owner           = $workspace_owner_id === $user_id;
        $team_members       = $this->get_team_members_for_owner( $workspace_owner_id );
        $owner_user         = get_userdata( $workspace_owner_id );

        return [
            'workspace_owner_id'   => $workspace_owner_id,
            'is_owner'             => $is_owner,
            'is_team_member'       => ! $is_owner,
            'can_manage_team'      => $is_owner && $this->owner_workspace_active( $workspace_owner_id ) && $seat_limit > 0,
            'seat_limit'           => $seat_limit,
            'seat_count'           => count( $team_members ),
            'members'              => $team_members,
            'workspace_owner_name' => $owner_user ? $owner_user->display_name : '',
            'workspace_owner_email'=> $owner_user ? $owner_user->user_email : '',
            'usage_model'          => 'workspace',
        ];
    }

    private function owner_workspace_active( int $owner_user_id ): bool {
        $mem = $this->get_user_membership( $owner_user_id );
        return $mem && ( $mem['plan_slug'] ?? '' ) === 'publisher' && in_array( $mem['status'], [ 'active', 'trialing' ], true );
    }

    private function get_team_seat_for_member( int $member_user_id ): ?array {
        global $wpdb;
        $table = Database::team_table();
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE member_user_id = %d AND status = 'active' ORDER BY id DESC LIMIT 1", $member_user_id ),
            ARRAY_A
        );
    }

    private function get_team_members_for_owner( int $owner_user_id ): array {
        global $wpdb;
        $table = Database::team_table();
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE owner_user_id = %d ORDER BY created_at ASC", $owner_user_id ),
            ARRAY_A
        );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $user = ! empty( $row['member_user_id'] ) ? get_userdata( (int) $row['member_user_id'] ) : null;
            $out[] = [
                'id'           => (int) $row['id'],
                'status'       => (string) $row['status'],
                'email'        => (string) $row['invited_email'],
                'member_user_id'=> (int) $row['member_user_id'],
                'name'         => $user ? $user->display_name : '',
            ];
        }
        return $out;
    }

    private function invite_team_member( int $owner_user_id, string $email ) {
        if ( ! $this->owner_workspace_active( $owner_user_id ) ) {
            return new \WP_Error( 'awg_mem_team_requires_publisher', __( 'Only an active Publisher workspace can invite team seats.', 'authorwings-membership' ) );
        }

        $context = $this->get_team_context( $owner_user_id );
        if ( $context['seat_limit'] > 0 && $context['seat_count'] >= $context['seat_limit'] ) {
            return new \WP_Error( 'awg_mem_team_full', __( 'All team seats are already in use.', 'authorwings-membership' ) );
        }

        $user = get_user_by( 'email', $email );
        if ( $user && (int) $user->ID === $owner_user_id ) {
            return new \WP_Error( 'awg_mem_team_owner', __( 'You cannot invite your own email as a team seat.', 'authorwings-membership' ) );
        }

        global $wpdb;
        $table = Database::team_table();
        $now   = current_time( 'mysql' );
        $data  = [
            'owner_user_id'  => $owner_user_id,
            'member_user_id' => $user ? (int) $user->ID : 0,
            'invited_email'  => $email,
            'status'         => $user ? 'active' : 'pending',
            'updated_at'     => $now,
        ];

        $existing = $wpdb->get_row(
            $wpdb->prepare( "SELECT id FROM {$table} WHERE owner_user_id = %d AND invited_email = %s LIMIT 1", $owner_user_id, $email ),
            ARRAY_A
        );

        if ( $existing ) {
            $wpdb->update( $table, $data, [ 'id' => (int) $existing['id'] ] );
        } else {
            $data['created_at'] = $now;
            $wpdb->insert( $table, $data );
        }

        if ( $user ) {
            Roles::set_user_role( (int) $user->ID, Roles::PUBLISHER );
        } else {
            $owner = get_userdata( $owner_user_id );
            $subject = __( 'You were invited to an AuthorWings Publisher workspace', 'authorwings-membership' );
            $message = sprintf(
                __( "%1$s invited %2$s to join a Publisher workspace on AuthorWings. Create or log into an account with this email to claim the seat.", 'authorwings-membership' ),
                $owner ? $owner->display_name : __( 'A workspace owner', 'authorwings-membership' ),
                $email
            );
            wp_mail( $email, $subject, $message );
        }

        return true;
    }

    private function remove_team_member( int $owner_user_id, int $seat_id ): bool {
        global $wpdb;
        $table = Database::team_table();
        $seat  = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND owner_user_id = %d LIMIT 1", $seat_id, $owner_user_id ),
            ARRAY_A
        );
        if ( ! $seat ) {
            return false;
        }

        $deleted = $wpdb->delete( $table, [ 'id' => $seat_id, 'owner_user_id' => $owner_user_id ] );
        if ( $deleted && ! empty( $seat['member_user_id'] ) ) {
            $this->refresh_user_access_role( (int) $seat['member_user_id'] );
        }
        return (bool) $deleted;
    }

    private function claim_pending_team_invites( int $user_id ): void {
        $user = get_userdata( $user_id );
        if ( ! $user || ! is_email( $user->user_email ) ) {
            return;
        }

        global $wpdb;
        $table = Database::team_table();
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE invited_email = %s AND status = 'pending'", $user->user_email ),
            ARRAY_A
        );

        foreach ( (array) $rows as $row ) {
            if ( ! $this->owner_workspace_active( (int) $row['owner_user_id'] ) ) {
                continue;
            }
            $wpdb->update(
                $table,
                [
                    'member_user_id' => $user_id,
                    'status'         => 'active',
                    'updated_at'     => current_time( 'mysql' ),
                ],
                [ 'id' => (int) $row['id'] ]
            );
            Roles::set_user_role( $user_id, Roles::PUBLISHER );
        }
    }

    private function refresh_user_access_role( int $user_id ): void {
        $mem = $this->get_user_membership( $user_id );
        if ( $mem && ! empty( $mem['plan_slug'] ) ) {
            Roles::set_user_role( $user_id, Roles::slug_to_role( (string) $mem['plan_slug'] ) );
            return;
        }
        Roles::set_user_role( $user_id, Roles::FREE );
    }

    private function sync_team_access_for_owner( int $owner_user_id ): void {
        global $wpdb;
        $table = Database::team_table();
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE owner_user_id = %d", $owner_user_id ),
            ARRAY_A
        );

        $workspace_active = $this->owner_workspace_active( $owner_user_id );
        foreach ( (array) $rows as $row ) {
            $member_user_id = (int) ( $row['member_user_id'] ?? 0 );
            if ( $workspace_active ) {
                $wpdb->update( $table, [ 'status' => $member_user_id > 0 ? 'active' : 'pending', 'updated_at' => current_time( 'mysql' ) ], [ 'id' => (int) $row['id'] ] );
                if ( $member_user_id > 0 ) {
                    Roles::set_user_role( $member_user_id, Roles::PUBLISHER );
                }
            } else {
                if ( $member_user_id > 0 ) {
                    $this->refresh_user_access_role( $member_user_id );
                }
                $wpdb->delete( $table, [ 'id' => (int) $row['id'] ] );
            }
        }
    }
}
