<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Roles {

    // Role slugs
    public const FREE      = 'awg_free_member';
    public const BASIC     = 'awg_basic_member';
    public const PRO       = 'awg_pro_member';
    public const PUBLISHER = 'awg_publisher';

    // Ordered hierarchy (index = level, higher = more access)
    public const HIERARCHY = [
        self::FREE,
        self::BASIC,
        self::PRO,
        self::PUBLISHER,
    ];

    public static function register(): void {
        // Base subscriber caps
        $subscriber_caps = [ 'read' => true ];

        $definitions = [
            self::FREE => [
                'label' => 'AuthorWings Free Member',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                ] ),
            ],
            self::BASIC => [
                'label' => 'AuthorWings Basic Member',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                    'awg_use_basic_tools'    => true,
                    'awg_download_outputs'   => true,
                    'awg_view_history'       => true,
                ] ),
            ],
            self::PRO => [
                'label' => 'AuthorWings Pro Member',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                    'awg_use_basic_tools'    => true,
                    'awg_use_pro_tools'      => true,
                    'awg_download_outputs'   => true,
                    'awg_view_history'       => true,
                    'awg_priority_queue'     => true,
                    'awg_service_discounts'  => true,
                ] ),
            ],
            self::PUBLISHER => [
                'label' => 'AuthorWings Publisher',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                    'awg_use_basic_tools'    => true,
                    'awg_use_pro_tools'      => true,
                    'awg_use_publisher_tools'=> true,
                    'awg_download_outputs'   => true,
                    'awg_view_history'       => true,
                    'awg_priority_queue'     => true,
                    'awg_service_discounts'  => true,
                    'awg_team_seats'         => true,
                    'awg_bulk_tools'         => true,
                ] ),
            ],
        ];

        foreach ( $definitions as $slug => $def ) {
            // Only add if not already registered
            if ( ! get_role( $slug ) ) {
                add_role( $slug, $def['label'], $def['caps'] );
            }
        }
    }

    /**
     * Return the AWG role slug for a user (or FREE if none found).
     */
    public static function get_user_awg_role( int $user_id ): string {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return self::FREE;
        }
        foreach ( array_reverse( self::HIERARCHY ) as $role ) {
            if ( in_array( $role, (array) $user->roles, true ) ) {
                return $role;
            }
        }
        return self::FREE;
    }

    /**
     * Assign an AWG role to a user, removing any previous AWG role first.
     */
    public static function set_user_role( int $user_id, string $role ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }
        // Strip existing AWG roles
        foreach ( self::HIERARCHY as $r ) {
            $user->remove_role( $r );
        }
        $user->add_role( $role );
    }

    /**
     * Return human-readable label for a role slug.
     */
    public static function label( string $slug ): string {
        $labels = [
            self::FREE      => __( 'Free',      'authorwings-membership' ),
            self::BASIC     => __( 'Basic',     'authorwings-membership' ),
            self::PRO       => __( 'Pro',       'authorwings-membership' ),
            self::PUBLISHER => __( 'Publisher', 'authorwings-membership' ),
        ];
        return $labels[ $slug ] ?? $slug;
    }


    /**
     * Map a membership plan slug to the corresponding AWG role slug.
     */
    public static function slug_to_role( string $slug ): string {
        $map = [
            'free'      => self::FREE,
            'basic'     => self::BASIC,
            'pro'       => self::PRO,
            'publisher' => self::PUBLISHER,
        ];

        return $map[ $slug ] ?? self::FREE;
    }

    /**
     * Return numeric level for a role (higher = more access).
     */
    public static function level( string $slug ): int {
        $idx = array_search( $slug, self::HIERARCHY, true );
        return $idx === false ? 0 : (int) $idx;
    }
}
