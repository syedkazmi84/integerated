=== AuthorWings AI ===
Contributors: Syed Kazmi
Tags: ai, openai, generator, shortcode, gutenberg
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 5.1.5
License: GPLv2 or later

== Description ==
Create customizable AI generator templates and render them via shortcode or Gutenberg block. Includes professional front-end actions (copy, download, clear), usage insights, and stronger required-field validation. Owner: AuthorWings (authorwings.com). Private use only—unauthorized use is not permitted.

== Installation ==
1. Upload the plugin folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Go to Settings → AuthorWings AI and add your OpenAI API Key.
4. Go to AuthorWings AI Templates → Add New to create a template.

== Usage ==
Shortcode:
[awg_generator id="123"]

Gutenberg:
Add block “AuthorWings AI” and select a template.

== Uninstall ==
Removing the plugin deactivates it and leaves existing data in place unless you manually remove it.