(function (wp) {
  if (!wp || !wp.blocks) return;

  const { registerBlockType } = wp.blocks;
  const { InspectorControls } = wp.blockEditor || wp.editor; // fallback
  const { PanelBody, SelectControl, Notice } = wp.components;
  const { useSelect } = wp.data;
  const { createElement: el, Fragment } = wp.element;
  const __ = (wp.i18n && wp.i18n.__) ? wp.i18n.__ : function (text) { return text; };

  registerBlockType("awg/generator", {
    title: __("AuthorWings AI", "authorwings-ai-tools"),
    icon: "lightbulb",
    category: "widgets",
    attributes: {
      templateId: { type: "number", default: 0 },
    },

    edit: function (props) {
      const templateId = props.attributes.templateId;

      const templates = useSelect((select) => {
        const core = select("core");
        if (!core || !core.getEntityRecords) return null;

        return core.getEntityRecords("postType", "awg_ai_template", {
          per_page: 100,
          status: "publish",
        });
      }, []);

      let options = [{ label: __("Select a template…", "authorwings-ai-tools"), value: 0 }];

      if (templates && Array.isArray(templates)) {
        options = options.concat(
          templates.map((p) => ({
            label: (p.title && p.title.rendered) ? p.title.rendered : (__("Template #", "authorwings-ai-tools") + p.id),
            value: p.id,
          }))
        );
      }

      return el(
        Fragment,
        {},
        el(
          InspectorControls,
          {},
          el(
            PanelBody,
            { title: __("Generator Settings", "authorwings-ai-tools"), initialOpen: true },
            templates === null
              ? el(Notice, { status: "warning", isDismissible: false }, __("Loading templates…", "authorwings-ai-tools"))
              : null,
            el(SelectControl, {
              label: __("Template", "authorwings-ai-tools"),
              value: templateId,
              options: options,
              onChange: (val) =>
                props.setAttributes({ templateId: parseInt(val, 10) || 0 }),
            })
          )
        ),
        el(
          "div",
          { className: "awg-block-preview" },
          templateId
            ? __("AuthorWings AI selected:", "authorwings-ai-tools") + " #" + templateId
            : __("Select a template from the block sidebar settings.", "authorwings-ai-tools")
        )
      );
    },

    save: function () {
      return null; // dynamic render via PHP
    },
  });
})(window.wp);
