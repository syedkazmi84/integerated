<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

/**
 * Stores generator runs as admin-only records.
 */
final class Submissions {
    /** @var string */
    private $cpt;
    /** @var string */
    private $template_cpt;

    public function __construct(string $cpt, string $template_cpt) {
        $this->cpt = $cpt;
        $this->template_cpt = $template_cpt;
    }

    public function register(): void {
        register_post_type($this->cpt, [
            'labels' => [
                'name' => __('AI Submissions', 'authorwings-ai-tools'),
                'singular_name' => __('AI Submission', 'authorwings-ai-tools'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => false,
            // We attach this CPT under the top-level "AuthorWings AI" menu via custom submenus.
            'show_in_menu' => false,
            'supports' => ['title'],
            'capabilities' => [
                'edit_post'          => 'manage_options',
                'read_post'          => 'manage_options',
                'delete_post'        => 'manage_options',
                'edit_posts'         => 'manage_options',
                'edit_others_posts'  => 'manage_options',
                'publish_posts'      => 'manage_options',
                'read_private_posts' => 'manage_options',
                'delete_posts'       => 'manage_options',
                'delete_private_posts' => 'manage_options',
                'delete_published_posts' => 'manage_options',
                'delete_others_posts' => 'manage_options',
                'edit_private_posts' => 'manage_options',
                'edit_published_posts' => 'manage_options',
                'create_posts'       => 'manage_options',
            ],
        ]);
    }

    public function register_metabox(): void {
        add_meta_box(
            'awg_aig_submission_details',
            __('Submission Details', 'authorwings-ai-tools'),
            [$this, 'metabox_html'],
            $this->cpt,
            'normal',
            'high'
        );
    }

    public function metabox_html($post): void {
        $template_id = (int) get_post_meta($post->ID, '_awg_aig_template_id', true);
        $user_id = (int) get_post_meta($post->ID, '_awg_aig_user_id', true);
        $gclid = (string) get_post_meta($post->ID, '_awg_aig_gclid', true);
        $ip = (string) get_post_meta($post->ID, '_awg_aig_ip', true);
        $ua = (string) get_post_meta($post->ID, '_awg_aig_ua', true);
        $fields = get_post_meta($post->ID, '_awg_aig_fields', true);
        $output = (string) get_post_meta($post->ID, '_awg_aig_output', true);
        $model = (string) get_post_meta($post->ID, '_awg_aig_model', true);
        $cached = (string) get_post_meta($post->ID, '_awg_aig_cached', true);

        if (!is_array($fields)) { $fields = []; }

        $template_title = '';
        if ($template_id > 0) {
            $p = get_post($template_id);
            if ($p && $p->post_type === $this->template_cpt) {
                $template_title = $p->post_title;
            }
        }

        $user_label = $user_id ? ('#' . $user_id) : __('Guest', 'authorwings-ai-tools');
        if ($user_id) {
            $u = get_user_by('id', $user_id);
            if ($u) { $user_label = $u->display_name . ' (' . $u->user_email . ')'; }
        }

        echo '<p><strong>' . esc_html__('Template:', 'authorwings-ai-tools') . '</strong> ';
        if ($template_id && $template_title) {
            echo '<a href="' . esc_url(get_edit_post_link($template_id)) . '">' . esc_html($template_title) . '</a> (ID ' . esc_html((string)$template_id) . ')';
        } else {
            echo esc_html__('Unknown', 'authorwings-ai-tools');
        }
        echo '</p>';

        echo '<p><strong>' . esc_html__('User:', 'authorwings-ai-tools') . '</strong> ' . esc_html($user_label) . '</p>';
        echo '<p><strong>' . esc_html__('Model:', 'authorwings-ai-tools') . '</strong> ' . esc_html($model ?: '');
        echo ' <strong style="margin-left:12px;">' . esc_html__('Cached:', 'authorwings-ai-tools') . '</strong> ' . esc_html($cached === '1' ? 'Yes' : 'No') . '</p>';

        if ($gclid !== '') {
            echo '<p><strong>GCLID:</strong> ' . esc_html($gclid) . '</p>';
        }
        if ($ip !== '') {
            echo '<p><strong>' . esc_html__('IP:', 'authorwings-ai-tools') . '</strong> ' . esc_html($ip) . '</p>';
        }
        if ($ua !== '') {
            echo '<p><strong>' . esc_html__('User Agent:', 'authorwings-ai-tools') . '</strong> ' . esc_html($ua) . '</p>';
        }

        echo '<hr>';

        echo '<h4 style="margin:0 0 8px;">' . esc_html__('Submitted Fields', 'authorwings-ai-tools') . '</h4>';
        if (empty($fields)) {
            echo '<p class="description">' . esc_html__('No fields stored.', 'authorwings-ai-tools') . '</p>';
        } else {
            echo '<table class="widefat striped" style="max-width:980px;">';
            echo '<thead><tr><th>' . esc_html__('Field', 'authorwings-ai-tools') . '</th><th>' . esc_html__('Value', 'authorwings-ai-tools') . '</th></tr></thead><tbody>';
            foreach ($fields as $k => $v) {
                if (is_array($v)) { $v = implode(', ', $v); }
                echo '<tr><td><code>' . esc_html((string)$k) . '</code></td><td>' . esc_html((string)$v) . '</td></tr>';
            }
            echo '</tbody></table>';
        }

        echo '<h4 style="margin:16px 0 8px;">' . esc_html__('AI Output', 'authorwings-ai-tools') . '</h4>';
        echo '<textarea class="large-text code" rows="12" readonly>' . esc_textarea($output) . '</textarea>';
    }
}
