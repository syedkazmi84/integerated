<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Renderer {
    /** @var string */
    private $cpt;

    /** @var Settings */
    private $settings;

    public function __construct(string $cpt, Settings $settings) {
        $this->cpt = $cpt;
        $this->settings = $settings;
    }

    private function allowed_colors(): array {
        return ['030c17', 'e8f1fd', 'ffffff', '1a73e8', 'd1e3fa', 'fbbf24'];
    }

    private function color_or_default($value, string $default): string {
        $value = strtolower((string) $value);
        return in_array($value, $this->allowed_colors(), true) ? $value : $default;
    }

    private function sanitize_icon_class($value): string {
        $class = trim((string) $value);
        if ($class === '') {
            return '';
        }
        $parts = preg_split('/\s+/', $class);
        $parts = array_map('sanitize_html_class', array_filter($parts, static function ($part) {
            return is_string($part) && $part !== '';
        }));
        return trim(implode(' ', $parts));
    }

    private function render_icon(string $icon_class, int $size, string $extra_class = ''): string {
        if ($icon_class === '') {
            return '';
        }
        $classes = trim('awg-aig__icon ' . $extra_class . ' ' . $icon_class);
        return sprintf(
            '<span class="%1$s" style="font-size:%2$spx;width:%2$spx;height:%2$spx;" aria-hidden="true"></span>',
            esc_attr($classes),
            esc_attr($size)
        );
    }

    public function template_defaults(): array {
        return [
            'form_title' => 'Generator',
            'form_description' => 'Get tailored ideas for your next publishing project.',
            'button_label' => 'Generate',
            'title_icon_class' => '',
            'title_icon_size' => 20,
            'title_icon_position' => 'before',
            'success_title' => 'Result',
            'placeholder_output' => 'Your results will appear here…',
            'disclaimer_text' => 'AI results should be reviewed for accuracy before publishing.',
            'style_bg_color' => 'ffffff',
            'style_text_color' => '030c17',
            'style_border_color' => 'd1e3fa',
            'style_accent_color' => '1a73e8',
            'style_button_bg_color' => '1a73e8',
            'style_button_text_color' => 'ffffff',
            'style_button_border_color' => '1a73e8',
            'style_button_padding_y' => 10,
            'style_button_padding_x' => 14,
            'style_button_radius' => 10,
            'button_icon_class' => '',
            'button_icon_size' => 18,
            'button_icon_position' => 'before',
            'button_icon_css_class' => '',
            'style_padding' => 16,
            'style_margin' => 12,
            'style_radius' => 14,
            'style_input_height' => 44,
            'style_textarea_rows' => 5,
            'use_global_styles' => 1,
            'use_global_field_sizes' => 1,

            // Prompt settings
            'system_prompt' => 'You are a helpful publishing assistant.',
            'user_prompt'   => "Task: {{task}}\nGenerate: {{count}}\n\nInputs:\n{{fields}}\n\nRules:\n{{rules}}\n\nReturn clean output.",
            'task' => 'Book Title Generator',
            'rules' => "Use concise, marketable results.\nAvoid clichés.\nOutput as numbered list.",

            // Model + tuning
            'model' => '',
            'temperature' => 0.8,
            'max_output_tokens' => 600,

            // Output format
            'output_format' => 'text', // text | html | json
            'wrap_in_pre' => 1,
            'show_copy' => 1,
            'show_download' => 1,
            'show_clear' => 1,

            // Protection
            'allow_guests' => -1,
            'rate_per_min' => 10,
            'cache_seconds' => 0,
            'debug_admin' => 0,

            // Fields array
            'fields' => [
                [
                    'key' => 'genre',
                    'label' => 'Genre',
                    'type' => 'text',
                    'required' => 1,
                    'placeholder' => 'e.g., Mystery, Romance, Fantasy',
                    'options' => '',
                    'default' => '',
                    'icon_class' => '',
                    'icon_size' => 16,
                    'icon_position' => 'before_label',
                ],
                [
                    'key' => 'keywords',
                    'label' => 'Keywords',
                    'type' => 'textarea',
                    'required' => 0,
                    'placeholder' => 'Comma-separated keywords',
                    'options' => '',
                    'default' => '',
                    'icon_class' => '',
                    'icon_size' => 16,
                    'icon_position' => 'before_label',
                ],
            ],

            'count' => 10,
        ];
    }

    public function get_template_meta(int $post_id): array {
        $m = get_post_meta($post_id, '_awg_aig_template', true);
        if (!is_array($m)) { $m = []; }
        $meta = array_merge($this->template_defaults(), $m);
        $settings = $this->settings->get();

        $meta['use_global_styles'] = isset($meta['use_global_styles']) ? (int) $meta['use_global_styles'] : 1;
        $meta['use_global_field_sizes'] = isset($meta['use_global_field_sizes']) ? (int) $meta['use_global_field_sizes'] : 1;

        if ($meta['use_global_styles'] === 1) {
            $meta['style_bg_color'] = $this->color_or_default($settings['global_style_bg_color'] ?? '', 'ffffff');
            $meta['style_text_color'] = $this->color_or_default($settings['global_style_text_color'] ?? '', '030c17');
            $meta['style_border_color'] = $this->color_or_default($settings['global_style_border_color'] ?? '', 'd1e3fa');
            $meta['style_accent_color'] = $this->color_or_default($settings['global_style_accent_color'] ?? '', '1a73e8');
            $meta['style_button_bg_color'] = $this->color_or_default($settings['global_style_button_bg_color'] ?? '', '1a73e8');
            $meta['style_button_text_color'] = $this->color_or_default($settings['global_style_button_text_color'] ?? '', 'ffffff');
            $meta['style_button_border_color'] = $this->color_or_default($settings['global_style_button_border_color'] ?? '', '1a73e8');
            $meta['style_padding'] = max(0, min(80, intval($settings['global_style_padding'] ?? 16)));
            $meta['style_margin'] = max(0, min(80, intval($settings['global_style_margin'] ?? 12)));
            $meta['style_radius'] = max(0, min(40, intval($settings['global_style_radius'] ?? 14)));
            $meta['style_button_padding_y'] = max(6, min(30, intval($settings['global_style_button_padding_y'] ?? 10)));
            $meta['style_button_padding_x'] = max(8, min(40, intval($settings['global_style_button_padding_x'] ?? 14)));
            $meta['style_button_radius'] = max(0, min(20, intval($settings['global_style_button_radius'] ?? 10)));
        } else {
            $meta['style_bg_color'] = $this->color_or_default($meta['style_bg_color'] ?? '', 'ffffff');
            $meta['style_text_color'] = $this->color_or_default($meta['style_text_color'] ?? '', '030c17');
            $meta['style_border_color'] = $this->color_or_default($meta['style_border_color'] ?? '', 'd1e3fa');
            $meta['style_accent_color'] = $this->color_or_default($meta['style_accent_color'] ?? '', '1a73e8');
            $meta['style_button_bg_color'] = $this->color_or_default($meta['style_button_bg_color'] ?? '', '1a73e8');
            $meta['style_button_text_color'] = $this->color_or_default($meta['style_button_text_color'] ?? '', 'ffffff');
            $meta['style_button_border_color'] = $this->color_or_default($meta['style_button_border_color'] ?? '', '1a73e8');
        }

        if ($meta['use_global_field_sizes'] === 1) {
            $meta['style_input_height'] = max(32, min(80, intval($settings['global_style_input_height'] ?? 44)));
            $meta['style_textarea_rows'] = max(2, min(20, intval($settings['global_style_textarea_rows'] ?? 5)));
        } else {
            $meta['style_input_height'] = max(32, min(80, intval($meta['style_input_height'] ?? 44)));
            $meta['style_textarea_rows'] = max(2, min(20, intval($meta['style_textarea_rows'] ?? 5)));
        }

        $meta['button_icon_class'] = $this->sanitize_icon_class($meta['button_icon_class'] ?? '');
        $meta['button_icon_css_class'] = $this->sanitize_icon_class($meta['button_icon_css_class'] ?? '');
        $meta['button_icon_size'] = max(10, min(40, intval($meta['button_icon_size'] ?? 18)));
        $meta['button_icon_position'] = in_array(($meta['button_icon_position'] ?? 'before'), ['before', 'after'], true)
            ? $meta['button_icon_position']
            : 'before';
        $meta['title_icon_class'] = $this->sanitize_icon_class($meta['title_icon_class'] ?? '');
        $meta['title_icon_size'] = max(10, min(40, intval($meta['title_icon_size'] ?? 20)));
        $meta['title_icon_position'] = in_array(($meta['title_icon_position'] ?? 'before'), ['before', 'after'], true)
            ? $meta['title_icon_position']
            : 'before';

        if (is_array($meta['fields'])) {
            foreach ($meta['fields'] as $idx => $field) {
                if (!is_array($field)) {
                    continue;
                }
                $meta['fields'][$idx]['icon_class'] = $this->sanitize_icon_class($field['icon_class'] ?? '');
                $meta['fields'][$idx]['icon_size'] = max(10, min(30, intval($field['icon_size'] ?? 16)));
                $meta['fields'][$idx]['icon_position'] = in_array(($field['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true)
                    ? $field['icon_position']
                    : 'before_label';
            }
        }

        return $meta;
    }

    public function shortcode($atts): string {
        $atts = shortcode_atts(['id' => 0], $atts, 'awg_generator');
        $id = intval($atts['id']);
        if ($id <= 0) return '';
        return $this->render_form($id);
    }

    public function render_form(int $template_id): string {
        $p = get_post($template_id);
        if (!$p || $p->post_type !== $this->cpt) return '';

        // Only load assets when generator exists on the page.
        $plugin = Plugin::instance();
        if (!empty($plugin->assets)) {
            $plugin->assets->enqueue_front_assets();
        }

        $m = $this->get_template_meta($template_id);
        $settings = $this->settings->get();
        $file_stub = sanitize_file_name($p->post_title ?: ('generator-' . $template_id));

        ob_start();
        $style = sprintf(
            '--awg-bg:#%1$s;--awg-text:#%2$s;--awg-border:#%3$s;--awg-accent:#%4$s;--awg-pad:%5$spx;--awg-margin:%6$spx;--awg-radius:%7$spx;--awg-btn-bg:#%8$s;--awg-btn-text:#%9$s;--awg-btn-border:#%10$s;--awg-btn-pad-y:%11$spx;--awg-btn-pad-x:%12$spx;--awg-btn-radius:%13$spx;--awg-input-height:%14$spx;--awg-textarea-rows:%15$s;',
            esc_attr($m['style_bg_color']),
            esc_attr($m['style_text_color']),
            esc_attr($m['style_border_color']),
            esc_attr($m['style_accent_color']),
            esc_attr((int) $m['style_padding']),
            esc_attr((int) $m['style_margin']),
            esc_attr((int) $m['style_radius']),
            esc_attr($m['style_button_bg_color']),
            esc_attr($m['style_button_text_color']),
            esc_attr($m['style_button_border_color']),
            esc_attr((int) $m['style_button_padding_y']),
            esc_attr((int) $m['style_button_padding_x']),
            esc_attr((int) $m['style_button_radius']),
            esc_attr((int) $m['style_input_height']),
            esc_attr((int) $m['style_textarea_rows'])
        );
        ?>
        <div class="awg-aig" data-template-id="<?php echo esc_attr($template_id); ?>" style="<?php echo esc_attr($style); ?>">
            <?php $title_icon = $this->render_icon($this->sanitize_icon_class($m['title_icon_class'] ?? ''), max(10, min(40, intval($m['title_icon_size'] ?? 20))), 'awg-aig__title-icon'); ?>
            <div class="awg-aig__title">
                <?php if ($title_icon && ($m['title_icon_position'] ?? 'before') === 'before') { echo $title_icon; } ?>
                <span><?php echo esc_html($m['form_title']); ?></span>
                <?php if ($title_icon && ($m['title_icon_position'] ?? 'before') === 'after') { echo $title_icon; } ?>
            </div>
            <?php if (!empty($m['form_description'])): ?>
                <div class="awg-aig__desc"><?php echo esc_html($m['form_description']); ?></div>
            <?php endif; ?>

            <form class="awg-aig__form">
                <?php if (!empty($settings['enable_gclid'])): ?>
                    <input type="hidden" name="gclid" class="awg-aig__input awg-aig__gclid" value="">
                <?php endif; ?>
                <?php foreach ($m['fields'] as $f):
                    $key = sanitize_key($f['key']);
                    if ($key === '') {
                        continue;
                    }
                    $label = esc_html($f['label']);
                    $allowed_types = ['text', 'textarea', 'select', 'number', 'email', 'checkbox', 'radio'];
                    $type = in_array(($f['type'] ?? 'text'), $allowed_types, true) ? $f['type'] : 'text';
                    $req = !empty($f['required']);
                    $ph = esc_attr($f['placeholder'] ?? '');
                    $def_raw = (string)($f['default'] ?? '');
                    $name = esc_attr($key);
                    $field_icon = $this->sanitize_icon_class($f['icon_class'] ?? '');
                    $field_icon_size = max(10, min(30, intval($f['icon_size'] ?? 16)));
                    $field_icon_position = in_array(($f['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true)
                        ? $f['icon_position']
                        : 'before_label';
                    $field_icon_markup = $this->render_icon($field_icon, $field_icon_size, 'awg-aig__field-icon');
                ?>
                    <div class="awg-aig__field">
                        <label class="awg-aig__label">
                            <?php if ($field_icon_markup && $field_icon_position === 'before_label') { echo $field_icon_markup; } ?>
                            <span><?php echo $label; ?><?php echo $req ? ' <span class="awg-aig__req">*</span>' : ''; ?></span>
                            <?php if ($field_icon_markup && $field_icon_position === 'after_label') { echo $field_icon_markup; } ?>
                        </label>

                        <?php if ($field_icon_markup && $field_icon_position === 'before_input') { echo $field_icon_markup; } ?>
                        <?php if ($type === 'textarea'): ?>
                            <textarea class="awg-aig__input awg-aig__textarea" rows="<?php echo esc_attr((int) $m['style_textarea_rows']); ?>" name="<?php echo $name; ?>" placeholder="<?php echo $ph; ?>" <?php echo $req ? 'required' : ''; ?>><?php echo esc_textarea($def_raw); ?></textarea>

                        <?php elseif ($type === 'select'): ?>
                            <?php
                                $raw_opts = (string)($f['options'] ?? '');
                                $opts = preg_split('/[\r\n,]+/', $raw_opts);
                                $opts = array_values(array_filter(array_map('trim', $opts), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $default_val = trim($def_raw);
                            ?>
                            <select class="awg-aig__input" name="<?php echo $name; ?>" <?php echo $req ? 'required' : ''; ?>>
                                <option value=""><?php echo $ph ? esc_html($ph) : esc_html__('Select…', 'authorwings-ai-tools'); ?></option>
                                <?php foreach ($opts as $opt): ?>
                                    <option value="<?php echo esc_attr($opt); ?>" <?php selected($default_val, $opt); ?>>
                                        <?php echo esc_html($opt); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                        <?php elseif ($type === 'checkbox'): ?>
                            <?php
                                $raw_opts = (string)($f['options'] ?? '');
                                $opts = preg_split('/[\r\n,]+/', $raw_opts);
                                $opts = array_values(array_filter(array_map('trim', $opts), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $default_vals = preg_split('/[\r\n,]+/', $def_raw);
                                $default_vals = array_values(array_filter(array_map('trim', $default_vals), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $single_checked = in_array(strtolower(trim($def_raw)), ['1', 'true', 'yes', 'on'], true);
                            ?>
                            <?php if (!empty($opts)): ?>
                                <div class="awg-aig__choices" role="group" aria-label="<?php echo esc_attr($label); ?>">
                                    <?php foreach ($opts as $opt): ?>
                                        <label class="awg-aig__choice-row">
                                            <input class="awg-aig__choice" type="checkbox" name="<?php echo $name; ?>[]" value="<?php echo esc_attr($opt); ?>" <?php checked(in_array($opt, $default_vals, true)); ?> />
                                            <span><?php echo esc_html($opt); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <label class="awg-aig__choice-row">
                                    <input class="awg-aig__choice" type="checkbox" name="<?php echo $name; ?>" value="1" <?php checked($single_checked); ?> />
                                    <span><?php echo $ph ? esc_html($ph) : esc_html__('Yes', 'authorwings-ai-tools'); ?></span>
                                </label>
                            <?php endif; ?>

                        <?php elseif ($type === 'radio'): ?>
                            <?php
                                $raw_opts = (string)($f['options'] ?? '');
                                $opts = preg_split('/[\r\n,]+/', $raw_opts);
                                $opts = array_values(array_filter(array_map('trim', $opts), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $default_val = trim($def_raw);
                            ?>
                            <div class="awg-aig__choices" role="radiogroup" aria-label="<?php echo esc_attr($label); ?>">
                                <?php foreach ($opts as $index => $opt): ?>
                                    <label class="awg-aig__choice-row">
                                        <input class="awg-aig__choice" type="radio" name="<?php echo $name; ?>" value="<?php echo esc_attr($opt); ?>" <?php checked($default_val, $opt); ?> <?php echo ($req && $index === 0) ? 'required' : ''; ?> />
                                        <span><?php echo esc_html($opt); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>

                        <?php else: ?>
                            <input class="awg-aig__input" type="<?php echo esc_attr($type); ?>" name="<?php echo $name; ?>"
                                   value="<?php echo esc_attr($def_raw); ?>" placeholder="<?php echo $ph; ?>" <?php echo $req ? 'required' : ''; ?> />
                        <?php endif; ?>
                        <?php if ($field_icon_markup && $field_icon_position === 'after_input') { echo $field_icon_markup; } ?>
                    </div>
                <?php endforeach; ?>

                <div class="awg-aig__actions">
                    <?php
                    $button_icon = $this->render_icon(
                        $this->sanitize_icon_class($m['button_icon_class'] ?? ''),
                        max(10, min(40, intval($m['button_icon_size'] ?? 18))),
                        trim('awg-aig__button-icon ' . $this->sanitize_icon_class($m['button_icon_css_class'] ?? ''))
                    );
                    ?>
                    <button class="awg-aig__btn" type="submit">
                        <?php if ($button_icon && $m['button_icon_position'] === 'before') { echo $button_icon; } ?>
                        <span><?php echo esc_html($m['button_label']); ?></span>
                        <?php if ($button_icon && $m['button_icon_position'] === 'after') { echo $button_icon; } ?>
                    </button>
                    <span class="awg-aig__status" aria-live="polite"></span>
                </div>
            </form>

            <?php if (!empty($m['disclaimer_text'])): ?>
                <div class="awg-aig__note"><?php echo esc_html($m['disclaimer_text']); ?></div>
            <?php endif; ?>

            <div class="awg-aig__result" data-filename="<?php echo esc_attr($file_stub); ?>" hidden>
                <div class="awg-aig__result-head">
                    <strong><span class="awg-aig__result-head-icon dashicons dashicons-saved" aria-hidden="true"></span><span><?php echo esc_html($m['success_title']); ?></span></strong>
                </div>
                <div class="awg-aig__output" data-format="<?php echo esc_attr($m['output_format']); ?>"></div>
                <div class="awg-aig__result-actions awg-aig__result-actions--bottom">
                    <?php if (!empty($m['show_copy'])): ?>
                        <button type="button" class="awg-aig__copy"><span class="dashicons dashicons-clipboard"></span><span><?php echo esc_html__('Copy', 'authorwings-ai-tools'); ?></span></button>
                    <?php endif; ?>
                    <?php if (!empty($m['show_download'])): ?>
                        <button type="button" class="awg-aig__download"><span class="dashicons dashicons-download"></span><span><?php echo esc_html__('Download', 'authorwings-ai-tools'); ?></span></button>
                    <?php endif; ?>
                    <?php if (!empty($m['show_clear'])): ?>
                        <button type="button" class="awg-aig__clear"><span class="dashicons dashicons-trash"></span><span><?php echo esc_html__('Clear', 'authorwings-ai-tools'); ?></span></button>
                    <?php endif; ?>
                    <button type="button" class="awg-aig__regenerate"><span class="dashicons dashicons-update"></span><span><?php echo esc_html__('Regenerate', 'authorwings-ai-tools'); ?></span></button>
                </div>
            </div>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    public function fields_to_text(array $fields_schema, array $submitted): string {
        $lines = [];
        foreach ($fields_schema as $f) {
            $key = sanitize_key($f['key'] ?? '');
            if (!$key) continue;

            $label = $f['label'] ?? $key;
            $val = $submitted[$key] ?? '';

            if (is_array($val)) {
                $val = implode(', ', array_map('sanitize_text_field', $val));
            }
            $val = is_string($val) ? sanitize_text_field($val) : '';


            if ($val === '') continue;
            $lines[] = "- {$label}: {$val}";
        }
        return implode("\n", $lines);
    }
}
