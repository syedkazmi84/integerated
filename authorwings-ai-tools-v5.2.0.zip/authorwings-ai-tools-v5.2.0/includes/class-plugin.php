<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Plugin {
    private static $instance = null;

    /** @var CPT */
    public $cpt;
    /** @var Settings */
    public $settings;
    /** @var Metabox */
    public $metabox;
    /** @var Renderer */
    public $renderer;
    /** @var Assets */
    public $assets;
    /** @var Ajax */
    public $ajax;
    /** @var Block */
    public $block;
    /** @var Submissions */
    public $submissions;

    public const CPT = 'awg_ai_template';
    public const SUB_CPT = 'awg_ai_submission';
    public const OPT = 'awg_aig_settings';

    public static function instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function activate(): void {
        require_once AWG_AIG_PATH . 'includes/class-settings.php';
        require_once AWG_AIG_PATH . 'includes/class-cpt.php';
        require_once AWG_AIG_PATH . 'includes/class-renderer.php';
        $settings = new Settings(self::OPT);
        if (get_option(self::OPT, null) === null) {
            add_option(self::OPT, $settings->defaults());
        }
    }

    public static function deactivate(): void {
        // Reserved for future use.
    }

    private function __construct() {
        $this->includes();

        // i18n
        add_action('init', [$this, 'load_textdomain']);

        // Core modules
        $this->settings = new Settings(self::OPT);
        $this->cpt      = new CPT(self::CPT);
        $this->renderer = new Renderer(self::CPT, $this->settings);
        $this->metabox  = new Metabox(self::CPT, $this->renderer);
        $this->assets   = new Assets();
        $this->ajax     = new Ajax(self::CPT, $this->settings, $this->renderer);
        $this->block    = new Block($this->renderer);
        $this->submissions = new Submissions(self::SUB_CPT, self::CPT);

        // Hooks
        add_action('init', [$this->cpt, 'register']);
        add_action('init', [$this->submissions, 'register']);
        add_action('admin_menu', [$this->settings, 'menu']);
        add_action('admin_init', [$this->settings, 'register']);

        add_action('add_meta_boxes', [$this->metabox, 'register']);
        add_action('add_meta_boxes', [$this->submissions, 'register_metabox']);
        add_action('save_post', [$this->metabox, 'save'], 10, 2);
        add_filter('manage_' . self::CPT . '_posts_columns', [$this->cpt, 'columns']);
        add_action('manage_' . self::CPT . '_posts_custom_column', [$this->cpt, 'column_data'], 10, 2);
        add_filter('manage_edit-' . self::CPT . '_sortable_columns', [$this->cpt, 'sortable_columns']);
        add_action('pre_get_posts', [$this->cpt, 'sort_columns']);

        add_shortcode('awg_generator', [$this->renderer, 'shortcode']);

        // Front assets (only when generator is present)
        add_action('wp_enqueue_scripts', [$this->assets, 'maybe_enqueue_front_assets']);
        add_action('admin_enqueue_scripts', [$this->assets, 'admin_assets']);

        // Block
        add_action('init', [$this->block, 'register']);

        // AJAX
        add_action('wp_ajax_awg_aig_generate', [$this->ajax, 'generate']);
        add_action('wp_ajax_nopriv_awg_aig_generate', [$this->ajax, 'generate']);
    }

    private function __clone() {
        _doing_it_wrong(__FUNCTION__, esc_html__('Cloning is not allowed for this singleton.', 'authorwings-ai-tools'), AWG_AIG_VERSION);
    }

    public function __wakeup() {
        _doing_it_wrong(__FUNCTION__, esc_html__('Unserializing is not allowed for this singleton.', 'authorwings-ai-tools'), AWG_AIG_VERSION);
    }

    public function load_textdomain(): void {
        load_plugin_textdomain('authorwings-ai-tools', false, dirname(plugin_basename(AWG_AIG_FILE)) . '/languages');
    }

    private function includes(): void {
        require_once AWG_AIG_PATH . 'includes/class-settings.php';
        require_once AWG_AIG_PATH . 'includes/class-cpt.php';
        require_once AWG_AIG_PATH . 'includes/class-assets.php';
        require_once AWG_AIG_PATH . 'includes/class-renderer.php';
        require_once AWG_AIG_PATH . 'includes/class-metabox.php';
        require_once AWG_AIG_PATH . 'includes/class-ajax.php';
        require_once AWG_AIG_PATH . 'includes/class-block.php';
        require_once AWG_AIG_PATH . 'includes/class-submissions.php';
    }

}
