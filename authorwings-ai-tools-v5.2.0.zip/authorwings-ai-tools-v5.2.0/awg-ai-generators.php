<?php
/**
 * Plugin Name: AuthorWings AI
 * Description: Professional AI generator templates for publishing services with shortcode and Gutenberg block.
 * Version: 5.2.0
 * Author: AuthorWings
 * Author URI: https://authorwings.com
 * License: GPLv2 or later
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: authorwings-ai-tools
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

define('AWG_AIG_VERSION', '5.2.0');
define('AWG_AIG_FILE', __FILE__);
define('AWG_AIG_PATH', plugin_dir_path(__FILE__));
define('AWG_AIG_URL', plugin_dir_url(__FILE__));

require_once AWG_AIG_PATH . 'includes/class-plugin.php';

register_activation_hook(AWG_AIG_FILE, ['\\AWG_AIG\\Plugin', 'activate']);
register_deactivation_hook(AWG_AIG_FILE, ['\\AWG_AIG\\Plugin', 'deactivate']);

add_action('plugins_loaded', function () {
    \AWG_AIG\Plugin::instance();
});