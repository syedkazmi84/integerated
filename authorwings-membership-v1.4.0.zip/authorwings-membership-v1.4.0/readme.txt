=== AuthorWings Membership ===
Author: AuthorWings
Author URI: https://authorwings.com
Requires at least: 6.0
Requires PHP: 7.4
Version: 1.0.0
License: GPLv2 or later

== Description ==

Membership plans, user dashboard, usage gating, and publishing services for AuthorWings.com.

Works alongside the AuthorWings AI plugin (v5.1.5+) to gate AI tool access per plan.

== Features ==

* 4 membership tiers: Free, Basic, Pro, Publisher
* Monthly AI generation limits per plan
* User dashboard with tabs: Home, AI Tools, Services, History, Account
* Professional services listing with quote request form
* Admin panel: member management, orders, plan settings
* Stripe-ready payment integration (add your keys in Settings)
* Automatic email notifications (welcome, upgrade, cancel, expiry)
* Pricing page shortcode: [awg_pricing]
* Dashboard shortcode: [awg_dashboard]

== Integration with AuthorWings AI Plugin ==

The membership plugin hooks into the AI plugin non-destructively:
- Checks usage limits before generation
- Increments usage counter after successful generation
- Filters visible templates by user plan

To enable full hook support, add these 3 lines to the AI plugin's class-ajax.php
generate() method (optional — fallback interception works without it):

  // Before generation:
  $can = apply_filters('awg_aig_can_generate', true, get_current_user_id(), $template_id);
  if (is_wp_error($can)) { wp_send_json_error(['message' => $can->get_error_message()]); }

  // After generation:
  do_action('awg_aig_generated', get_current_user_id(), $template_id, $text);

== Stripe Integration ==

1. Add your Stripe keys in AW Members → Settings
2. Hook into the filter `awg_mem_stripe_checkout_url` to return a Stripe Checkout URL
3. Create a webhook endpoint and verify with your webhook secret
4. On payment success: call $memberships->set_user_plan($user_id, $plan_id, $billing)

== Shortcodes ==

[awg_dashboard]  — Full user dashboard (put on /member-dashboard/ page)
[awg_pricing]    — Pricing comparison table (put on /pricing/ page)

== Changelog ==

= 1.0.0 =
* Initial release
