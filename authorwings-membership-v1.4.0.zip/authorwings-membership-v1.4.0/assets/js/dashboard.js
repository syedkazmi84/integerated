/* AuthorWings Membership — Dashboard JS v1.1.0 */
(function ($) {
    'use strict';

    const cfg   = window.AWG_MEM || {};
    const ajax  = cfg.ajax_url;
    const nonce = cfg.nonce;
    const s     = cfg.strings || {};

    // ── Helpers ──────────────────────────────────────────────

    /**
     * Move modals to <body> so position:fixed works in every theme.
     * CSS transforms or overflow:hidden on ancestors break fixed positioning —
     * appending to body bypasses all of that.
     */
    function hoistModalsToBody() {
        $('.awg-mem-modal').each(function () {
            if ( $(this).parent().is('body') ) { return; }
            $(this).appendTo('body');
        });
    }

    function openModal($modal) {
        $modal.addClass('is-open');
        $('body').addClass('awg-modal-open');
    }

    function closeModal($modal) {
        $modal.removeClass('is-open');
        // Only remove scroll lock if no other modals are open
        if ( ! $('.awg-mem-modal.is-open').length ) {
            $('body').removeClass('awg-modal-open');
        }
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function injectSpinStyle() {
        if ( document.getElementById('awg-spin-style') ) { return; }
        var el = document.createElement('style');
        el.id  = 'awg-spin-style';
        el.textContent = '@keyframes awg-spin{to{transform:rotate(360deg)}}';
        document.head.appendChild(el);
    }

    // ── Tab switching ────────────────────────────────────────
    function initTabs() {
        var $tabs   = $('.awg-mem-tab');
        var $panels = $('.awg-mem-panel');

        function activateTab(tab) {
            $tabs.removeClass('awg-mem-tab--active');
            $panels.removeClass('awg-mem-panel--active');
            $tabs.filter('[data-tab="' + tab + '"]').addClass('awg-mem-tab--active');
            $panels.filter('[data-panel="' + tab + '"]').addClass('awg-mem-panel--active');
            if (history.replaceState) {
                history.replaceState(null, '', '#' + tab);
            }
        }

        $tabs.on('click', function () { activateTab($(this).data('tab')); });

        $(document).on('click', '.awg-mem-tab-link', function (e) {
            e.preventDefault();
            activateTab($(this).data('tab'));
        });

        var hash = window.location.hash.replace('#', '');
        if (hash && $('.awg-mem-tab[data-tab="' + hash + '"]').length) {
            activateTab(hash);
        }
        if (new URLSearchParams(window.location.search).get('upgrade')) {
            activateTab('account');
        }
    }

    // ── Tool modal ───────────────────────────────────────────
    function initToolModal() {
        var $modal   = $('#awg-tool-modal');
        var $content = $('#awg-tool-modal-content');

        $(document).on('click', '.awg-mem-open-tool', function () {
            var templateId = $(this).data('template-id');
            if ( ! templateId ) { return; }

            // Loading state
            $content.html(
                '<div style="padding:48px 24px;text-align:center;color:#6b7280;">' +
                '<span class="dashicons dashicons-update-alt" style="font-size:36px;width:36px;height:36px;' +
                'display:inline-block;animation:awg-spin 1s linear infinite;"></span>' +
                '<p style="margin:14px 0 0;font-size:14px;">' + escHtml(s.tool_loading || 'Loading tool…') + '</p>' +
                '</div>'
            );
            openModal($modal);

            $.post(ajax, {
                action:      'awg_mem_get_tool_html',
                nonce:       nonce,
                template_id: templateId,
            })
            .done(function (res) {
                if (res.success && res.data && res.data.html) {
                    // Update modal title if element exists
                    $modal.find('.awg-mem-modal__title').text(res.data.title || '');
                    $content.html(res.data.html);
                    // Notify AI plugin that new generator HTML was injected
                    $(document).trigger('awg_aig_modal_loaded', [$content]);
                } else {
                    var msg = (res.data && res.data.message) || (s.tool_error || 'Could not load tool.');
                    $content.html(
                        '<div style="padding:28px 24px;">' +
                        '<p style="color:#991b1b;font-size:14px;margin:0 0 12px;">' + escHtml(msg) + '</p>' +
                        '<p style="font-size:13px;color:#6b7280;margin:0;">You can also add this tool to any page with the shortcode:<br>' +
                        '<code style="background:#f3f4f6;padding:3px 7px;border-radius:4px;font-size:12px;">' +
                        '[awg_generator id="' + parseInt(templateId, 10) + '"]</code></p>' +
                        '</div>'
                    );
                }
            })
            .fail(function () {
                $content.html(
                    '<p style="padding:28px 24px;color:#991b1b;font-size:14px;margin:0;">' +
                    escHtml(s.tool_error || 'Could not load tool. Please try again.') + '</p>'
                );
            });
        });

        // Close handlers
        $(document).on('click', '#awg-tool-modal-close', function () {
            closeModal($modal);
            $content.html('');
            $modal.find('.awg-mem-modal__title').text('');
        });
        $(document).on('click', '#awg-tool-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
            $content.html('');
            $modal.find('.awg-mem-modal__title').text('');
        });
        $(document).on('keydown.awg-tool-modal', function (e) {
            if (e.key === 'Escape' && $modal.hasClass('is-open')) {
                closeModal($modal);
                $content.html('');
            }
        });
    }

    // ── Service order modal ──────────────────────────────────
    function initServiceModal() {
        var $modal      = $('#awg-service-modal');
        var currentSlug = '';
        var currentName = '';

        $(document).on('click', '.awg-mem-request-service', function () {
            currentSlug = $(this).data('slug');
            currentName = $(this).data('name');
            $('#awg-service-modal-title').text(currentName);
            $('#awg-service-modal-msg').hide().removeClass('awg-mem-alert--success awg-mem-alert--error');
            $('#awg-service-form-wrap').show();
            $('#awg-service-notes').val('');
            openModal($modal);
        });

        $(document).on('click', '#awg-service-modal-close', function () { closeModal($modal); });
        $(document).on('click', '#awg-service-modal .awg-mem-modal__backdrop', function () { closeModal($modal); });
        $(document).on('keydown.awg-service-modal', function (e) {
            if (e.key === 'Escape' && $modal.hasClass('is-open')) { closeModal($modal); }
        });

        $(document).on('click', '#awg-service-submit', function () {
            var notes = $('#awg-service-notes').val().trim();
            var $btn  = $(this);
            $btn.prop('disabled', true).text(s.submitting || 'Submitting…');

            $.post(ajax, {
                action:       'awg_mem_submit_order',
                nonce:        nonce,
                service_slug: currentSlug,
                service_name: currentName,
                notes:        notes,
            })
            .done(function (res) {
                $btn.prop('disabled', false).text('Submit Request');
                var $msg = $('#awg-service-modal-msg');
                if (res.success) {
                    $msg.removeClass('awg-mem-alert--error')
                        .addClass('awg-mem-alert awg-mem-alert--success')
                        .text(res.data.message).show();
                    $('#awg-service-form-wrap').hide();
                } else {
                    $msg.removeClass('awg-mem-alert--success')
                        .addClass('awg-mem-alert awg-mem-alert--error')
                        .text((res.data && res.data.message) || s.error_generic).show();
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).text('Submit Request');
                alert(s.error_generic || 'Something went wrong. Please try again.');
            });
        });
    }

    // ── Plan upgrade ─────────────────────────────────────────
    function initPlanUpgrade() {
        $(document).on('click', '.awg-mem-select-plan', function () {
            var $btn     = $(this);
            var plan     = $btn.data('plan');
            var billing  = $btn.data('billing') || 'monthly';
            var origText = $btn.text().trim();

            $btn.prop('disabled', true).text(s.upgrading || 'Processing…');

            $.post(ajax, { action: 'awg_mem_upgrade_plan', nonce: nonce, plan: plan, billing: billing })
            .done(function (res) {
                if (res.success) {
                    if (res.data && res.data.redirect) {
                        window.location.href = res.data.redirect;
                    } else {
                        window.location.reload();
                    }
                } else {
                    $btn.prop('disabled', false).text(origText);
                    alert((res.data && res.data.message) || s.error_generic);
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).text(origText);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }

    // ── Cancel plan ──────────────────────────────────────────
    function initCancelPlan() {
        $(document).on('click', '.awg-mem-cancel-plan', function () {
            if ( ! confirm(s.confirm_cancel || 'Cancel your membership? You will be moved to the free plan.') ) { return; }
            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(ajax, { action: 'awg_mem_cancel_plan', nonce: nonce })
            .done(function (res) {
                if (res.success) {
                    window.location.reload();
                } else {
                    alert((res.data && res.data.message) || s.error_generic);
                    $btn.prop('disabled', false);
                }
            })
            .fail(function () {
                $btn.prop('disabled', false);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }

    // ── Copy to clipboard ────────────────────────────────────
    function initCopyButtons() {
        $(document).on('click', '.awg-mem-copy-btn', function () {
            var text = $(this).data('copy');
            var $btn = $(this);
            var orig = $btn.text();

            function done() {
                $btn.text(s.copied || 'Copied!');
                setTimeout(function () { $btn.text(orig); }, 2000);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () {
                    fallbackCopy(text); done();
                });
            } else {
                fallbackCopy(text); done();
            }
        });

        function fallbackCopy(text) {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
            document.body.appendChild(ta);
            ta.focus(); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta);
        }
    }

    // ── Init ─────────────────────────────────────────────────
    $(function () {
        if ( ! $('.awg-mem-dashboard').length ) { return; }

        hoistModalsToBody(); // Must run first
        injectSpinStyle();
        initTabs();
        initToolModal();
        initServiceModal();
        initPlanUpgrade();
        initCancelPlan();
        initCopyButtons();
    });

}(jQuery));
