<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Admin {

    /** @var Memberships */
    private $memberships;

    /** @var Plans */
    private $plans;

    /** @var Usage */
    private $usage;

    public function __construct( Memberships $memberships, Plans $plans, Usage $usage ) {
        $this->memberships = $memberships;
        $this->plans       = $plans;
        $this->usage       = $usage;
    }

    public function menu(): void {
        add_menu_page(
            __( 'AuthorWings Members', 'authorwings-membership' ),
            __( 'AW Members', 'authorwings-membership' ),
            'manage_options',
            'awg-membership',
            [ $this, 'page_members' ],
            'dashicons-groups',
            57
        );

        add_submenu_page(
            'awg-membership',
            __( 'Members', 'authorwings-membership' ),
            __( 'Members', 'authorwings-membership' ),
            'manage_options',
            'awg-membership',
            [ $this, 'page_members' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Plans', 'authorwings-membership' ),
            __( 'Plans', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-plans',
            [ $this, 'page_plans' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Service Orders', 'authorwings-membership' ),
            __( 'Service Orders', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-orders',
            [ $this, 'page_orders' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Services', 'authorwings-membership' ),
            __( 'Services', 'authorwings-membership' ),
            'manage_options',
            'edit.php?post_type=awg_service'
        );

        add_submenu_page(
            'awg-membership',
            __( 'Settings', 'authorwings-membership' ),
            __( 'Settings', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-settings',
            [ $this, 'page_settings' ]
        );
    }

    public function register_settings(): void {
        register_setting( 'awg_mem_settings_group', Plugin::OPT, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_settings' ],
        ] );
    }

    public function sanitize_settings( $input ): array {
        $out = [];
        $out['notify_admin_email'] = sanitize_email( $input['notify_admin_email'] ?? get_option( 'admin_email' ) );
        $out['stripe_secret_key']  = sanitize_text_field( $input['stripe_secret_key']  ?? '' );
        $out['stripe_public_key']  = sanitize_text_field( $input['stripe_public_key']  ?? '' );
        $out['stripe_webhook_secret'] = sanitize_text_field( $input['stripe_webhook_secret'] ?? '' );
        $out['dashboard_page_id']  = (int) ( $input['dashboard_page_id'] ?? 0 );
        return $out;
    }

    // ----------------------------------------------------------
    // Admin pages
    // ----------------------------------------------------------

    public function page_members(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        global $wpdb;
        $mems_table  = Database::mems_table();
        $plans_table = Database::plans_table();

        // Handle manual plan assignment
        if ( isset( $_POST['awg_assign_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_assign_plan_nonce'] ) ), 'awg_assign_plan' ) ) {
            $uid     = (int) $_POST['awg_uid'];
            $plan_id = (int) $_POST['awg_plan_id'];
            $billing = in_array( $_POST['awg_billing'] ?? '', [ 'monthly', 'yearly', 'free' ], true )
                       ? sanitize_text_field( $_POST['awg_billing'] )
                       : 'monthly';
            if ( $uid && $plan_id ) {
                $this->memberships->set_user_plan( $uid, $plan_id, $billing );
                echo '<div class="notice notice-success"><p>' . esc_html__( 'Plan updated.', 'authorwings-membership' ) . '</p></div>';
            }
        }

        $members = $wpdb->get_results(
            "SELECT m.*, p.name as plan_name, p.slug as plan_slug, u.display_name, u.user_email
             FROM {$mems_table} m
             LEFT JOIN {$plans_table} p ON p.id = m.plan_id
             LEFT JOIN {$wpdb->users} u ON u.ID = m.user_id
             WHERE m.status IN ('active','cancelled')
             ORDER BY m.id DESC
             LIMIT 100",
            ARRAY_A
        );

        $all_plans = $this->plans->get_all();

        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'AuthorWings Members', 'authorwings-membership' ); ?></h1>

            <!-- Stats row -->
            <?php
            $total_active  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$mems_table} WHERE status = 'active'" );
            $total_paid    = (int) $wpdb->get_row( "SELECT COUNT(*) as c FROM {$mems_table} m LEFT JOIN {$plans_table} p ON p.id = m.plan_id WHERE m.status = 'active' AND p.is_free = 0" )->c;
            $total_free    = $total_active - $total_paid;
            ?>
            <div style="display:flex;gap:16px;margin:16px 0;">
                <div style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:16px 24px;min-width:120px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;"><?php echo esc_html( $total_active ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Active Members', 'authorwings-membership' ); ?></div>
                </div>
                <div style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:16px 24px;min-width:120px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;color:#1D9E75;"><?php echo esc_html( $total_paid ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Paid Members', 'authorwings-membership' ); ?></div>
                </div>
                <div style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:16px 24px;min-width:120px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;color:#888;"><?php echo esc_html( $total_free ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Free Members', 'authorwings-membership' ); ?></div>
                </div>
            </div>

            <table class="widefat striped" style="margin-top:16px;">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'User', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Billing', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Renews', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Usage (this month)', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Change Plan', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $members ) ) : ?>
                        <tr><td colspan="7"><?php esc_html_e( 'No members yet.', 'authorwings-membership' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $members as $m ) :
                            $usage = $this->usage->get( (int) $m['user_id'], 'ai_generation' );
                        ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html( $m['display_name'] ); ?></strong><br>
                                    <small><?php echo esc_html( $m['user_email'] ); ?></small>
                                </td>
                                <td>
                                    <span style="background:<?php echo $m['plan_slug'] === 'free' ? '#f0f0f0' : '#e8f1fd'; ?>;padding:2px 8px;border-radius:3px;font-size:12px;">
                                        <?php echo esc_html( $m['plan_name'] ); ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="color:<?php echo $m['status'] === 'active' ? 'green' : '#888'; ?>">
                                        <?php echo esc_html( ucfirst( $m['status'] ) ); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html( ucfirst( $m['billing_cycle'] ) ); ?></td>
                                <td><?php echo $m['end_date'] ? esc_html( wp_date( 'd M Y', strtotime( $m['end_date'] ) ) ) : '—'; ?></td>
                                <td><?php echo esc_html( $usage ); ?> <?php esc_html_e( 'generations', 'authorwings-membership' ); ?></td>
                                <td>
                                    <form method="post" style="display:flex;gap:6px;align-items:center;">
                                        <?php wp_nonce_field( 'awg_assign_plan', 'awg_assign_plan_nonce' ); ?>
                                        <input type="hidden" name="awg_uid" value="<?php echo esc_attr( $m['user_id'] ); ?>">
                                        <select name="awg_plan_id" style="max-width:110px;">
                                            <?php foreach ( $all_plans as $p ) : ?>
                                                <option value="<?php echo esc_attr( $p['id'] ); ?>" <?php selected( $p['id'], $m['plan_id'] ); ?>>
                                                    <?php echo esc_html( $p['name'] ); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <select name="awg_billing">
                                            <option value="monthly"><?php esc_html_e( 'Monthly', 'authorwings-membership' ); ?></option>
                                            <option value="yearly"><?php esc_html_e( 'Yearly',  'authorwings-membership' ); ?></option>
                                        </select>
                                        <button type="submit" class="button"><?php esc_html_e( 'Save', 'authorwings-membership' ); ?></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_plans(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $plans = $this->plans->get_all();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Membership Plans', 'authorwings-membership' ); ?></h1>
            <p><?php esc_html_e( 'Plans are seeded on activation. Edit prices and features directly in the database or extend this page to add a UI.', 'authorwings-membership' ); ?></p>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Name', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Monthly', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Yearly', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Features', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $plans as $plan ) : ?>
                        <tr>
                            <td><?php echo esc_html( $plan['id'] ); ?></td>
                            <td><strong><?php echo esc_html( $plan['name'] ); ?></strong></td>
                            <td><?php echo $plan['is_free'] ? '—' : '$' . esc_html( number_format( $plan['price_monthly'], 2 ) ); ?></td>
                            <td><?php echo $plan['is_free'] ? '—' : '$' . esc_html( number_format( $plan['price_yearly'],  2 ) ); ?></td>
                            <td><?php echo esc_html( implode( ', ', array_slice( (array) $plan['features'], 0, 3 ) ) ); ?>…</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_orders(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        global $wpdb;
        $table  = Database::orders_table();
        $orders = $wpdb->get_results(
            "SELECT o.*, u.display_name, u.user_email FROM {$table} o
             LEFT JOIN {$wpdb->users} u ON u.ID = o.user_id
             ORDER BY o.id DESC LIMIT 100",
            ARRAY_A
        );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Service Orders', 'authorwings-membership' ); ?></h1>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Service', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'User', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Notes', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $orders ) ) : ?>
                        <tr><td colspan="6"><?php esc_html_e( 'No orders yet.', 'authorwings-membership' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $orders as $o ) : ?>
                            <tr>
                                <td><?php echo esc_html( $o['id'] ); ?></td>
                                <td><strong><?php echo esc_html( $o['service_name'] ); ?></strong></td>
                                <td><?php echo esc_html( $o['display_name'] ); ?><br><small><?php echo esc_html( $o['user_email'] ); ?></small></td>
                                <td>
                                    <span style="background:<?php echo $o['status'] === 'pending' ? '#fff3cd' : '#d4edda'; ?>;padding:2px 8px;border-radius:3px;font-size:12px;">
                                        <?php echo esc_html( ucfirst( $o['status'] ) ); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html( wp_trim_words( $o['notes'], 15 ) ); ?></td>
                                <td><?php echo esc_html( wp_date( 'd M Y', strtotime( $o['created_at'] ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $s = get_option( Plugin::OPT, [] );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'AuthorWings Membership Settings', 'authorwings-membership' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'awg_mem_settings_group' ); ?>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Admin Notification Email', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="email" name="<?php echo esc_attr( Plugin::OPT ); ?>[notify_admin_email]"
                                   value="<?php echo esc_attr( $s['notify_admin_email'] ?? get_option( 'admin_email' ) ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Secret Key', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_secret_key]"
                                   value="<?php echo esc_attr( $s['stripe_secret_key'] ?? '' ); ?>"
                                   class="regular-text" autocomplete="off">
                            <p class="description"><?php esc_html_e( 'Your Stripe secret key (sk_live_... or sk_test_...)', 'authorwings-membership' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Publishable Key', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_public_key]"
                                   value="<?php echo esc_attr( $s['stripe_public_key'] ?? '' ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Webhook Secret', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_webhook_secret]"
                                   value="<?php echo esc_attr( $s['stripe_webhook_secret'] ?? '' ); ?>"
                                   class="regular-text" autocomplete="off">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Dashboard Page', 'authorwings-membership' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[dashboard_page_id]',
                                'selected'         => (int) ( $s['dashboard_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (member-dashboard)', 'authorwings-membership' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    // AJAX
    public function ajax_assign_plan(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 403 );
        }
        $uid     = (int) ( $_POST['user_id'] ?? 0 );
        $plan_id = (int) ( $_POST['plan_id'] ?? 0 );
        $billing = sanitize_text_field( $_POST['billing'] ?? 'monthly' );
        if ( ! $uid || ! $plan_id ) {
            wp_send_json_error( [ 'message' => 'Missing params' ] );
        }
        $this->memberships->set_user_plan( $uid, $plan_id, $billing );
        wp_send_json_success( [ 'message' => 'Plan updated.' ] );
    }

    public function ajax_get_stats(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 403 );
        }
        global $wpdb;
        $mt = Database::mems_table();
        $pt = Database::plans_table();
        $ut = Database::usage_table();
        $period = Usage::current_period();

        $total_members = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$mt} WHERE status='active'" );
        $paid_members  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$mt} m LEFT JOIN {$pt} p ON p.id=m.plan_id WHERE m.status='active' AND p.is_free=0" );
        $total_gen     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(used) FROM {$ut} WHERE period=%s AND service_slug='ai_generation'", $period ) );

        wp_send_json_success( [
            'total_members' => $total_members,
            'paid_members'  => $paid_members,
            'free_members'  => $total_members - $paid_members,
            'generations'   => $total_gen,
            'period'        => $period,
        ] );
    }
}
