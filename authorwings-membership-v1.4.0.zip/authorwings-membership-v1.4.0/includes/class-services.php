<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Services {

    public const CPT = 'awg_service';

    public function register_cpt(): void {
        register_post_type( self::CPT, [
            'labels' => [
                'name'          => __( 'Publishing Services', 'authorwings-membership' ),
                'singular_name' => __( 'Publishing Service',  'authorwings-membership' ),
                'add_new_item'  => __( 'Add New Service',     'authorwings-membership' ),
                'edit_item'     => __( 'Edit Service',        'authorwings-membership' ),
            ],
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'supports'     => [ 'title', 'editor', 'thumbnail' ],
            'menu_icon'    => 'dashicons-book-alt',
        ] );
    }

    /**
     * Get all published services.
     */
    public function get_all(): array {
        $posts = get_posts( [
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ] );

        return array_map( function( $p ) {
            return [
                'id'          => $p->ID,
                'title'       => $p->post_title,
                'description' => wp_strip_all_tags( $p->post_content ),
                'slug'        => $p->post_name,
                'category'    => get_post_meta( $p->ID, '_awg_svc_category',     true ) ?: 'general',
                'price_from'  => get_post_meta( $p->ID, '_awg_svc_price_from',   true ) ?: '',
                'is_free'     => (bool) get_post_meta( $p->ID, '_awg_svc_is_free', true ),
                'turnaround'  => get_post_meta( $p->ID, '_awg_svc_turnaround',   true ) ?: '',
                'icon'        => get_post_meta( $p->ID, '_awg_svc_icon',         true ) ?: 'dashicons-star-filled',
            ];
        }, $posts );
    }

    /**
     * AJAX: submit a service order request.
     */
    public function ajax_submit_order(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in to request a service.', 'authorwings-membership' ) ], 401 );
        }

        $user_id     = get_current_user_id();
        $service_slug = sanitize_text_field( $_POST['service_slug'] ?? '' );
        $service_name = sanitize_text_field( $_POST['service_name'] ?? '' );
        $notes        = sanitize_textarea_field( $_POST['notes']        ?? '' );

        if ( ! $service_slug ) {
            wp_send_json_error( [ 'message' => __( 'Please select a service.', 'authorwings-membership' ) ] );
        }

        global $wpdb;
        $table = Database::orders_table();
        $now   = current_time( 'mysql' );

        $inserted = $wpdb->insert( $table, [
            'user_id'      => $user_id,
            'service_slug' => $service_slug,
            'service_name' => $service_name,
            'status'       => 'pending',
            'notes'        => $notes,
            'meta'         => wp_json_encode( [
                'user_email' => wp_get_current_user()->user_email,
            ] ),
            'created_at'   => $now,
            'updated_at'   => $now,
        ] );

        if ( ! $inserted ) {
            wp_send_json_error( [ 'message' => __( 'Could not submit your request. Please try again.', 'authorwings-membership' ) ] );
        }

        // Notify admin
        do_action( 'awg_mem_service_ordered', $wpdb->insert_id, $user_id, $service_slug );

        wp_send_json_success( [
            'message' => __( 'Your request has been submitted! We will get back to you within 24 hours.', 'authorwings-membership' ),
        ] );
    }
}
