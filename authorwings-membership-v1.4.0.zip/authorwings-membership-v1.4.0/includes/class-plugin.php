<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Plugin {

    private static $instance = null;

    /** @var Database */
    public $db;
    /** @var Roles */
    public $roles;
    /** @var Plans */
    public $plans;
    /** @var Memberships */
    public $memberships;
    /** @var Usage */
    public $usage;
    /** @var Dashboard */
    public $dashboard;
    /** @var Services */
    public $services;
    /** @var Admin */
    public $admin;
    /** @var Emails */
    public $emails;
    /** @var AI_Gate */
    public $ai_gate;
    /** @var Assets */
    public $assets;

    // Option / table name constants
    public const OPT          = 'awg_mem_settings';
    public const TABLE_PLANS  = 'awg_mem_plans';
    public const TABLE_MEMS   = 'awg_mem_memberships';
    public const TABLE_USAGE  = 'awg_mem_usage';
    public const TABLE_ORDERS = 'awg_mem_service_orders';

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function activate(): void {
        require_once AWG_MEM_PATH . 'includes/class-database.php';
        require_once AWG_MEM_PATH . 'includes/class-roles.php';
        require_once AWG_MEM_PATH . 'includes/class-plans.php';

        Database::create_tables();
        Roles::register();
        Plans::seed_defaults();

        // Create dashboard page if it doesn't exist
        self::create_dashboard_page();

        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    private static function create_dashboard_page(): void {
        $existing = get_page_by_path( 'member-dashboard' );
        if ( $existing ) {
            return;
        }
        wp_insert_post( [
            'post_title'   => 'Member Dashboard',
            'post_name'    => 'member-dashboard',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[awg_dashboard]',
        ] );
    }

    private function __construct() {
        $this->includes();
        add_action( 'init', [ $this, 'load_textdomain' ] );
        $this->boot_modules();
    }

    private function includes(): void {
        require_once AWG_MEM_PATH . 'includes/class-database.php';
        require_once AWG_MEM_PATH . 'includes/class-roles.php';
        require_once AWG_MEM_PATH . 'includes/class-plans.php';
        require_once AWG_MEM_PATH . 'includes/class-memberships.php';
        require_once AWG_MEM_PATH . 'includes/class-usage.php';
        require_once AWG_MEM_PATH . 'includes/class-ai-gate.php';
        require_once AWG_MEM_PATH . 'includes/class-services.php';
        require_once AWG_MEM_PATH . 'includes/class-dashboard.php';
        require_once AWG_MEM_PATH . 'includes/class-admin.php';
        require_once AWG_MEM_PATH . 'includes/class-emails.php';
        require_once AWG_MEM_PATH . 'includes/class-assets.php';
    }

    private function boot_modules(): void {
        $this->db          = new Database();
        $this->roles       = new Roles();
        $this->plans       = new Plans();
        $this->memberships = new Memberships();
        $this->usage       = new Usage();
        $this->ai_gate     = new AI_Gate( $this->memberships, $this->usage );
        $this->services    = new Services();
        $this->dashboard   = new Dashboard( $this->memberships, $this->usage, $this->plans );
        $this->admin       = new Admin( $this->memberships, $this->plans, $this->usage );
        $this->emails      = new Emails();
        $this->assets      = new Assets();

        // Services CPT — must register on every request so WP knows the post type
        add_action( 'init', [ $this->services, 'register_cpt' ] );

        // NOTE: Roles are NOT re-registered on init.
        // add_role() is called once during plugin activation (Plugin::activate()).
        // WordPress stores roles in the database (wp_options → wp_user_roles).
        // Re-calling add_role() on every page load is wasteful — WP checks
        // if the role exists before inserting, but it still hits the DB each time.
        // If roles are ever missing (e.g. after a DB restore), deactivate and
        // reactivate the plugin to re-seed them.

        // Shortcodes
        add_shortcode( 'awg_dashboard', [ $this->dashboard, 'render' ] );
        add_shortcode( 'awg_pricing',   [ $this->plans,     'render_pricing_page' ] );

        // AJAX handlers — dashboard
        add_action( 'wp_ajax_awg_mem_get_dashboard',    [ $this->dashboard,   'ajax_get_data' ] );
        add_action( 'wp_ajax_awg_mem_get_tool_html',    [ $this->dashboard,   'ajax_get_tool_html' ] );
        add_action( 'wp_ajax_awg_mem_upgrade_plan',     [ $this->memberships, 'ajax_upgrade' ] );
        add_action( 'wp_ajax_awg_mem_cancel_plan',      [ $this->memberships, 'ajax_cancel' ] );
        add_action( 'wp_ajax_awg_mem_submit_order',     [ $this->services,    'ajax_submit_order' ] );
        add_action( 'wp_ajax_awg_mem_get_history',      [ $this->dashboard,   'ajax_get_history' ] );

        // Admin menu
        add_action( 'admin_menu', [ $this->admin, 'menu' ] );
        add_action( 'admin_init', [ $this->admin, 'register_settings' ] );

        // Admin AJAX
        add_action( 'wp_ajax_awg_mem_admin_assign_plan',  [ $this->admin, 'ajax_assign_plan' ] );
        add_action( 'wp_ajax_awg_mem_admin_get_stats',    [ $this->admin, 'ajax_get_stats' ] );

        // Assets
        add_action( 'wp_enqueue_scripts',    [ $this->assets, 'frontend' ] );
        add_action( 'admin_enqueue_scripts', [ $this->assets, 'admin' ] );

        // Auto-assign free plan on registration
        add_action( 'user_register', [ $this->memberships, 'on_register' ] );

        // Daily cron: check expiries
        add_action( 'awg_mem_daily_cron', [ $this->memberships, 'check_expiries' ] );
        if ( ! wp_next_scheduled( 'awg_mem_daily_cron' ) ) {
            wp_schedule_event( time(), 'daily', 'awg_mem_daily_cron' );
        }

        // Hook into AuthorWings AI plugin (if active)
        $this->ai_gate->register_hooks();
    }

    private function __clone() {}
    public function __wakeup() {}

    public function load_textdomain(): void {
        load_plugin_textdomain(
            'authorwings-membership',
            false,
            dirname( plugin_basename( AWG_MEM_FILE ) ) . '/languages'
        );
    }
}
