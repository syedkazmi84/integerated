<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Usage {

    /**
     * Current billing period string: YYYY-MM
     */
    public static function current_period(): string {
        return gmdate( 'Y-m' );
    }

    /**
     * Get usage count for a user + service in the current period.
     */
    public function get( int $user_id, string $service_slug ): int {
        global $wpdb;
        $table  = Database::usage_table();
        $period = self::current_period();
        $count  = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT used FROM {$table} WHERE user_id = %d AND service_slug = %s AND period = %s",
                $user_id, $service_slug, $period
            )
        );
        return (int) $count;
    }

    /**
     * Increment usage by 1 for a user + service.
     */
    public function increment( int $user_id, string $service_slug ): void {
        global $wpdb;
        $table  = Database::usage_table();
        $period = self::current_period();
        $now    = current_time( 'mysql' );

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$table} (user_id, service_slug, period, used, updated_at)
                 VALUES (%d, %s, %s, 1, %s)
                 ON DUPLICATE KEY UPDATE used = used + 1, updated_at = %s",
                $user_id, $service_slug, $period, $now, $now
            )
        );
    }

    /**
     * Get all usage for a user in the current period (keyed by service_slug).
     */
    public function get_all_for_user( int $user_id ): array {
        global $wpdb;
        $table  = Database::usage_table();
        $period = self::current_period();
        $rows   = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT service_slug, used FROM {$table} WHERE user_id = %d AND period = %s",
                $user_id, $period
            ),
            ARRAY_A
        );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $out[ $row['service_slug'] ] = (int) $row['used'];
        }
        return $out;
    }

    /**
     * Check whether a user can still use a service (returns true if allowed).
     */
    public function can_use( int $user_id, string $service_slug, int $limit ): bool {
        if ( $limit < 0 ) {
            return true; // unlimited
        }
        return $this->get( $user_id, $service_slug ) < $limit;
    }
}
