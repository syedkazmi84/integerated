<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Dashboard {

    /** @var Memberships */
    private $memberships;

    /** @var Usage */
    private $usage;

    /** @var Plans */
    private $plans;

    public function __construct( Memberships $memberships, Usage $usage, Plans $plans ) {
        $this->memberships = $memberships;
        $this->usage       = $usage;
        $this->plans       = $plans;
    }

    /**
     * Render [awg_dashboard] shortcode.
     */
    public function render( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return $this->render_login_prompt();
        }

        $user    = wp_get_current_user();
        $user_id = $user->ID;
        $mem     = $this->memberships->get_user_membership( $user_id );
        $limits  = $this->memberships->get_user_limits( $user_id );
        $usage   = $this->usage->get_all_for_user( $user_id );
        $plans   = $this->plans->get_all();
        $plan_slug = $this->memberships->get_user_plan_slug( $user_id );

        $ai_limit = (int) ( $limits['ai_generations_per_month'] ?? 10 );
        $ai_used  = (int) ( $usage['ai_generation'] ?? 0 );

        ob_start();
        ?>
        <div class="awg-mem-dashboard" id="awg-dashboard"
             data-nonce="<?php echo esc_attr( wp_create_nonce( 'awg_mem_nonce' ) ); ?>"
             data-user-id="<?php echo esc_attr( $user_id ); ?>"
             data-plan="<?php echo esc_attr( $plan_slug ); ?>">

            <!-- Top bar -->
            <div class="awg-mem-topbar">
                <div class="awg-mem-topbar__left">
                    <div class="awg-mem-avatar">
                        <?php echo get_avatar( $user_id, 40 ); ?>
                    </div>
                    <div>
                        <div class="awg-mem-topbar__name">
                            <?php echo esc_html( $user->display_name ); ?>
                        </div>
                        <div class="awg-mem-topbar__plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?>">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?> <?php esc_html_e( 'Plan', 'authorwings-membership' ); ?>
                        </div>
                    </div>
                </div>
                <?php if ( $plan_slug === 'free' || $plan_slug === 'basic' ) : ?>
                    <a href="#account" class="awg-mem-btn awg-mem-btn--primary awg-mem-tab-link" data-tab="account">
                        <?php esc_html_e( 'Upgrade Plan', 'authorwings-membership' ); ?>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Tab nav -->
            <nav class="awg-mem-tabs">
                <button class="awg-mem-tab awg-mem-tab--active" data-tab="home">
                    <?php esc_html_e( 'Home', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="tools">
                    <?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?>
                </button>
                <button class="awg-mem-tab" data-tab="services">
                    <?php esc_html_e( 'Services', 'authorwings-membership' ); ?>
                </button>
                <?php if ( current_user_can( 'awg_view_history' ) ) : ?>
                    <button class="awg-mem-tab" data-tab="history">
                        <?php esc_html_e( 'History', 'authorwings-membership' ); ?>
                    </button>
                <?php endif; ?>
                <button class="awg-mem-tab" data-tab="account">
                    <?php esc_html_e( 'Account', 'authorwings-membership' ); ?>
                </button>
            </nav>

            <!-- HOME TAB -->
            <div class="awg-mem-panel awg-mem-panel--active" data-panel="home">

                <!-- Usage meters -->
                <div class="awg-mem-usage-grid">
                    <div class="awg-mem-usage-card">
                        <?php
                        $pct = ( $ai_limit > 0 ) ? min( 100, round( $ai_used / $ai_limit * 100 ) ) : 0;
                        $color = $pct >= 90 ? '#E24B4A' : ( $pct >= 70 ? '#EF9F27' : '#1D9E75' );
                        ?>
                        <div class="awg-mem-usage-card__title">
                            <?php esc_html_e( 'AI Generations', 'authorwings-membership' ); ?>
                        </div>
                        <div class="awg-mem-usage-donut">
                            <svg viewBox="0 0 64 64" width="64" height="64">
                                <circle cx="32" cy="32" r="26" fill="none" stroke="#e5e7eb" stroke-width="8"/>
                                <circle cx="32" cy="32" r="26" fill="none"
                                    stroke="<?php echo esc_attr( $color ); ?>"
                                    stroke-width="8"
                                    stroke-dasharray="<?php echo esc_attr( $ai_limit < 0 ? 163 : round( $pct * 1.63 ) ); ?> 163"
                                    stroke-linecap="round"
                                    transform="rotate(-90 32 32)"/>
                            </svg>
                            <span class="awg-mem-usage-donut__label">
                                <?php if ( $ai_limit < 0 ) : ?>
                                    ∞
                                <?php else : ?>
                                    <?php echo esc_html( $ai_used . '/' . $ai_limit ); ?>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="awg-mem-usage-card__sub">
                            <?php if ( $ai_limit < 0 ) : ?>
                                <?php esc_html_e( 'Unlimited', 'authorwings-membership' ); ?>
                            <?php else : ?>
                                <?php echo esc_html( $ai_limit - $ai_used ); ?>
                                <?php esc_html_e( 'remaining this month', 'authorwings-membership' ); ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Plan info card -->
                    <div class="awg-mem-usage-card awg-mem-usage-card--plan">
                        <div class="awg-mem-usage-card__title"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                        <div class="awg-mem-plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?> awg-mem-plan-badge--lg">
                            <?php echo esc_html( ucfirst( $plan_slug ) ); ?>
                        </div>
                        <?php if ( $mem && ! empty( $mem['end_date'] ) && $mem['is_free'] != 1 ) : ?>
                            <div class="awg-mem-usage-card__sub">
                                <?php
                                printf(
                                    /* translators: %s: renewal date */
                                    esc_html__( 'Renews %s', 'authorwings-membership' ),
                                    esc_html( wp_date( get_option( 'date_format' ), strtotime( $mem['end_date'] ) ) )
                                );
                                ?>
                            </div>
                        <?php endif; ?>
                        <a href="#account" class="awg-mem-tab-link awg-mem-link" data-tab="account">
                            <?php esc_html_e( 'Manage plan →', 'authorwings-membership' ); ?>
                        </a>
                    </div>
                </div>

                <!-- Quick actions -->
                <h3 class="awg-mem-section-title"><?php esc_html_e( 'Quick Actions', 'authorwings-membership' ); ?></h3>
                <div class="awg-mem-quick-grid">
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="tools">
                        <span class="dashicons dashicons-lightbulb"></span>
                        <span><?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?></span>
                    </button>
                    <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="services">
                        <span class="dashicons dashicons-book-alt"></span>
                        <span><?php esc_html_e( 'Services', 'authorwings-membership' ); ?></span>
                    </button>
                    <?php if ( current_user_can( 'awg_view_history' ) ) : ?>
                        <button class="awg-mem-quick-card awg-mem-tab-link" data-tab="history">
                            <span class="dashicons dashicons-list-view"></span>
                            <span><?php esc_html_e( 'My History', 'authorwings-membership' ); ?></span>
                        </button>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( home_url( '/publishing-guides/' ) ); ?>" class="awg-mem-quick-card">
                        <span class="dashicons dashicons-media-document"></span>
                        <span><?php esc_html_e( 'Guides', 'authorwings-membership' ); ?></span>
                    </a>
                </div>
            </div>

            <!-- TOOLS TAB -->
            <div class="awg-mem-panel" data-panel="tools">
                <?php $this->render_tools_panel( $plan_slug, $ai_limit, $ai_used ); ?>
            </div>

            <!-- SERVICES TAB -->
            <div class="awg-mem-panel" data-panel="services">
                <?php $this->render_services_panel( $plan_slug ); ?>
            </div>

            <!-- HISTORY TAB -->
            <?php if ( current_user_can( 'awg_view_history' ) ) : ?>
                <div class="awg-mem-panel" data-panel="history">
                    <?php $this->render_history_panel( $user_id ); ?>
                </div>
            <?php endif; ?>

            <!-- ACCOUNT TAB -->
            <div class="awg-mem-panel" data-panel="account">
                <?php $this->render_account_panel( $user, $mem, $plan_slug, $plans ); ?>
            </div>

        </div><!-- /.awg-mem-dashboard -->
        <?php
        return ob_get_clean();
    }

    // -------------------------------------------------------
    // Panel renderers
    // -------------------------------------------------------

    private function render_tools_panel( string $plan_slug, int $ai_limit, int $ai_used ): void {
        $tools = $this->get_tool_definitions();
        $plan_level = Roles::level( $this->plan_slug_to_role( $plan_slug ) );

        // Group by category
        $grouped = [];
        foreach ( $tools as $tool ) {
            $grouped[ $tool['category'] ][] = $tool;
        }
        ?>
        <div class="awg-mem-tools-header">
            <div>
                <h2><?php esc_html_e( 'AI Tools', 'authorwings-membership' ); ?></h2>
                <p class="awg-mem-muted">
                    <?php if ( $ai_limit < 0 ) : ?>
                        <?php esc_html_e( 'Unlimited generations available', 'authorwings-membership' ); ?>
                    <?php else : ?>
                        <?php echo esc_html( $ai_used ); ?> / <?php echo esc_html( $ai_limit ); ?>
                        <?php esc_html_e( 'generations used this month', 'authorwings-membership' ); ?>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <?php foreach ( $grouped as $category => $cat_tools ) : ?>
            <h3 class="awg-mem-section-title"><?php echo esc_html( $category ); ?></h3>
            <div class="awg-mem-tools-grid">
                <?php foreach ( $cat_tools as $tool ) :
                    $required_level = Roles::level( $this->plan_slug_to_role( $tool['plan'] ) );
                    $locked         = $plan_level < $required_level;
                    $has_template   = ! empty( $tool['template_id'] );
                    ?>
                    <div class="awg-mem-tool-card<?php echo $locked ? ' awg-mem-tool-card--locked' : ''; ?>"
                         <?php if ( ! $locked && $has_template ) : ?>
                             data-template-id="<?php echo esc_attr( $tool['template_id'] ); ?>"
                         <?php endif; ?>>
                        <div class="awg-mem-tool-card__icon">
                            <span class="dashicons <?php echo esc_attr( $tool['icon'] ); ?>"></span>
                        </div>
                        <div class="awg-mem-tool-card__body">
                            <div class="awg-mem-tool-card__title"><?php echo esc_html( $tool['name'] ); ?></div>
                            <div class="awg-mem-tool-card__desc"><?php echo esc_html( $tool['description'] ); ?></div>
                            <?php if ( $locked ) : ?>
                                <div class="awg-mem-tool-card__lock">
                                    <span class="dashicons dashicons-lock"></span>
                                    <?php
                                    printf(
                                        /* translators: %s: plan name */
                                        esc_html__( 'Requires %s plan', 'authorwings-membership' ),
                                        esc_html( ucfirst( $tool['plan'] ) )
                                    );
                                    ?>
                                    — <a href="#account" class="awg-mem-tab-link" data-tab="account">
                                        <?php esc_html_e( 'Upgrade', 'authorwings-membership' ); ?>
                                    </a>
                                </div>
                            <?php elseif ( $has_template ) : ?>
                                <button class="awg-mem-btn awg-mem-btn--sm awg-mem-open-tool"
                                        data-template-id="<?php echo esc_attr( $tool['template_id'] ); ?>">
                                    <?php esc_html_e( 'Use Tool', 'authorwings-membership' ); ?>
                                </button>
                            <?php else : ?>
                                <span class="awg-mem-coming-soon"><?php esc_html_e( 'Coming soon', 'authorwings-membership' ); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>

        <!-- Tool modal — opened by JS when user clicks "Use Tool" -->
        <!-- hoistModalsToBody() in dashboard.js moves this to <body> on init -->
        <div class="awg-mem-modal" id="awg-tool-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box">
                <div class="awg-mem-modal__header">
                    <h3 class="awg-mem-modal__title"></h3>
                    <button class="awg-mem-modal__close" id="awg-tool-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div class="awg-mem-modal__content" id="awg-tool-modal-content">
                    <!-- Generator HTML loaded here via AJAX -->
                </div>
            </div>
        </div>
        <?php
    }

    private function render_services_panel( string $plan_slug ): void {
        $services = new Services();
        $all      = $services->get_all();

        if ( empty( $all ) ) {
            echo '<p class="awg-mem-muted">' . esc_html__( 'No services available yet. Check back soon.', 'authorwings-membership' ) . '</p>';
            return;
        }

        // Group by category
        $grouped = [];
        foreach ( $all as $svc ) {
            $grouped[ $svc['category'] ][] = $svc;
        }
        ?>
        <h2><?php esc_html_e( 'Publishing Services', 'authorwings-membership' ); ?></h2>
        <p class="awg-mem-muted"><?php esc_html_e( 'Browse our professional book publishing services. Submit a request and we\'ll get back to you within 24 hours.', 'authorwings-membership' ); ?></p>

        <?php foreach ( $grouped as $category => $svcs ) : ?>
            <h3 class="awg-mem-section-title"><?php echo esc_html( ucfirst( $category ) ); ?></h3>
            <div class="awg-mem-services-grid">
                <?php foreach ( $svcs as $svc ) : ?>
                    <div class="awg-mem-service-card">
                        <div class="awg-mem-service-card__icon">
                            <span class="dashicons <?php echo esc_attr( $svc['icon'] ); ?>"></span>
                        </div>
                        <div class="awg-mem-service-card__body">
                            <div class="awg-mem-service-card__title"><?php echo esc_html( $svc['title'] ); ?></div>
                            <div class="awg-mem-service-card__desc"><?php echo esc_html( $svc['description'] ); ?></div>
                            <?php if ( $svc['price_from'] ) : ?>
                                <div class="awg-mem-service-card__price">
                                    <?php esc_html_e( 'From', 'authorwings-membership' ); ?>
                                    <?php echo esc_html( $svc['price_from'] ); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ( $svc['turnaround'] ) : ?>
                                <div class="awg-mem-service-card__turnaround">
                                    <?php echo esc_html( $svc['turnaround'] ); ?>
                                </div>
                            <?php endif; ?>
                            <button class="awg-mem-btn awg-mem-btn--sm awg-mem-request-service"
                                    data-slug="<?php echo esc_attr( $svc['slug'] ); ?>"
                                    data-name="<?php echo esc_attr( $svc['title'] ); ?>">
                                <?php esc_html_e( 'Request Quote', 'authorwings-membership' ); ?>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>

        <!-- Service order modal -->
        <div class="awg-mem-modal" id="awg-service-modal">
            <div class="awg-mem-modal__backdrop"></div>
            <div class="awg-mem-modal__box awg-mem-modal__box--sm">
                <div class="awg-mem-modal__header">
                    <h3 class="awg-mem-modal__title" id="awg-service-modal-title"><?php esc_html_e( 'Request Service', 'authorwings-membership' ); ?></h3>
                    <button class="awg-mem-modal__close" id="awg-service-modal-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-membership' ); ?>">&times;</button>
                </div>
                <div id="awg-service-modal-msg" class="awg-mem-alert" style="display:none;"></div>
                <div id="awg-service-form-wrap">
                    <p class="awg-mem-muted"><?php esc_html_e( 'Tell us about your project and we\'ll prepare a personalised quote.', 'authorwings-membership' ); ?></p>
                    <textarea id="awg-service-notes" class="awg-mem-textarea" rows="5"
                              placeholder="<?php esc_attr_e( 'Describe your book, genre, word count, and any specific requirements...', 'authorwings-membership' ); ?>"></textarea>
                    <button class="awg-mem-btn awg-mem-btn--primary" id="awg-service-submit">
                        <?php esc_html_e( 'Submit Request', 'authorwings-membership' ); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    private function render_history_panel( int $user_id ): void {
        // Query the existing AI submission CPT from the AI plugin
        $submissions = get_posts( [
            'post_type'      => 'awg_ai_submission',
            'post_status'    => 'publish',
            'author'         => $user_id,
            'posts_per_page' => 20,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ] );
        ?>
        <h2><?php esc_html_e( 'My Generation History', 'authorwings-membership' ); ?></h2>

        <?php if ( empty( $submissions ) ) : ?>
            <p class="awg-mem-muted">
                <?php esc_html_e( 'No generations yet. Head to AI Tools to get started.', 'authorwings-membership' ); ?>
            </p>
        <?php else : ?>
            <div class="awg-mem-history-list">
                <?php foreach ( $submissions as $sub ) :
                    $template_id = (int) get_post_meta( $sub->ID, '_awg_aig_template_id', true );
                    $template    = $template_id ? get_post( $template_id ) : null;
                    $output      = (string) get_post_meta( $sub->ID, '_awg_aig_output', true );
                    $model       = (string) get_post_meta( $sub->ID, '_awg_aig_model',  true );
                    ?>
                    <div class="awg-mem-history-item">
                        <div class="awg-mem-history-item__header">
                            <span class="awg-mem-history-item__tool">
                                <?php echo $template ? esc_html( $template->post_title ) : esc_html__( 'AI Tool', 'authorwings-membership' ); ?>
                            </span>
                            <span class="awg-mem-history-item__date">
                                <?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sub->post_date ) ) ); ?>
                            </span>
                            <?php if ( $model ) : ?>
                                <span class="awg-mem-badge"><?php echo esc_html( $model ); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ( $output ) : ?>
                            <div class="awg-mem-history-item__output">
                                <pre><?php echo esc_html( wp_trim_words( $output, 40 ) ); ?></pre>
                                <button class="awg-mem-btn awg-mem-btn--xs awg-mem-copy-btn"
                                        data-copy="<?php echo esc_attr( $output ); ?>">
                                    <?php esc_html_e( 'Copy', 'authorwings-membership' ); ?>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php
    }

    private function render_account_panel( \WP_User $user, ?array $mem, string $plan_slug, array $plans ): void {
        ?>
        <h2><?php esc_html_e( 'Account & Plan', 'authorwings-membership' ); ?></h2>

        <!-- Current plan summary -->
        <div class="awg-mem-account-card">
            <div class="awg-mem-account-card__label"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
            <div class="awg-mem-plan-badge awg-mem-plan-<?php echo esc_attr( $plan_slug ); ?> awg-mem-plan-badge--lg">
                <?php echo esc_html( ucfirst( $plan_slug ) ); ?>
            </div>
            <?php if ( $mem && ! empty( $mem['end_date'] ) && $mem['is_free'] != 1 ) : ?>
                <div class="awg-mem-account-card__meta">
                    <?php
                    printf(
                        esc_html__( 'Next renewal: %s', 'authorwings-membership' ),
                        esc_html( wp_date( get_option( 'date_format' ), strtotime( $mem['end_date'] ) ) )
                    );
                    ?>
                </div>
                <button class="awg-mem-btn awg-mem-btn--danger-outline awg-mem-cancel-plan">
                    <?php esc_html_e( 'Cancel Membership', 'authorwings-membership' ); ?>
                </button>
            <?php endif; ?>
        </div>

        <!-- Plan comparison + upgrade -->
        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Available Plans', 'authorwings-membership' ); ?></h3>
        <div class="awg-mem-plans-grid">
            <?php foreach ( $plans as $plan ) :
                $is_current = $plan['slug'] === $plan_slug;
                $is_popular = $plan['slug'] === 'pro';
                $monthly    = (float) $plan['price_monthly'];
                $is_free    = (bool) $plan['is_free'];
            ?>
                <div class="awg-mem-plan-card<?php echo $is_popular ? ' awg-mem-plan-card--popular' : ''; ?><?php echo $is_current ? ' awg-mem-plan-card--current' : ''; ?>">
                    <?php if ( $is_popular ) : ?>
                        <div class="awg-mem-plan-card__badge"><?php esc_html_e( 'Most Popular', 'authorwings-membership' ); ?></div>
                    <?php endif; ?>
                    <div class="awg-mem-plan-card__name"><?php echo esc_html( $plan['name'] ); ?></div>
                    <div class="awg-mem-plan-card__price">
                        <?php if ( $is_free ) : ?>
                            <?php esc_html_e( 'Free', 'authorwings-membership' ); ?>
                        <?php else : ?>
                            $<?php echo esc_html( number_format( $monthly, 0 ) ); ?>/<?php esc_html_e( 'mo', 'authorwings-membership' ); ?>
                        <?php endif; ?>
                    </div>
                    <ul class="awg-mem-plan-card__features">
                        <?php foreach ( array_slice( (array) $plan['features'], 0, 5 ) as $feat ) : ?>
                            <li><?php echo esc_html( $feat ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ( $is_current ) : ?>
                        <div class="awg-mem-plan-card__current-label"><?php esc_html_e( 'Current Plan', 'authorwings-membership' ); ?></div>
                    <?php else : ?>
                        <button class="awg-mem-btn awg-mem-btn--primary awg-mem-select-plan<?php echo $is_popular ? ' awg-mem-btn--full' : ''; ?>"
                                data-plan="<?php echo esc_attr( $plan['slug'] ); ?>"
                                data-billing="monthly">
                            <?php echo $is_free
                                ? esc_html__( 'Downgrade to Free', 'authorwings-membership' )
                                : esc_html__( 'Select Plan', 'authorwings-membership' ); ?>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Profile info -->
        <h3 class="awg-mem-section-title"><?php esc_html_e( 'Your Info', 'authorwings-membership' ); ?></h3>
        <table class="awg-mem-info-table">
            <tr>
                <td><?php esc_html_e( 'Name', 'authorwings-membership' ); ?></td>
                <td><?php echo esc_html( $user->display_name ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Email', 'authorwings-membership' ); ?></td>
                <td><?php echo esc_html( $user->user_email ); ?></td>
            </tr>
            <tr>
                <td><?php esc_html_e( 'Member since', 'authorwings-membership' ); ?></td>
                <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $user->user_registered ) ) ); ?></td>
            </tr>
        </table>
        <a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>" class="awg-mem-link">
            <?php esc_html_e( 'Edit profile →', 'authorwings-membership' ); ?>
        </a>
        <?php
    }

    private function render_login_prompt(): string {
        ob_start();
        ?>
        <div class="awg-mem-login-prompt">
            <span class="dashicons dashicons-lock"></span>
            <h2><?php esc_html_e( 'Please log in to access your dashboard', 'authorwings-membership' ); ?></h2>
            <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="awg-mem-btn awg-mem-btn--primary">
                <?php esc_html_e( 'Log In', 'authorwings-membership' ); ?>
            </a>
            <p>
                <?php esc_html_e( 'Don\'t have an account?', 'authorwings-membership' ); ?>
                <a href="<?php echo esc_url( wp_registration_url() ); ?>">
                    <?php esc_html_e( 'Register free', 'authorwings-membership' ); ?>
                </a>
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

    // -------------------------------------------------------
    // AJAX handlers
    // -------------------------------------------------------

    /**
     * AJAX: render the [awg_generator id="X"] shortcode server-side
     * and return the HTML so the tool modal can display it.
     *
     * Also signals the AI plugin's Assets class to enqueue its
     * front-end scripts/styles on this request via the
     * awg_aig_enqueue_assets filter (picked up by wp_footer).
     */
    public function ajax_get_tool_html(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }

        $template_id = (int) ( $_POST['template_id'] ?? 0 );
        if ( $template_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Invalid tool.', 'authorwings-membership' ) ], 400 );
        }

        // Verify the template exists and is an AI plugin template
        $post = get_post( $template_id );
        if ( ! $post || $post->post_type !== 'awg_ai_template' || $post->post_status !== 'publish' ) {
            wp_send_json_error( [ 'message' => __( 'Tool not found.', 'authorwings-membership' ) ], 404 );
        }

        // Check user's plan allows this template
        $user_id       = get_current_user_id();
        $plan_slug     = $this->memberships->get_user_plan_slug( $user_id );
        $plan_level    = Roles::level( $this->plan_slug_to_role( $plan_slug ) );
        $required_plan = get_post_meta( $template_id, '_awg_mem_required_plan', true ) ?: 'free';
        $required_level = Roles::level( $this->plan_slug_to_role( $required_plan ) );

        if ( $plan_level < $required_level ) {
            wp_send_json_error( [
                'message' => sprintf(
                    __( 'This tool requires the %s plan.', 'authorwings-membership' ),
                    ucfirst( $required_plan )
                ),
            ], 403 );
        }

        // Render shortcode — the AI plugin's Renderer::shortcode() handles this
        $html = do_shortcode( '[awg_generator id="' . $template_id . '"]' );

        if ( empty( trim( $html ) ) ) {
            wp_send_json_error( [ 'message' => __( 'Could not render tool. Is the AuthorWings AI plugin active?', 'authorwings-membership' ) ] );
        }

        // Return the rendered HTML plus any inline scripts the AI plugin needs
        // front.js is already enqueued on the page (via awg_aig_enqueue_assets filter
        // in class-assets.php), so we only need to return the form HTML.
        wp_send_json_success( [
            'html'        => $html,
            'template_id' => $template_id,
            'title'       => get_the_title( $template_id ),
        ] );
    }

    public function ajax_get_data(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 401 );
        }
        $user_id  = get_current_user_id();
        $limits   = $this->memberships->get_user_limits( $user_id );
        $usage    = $this->usage->get_all_for_user( $user_id );
        $plan     = $this->memberships->get_user_plan_slug( $user_id );
        wp_send_json_success( compact( 'limits', 'usage', 'plan' ) );
    }

    public function ajax_get_history(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 401 );
        }
        // Handled server-side in render — this is for JS pagination
        $user_id  = get_current_user_id();
        $page     = max( 1, (int) ( $_POST['page'] ?? 1 ) );
        $per_page = 20;

        $submissions = get_posts( [
            'post_type'      => 'awg_ai_submission',
            'post_status'    => 'publish',
            'author'         => $user_id,
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ] );

        $out = [];
        foreach ( $submissions as $sub ) {
            $template_id = (int) get_post_meta( $sub->ID, '_awg_aig_template_id', true );
            $template    = $template_id ? get_post( $template_id ) : null;
            $out[]       = [
                'id'       => $sub->ID,
                'tool'     => $template ? $template->post_title : 'AI Tool',
                'date'     => wp_date( 'Y-m-d H:i', strtotime( $sub->post_date ) ),
                'model'    => get_post_meta( $sub->ID, '_awg_aig_model', true ),
                'output'   => wp_trim_words( (string) get_post_meta( $sub->ID, '_awg_aig_output', true ), 40 ),
            ];
        }
        wp_send_json_success( [ 'items' => $out, 'page' => $page ] );
    }

    // -------------------------------------------------------
    // Helpers
    // -------------------------------------------------------

    private function plan_slug_to_role( string $slug ): string {
        $map = [
            'free'      => Roles::FREE,
            'basic'     => Roles::BASIC,
            'pro'       => Roles::PRO,
            'publisher' => Roles::PUBLISHER,
        ];
        return $map[ $slug ] ?? Roles::FREE;
    }

    /**
    /**
     * Fetch all published AI templates from the database and normalise them
     * into the shape render_tools_panel() expects.
     *
     * Reads from the awg_ai_template CPT (AuthorWings AI plugin).
     * Required plan stored as _awg_mem_required_plan post meta (set in AI plugin
     * template editor when membership plugin is active).
     * Category stored as _awg_mem_category post meta (optional — defaults to "AI Tools").
     */
    private function get_tool_definitions(): array {
        // AI plugin CPT must be registered
        if ( ! post_type_exists( 'awg_ai_template' ) ) {
            return [];
        }

        $posts = get_posts( [
            'post_type'      => 'awg_ai_template',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order title',
            'order'          => 'ASC',
            'no_found_rows'  => true,
        ] );

        if ( empty( $posts ) ) {
            return [];
        }

        $tools = [];

        foreach ( $posts as $post ) {
            // Read the AI plugin meta blob (_awg_aig_template stores all settings)
            $meta = get_post_meta( $post->ID, '_awg_aig_template', true );
            if ( ! is_array( $meta ) ) {
                $meta = [];
            }

            // Required plan — set via the "Required Membership Plan" field
            // in the AI plugin template editor (added in v5.2.0).
            // Defaults to free so templates without the field are visible to all.
            $required_plan = get_post_meta( $post->ID, '_awg_mem_required_plan', true );
            if ( ! in_array( $required_plan, [ 'free', 'basic', 'pro', 'publisher' ], true ) ) {
                $required_plan = 'free';
            }

            // Name: use the template's form_title, fall back to WordPress post title
            $name = trim( (string) ( $meta['form_title'] ?? '' ) );
            if ( $name === '' ) {
                $name = get_the_title( $post->ID );
            }

            // Description: form_description from the template meta
            $description = trim( (string) ( $meta['form_description'] ?? '' ) );

            // Icon: title_icon_class set in template editor, defaults to lightbulb
            $icon = trim( (string) ( $meta['title_icon_class'] ?? '' ) );
            if ( $icon === '' ) {
                $icon = 'dashicons-lightbulb';
            }

            // Category: optional _awg_mem_category meta for grouping in dashboard.
            // Set it directly in wp-admin via Quick Edit or a custom field.
            // If empty, all templates appear under a single "AI Tools" group.
            $category = trim( (string) get_post_meta( $post->ID, '_awg_mem_category', true ) );
            if ( $category === '' ) {
                $category = __( 'AI Tools', 'authorwings-membership' );
            }

            $tools[] = [
                'template_id' => $post->ID,
                'name'        => $name,
                'description' => $description,
                'icon'        => $icon,
                'plan'        => $required_plan,
                'category'    => $category,
            ];
        }

        return $tools;
    }
}
