<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function frontend(): void {
        global $post;
        $has_dashboard = is_a( $post, 'WP_Post' ) && (
            has_shortcode( $post->post_content, 'awg_dashboard' ) ||
            has_shortcode( $post->post_content, 'awg_pricing' )
        );

        if ( ! $has_dashboard ) { return; }

        // ── Membership plugin assets ────────────────────────
        wp_enqueue_style(
            'awg-mem-front',
            AWG_MEM_URL . 'assets/css/dashboard.css',
            [ 'dashicons' ],
            AWG_MEM_VERSION
        );

        wp_enqueue_script(
            'awg-mem-front',
            AWG_MEM_URL . 'assets/js/dashboard.js',
            [ 'jquery' ],
            AWG_MEM_VERSION,
            true
        );

        wp_localize_script( 'awg-mem-front', 'AWG_MEM', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'awg_mem_nonce' ),
            'strings'  => [
                'confirm_cancel'  => __( 'Are you sure you want to cancel your membership? You will be moved to the free plan.', 'authorwings-membership' ),
                'upgrading'       => __( 'Processing…', 'authorwings-membership' ),
                'copied'          => __( 'Copied!', 'authorwings-membership' ),
                'submitting'      => __( 'Submitting…', 'authorwings-membership' ),
                'error_generic'   => __( 'Something went wrong. Please try again.', 'authorwings-membership' ),
                'tool_loading'    => __( 'Loading tool…', 'authorwings-membership' ),
                'tool_error'      => __( 'Could not load tool. Please try again.', 'authorwings-membership' ),
            ],
        ] );

        // ── Force-load AI plugin front assets on dashboard ──
        // The AI plugin's Assets::maybe_enqueue_front_assets() only loads
        // when it detects [awg_generator] in page content. The dashboard
        // uses [awg_dashboard], so we must signal the AI plugin manually.
        // The filter 'awg_aig_enqueue_assets' is checked by class-assets.php
        // in the AI plugin — returning true forces its front.js + front.css.
        add_filter( 'awg_aig_enqueue_assets', '__return_true' );

        // Fallback: if the AI plugin version doesn't have the filter yet,
        // enqueue its assets directly by calling its enqueue method.
        add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_ai_assets' ], 20 );
    }

    /**
     * Fallback: directly call the AI plugin's asset enqueue method
     * if the filter approach didn't work (older AI plugin version).
     * Runs at priority 20 — after the AI plugin's own priority-10 hook.
     */
    public function maybe_enqueue_ai_assets(): void {
        // Already enqueued via filter — nothing to do
        if ( wp_script_is( 'awg-aig-front', 'enqueued' ) ) {
            return;
        }

        // AI plugin is active — call its enqueue directly
        if ( class_exists( '\\AWG_AIG\\Assets' ) ) {
            $ai_assets = new \AWG_AIG\Assets();
            $ai_assets->enqueue_front_assets();
            return;
        }

        // Last resort: enqueue by known paths if AI plugin is active
        if ( defined( 'AWG_AIG_URL' ) && defined( 'AWG_AIG_VERSION' ) ) {
            wp_enqueue_style( 'dashicons' );
            wp_enqueue_style(
                'awg-aig-front',
                AWG_AIG_URL . 'assets/front.css',
                [],
                AWG_AIG_VERSION
            );
            wp_enqueue_script(
                'awg-aig-front',
                AWG_AIG_URL . 'assets/front.js',
                [ 'jquery' ],
                AWG_AIG_VERSION,
                true
            );
            wp_localize_script( 'awg-aig-front', 'AWG_AIG', [
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'awg_aig_nonce_front' ),
            ] );
        }
    }

    public function admin( string $hook ): void {
        if ( strpos( $hook, 'awg-membership' ) === false ) { return; }

        wp_enqueue_style(
            'awg-mem-admin',
            AWG_MEM_URL . 'assets/css/admin.css',
            [],
            AWG_MEM_VERSION
        );
    }
}
