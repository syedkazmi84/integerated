<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Memberships {

    /**
     * Get the active membership record for a user.
     */
    public function get_user_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d AND m.status IN ('active','trialing')
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    /**
     * Get plan limits for a user (decoded JSON).
     */
    public function get_user_limits( int $user_id ): array {
        $mem = $this->get_user_membership( $user_id );
        if ( ! $mem ) {
            // Default free limits
            return [
                'ai_generations_per_month' => 10,
                'tools_access'             => 'free',
            ];
        }
        return json_decode( $mem['limits'] ?? '{}', true ) ?: [];
    }

    /**
     * Get the plan slug for a user.
     */
    public function get_user_plan_slug( int $user_id ): string {
        $mem = $this->get_user_membership( $user_id );
        return $mem['plan_slug'] ?? 'free';
    }

    /**
     * Create or update a membership record for a user.
     */
    public function set_user_plan( int $user_id, int $plan_id, string $billing = 'monthly', string $stripe_sub_id = '', string $stripe_cust_id = '' ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        // Expire previous active memberships
        $wpdb->update(
            $table,
            [ 'status' => 'cancelled', 'updated_at' => $now ],
            [ 'user_id' => $user_id, 'status' => 'active' ]
        );

        // Calculate end_date:
        // - free plan  → NULL  (never expires — cron only cancels rows with end_date < now)
        // - yearly     → +1 year
        // - monthly    → +1 month
        if ( $billing === 'free' ) {
            $end_date = null;
        } elseif ( $billing === 'yearly' ) {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 year' ) );
        } else {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 month' ) );
        }

        // Insert new
        $inserted = $wpdb->insert( $table, [
            'user_id'               => $user_id,
            'plan_id'               => $plan_id,
            'status'                => 'active',
            'billing_cycle'         => $billing,
            'start_date'            => $now,
            'end_date'              => $end_date,
            'stripe_subscription_id'=> $stripe_sub_id,
            'stripe_customer_id'    => $stripe_cust_id,
            'created_at'            => $now,
            'updated_at'            => $now,
        ] );

        if ( $inserted ) {
            // Update WordPress role based on plan
            $ptable = Database::plans_table();
            $plan   = $wpdb->get_row(
                $wpdb->prepare( "SELECT slug FROM {$ptable} WHERE id = %d", $plan_id ),
                ARRAY_A
            );
            if ( $plan ) {
                $role_map = [
                    'free'      => Roles::FREE,
                    'basic'     => Roles::BASIC,
                    'pro'       => Roles::PRO,
                    'publisher' => Roles::PUBLISHER,
                ];
                $role = $role_map[ $plan['slug'] ] ?? Roles::FREE;
                Roles::set_user_role( $user_id, $role );
            }
            do_action( 'awg_mem_plan_changed', $user_id, $plan_id );
        }

        return (bool) $inserted;
    }

    /**
     * Cancel a user's active membership.
     */
    public function cancel_user_membership( int $user_id ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $updated = $wpdb->update(
            $table,
            [ 'status' => 'cancelled', 'updated_at' => $now ],
            [ 'user_id' => $user_id, 'status' => 'active' ]
        );

        if ( $updated ) {
            // Downgrade to free
            Roles::set_user_role( $user_id, Roles::FREE );
            do_action( 'awg_mem_cancelled', $user_id );
        }

        return (bool) $updated;
    }

    /**
     * Auto-assign free plan on new user registration.
     */
    public function on_register( int $user_id ): void {
        global $wpdb;
        $ptable  = Database::plans_table();
        $free_plan = $wpdb->get_row(
            "SELECT id FROM {$ptable} WHERE is_free = 1 AND is_active = 1 LIMIT 1",
            ARRAY_A
        );
        if ( $free_plan ) {
            $this->set_user_plan( $user_id, (int) $free_plan['id'], 'free' );
        } else {
            // Fallback: just set role
            Roles::set_user_role( $user_id, Roles::FREE );
        }
    }

    /**
     * Daily cron: expire memberships past their end_date.
     */
    public function check_expiries(): void {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $expired = $wpdb->get_results(
            "SELECT user_id FROM {$table}
             WHERE status = 'active' AND end_date IS NOT NULL AND end_date < '{$now}'",
            ARRAY_A
        );

        foreach ( (array) $expired as $row ) {
            $this->cancel_user_membership( (int) $row['user_id'] );
            do_action( 'awg_mem_expired', (int) $row['user_id'] );
        }
    }

    /**
     * AJAX: upgrade plan (redirect to payment — wire Stripe here).
     */
    public function ajax_upgrade(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }

        $plan_slug = sanitize_text_field( $_POST['plan'] ?? '' );
        $billing   = in_array( $_POST['billing'] ?? '', [ 'monthly', 'yearly' ], true )
                     ? sanitize_text_field( $_POST['billing'] )
                     : 'monthly';

        global $wpdb;
        $ptable = Database::plans_table();
        $plan   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$ptable} WHERE slug = %s AND is_active = 1 LIMIT 1", $plan_slug ),
            ARRAY_A
        );

        if ( ! $plan ) {
            wp_send_json_error( [ 'message' => __( 'Plan not found.', 'authorwings-membership' ) ] );
        }

        // If free plan, assign directly and stop — no payment needed
        if ( (bool) $plan['is_free'] ) {
            $this->set_user_plan( get_current_user_id(), (int) $plan['id'], 'free' );
            wp_send_json_success( [ 'message' => __( 'Plan updated.', 'authorwings-membership' ), 'redirect' => '' ] );
            return; // wp_send_json_success calls wp_die() but return is explicit safety net
        }

        // For paid plans: return Stripe checkout URL
        // Wire your Stripe integration here.
        $checkout_url = apply_filters( 'awg_mem_stripe_checkout_url', '', (int) $plan['id'], $billing, get_current_user_id() );

        if ( $checkout_url ) {
            wp_send_json_success( [ 'redirect' => $checkout_url ] );
        } else {
            // Fallback: direct upgrade without payment (dev/testing mode)
            $this->set_user_plan( get_current_user_id(), (int) $plan['id'], $billing );
            wp_send_json_success( [
                'message'  => __( 'Plan upgraded (no payment gateway configured).', 'authorwings-membership' ),
                'redirect' => '',
            ] );
        }
    }

    /**
     * AJAX: cancel membership.
     */
    public function ajax_cancel(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        $this->cancel_user_membership( get_current_user_id() );
        wp_send_json_success( [ 'message' => __( 'Membership cancelled.', 'authorwings-membership' ) ] );
    }
}
