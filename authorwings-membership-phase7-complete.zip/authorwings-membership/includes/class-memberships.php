<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Memberships {

    private const STRIPE_API_BASE = 'https://api.stripe.com/v1';

    public function get_current_user_membership(): ?array {
        return $this->get_effective_membership( get_current_user_id() );
    }

    public function get_current_user_plan_slug(): string {
        return $this->get_user_plan_slug( get_current_user_id() );
    }

    public function get_member_status( int $user_id ): string {
        $mem = $this->get_effective_membership( $user_id );
        return sanitize_key( (string) ( $mem['status'] ?? 'inactive' ) );
    }

    public function get_stripe_customer_id( int $user_id ): string {
        $mem = $this->get_latest_membership( $user_id );
        return sanitize_text_field( (string) ( $mem['stripe_customer_id'] ?? '' ) );
    }

    public function log_membership_action( string $event, array $context = [] ): void {
        Logger::log( $event, $context );
    }

    public function get_user_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d AND m.status IN ('active','trialing')
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    public function get_latest_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    public function get_effective_membership( int $user_id ): ?array {
        $owner_id = $this->get_workspace_owner_id( $user_id );
        return $this->get_user_membership( $owner_id );
    }

    public function get_user_limits( int $user_id ): array {
        $mem = $this->get_effective_membership( $user_id );
        if ( ! $mem ) {
            return [
                'ai_generations_per_month' => 10,
                'tools_access'             => 'free',
            ];
        }
        return json_decode( $mem['limits'] ?? '{}', true ) ?: [];
    }

    public function get_user_plan_slug( int $user_id ): string {
        $mem = $this->get_effective_membership( $user_id );
        return $mem['plan_slug'] ?? 'free';
    }

    public function get_workspace_owner_id( int $user_id ): int {
        $seat = $this->get_team_seat_for_member( $user_id );
        if ( $seat && ! empty( $seat['owner_user_id'] ) && $this->owner_workspace_active( (int) $seat['owner_user_id'] ) ) {
            return (int) $seat['owner_user_id'];
        }
        return $user_id;
    }

    public function is_team_member( int $user_id ): bool {
        return $this->get_workspace_owner_id( $user_id ) !== $user_id;
    }

    public function user_can( int $user_id, string $capability ): bool {
        $user_id = max( 0, $user_id );
        if ( $user_id <= 0 ) {
            return false;
        }

        if ( user_can( $user_id, $capability ) ) {
            return true;
        }

        if ( ! $this->is_team_member( $user_id ) ) {
            return false;
        }

        $plan_slug = $this->get_user_plan_slug( $user_id );
        if ( $plan_slug === 'publisher' && $capability === 'awg_team_seats' ) {
            return false;
        }

        return in_array( $capability, Roles::caps_for_plan_slug( $plan_slug ), true );
    }

    public function get_usage_owner_id( int $user_id ): int {
        return $this->get_workspace_owner_id( $user_id );
    }

    public function set_user_plan( int $user_id, int $plan_id, string $billing = 'monthly', string $stripe_sub_id = '', string $stripe_cust_id = '' ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $wpdb->update(
            $table,
            [ 'status' => 'cancelled', 'updated_at' => $now ],
            [ 'user_id' => $user_id, 'status' => 'active' ]
        );

        if ( $billing === 'free' ) {
            $end_date = null;
        } elseif ( $billing === 'yearly' ) {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 year' ) );
        } else {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 month' ) );
        }

        $inserted = $wpdb->insert( $table, [
            'user_id'                => $user_id,
            'plan_id'                => $plan_id,
            'status'                 => 'active',
            'billing_cycle'          => $billing,
            'start_date'             => $now,
            'end_date'               => $end_date,
            'stripe_subscription_id' => $stripe_sub_id,
            'stripe_customer_id'     => $stripe_cust_id,
            'created_at'             => $now,
            'updated_at'             => $now,
        ] );

        if ( $inserted ) {
            $ptable = Database::plans_table();
            $plan   = $wpdb->get_row(
                $wpdb->prepare( "SELECT slug FROM {$ptable} WHERE id = %d", $plan_id ),
                ARRAY_A
            );
            if ( $plan ) {
                Roles::set_user_role( $user_id, Roles::slug_to_role( (string) $plan['slug'] ) );
            }
            $this->sync_team_access_for_owner( $user_id );
            do_action( 'awg_mem_plan_changed', $user_id, $plan_id );
        }

        return (bool) $inserted;
    }

    public function cancel_user_membership( int $user_id, string $status = 'cancelled' ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = %s, updated_at = %s WHERE user_id = %d AND status IN ('active','trialing')",
                $status,
                $now,
                $user_id
            )
        );

        if ( $updated ) {
            Roles::clear_awg_roles( $user_id );
            $this->sync_team_access_for_owner( $user_id );
            if ( $status === 'cancelled' ) {
                do_action( 'awg_mem_cancelled', $user_id );
            } elseif ( $status === 'payment_failed' ) {
                do_action( 'awg_mem_payment_failed', $user_id );
            }
        }

        return (bool) $updated;
    }

    public function on_register( int $user_id ): void {
        global $wpdb;
        $ptable  = Database::plans_table();
        $free_plan = $wpdb->get_row(
            "SELECT id FROM {$ptable} WHERE is_free = 1 AND is_active = 1 LIMIT 1",
            ARRAY_A
        );
        if ( $free_plan ) {
            $this->set_user_plan( $user_id, (int) $free_plan['id'], 'free' );
        } else {
            Roles::clear_awg_roles( $user_id );
        }

        $this->claim_pending_team_invites( $user_id );
    }

    public function check_expiries(): void {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $expired = $wpdb->get_results(
            "SELECT user_id FROM {$table}
             WHERE status = 'active' AND end_date IS NOT NULL AND end_date < '{$now}'",
            ARRAY_A
        );

        foreach ( (array) $expired as $row ) {
            $this->cancel_user_membership( (int) $row['user_id'], 'expired' );
            do_action( 'awg_mem_expired', (int) $row['user_id'] );
        }
    }

    private function get_settings(): array {
        return URLs::get_settings();
    }

    private function get_account_url(): string {
        return URLs::account();
    }

    private function create_stripe_checkout_session( array $plan, string $billing, int $user_id ) {
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_secret', __( 'Stripe secret key is missing. Add it in Membership Settings.', 'authorwings-membership' ) );
        }

        $price_key = $billing === 'yearly' ? 'stripe_yearly_price_id' : 'stripe_monthly_price_id';
        $price_id  = trim( (string) ( $plan[ $price_key ] ?? '' ) );
        if ( $price_id === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_price', __( 'This plan is not connected to a Stripe price yet. Please contact support.', 'authorwings-membership' ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new \WP_Error( 'awg_mem_user_not_found', __( 'User account not found.', 'authorwings-membership' ) );
        }

        $account_url = $this->get_account_url();
        $success_url = add_query_arg(
            [
                'tab'        => 'account',
                'payment'    => 'success',
                'session_id' => '{CHECKOUT_SESSION_ID}',
            ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled' ], $account_url )
        );
        $cancel_url  = add_query_arg(
            [
                'tab'       => 'account',
                'cancelled' => '1',
            ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled' ], $account_url )
        );

        $body = [
            'mode'                         => 'subscription',
            'success_url'                  => $success_url,
            'cancel_url'                   => $cancel_url,
            'client_reference_id'          => (string) $user_id,
            'customer_email'               => (string) $user->user_email,
            'line_items[0][price]'         => $price_id,
            'line_items[0][quantity]'      => 1,
            'metadata[user_id]'            => (string) $user_id,
            'metadata[plan_id]'            => (string) (int) $plan['id'],
            'metadata[plan_slug]'          => (string) $plan['slug'],
            'metadata[billing]'            => $billing,
            'subscription_data[metadata][user_id]'   => (string) $user_id,
            'subscription_data[metadata][plan_id]'   => (string) (int) $plan['id'],
            'subscription_data[metadata][plan_slug]' => (string) $plan['slug'],
            'subscription_data[metadata][billing]'   => $billing,
        ];

        $response = wp_remote_post(
            self::STRIPE_API_BASE . '/checkout/sessions',
            [
                'timeout' => 30,
                'headers' => [ 'Authorization' => 'Bearer ' . $secret ],
                'body'    => $body,
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_request_failed', [ 'message' => $response->get_error_message(), 'user_id' => (string) $user_id, 'billing' => $billing ] );
            return new \WP_Error( 'awg_mem_stripe_request_failed', $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $json = json_decode( (string) wp_remote_retrieve_body( $response ), true );

        if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
            $message = __( 'Unable to start checkout right now. Please try again.', 'authorwings-membership' );
            if ( is_array( $json ) && ! empty( $json['error']['message'] ) ) {
                $message = sanitize_text_field( (string) $json['error']['message'] );
            }
            $this->log_membership_action( 'stripe_checkout_failed', [ 'message' => $message, 'user_id' => (string) $user_id, 'billing' => $billing, 'plan_id' => (string) (int) $plan['id'] ] );
            return new \WP_Error( 'awg_mem_stripe_checkout_failed', $message, [ 'raw' => $json ] );
        }

        if ( empty( $json['url'] ) ) {
            return new \WP_Error( 'awg_mem_stripe_missing_url', __( 'Stripe checkout URL was not returned.', 'authorwings-membership' ) );
        }

        return esc_url_raw( (string) $json['url'] );
    }

    public function verify_stripe_signature( string $payload, string $signature_header, string $secret ): bool {
        if ( $payload === '' || $signature_header === '' || $secret === '' ) {
            return false;
        }

        $parts = [];
        foreach ( explode( ',', $signature_header ) as $segment ) {
            $pair = explode( '=', trim( $segment ), 2 );
            if ( count( $pair ) === 2 ) {
                $parts[ $pair[0] ] = $pair[1];
            }
        }

        $timestamp = isset( $parts['t'] ) ? (string) $parts['t'] : '';
        $signature = isset( $parts['v1'] ) ? (string) $parts['v1'] : '';
        if ( $timestamp === '' || $signature === '' ) {
            return false;
        }

        if ( abs( time() - (int) $timestamp ) > 300 ) {
            return false;
        }

        $expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
        return hash_equals( $expected, $signature );
    }

    private function find_user_id_by_subscription( string $subscription_id ): int {
        if ( $subscription_id === '' ) {
            return 0;
        }

        global $wpdb;
        $table = Database::mems_table();
        $user_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE stripe_subscription_id = %s ORDER BY id DESC LIMIT 1",
                $subscription_id
            )
        );

        return (int) $user_id;
    }

    private function find_user_id_by_customer( string $customer_id ): int {
        if ( $customer_id === '' ) {
            return 0;
        }

        global $wpdb;
        $table = Database::mems_table();
        $user_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE stripe_customer_id = %s ORDER BY id DESC LIMIT 1",
                $customer_id
            )
        );

        return (int) $user_id;
    }

    private function cancel_stripe_subscription( string $subscription_id ): bool {
        $subscription_id = sanitize_text_field( $subscription_id );
        if ( $subscription_id === '' ) {
            return true;
        }

        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return false;
        }

        $response = wp_remote_request(
            self::STRIPE_API_BASE . '/subscriptions/' . rawurlencode( $subscription_id ),
            [
                'method'  => 'DELETE',
                'timeout' => 30,
                'headers' => [ 'Authorization' => 'Bearer ' . $secret ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_cancel_request_failed', [
                'subscription_id' => $subscription_id,
                'message'         => $response->get_error_message(),
            ] );
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $json = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        $ok   = $code >= 200 && $code < 300 && is_array( $json ) && ! empty( $json['id'] );

        if ( ! $ok ) {
            $message = is_array( $json ) && ! empty( $json['error']['message'] )
                ? sanitize_text_field( (string) $json['error']['message'] )
                : 'Stripe cancellation failed';
            $this->log_membership_action( 'stripe_cancel_failed', [
                'subscription_id' => $subscription_id,
                'http_code'       => (string) $code,
                'message'         => $message,
            ] );
            return false;
        }

        $this->log_membership_action( 'stripe_cancel_succeeded', [
            'subscription_id' => $subscription_id,
            'status'          => sanitize_text_field( (string) ( $json['status'] ?? '' ) ),
        ] );

        return true;
    }

    private function handle_stripe_subscription_event( array $object, string $event_type ): void {
        $metadata        = isset( $object['metadata'] ) && is_array( $object['metadata'] ) ? $object['metadata'] : [];
        $user_id         = isset( $metadata['user_id'] ) ? (int) $metadata['user_id'] : 0;
        $plan_id         = isset( $metadata['plan_id'] ) ? (int) $metadata['plan_id'] : 0;
        $billing         = isset( $metadata['billing'] ) && in_array( $metadata['billing'], [ 'monthly', 'yearly', 'free' ], true ) ? (string) $metadata['billing'] : 'monthly';
        $customer_id     = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );
        $subscription_id = sanitize_text_field( (string) ( $object['id'] ?? $object['subscription'] ?? '' ) );

        if ( $user_id <= 0 && $customer_id !== '' ) {
            $user_id = $this->find_user_id_by_customer( $customer_id );
        }

        if ( $user_id <= 0 && $subscription_id !== '' ) {
            $user_id = $this->find_user_id_by_subscription( $subscription_id );
        }

        if ( $plan_id <= 0 && $user_id > 0 ) {
            $mem     = $this->get_latest_membership( $user_id );
            $plan_id = (int) ( $mem['plan_id'] ?? 0 );
            if ( $billing === 'monthly' && ! empty( $mem['billing_cycle'] ) && in_array( $mem['billing_cycle'], [ 'monthly', 'yearly', 'free' ], true ) ) {
                $billing = (string) $mem['billing_cycle'];
            }
        }

        $log_context = [
            'event_type'       => $event_type,
            'resolved_user_id' => (string) $user_id,
            'customer_id'      => $customer_id,
            'subscription_id'  => $subscription_id,
            'plan_id'          => (string) $plan_id,
            'billing'          => $billing,
        ];

        if ( $user_id <= 0 ) {
            $this->log_membership_action( 'stripe_webhook_unresolved_user', $log_context );
            return;
        }

        if ( $event_type === 'customer.subscription.deleted' ) {
            $this->cancel_user_membership( $user_id, 'cancelled' );
            $this->log_membership_action( 'stripe_webhook_membership_cancelled', $log_context + [ 'action' => 'cancel' ] );
            return;
        }

        if ( $event_type === 'invoice.payment_failed' ) {
            $this->cancel_user_membership( $user_id, 'payment_failed' );
            $this->log_membership_action( 'stripe_webhook_membership_payment_failed', $log_context + [ 'action' => 'fail' ] );
            return;
        }

        if ( $plan_id <= 0 ) {
            $this->log_membership_action( 'stripe_webhook_missing_plan', $log_context );
            return;
        }

        $this->set_user_plan( $user_id, $plan_id, $billing, $subscription_id, $customer_id );
        $this->log_membership_action( 'stripe_webhook_membership_synced', $log_context + [ 'action' => 'sync' ] );
    }

    public function rest_webhook( \WP_REST_Request $request ): \WP_REST_Response {
        $payload  = $request->get_body();
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_webhook_secret'] ?? '' ) );
        $sig      = (string) $request->get_header( 'stripe-signature' );

        if ( ! $this->verify_stripe_signature( $payload, $sig, $secret ) ) {
            return new \WP_REST_Response( [ 'received' => false, 'message' => 'Invalid signature.' ], 400 );
        }

        $event = json_decode( $payload, true );
        if ( ! is_array( $event ) || empty( $event['type'] ) || empty( $event['data']['object'] ) || ! is_array( $event['data']['object'] ) ) {
            return new \WP_REST_Response( [ 'received' => false, 'message' => 'Invalid payload.' ], 400 );
        }

        $type   = sanitize_text_field( (string) $event['type'] );
        $object = $event['data']['object'];

        $this->log_membership_action( 'stripe_webhook_received', [
            'event_type' => $type,
            'object_id'  => sanitize_text_field( (string) ( $object['id'] ?? '' ) ),
        ] );

        switch ( $type ) {
            case 'checkout.session.completed':
                $metadata = isset( $object['metadata'] ) && is_array( $object['metadata'] ) ? $object['metadata'] : [];
                $user_id  = isset( $metadata['user_id'] ) ? (int) $metadata['user_id'] : (int) ( $object['client_reference_id'] ?? 0 );
                $plan_id  = isset( $metadata['plan_id'] ) ? (int) $metadata['plan_id'] : 0;
                $billing  = isset( $metadata['billing'] ) && in_array( $metadata['billing'], [ 'monthly', 'yearly', 'free' ], true ) ? (string) $metadata['billing'] : 'monthly';
                $sub_id   = sanitize_text_field( (string) ( $object['subscription'] ?? '' ) );
                $cust_id  = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );
                if ( $user_id > 0 && $plan_id > 0 ) {
                    $this->set_user_plan( $user_id, $plan_id, $billing, $sub_id, $cust_id );
                    $this->log_membership_action( 'stripe_webhook_checkout_completed', [
                        'event_type'       => $type,
                        'resolved_user_id' => (string) $user_id,
                        'customer_id'      => $cust_id,
                        'subscription_id'  => $sub_id,
                        'plan_id'          => (string) $plan_id,
                        'billing'          => $billing,
                        'action'           => 'activate',
                    ] );
                } else {
                    $this->log_membership_action( 'stripe_webhook_checkout_missing_metadata', [
                        'event_type'       => $type,
                        'resolved_user_id' => (string) $user_id,
                        'customer_id'      => $cust_id,
                        'subscription_id'  => $sub_id,
                        'plan_id'          => (string) $plan_id,
                    ] );
                }
                break;

            case 'customer.subscription.created':
            case 'customer.subscription.updated':
            case 'customer.subscription.deleted':
            case 'invoice.payment_failed':
                $this->handle_stripe_subscription_event( $object, $type );
                break;
        }

        return new \WP_REST_Response( [ 'received' => true ], 200 );
    }

    public function ajax_upgrade(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot change workspace billing. Please contact the workspace owner.', 'authorwings-membership' ) ], 403 );
        }

        $plan_slug = isset( $_POST['plan'] ) ? sanitize_key( wp_unslash( (string) $_POST['plan'] ) ) : '';
        $billing_raw = isset( $_POST['billing'] ) ? wp_unslash( (string) $_POST['billing'] ) : '';
        $billing   = in_array( $billing_raw, [ 'monthly', 'yearly' ], true )
            ? sanitize_key( $billing_raw )
            : 'monthly';

        global $wpdb;
        $ptable = Database::plans_table();
        $plan   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$ptable} WHERE slug = %s AND is_active = 1 LIMIT 1", $plan_slug ),
            ARRAY_A
        );

        if ( ! $plan ) {
            wp_send_json_error( [ 'message' => __( 'Plan not found.', 'authorwings-membership' ) ] );
        }

        if ( (bool) $plan['is_free'] ) {
            $this->set_user_plan( get_current_user_id(), (int) $plan['id'], 'free' );
            wp_send_json_success( [ 'message' => __( 'Plan updated.', 'authorwings-membership' ), 'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'plan-updated' ], $this->get_account_url() ) ] );
            return;
        }

        $checkout_url = $this->create_stripe_checkout_session( $plan, $billing, get_current_user_id() );
        if ( is_wp_error( $checkout_url ) ) {
            wp_send_json_error( [ 'message' => $checkout_url->get_error_message() ], 400 );
        }

        wp_send_json_success( [ 'redirect' => $checkout_url ] );
    }

    public function ajax_cancel(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot cancel workspace billing. Please contact the workspace owner.', 'authorwings-membership' ) ], 403 );
        }

        $latest = $this->get_latest_membership( get_current_user_id() );
        $subscription_id = sanitize_text_field( (string) ( $latest['stripe_subscription_id'] ?? '' ) );
        $status          = sanitize_key( (string) ( $latest['status'] ?? '' ) );
        if ( $subscription_id !== '' && in_array( $status, [ 'active', 'trialing', 'payment_failed', 'past_due', 'unpaid' ], true ) ) {
            if ( ! $this->cancel_stripe_subscription( $subscription_id ) ) {
                wp_send_json_error( [ 'message' => __( 'We could not cancel your Stripe subscription right now. Please try again or contact support before retrying.', 'authorwings-membership' ) ], 502 );
            }
        }

        $this->cancel_user_membership( get_current_user_id(), 'cancelled' );
        wp_send_json_success( [
            'message'  => __( 'Membership cancelled.', 'authorwings-membership' ),
            'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'cancelled' ], $this->get_account_url() ),
        ] );
    }

    public function ajax_invite_team_member(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }
        $email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( (string) $_POST['email'] ) ) : '';
        if ( ! is_email( $email ) ) {
            wp_send_json_error( [ 'message' => __( 'Please enter a valid email address.', 'authorwings-membership' ) ], 400 );
        }

        $result = $this->invite_team_member( get_current_user_id(), $email );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
        }

        wp_send_json_success( [
            'message' => __( 'Seat invitation saved.', 'authorwings-membership' ),
            'team'    => $this->get_team_context( get_current_user_id() ),
        ] );
    }

    public function ajax_remove_team_member(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-membership' ) ], 401 );
        }

        $seat_id = isset( $_POST['seat_id'] ) ? (int) wp_unslash( (string) $_POST['seat_id'] ) : 0;
        if ( $seat_id <= 0 ) {
            wp_send_json_error( [ 'message' => __( 'Invalid seat.', 'authorwings-membership' ) ], 400 );
        }

        $ok = $this->remove_team_member( get_current_user_id(), $seat_id );
        if ( ! $ok ) {
            wp_send_json_error( [ 'message' => __( 'Could not remove that seat.', 'authorwings-membership' ) ], 400 );
        }

        wp_send_json_success( [
            'message' => __( 'Seat removed.', 'authorwings-membership' ),
            'team'    => $this->get_team_context( get_current_user_id() ),
        ] );
    }

    public function get_team_context( int $user_id ): array {
        $workspace_owner_id = $this->get_workspace_owner_id( $user_id );
        $owner_mem          = $this->get_user_membership( $workspace_owner_id );
        $limits             = $owner_mem ? ( json_decode( $owner_mem['limits'] ?? '{}', true ) ?: [] ) : [];
        $seat_limit         = max( 0, (int) ( $limits['team_seats'] ?? 0 ) );
        $is_owner           = $workspace_owner_id === $user_id;
        $team_members       = $this->get_team_members_for_owner( $workspace_owner_id );
        $owner_user         = get_userdata( $workspace_owner_id );

        $seat_count = 0;
        foreach ( $team_members as $team_member ) {
            if ( in_array( $team_member['status'], [ 'active', 'pending' ], true ) ) {
                $seat_count++;
            }
        }

        return [
            'workspace_owner_id'   => $workspace_owner_id,
            'is_owner'             => $is_owner,
            'is_team_member'       => ! $is_owner,
            'can_manage_team'      => $is_owner && $this->owner_workspace_active( $workspace_owner_id ) && $seat_limit > 0,
            'seat_limit'           => $seat_limit,
            'seat_count'           => $seat_count,
            'members'              => $team_members,
            'workspace_owner_name' => $owner_user ? $owner_user->display_name : '',
            'workspace_owner_email'=> $owner_user ? $owner_user->user_email : '',
            'usage_model'          => 'workspace',
        ];
    }


    private function get_active_workspace_seat_for_user( int $member_user_id ): ?array {
        global $wpdb;
        $table = Database::team_table();
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE member_user_id = %d AND status = 'active' ORDER BY id DESC LIMIT 1", $member_user_id ),
            ARRAY_A
        );
    }

    private function owner_workspace_active( int $owner_user_id ): bool {
        $mem = $this->get_user_membership( $owner_user_id );
        return $mem && ( $mem['plan_slug'] ?? '' ) === 'publisher' && in_array( $mem['status'], [ 'active', 'trialing' ], true );
    }

    private function get_team_seat_for_member( int $member_user_id ): ?array {
        return $this->get_active_workspace_seat_for_user( $member_user_id );
    }

    private function get_team_members_for_owner( int $owner_user_id ): array {
        global $wpdb;
        $table = Database::team_table();
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE owner_user_id = %d ORDER BY created_at ASC", $owner_user_id ),
            ARRAY_A
        );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $user = ! empty( $row['member_user_id'] ) ? get_userdata( (int) $row['member_user_id'] ) : null;
            $out[] = [
                'id'           => (int) $row['id'],
                'status'       => (string) $row['status'],
                'email'        => (string) $row['invited_email'],
                'member_user_id'=> (int) $row['member_user_id'],
                'name'         => $user ? $user->display_name : '',
            ];
        }
        return $out;
    }

    private function invite_team_member( int $owner_user_id, string $email ) {
        if ( ! $this->owner_workspace_active( $owner_user_id ) ) {
            return new \WP_Error( 'awg_mem_team_requires_publisher', __( 'Only an active Publisher workspace can invite team seats.', 'authorwings-membership' ) );
        }

        global $wpdb;
        $table = Database::team_table();
        $existing = $wpdb->get_row(
            $wpdb->prepare( "SELECT id FROM {$table} WHERE owner_user_id = %d AND invited_email = %s LIMIT 1", $owner_user_id, $email ),
            ARRAY_A
        );

        $context = $this->get_team_context( $owner_user_id );
        if ( ! $existing && $context['seat_limit'] > 0 && $context['seat_count'] >= $context['seat_limit'] ) {
            return new \WP_Error( 'awg_mem_team_full', __( 'All team seats are already in use.', 'authorwings-membership' ) );
        }

        $user = get_user_by( 'email', $email );
        if ( $user && (int) $user->ID === $owner_user_id ) {
            return new \WP_Error( 'awg_mem_team_owner', __( 'You cannot invite your own email as a team seat.', 'authorwings-membership' ) );
        }

        if ( $user ) {
            $active_workspace = $this->get_active_workspace_seat_for_user( (int) $user->ID );
            if ( $active_workspace && (int) $active_workspace['owner_user_id'] !== $owner_user_id ) {
                return new \WP_Error( 'awg_mem_team_already_assigned', __( 'This user already belongs to another active workspace.', 'authorwings-membership' ) );
            }
        }

        $now   = current_time( 'mysql' );
        $data  = [
            'owner_user_id'  => $owner_user_id,
            'member_user_id' => $user ? (int) $user->ID : 0,
            'invited_email'  => $email,
            'status'         => $user ? 'active' : 'pending',
            'updated_at'     => $now,
        ];

        if ( $existing ) {
            $wpdb->update( $table, $data, [ 'id' => (int) $existing['id'] ] );
            $seat_id = (int) $existing['id'];
        } else {
            $data['created_at'] = $now;
            $wpdb->insert( $table, $data );
            $seat_id = (int) $wpdb->insert_id;
        }

        $this->log_membership_action( 'team_seat_invited', [
            'owner_user_id'  => (string) $owner_user_id,
            'seat_id'        => (string) $seat_id,
            'member_user_id' => $user ? (string) (int) $user->ID : '0',
            'email'          => $email,
            'status'         => (string) $data['status'],
        ] );

        do_action( 'awg_mem_team_invited', $owner_user_id, $email, $user ? (int) $user->ID : 0, (string) $data['status'] );

        return true;
    }

    private function remove_team_member( int $owner_user_id, int $seat_id ): bool {
        global $wpdb;
        $table = Database::team_table();
        $seat  = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND owner_user_id = %d LIMIT 1", $seat_id, $owner_user_id ),
            ARRAY_A
        );
        if ( ! $seat ) {
            return false;
        }

        $deleted = $wpdb->delete( $table, [ 'id' => $seat_id, 'owner_user_id' => $owner_user_id ] );
        if ( $deleted && ! empty( $seat['member_user_id'] ) ) {
            $this->refresh_user_access_role( (int) $seat['member_user_id'] );
        }
        if ( $deleted ) {
            $this->log_membership_action( 'team_seat_removed', [
                'owner_user_id'  => (string) $owner_user_id,
                'seat_id'        => (string) $seat_id,
                'member_user_id' => (string) (int) ( $seat['member_user_id'] ?? 0 ),
                'email'          => (string) ( $seat['invited_email'] ?? '' ),
            ] );
        }
        return (bool) $deleted;
    }

    private function claim_pending_team_invites( int $user_id ): void {
        $user = get_userdata( $user_id );
        if ( ! $user || ! is_email( $user->user_email ) ) {
            return;
        }

        global $wpdb;
        $table = Database::team_table();
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE invited_email = %s AND status = 'pending'", $user->user_email ),
            ARRAY_A
        );

        foreach ( (array) $rows as $row ) {
            if ( ! $this->owner_workspace_active( (int) $row['owner_user_id'] ) ) {
                continue;
            }

            $active_workspace = $this->get_active_workspace_seat_for_user( $user_id );
            if ( $active_workspace && (int) $active_workspace['owner_user_id'] !== (int) $row['owner_user_id'] ) {
                $this->log_membership_action( 'team_seat_claim_skipped', [
                    'user_id'            => (string) $user_id,
                    'pending_owner_id'   => (string) (int) $row['owner_user_id'],
                    'active_owner_id'    => (string) (int) $active_workspace['owner_user_id'],
                    'seat_id'            => (string) (int) $row['id'],
                ] );
                continue;
            }

            $wpdb->update(
                $table,
                [
                    'member_user_id' => $user_id,
                    'status'         => 'active',
                    'updated_at'     => current_time( 'mysql' ),
                ],
                [ 'id' => (int) $row['id'] ]
            );

            $this->log_membership_action( 'team_seat_claimed', [
                'user_id'        => (string) $user_id,
                'owner_user_id'  => (string) (int) $row['owner_user_id'],
                'seat_id'        => (string) (int) $row['id'],
                'email'          => (string) $user->user_email,
            ] );
        }
    }

    private function refresh_user_access_role( int $user_id ): void {
        $mem = $this->get_user_membership( $user_id );
        if ( $mem && ! empty( $mem['plan_slug'] ) ) {
            Roles::set_user_role( $user_id, Roles::slug_to_role( (string) $mem['plan_slug'] ) );
            return;
        }
        Roles::clear_awg_roles( $user_id );
    }

    private function sync_team_access_for_owner( int $owner_user_id ): void {
        global $wpdb;
        $table = Database::team_table();
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE owner_user_id = %d", $owner_user_id ),
            ARRAY_A
        );

        $workspace_active = $this->owner_workspace_active( $owner_user_id );
        foreach ( (array) $rows as $row ) {
            $member_user_id = (int) ( $row['member_user_id'] ?? 0 );
            if ( $workspace_active ) {
                $new_status = $member_user_id > 0 ? 'active' : 'pending';
                $wpdb->update( $table, [ 'status' => $new_status, 'updated_at' => current_time( 'mysql' ) ], [ 'id' => (int) $row['id'] ] );
                $this->log_membership_action( 'team_seat_synced', [
                    'owner_user_id'  => (string) $owner_user_id,
                    'seat_id'        => (string) (int) $row['id'],
                    'member_user_id' => (string) $member_user_id,
                    'status'         => $new_status,
                ] );
            } else {
                if ( $member_user_id > 0 ) {
                    $this->refresh_user_access_role( $member_user_id );
                }
                $wpdb->delete( $table, [ 'id' => (int) $row['id'] ] );
                $this->log_membership_action( 'team_seat_deleted_on_workspace_end', [
                    'owner_user_id'  => (string) $owner_user_id,
                    'seat_id'        => (string) (int) $row['id'],
                    'member_user_id' => (string) $member_user_id,
                ] );
            }
        }
    }
}
