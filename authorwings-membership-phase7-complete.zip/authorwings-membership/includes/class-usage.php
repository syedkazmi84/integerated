<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Usage {

    public static function current_period(): string {
        return gmdate( 'Y-m' );
    }

    private function resolve_user_id( int $user_id ): int {
        $mapped = (int) apply_filters( 'awg_mem_usage_owner_user_id', $user_id, $user_id );
        return $mapped > 0 ? $mapped : $user_id;
    }

    private function resolve_actor_and_owner_ids( int $user_id ): array {
        $owner_id = $this->resolve_user_id( $user_id );
        return [
            'actor_user_id' => $user_id,
            'owner_user_id' => $owner_id,
        ];
    }

    public function get( int $user_id, string $service_slug ): int {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $table  = Database::usage_table();
        $period = self::current_period();
        $count  = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT used FROM {$table} WHERE user_id = %d AND service_slug = %s AND period = %s",
                $user_id, $service_slug, $period
            )
        );
        return (int) $count;
    }

    public function increment( int $user_id, string $service_slug ): void {
        global $wpdb;
        $ids    = $this->resolve_actor_and_owner_ids( $user_id );
        $user_id = $ids['owner_user_id'];
        $table  = Database::usage_table();
        $period = self::current_period();
        $now    = current_time( 'mysql' );

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$table} (user_id, service_slug, period, used, updated_at)
                 VALUES (%d, %s, %s, 1, %s)
                 ON DUPLICATE KEY UPDATE used = used + 1, updated_at = %s",
                $user_id, $service_slug, $period, $now, $now
            )
        );

        if ( $ids['actor_user_id'] > 0 && $ids['actor_user_id'] !== $ids['owner_user_id'] ) {
            Logger::log( 'workspace_usage_incremented', [
                'actor_user_id' => (string) $ids['actor_user_id'],
                'owner_user_id' => (string) $ids['owner_user_id'],
                'service_slug'  => $service_slug,
                'period'        => $period,
            ] );
        }
    }

    public function get_all_for_user( int $user_id ): array {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $table  = Database::usage_table();
        $period = self::current_period();
        $rows   = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT service_slug, used FROM {$table} WHERE user_id = %d AND period = %s",
                $user_id, $period
            ),
            ARRAY_A
        );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $out[ $row['service_slug'] ] = (int) $row['used'];
        }
        return $out;
    }



    public function get_monthly_breakdown( int $user_id, int $months = 6 ): array {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $months  = max( 1, min( 24, $months ) );
        $table   = Database::usage_table();
        $start   = gmdate( 'Y-m', strtotime( '-' . ( $months - 1 ) . ' months', strtotime( gmdate( 'Y-m-01' ) ) ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT period, SUM(used) AS total_used FROM {$table} WHERE user_id = %d AND period >= %s GROUP BY period ORDER BY period ASC",
                $user_id,
                $start
            ),
            ARRAY_A
        );

        $map = [];
        foreach ( (array) $rows as $row ) {
            $map[ $row['period'] ] = (int) $row['total_used'];
        }

        $out = [];
        for ( $i = $months - 1; $i >= 0; $i-- ) {
            $period = gmdate( 'Y-m', strtotime( '-' . $i . ' months', strtotime( gmdate( 'Y-m-01' ) ) ) );
            $out[] = [
                'period' => $period,
                'label'  => wp_date( 'M Y', strtotime( $period . '-01 00:00:00' ) ),
                'used'   => $map[ $period ] ?? 0,
            ];
        }

        return $out;
    }

    public function get_recent_tools_used( int $user_id, int $limit = 5 ): array {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $limit   = max( 1, min( 20, $limit ) );

        $posts = $wpdb->posts;
        $meta  = $wpdb->postmeta;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT COALESCE(tt.meta_value, t.post_title, 'AI Tool') AS tool_name, COUNT(p.ID) AS run_count, MAX(p.post_date) AS last_used
                 FROM {$posts} p
                 LEFT JOIN {$meta} owner ON owner.post_id = p.ID AND owner.meta_key = '_awg_aig_owner_user_id'
                 LEFT JOIN {$meta} actor ON actor.post_id = p.ID AND actor.meta_key = '_awg_aig_user_id'
                 LEFT JOIN {$meta} tid ON tid.post_id = p.ID AND tid.meta_key = '_awg_aig_template_id'
                 LEFT JOIN {$posts} t ON t.ID = CAST(tid.meta_value AS UNSIGNED)
                 LEFT JOIN {$meta} tt ON tt.post_id = p.ID AND tt.meta_key = '_awg_aig_template_title'
                 WHERE p.post_type = 'awg_ai_submission'
                   AND p.post_status = 'publish'
                   AND ( CAST(owner.meta_value AS UNSIGNED) = %d OR (owner.meta_value IS NULL AND CAST(actor.meta_value AS UNSIGNED) = %d) )
                 GROUP BY tool_name
                 ORDER BY last_used DESC
                 LIMIT %d",
                $user_id,
                $user_id,
                $limit
            ),
            ARRAY_A
        );

        return array_map( static function( $row ) {
            return [
                'tool'      => (string) $row['tool_name'],
                'run_count' => (int) $row['run_count'],
                'last_used' => (string) $row['last_used'],
            ];
        }, (array) $rows );
    }



    public function get_workspace_usage_breakdown( int $owner_user_id, int $limit = 20 ): array {
        global $wpdb;
        $owner_user_id = max( 0, $owner_user_id );
        if ( $owner_user_id <= 0 ) {
            return [];
        }

        $limit = max( 1, min( 100, $limit ) );
        $posts = $wpdb->posts;
        $meta  = $wpdb->postmeta;
        $period_start = gmdate( 'Y-m-01 00:00:00' );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    CAST(actor.meta_value AS UNSIGNED) AS actor_user_id,
                    COUNT(p.ID) AS run_count,
                    MAX(p.post_date) AS last_used
                 FROM {$posts} p
                 INNER JOIN {$meta} owner ON owner.post_id = p.ID AND owner.meta_key = '_awg_aig_owner_user_id'
                 LEFT JOIN {$meta} actor ON actor.post_id = p.ID AND actor.meta_key = '_awg_aig_user_id'
                 WHERE p.post_type = 'awg_ai_submission'
                   AND p.post_status = 'publish'
                   AND CAST(owner.meta_value AS UNSIGNED) = %d
                   AND p.post_date >= %s
                 GROUP BY actor_user_id
                 ORDER BY run_count DESC, last_used DESC
                 LIMIT %d",
                $owner_user_id,
                $period_start,
                $limit
            ),
            ARRAY_A
        );

        $out = [];
        foreach ( (array) $rows as $row ) {
            $actor_user_id = (int) ( $row['actor_user_id'] ?? 0 );
            $user = $actor_user_id > 0 ? get_userdata( $actor_user_id ) : null;
            $out[] = [
                'actor_user_id' => $actor_user_id,
                'name'          => $user ? $user->display_name : __( 'Unknown user', 'authorwings-membership' ),
                'email'         => $user ? $user->user_email : '',
                'run_count'     => (int) ( $row['run_count'] ?? 0 ),
                'last_used'     => (string) ( $row['last_used'] ?? '' ),
            ];
        }

        return $out;
    }

    public function get_member_activity_summary( int $limit = 20 ): array {
        global $wpdb;
        $limit = max( 1, min( 100, $limit ) );
        $period = self::current_period();
        $usage_table = Database::usage_table();
        $mems_table  = Database::mems_table();
        $plans_table = Database::plans_table();
        $posts = $wpdb->posts;
        $meta  = $wpdb->postmeta;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT u.ID AS user_id, u.display_name, u.user_email, COALESCE(p.name, 'Free') AS plan_name, COALESCE(SUM(us.used), 0) AS month_used, MAX(sub.post_date) AS last_activity
                 FROM {$wpdb->users} u
                 LEFT JOIN {$mems_table} m ON m.user_id = u.ID AND m.status IN ('active','trialing','cancelled','payment_failed','expired')
                 LEFT JOIN {$plans_table} p ON p.id = m.plan_id
                 LEFT JOIN {$usage_table} us ON us.user_id = u.ID AND us.period = %s
                 LEFT JOIN {$meta} owner ON owner.meta_key = '_awg_aig_owner_user_id' AND CAST(owner.meta_value AS UNSIGNED) = u.ID
                 LEFT JOIN {$posts} sub ON sub.ID = owner.post_id AND sub.post_type = 'awg_ai_submission' AND sub.post_status = 'publish'
                 GROUP BY u.ID, u.display_name, u.user_email, p.name
                 HAVING month_used > 0 OR last_activity IS NOT NULL
                 ORDER BY last_activity DESC, month_used DESC
                 LIMIT %d",
                $period,
                $limit
            ),
            ARRAY_A
        );

        return array_map( static function( $row ) {
            return [
                'user_id' => (int) $row['user_id'],
                'display_name' => (string) $row['display_name'],
                'user_email' => (string) $row['user_email'],
                'plan_name' => (string) $row['plan_name'],
                'month_used' => (int) $row['month_used'],
                'last_activity' => (string) $row['last_activity'],
            ];
        }, (array) $rows );
    }

    public function can_use( int $user_id, string $service_slug, int $limit ): bool {
        if ( $limit < 0 ) {
            return true;
        }
        return $this->get( $user_id, $service_slug ) < $limit;
    }
}
