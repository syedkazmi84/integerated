<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Services {

    public const CPT = 'awg_service';
    public const NONCE = 'awg_service_save';

    public function register_cpt(): void {
        register_post_type( self::CPT, [
            'labels' => [
                'name'          => __( 'Publishing Services', 'authorwings-membership' ),
                'singular_name' => __( 'Publishing Service',  'authorwings-membership' ),
                'add_new_item'  => __( 'Add New Service',     'authorwings-membership' ),
                'edit_item'     => __( 'Edit Service',        'authorwings-membership' ),
            ],
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'supports'     => [ 'title', 'editor', 'thumbnail', 'page-attributes' ],
            'menu_icon'    => 'dashicons-book-alt',
        ] );
    }

    public function register_metaboxes(): void {
        add_meta_box(
            'awg-service-details',
            __( 'Service Details', 'authorwings-membership' ),
            [ $this, 'render_metabox' ],
            self::CPT,
            'normal',
            'high'
        );
    }

    public function render_metabox( \WP_Post $post ): void {
        wp_nonce_field( self::NONCE, 'awg_service_nonce' );
        $category   = get_post_meta( $post->ID, '_awg_svc_category', true ) ?: 'general';
        $price_from = get_post_meta( $post->ID, '_awg_svc_price_from', true ) ?: '';
        $turnaround = get_post_meta( $post->ID, '_awg_svc_turnaround', true ) ?: '';
        $icon       = get_post_meta( $post->ID, '_awg_svc_icon', true ) ?: 'dashicons-star-filled';
        $featured   = (int) get_post_meta( $post->ID, '_awg_svc_featured', true );
        ?>
        <table class="form-table" role="presentation">
            <tr>
                <th><label for="awg-svc-category"><?php esc_html_e( 'Category', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-category" type="text" class="regular-text" name="awg_service_meta[category]" value="<?php echo esc_attr( $category ); ?>" placeholder="editing, publishing, marketing"></td>
            </tr>
            <tr>
                <th><label for="awg-svc-price"><?php esc_html_e( 'Price From', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-price" type="text" class="regular-text" name="awg_service_meta[price_from]" value="<?php echo esc_attr( $price_from ); ?>" placeholder="$199"></td>
            </tr>
            <tr>
                <th><label for="awg-svc-turnaround"><?php esc_html_e( 'Turnaround', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-turnaround" type="text" class="regular-text" name="awg_service_meta[turnaround]" value="<?php echo esc_attr( $turnaround ); ?>" placeholder="3-5 business days"></td>
            </tr>
            <tr>
                <th><label for="awg-svc-icon"><?php esc_html_e( 'Dashicon Class', 'authorwings-membership' ); ?></label></th>
                <td><input id="awg-svc-icon" type="text" class="regular-text" name="awg_service_meta[icon]" value="<?php echo esc_attr( $icon ); ?>" placeholder="dashicons-format-aside"><p class="description"><?php esc_html_e( 'Use any Dashicons class for dashboard service cards.', 'authorwings-membership' ); ?></p></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Featured', 'authorwings-membership' ); ?></th>
                <td><label><input type="checkbox" name="awg_service_meta[featured]" value="1" <?php checked( $featured, 1 ); ?>> <?php esc_html_e( 'Mark this service as featured', 'authorwings-membership' ); ?></label></td>
            </tr>
        </table>
        <?php
    }

    public function save_metabox( int $post_id, $post ): void {
        if ( ! is_object( $post ) || $post->post_type !== self::CPT ) {
            return;
        }
        if ( ! isset( $_POST['awg_service_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_service_nonce'] ) ), self::NONCE ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $meta = isset( $_POST['awg_service_meta'] ) && is_array( $_POST['awg_service_meta'] ) ? wp_unslash( $_POST['awg_service_meta'] ) : [];

        update_post_meta( $post_id, '_awg_svc_category', sanitize_text_field( $meta['category'] ?? 'general' ) );
        update_post_meta( $post_id, '_awg_svc_price_from', sanitize_text_field( $meta['price_from'] ?? '' ) );
        update_post_meta( $post_id, '_awg_svc_turnaround', sanitize_text_field( $meta['turnaround'] ?? '' ) );
        update_post_meta( $post_id, '_awg_svc_icon', sanitize_html_class( $meta['icon'] ?? 'dashicons-star-filled' ) );
        update_post_meta( $post_id, '_awg_svc_featured', ! empty( $meta['featured'] ) ? 1 : 0 );
    }

    /**
     * Get all published services.
     */
    public function get_all(): array {
        $posts = get_posts( [
            'post_type'      => self::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        ] );

        return array_map( function( $p ) {
            return [
                'id'          => $p->ID,
                'title'       => $p->post_title,
                'description' => wp_strip_all_tags( $p->post_content ),
                'slug'        => $p->post_name,
                'category'    => get_post_meta( $p->ID, '_awg_svc_category', true ) ?: 'general',
                'price_from'  => get_post_meta( $p->ID, '_awg_svc_price_from', true ) ?: '',
                'is_free'     => (bool) get_post_meta( $p->ID, '_awg_svc_is_free', true ),
                'turnaround'  => get_post_meta( $p->ID, '_awg_svc_turnaround', true ) ?: '',
                'icon'        => get_post_meta( $p->ID, '_awg_svc_icon', true ) ?: 'dashicons-star-filled',
                'featured'    => (bool) get_post_meta( $p->ID, '_awg_svc_featured', true ),
            ];
        }, $posts );
    }

    public function ajax_submit_order(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in to request a service.', 'authorwings-membership' ) ], 401 );
        }

        $user_id      = get_current_user_id();
        $service_slug = isset( $_POST['service_slug'] ) ? sanitize_key( wp_unslash( (string) $_POST['service_slug'] ) ) : '';
        $service_name = isset( $_POST['service_name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['service_name'] ) ) : '';
        $notes        = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['notes'] ) ) : '';
        $project_type = isset( $_POST['project_type'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['project_type'] ) ) : '';
        $timeline     = isset( $_POST['timeline'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['timeline'] ) ) : '';

        if ( ! $service_slug ) {
            wp_send_json_error( [ 'message' => __( 'Please select a service.', 'authorwings-membership' ) ] );
        }

        if ( '' === trim( $notes ) ) {
            wp_send_json_error( [ 'message' => __( 'Please add a few project details so our team can prepare the right quote.', 'authorwings-membership' ) ], 422 );
        }

        global $wpdb;
        $table = Database::orders_table();
        $now   = current_time( 'mysql' );

        $inserted = $wpdb->insert( $table, [
            'user_id'      => $user_id,
            'service_slug' => $service_slug,
            'service_name' => $service_name,
            'status'       => 'pending',
            'notes'        => $notes,
            'meta'         => wp_json_encode( [
                'user_email'   => wp_get_current_user()->user_email,
                'project_type' => $project_type,
                'timeline'     => $timeline,
            ] ),
            'created_at'   => $now,
            'updated_at'   => $now,
        ] );

        if ( ! $inserted ) {
            wp_send_json_error( [ 'message' => __( 'Could not submit your request. Please try again.', 'authorwings-membership' ) ] );
        }

        do_action( 'awg_mem_service_ordered', $wpdb->insert_id, $user_id, $service_slug );

        wp_send_json_success( [
            'message' => __( 'Your request has been submitted! We will get back to you within 24 hours.', 'authorwings-membership' ),
        ] );
    }
}
