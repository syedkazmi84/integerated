<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Bridges the membership plugin with the AuthorWings AI plugin.
 * Uses the current filter/action integration path supported by the AI plugin.
 */
class AI_Gate {

    /** @var Memberships */
    private $memberships;

    /** @var Usage */
    private $usage;

    public function __construct( Memberships $memberships, Usage $usage ) {
        $this->memberships = $memberships;
        $this->usage       = $usage;
    }

    public function register_hooks(): void {
        add_filter( 'awg_aig_can_generate', [ $this, 'check_can_generate' ], 10, 3 );
        add_action( 'awg_aig_generated', [ $this, 'on_generated' ], 10, 3 );
        add_filter( 'awg_mem_usage_owner_user_id', [ $this, 'map_usage_owner_user_id' ], 10, 2 );
        add_filter( 'awg_aig_visible_templates', [ $this, 'filter_templates' ], 10, 2 );
    }

    /**
     * Filter: awg_aig_can_generate
     * Return false (or WP_Error) to block generation.
     */
    public function check_can_generate( $can, int $user_id, int $template_id ) {
        if ( ! $can ) {
            return $can;
        }

        if ( $user_id <= 0 ) {
            return true;
        }

        $limits = $this->memberships->get_user_limits( $user_id );
        $max    = isset( $limits['ai_generations_per_month'] )
            ? (int) $limits['ai_generations_per_month']
            : 10;

        if ( $max >= 0 && ! $this->usage->can_use( $user_id, 'ai_generation', $max ) ) {
            $plan        = $this->memberships->get_user_plan_slug( $user_id );
            $current_mem = $this->memberships->get_effective_membership( $user_id );
            $status      = sanitize_key( (string) ( $current_mem['status'] ?? 'active' ) );
            $required    = sanitize_key( (string) get_post_meta( $template_id, '_awg_mem_required_plan', true ) );
            if ( ! in_array( $required, [ 'free', 'basic', 'pro', 'publisher' ], true ) ) {
                $required = 'free';
            }

            $upgrade_url   = URLs::upgrade( $required !== 'free' ? $required : 'basic' );
            $upgrade_label = __( 'Upgrade your plan', 'authorwings-membership' );
            $message       = sprintf(
                __( 'You have reached your %s plan limit for this month.', 'authorwings-membership' ),
                esc_html( ucfirst( $plan ) )
            );

            if ( in_array( $status, [ 'past_due', 'unpaid', 'canceled', 'cancelled', 'incomplete', 'incomplete_expired' ], true ) ) {
                $message       = __( 'Your membership billing needs attention before you can keep generating content.', 'authorwings-membership' );
                $upgrade_url   = URLs::account();
                $upgrade_label = __( 'Manage billing', 'authorwings-membership' );
            } elseif ( $required !== 'free' ) {
                $message = sprintf(
                    __( 'You have reached the monthly limit for your %1$s plan. This tool requires %2$s access for more usage.', 'authorwings-membership' ),
                    esc_html( ucfirst( $plan ) ),
                    esc_html( ucfirst( $required ) )
                );
            }

            return new \WP_Error(
                'awg_mem_limit_reached',
                $message,
                [
                    'upgrade_url'   => $upgrade_url,
                    'upgrade_label' => $upgrade_label,
                    'reason'        => 'limit_reached',
                    'plan'          => $plan,
                    'required_plan' => $required,
                ]
            );
        }

        return true;
    }

    /**
     * Action: awg_aig_generated — increment usage counter after successful generation.
     */
    public function on_generated( int $user_id, int $template_id, string $output ): void {
        unset( $template_id, $output );
        if ( $user_id > 0 ) {
            $this->usage->increment( $user_id, 'ai_generation' );
        }
    }

    public function map_usage_owner_user_id( int $mapped_user_id, int $requested_user_id ): int {
        unset( $mapped_user_id );
        return $this->memberships->get_usage_owner_id( $requested_user_id );
    }

    /**
     * Filter: awg_aig_visible_templates — hide templates the user can't access.
     */
    public function filter_templates( array $templates, int $user_id ): array {
        $plan    = $this->memberships->get_user_plan_slug( $user_id );
        $level   = Roles::level( Roles::slug_to_role( $plan ) );
        $allowed = [];
        foreach ( $templates as $template ) {
            $required = get_post_meta( $template->ID, '_awg_mem_required_plan', true ) ?: 'free';
            $required_level = Roles::level( Roles::slug_to_role( $required ) );
            if ( $level >= $required_level ) {
                $allowed[] = $template;
            }
        }
        return $allowed;
    }
}
