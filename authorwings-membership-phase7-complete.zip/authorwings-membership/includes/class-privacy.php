<?php
namespace AWG_MEM;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Privacy {
    public function register(): void {
        add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'register_exporter' ] );
        add_filter( 'wp_privacy_personal_data_erasers', [ $this, 'register_eraser' ] );
    }
    public function register_exporter( array $exporters ): array {
        $exporters['authorwings-membership'] = ['exporter_friendly_name' => __( 'AuthorWings membership data', 'authorwings-membership' ), 'callback' => [ $this, 'exporter' ]];
        return $exporters;
    }
    public function register_eraser( array $erasers ): array {
        $erasers['authorwings-membership'] = ['eraser_friendly_name' => __( 'AuthorWings membership data', 'authorwings-membership' ), 'callback' => [ $this, 'eraser' ]];
        return $erasers;
    }
    public function exporter( string $email_address, int $page = 1 ): array {
        $user = get_user_by( 'email', $email_address );
        if ( ! $user ) { return [ 'data' => [], 'done' => true ]; }
        global $wpdb; $data = []; $per_page = 20; $offset = max( 0, ( $page - 1 ) * $per_page );
        $mems = $wpdb->get_results( $wpdb->prepare("SELECT m.*, p.name AS plan_name, p.slug AS plan_slug FROM " . Database::mems_table() . " m LEFT JOIN " . Database::plans_table() . " p ON p.id = m.plan_id WHERE m.user_id = %d ORDER BY m.id DESC LIMIT %d OFFSET %d", $user->ID, $per_page, $offset), ARRAY_A );
        foreach ( (array) $mems as $row ) { $data[] = ['group_id' => 'authorwings-membership','group_label' => __( 'AuthorWings Membership', 'authorwings-membership' ),'item_id' => 'awg-membership-' . (int) $row['id'],'data' => [ ['name' => __( 'Membership ID', 'authorwings-membership' ), 'value' => (string) $row['id']], ['name' => __( 'Plan', 'authorwings-membership' ), 'value' => (string) ( $row['plan_name'] ?: $row['plan_slug'] )], ['name' => __( 'Status', 'authorwings-membership' ), 'value' => (string) $row['status']], ['name' => __( 'Billing cycle', 'authorwings-membership' ), 'value' => (string) $row['billing_cycle']], ['name' => __( 'Start date', 'authorwings-membership' ), 'value' => (string) $row['start_date']], ['name' => __( 'End date', 'authorwings-membership' ), 'value' => (string) $row['end_date']], ['name' => __( 'Stripe customer ID', 'authorwings-membership' ), 'value' => (string) $row['stripe_customer_id']], ['name' => __( 'Stripe subscription ID', 'authorwings-membership' ), 'value' => (string) $row['stripe_subscription_id']], ]]; }
        $usage = $wpdb->get_results( $wpdb->prepare("SELECT * FROM " . Database::usage_table() . " WHERE user_id = %d ORDER BY id DESC LIMIT %d OFFSET %d", $user->ID, $per_page, $offset), ARRAY_A );
        foreach ( (array) $usage as $row ) { $data[] = ['group_id' => 'authorwings-membership-usage','group_label' => __( 'AuthorWings Usage', 'authorwings-membership' ),'item_id' => 'awg-usage-' . (int) $row['id'],'data' => [ ['name' => __( 'Usage ID', 'authorwings-membership' ), 'value' => (string) $row['id']], ['name' => __( 'Service', 'authorwings-membership' ), 'value' => (string) $row['service_slug']], ['name' => __( 'Period', 'authorwings-membership' ), 'value' => (string) $row['period']], ['name' => __( 'Used', 'authorwings-membership' ), 'value' => (string) $row['used']], ['name' => __( 'Updated', 'authorwings-membership' ), 'value' => (string) $row['updated_at']], ]]; }
        $orders = $wpdb->get_results( $wpdb->prepare("SELECT * FROM " . Database::orders_table() . " WHERE user_id = %d ORDER BY id DESC LIMIT %d OFFSET %d", $user->ID, $per_page, $offset), ARRAY_A );
        foreach ( (array) $orders as $row ) { $data[] = ['group_id' => 'authorwings-membership-orders','group_label' => __( 'AuthorWings Service Orders', 'authorwings-membership' ),'item_id' => 'awg-order-' . (int) $row['id'],'data' => [ ['name' => __( 'Order ID', 'authorwings-membership' ), 'value' => (string) $row['id']], ['name' => __( 'Service', 'authorwings-membership' ), 'value' => (string) $row['service_name']], ['name' => __( 'Status', 'authorwings-membership' ), 'value' => (string) $row['status']], ['name' => __( 'Notes', 'authorwings-membership' ), 'value' => (string) $row['notes']], ['name' => __( 'Admin notes', 'authorwings-membership' ), 'value' => (string) $row['admin_notes']], ['name' => __( 'Created', 'authorwings-membership' ), 'value' => (string) $row['created_at']], ]]; }
        $has_more = count( $mems ) == $per_page || count( $usage ) == $per_page || count( $orders ) == $per_page;
        return [ 'data' => $data, 'done' => ! $has_more ];
    }
    public function eraser( string $email_address, int $page = 1 ): array {
        $user = get_user_by( 'email', $email_address );
        if ( ! $user ) { return [ 'items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true ]; }
        global $wpdb; $removed = false;
        $removed = (bool) $wpdb->delete( Database::usage_table(), [ 'user_id' => $user->ID ], [ '%d' ] ) || $removed;
        $removed = (bool) $wpdb->delete( Database::orders_table(), [ 'user_id' => $user->ID ], [ '%d' ] ) || $removed;
        $mems_table = Database::mems_table();
        $memberships = $wpdb->get_results( $wpdb->prepare( "SELECT id FROM {$mems_table} WHERE user_id = %d", $user->ID ), ARRAY_A );
        foreach ( (array) $memberships as $row ) {
            $removed = (bool) $wpdb->update( $mems_table, ['stripe_subscription_id' => '','stripe_customer_id' => '','status' => 'erased','updated_at' => current_time( 'mysql' )], [ 'id' => (int) $row['id'] ], [ '%s', '%s', '%s', '%s' ], [ '%d' ] ) || $removed;
        }
        $team_table = Database::team_table();
        $removed = (bool) $wpdb->delete( $team_table, [ 'member_user_id' => $user->ID ], [ '%d' ] ) || $removed;
        $removed = (bool) $wpdb->delete( $team_table, [ 'invited_email' => $email_address ], [ '%s' ] ) || $removed;
        return ['items_removed' => $removed,'items_retained' => false,'messages' => [],'done' => true];
    }
    public static function cleanup_retention(): void {
        global $wpdb; $settings = get_option( Plugin::OPT, [] );
        $usage_days = isset( $settings['usage_retention_days'] ) ? (int) $settings['usage_retention_days'] : 0;
        $order_days = isset( $settings['order_retention_days'] ) ? (int) $settings['order_retention_days'] : 0;
        $membership_days = isset( $settings['membership_retention_days'] ) ? (int) $settings['membership_retention_days'] : 0;
        if ( $usage_days > 0 ) { $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $usage_days * DAY_IN_SECONDS ) ); $wpdb->query( $wpdb->prepare( "DELETE FROM " . Database::usage_table() . " WHERE updated_at <> '0000-00-00 00:00:00' AND updated_at < %s", $cutoff ) ); }
        if ( $order_days > 0 ) { $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $order_days * DAY_IN_SECONDS ) ); $wpdb->query( $wpdb->prepare( "DELETE FROM " . Database::orders_table() . " WHERE updated_at <> '0000-00-00 00:00:00' AND updated_at < %s", $cutoff ) ); }
        if ( $membership_days > 0 ) { $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $membership_days * DAY_IN_SECONDS ) ); $wpdb->query( $wpdb->prepare( "DELETE FROM " . Database::mems_table() . " WHERE status IN ('cancelled','expired','erased') AND updated_at <> '0000-00-00 00:00:00' AND updated_at < %s", $cutoff ) ); }
        Logger::cleanup();
    }
}
