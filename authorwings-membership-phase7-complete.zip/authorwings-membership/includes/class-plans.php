<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Plans {

    /**
     * Seed the 4 default plans on first activation.
     */
    public static function seed_defaults(): void {
        global $wpdb;
        $table = Database::plans_table();

        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) > 0 ) {
            return; // Already seeded
        }

        $now   = current_time( 'mysql' );
        $plans = [
            [
                'name'          => 'Free',
                'slug'          => 'free',
                'description'   => 'Get started with basic AI tools for book publishing.',
                'price_monthly' => 0.00,
                'price_yearly'  => 0.00,
                'is_free'       => 1,
                'sort_order'    => 1,
                'features'      => wp_json_encode( [
                    'Book Title Generator (5/month)',
                    'Book Description Writer (3/month)',
                    'Genre & Comp Title Finder',
                    'Publishing Guides Library',
                    'Interactive Checklists',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => 10,
                    'tools_access'             => 'free',
                ] ),
            ],
            [
                'name'          => 'Basic',
                'slug'          => 'basic',
                'description'   => 'More AI tools and unlimited downloads for growing authors.',
                'price_monthly' => 19.00,
                'price_yearly'  => 179.00,
                'is_free'       => 0,
                'sort_order'    => 2,
                'features'      => wp_json_encode( [
                    'Everything in Free',
                    'AI Generations (100/month)',
                    'Book Synopsis Generator',
                    'Author Bio Generator (unlimited)',
                    'Social Media Caption Pack',
                    'ARC Outreach Email Writer',
                    'Amazon Listing Optimizer',
                    'Download all outputs',
                    'Submission history',
                    'Monthly webinars',
                    'Member community forum',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => 100,
                    'tools_access'             => 'basic',
                ] ),
            ],
            [
                'name'          => 'Pro',
                'slug'          => 'pro',
                'description'   => 'Full suite of AI tools and priority support for serious authors.',
                'price_monthly' => 49.00,
                'price_yearly'  => 449.00,
                'is_free'       => 0,
                'sort_order'    => 3,
                'features'      => wp_json_encode( [
                    'Everything in Basic',
                    'Unlimited AI Generations',
                    'Chapter Outline Generator',
                    'Query Letter Writer',
                    'Book Series Planner',
                    'Character Profile Builder',
                    'Dialogue Coach',
                    'Launch Email Sequence',
                    'Book Marketing Plan',
                    'Press Release Generator (unlimited)',
                    'Priority generation queue',
                    'Service discounts (10%)',
                    'Self-Publishing Masterclass',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => -1, // unlimited
                    'tools_access'             => 'pro',
                ] ),
            ],
            [
                'name'          => 'Publisher',
                'slug'          => 'publisher',
                'description'   => 'Agency-grade tools, team seats, and white-label outputs.',
                'price_monthly' => 149.00,
                'price_yearly'  => 1349.00,
                'is_free'       => 0,
                'sort_order'    => 4,
                'features'      => wp_json_encode( [
                    'Everything in Pro',
                    'Unlimited AI Generations',
                    'Up to 5 team seats',
                    'Bulk generation tools',
                    'White-label outputs',
                    'Dedicated account manager',
                    'Custom AI template creation',
                    'Service discounts (20%)',
                    'Priority email support',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => -1,
                    'tools_access'             => 'publisher',
                    'team_seats'               => 5,
                ] ),
            ],
        ];

        foreach ( $plans as $plan ) {
            $plan['created_at'] = $now;
            $wpdb->insert( $table, $plan );
        }
    }

    /**
     * Get all active plans ordered by sort_order.
     */
    public function get_all(): array {
        global $wpdb;
        $table = Database::plans_table();
        $rows  = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE is_active = 1 ORDER BY sort_order ASC",
            ARRAY_A
        );
        if ( ! $rows ) {
            return [];
        }
        return array_map( [ $this, 'decode_plan' ], $rows );
    }



    /**
     * Get all plans including inactive ones ordered by sort_order.
     */
    public function get_all_for_admin(): array {
        global $wpdb;
        $table = Database::plans_table();
        $rows  = $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY sort_order ASC, id ASC",
            ARRAY_A
        );
        if ( ! $rows ) {
            return [];
        }
        return array_map( [ $this, 'decode_plan' ], $rows );
    }

    /**
     * Insert or update a plan.
     */
    public function save_plan( array $plan ): int {
        global $wpdb;
        $table = Database::plans_table();
        $now   = current_time( 'mysql' );

        $data = [
            'name'                    => sanitize_text_field( $plan['name'] ?? '' ),
            'slug'                    => sanitize_title( $plan['slug'] ?? '' ),
            'description'             => sanitize_textarea_field( $plan['description'] ?? '' ),
            'price_monthly'           => round( (float) ( $plan['price_monthly'] ?? 0 ), 2 ),
            'price_yearly'            => round( (float) ( $plan['price_yearly'] ?? 0 ), 2 ),
            'currency'                => strtoupper( sanitize_text_field( $plan['currency'] ?? 'USD' ) ),
            'is_free'                 => ! empty( $plan['is_free'] ) ? 1 : 0,
            'is_active'               => ! empty( $plan['is_active'] ) ? 1 : 0,
            'sort_order'              => (int) ( $plan['sort_order'] ?? 0 ),
            'features'                => wp_json_encode( array_values( array_filter( (array) ( $plan['features'] ?? [] ) ) ) ),
            'limits'                  => wp_json_encode( (array) ( $plan['limits'] ?? [] ) ),
            'stripe_monthly_price_id' => sanitize_text_field( $plan['stripe_monthly_price_id'] ?? '' ),
            'stripe_yearly_price_id'  => sanitize_text_field( $plan['stripe_yearly_price_id'] ?? '' ),
        ];

        if ( empty( $data['currency'] ) ) {
            $data['currency'] = 'USD';
        }

        $existing_id = ! empty( $plan['id'] ) ? (int) $plan['id'] : 0;
        if ( $existing_id > 0 ) {
            $wpdb->update( $table, $data, [ 'id' => $existing_id ] );
            return $existing_id;
        }

        $data['created_at'] = $now;
        $wpdb->insert( $table, $data );
        return (int) $wpdb->insert_id;
    }

    /**
     * Get a single plan by ID.
     */
    public function get( int $plan_id ): ?array {
        global $wpdb;
        $table = Database::plans_table();
        $row   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", $plan_id ),
            ARRAY_A
        );
        return $row ? $this->decode_plan( $row ) : null;
    }

    /**
     * Get a plan by slug.
     */
    public function get_by_slug( string $slug ): ?array {
        global $wpdb;
        $table = Database::plans_table();
        $row   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s LIMIT 1", $slug ),
            ARRAY_A
        );
        return $row ? $this->decode_plan( $row ) : null;
    }

    /**
     * Get limits for a plan.
     */
    public function get_limits( int $plan_id ): array {
        $plan = $this->get( $plan_id );
        return $plan ? (array) $plan['limits'] : [];
    }

    /**
     * Decode JSON columns.
     */
    private function decode_plan( array $row ): array {
        $row['features'] = json_decode( $row['features'] ?? '[]', true ) ?: [];
        $row['limits']   = json_decode( $row['limits']   ?? '{}', true ) ?: [];
        return $row;
    }

    /**
     * Render the [awg_pricing] shortcode.
     */
    public function render_pricing_page( array $atts ): string {
        $plans = $this->get_all();
        ob_start();
        ?>
        <div class="awg-mem-pricing" id="awg-pricing">
            <div class="awg-mem-pricing__grid">
                <?php foreach ( $plans as $plan ) : ?>
                    <?php
                    $is_popular = $plan['slug'] === 'pro';
                    $monthly    = (float) $plan['price_monthly'];
                    $yearly     = (float) $plan['price_yearly'];
                    $is_free    = (bool) $plan['is_free'];
                    ?>
                    <div class="awg-mem-pricing__card<?php echo $is_popular ? ' awg-mem-pricing__card--popular' : ''; ?>">
                        <?php if ( $is_popular ) : ?>
                            <div class="awg-mem-pricing__badge"><?php esc_html_e( 'Most Popular', 'authorwings-membership' ); ?></div>
                        <?php endif; ?>

                        <h3 class="awg-mem-pricing__plan-name"><?php echo esc_html( $plan['name'] ); ?></h3>
                        <p class="awg-mem-pricing__desc"><?php echo esc_html( $plan['description'] ); ?></p>

                        <div class="awg-mem-pricing__price">
                            <?php if ( $is_free ) : ?>
                                <span class="awg-mem-pricing__amount">
                                    <?php esc_html_e( 'Free', 'authorwings-membership' ); ?>
                                </span>
                            <?php else : ?>
                                <span class="awg-mem-pricing__amount">
                                    $<?php echo esc_html( number_format( $monthly, 0 ) ); ?>
                                </span>
                                <span class="awg-mem-pricing__period">
                                    / <?php esc_html_e( 'month', 'authorwings-membership' ); ?>
                                </span>
                                <?php if ( $yearly > 0 ) : ?>
                                    <p class="awg-mem-pricing__yearly">
                                        <?php
                                        printf(
                                            /* translators: %s: yearly price */
                                            esc_html__( 'or $%s/year — save 2 months', 'authorwings-membership' ),
                                            esc_html( number_format( $yearly, 0 ) )
                                        );
                                        ?>
                                    </p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <a href="<?php echo esc_url( \AWG_MEM\URLs::upgrade( (string) $plan['slug'] ) ); ?>"
                           class="awg-mem-pricing__cta<?php echo $is_popular ? ' awg-mem-pricing__cta--primary' : ''; ?>">
                            <?php echo $is_free
                                ? esc_html__( 'Get Started Free', 'authorwings-membership' )
                                : esc_html__( 'Get Started', 'authorwings-membership' ); ?>
                        </a>

                        <ul class="awg-mem-pricing__features">
                            <?php foreach ( (array) $plan['features'] as $feature ) : ?>
                                <li><?php echo esc_html( $feature ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
