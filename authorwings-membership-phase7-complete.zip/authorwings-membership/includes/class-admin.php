<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Admin {

    /** @var Memberships */
    private $memberships;

    /** @var Plans */
    private $plans;

    /** @var Usage */
    private $usage;

    public function __construct( Memberships $memberships, Plans $plans, Usage $usage ) {
        $this->memberships = $memberships;
        $this->plans       = $plans;
        $this->usage       = $usage;
    }

    public function menu(): void {
        add_menu_page(
            __( 'AuthorWings Members', 'authorwings-membership' ),
            __( 'AW Members', 'authorwings-membership' ),
            'manage_options',
            'awg-membership',
            [ $this, 'page_members' ],
            'dashicons-groups',
            57
        );

        add_submenu_page(
            'awg-membership',
            __( 'Members', 'authorwings-membership' ),
            __( 'Members', 'authorwings-membership' ),
            'manage_options',
            'awg-membership',
            [ $this, 'page_members' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Plans', 'authorwings-membership' ),
            __( 'Plans', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-plans',
            [ $this, 'page_plans' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Service Orders', 'authorwings-membership' ),
            __( 'Service Orders', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-orders',
            [ $this, 'page_orders' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Services', 'authorwings-membership' ),
            __( 'Services', 'authorwings-membership' ),
            'manage_options',
            'edit.php?post_type=awg_service'
        );

        add_submenu_page(
            'awg-membership',
            __( 'Settings', 'authorwings-membership' ),
            __( 'Settings', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-settings',
            [ $this, 'page_settings' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Release Tests', 'authorwings-membership' ),
            __( 'Release Tests', 'authorwings-membership' ),
            'manage_options',
            'awg-membership-release-tests',
            [ $this, 'page_release_tests' ]
        );
    }


    public function page_release_tests(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        $results = null;
        if ( isset( $_POST['awg_mem_run_selftests'] ) && check_admin_referer( 'awg_mem_run_selftests_action', 'awg_mem_run_selftests_nonce' ) ) {
            $results = Plugin::instance()->selftest->run_all( get_current_user_id() );
        }
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Release Tests', 'authorwings-membership' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Run automated plugin self-tests before packaging or deploying updates. Then complete the manual release checklist included in the plugin package.', 'authorwings-membership' ); ?></p>
            <form method="post">
                <?php wp_nonce_field( 'awg_mem_run_selftests_action', 'awg_mem_run_selftests_nonce' ); ?>
                <p><button type="submit" name="awg_mem_run_selftests" class="button button-primary"><?php esc_html_e( 'Run Self-Tests', 'authorwings-membership' ); ?></button></p>
            </form>
            <?php if ( is_array( $results ) ) : ?>
                <?php $all_passed = ! empty( $results['passed'] ); ?>
                <div class="notice <?php echo $all_passed ? 'notice-success' : 'notice-error'; ?>"><p><?php echo esc_html( $all_passed ? __( 'All automated self-tests passed.', 'authorwings-membership' ) : __( 'One or more self-tests failed. Review the results below before release.', 'authorwings-membership' ) ); ?></p></div>
                <table class="widefat striped">
                    <thead><tr><th><?php esc_html_e( 'Test', 'authorwings-membership' ); ?></th><th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th><th><?php esc_html_e( 'Details', 'authorwings-membership' ); ?></th></tr></thead>
                    <tbody>
                    <?php foreach ( (array) $results['tests'] as $test ) : ?>
                        <tr>
                            <td><strong><?php echo esc_html( $test['name'] ); ?></strong></td>
                            <td><?php echo esc_html( ! empty( $test['passed'] ) ? __( 'Passed', 'authorwings-membership' ) : __( 'Failed', 'authorwings-membership' ) ); ?></td>
                            <td><?php echo esc_html( $test['message'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    public function register_settings(): void {
        register_setting( 'awg_mem_settings_group', Plugin::OPT, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_settings' ],
        ] );
    }

    public function sanitize_settings( $input ): array {
        $input = is_array( $input ) ? wp_unslash( $input ) : [];
        $out = [];
        $out['notify_admin_email'] = sanitize_email( $input['notify_admin_email'] ?? get_option( 'admin_email' ) );
        $out['stripe_secret_key']  = sanitize_text_field( $input['stripe_secret_key']  ?? '' );
        $out['stripe_public_key']  = sanitize_text_field( $input['stripe_public_key']  ?? '' );
        $out['stripe_webhook_secret'] = sanitize_text_field( $input['stripe_webhook_secret'] ?? '' );
        $out['dashboard_page_id']  = (int) ( $input['dashboard_page_id'] ?? 0 );
        $out['pricing_page_id']    = (int) ( $input['pricing_page_id'] ?? 0 );
        $out['enable_error_logging'] = isset( $input['enable_error_logging'] ) ? 1 : 0;
        $out['log_retention_days'] = max( 0, (int) ( $input['log_retention_days'] ?? 30 ) );
        $out['usage_retention_days'] = max( 0, (int) ( $input['usage_retention_days'] ?? 0 ) );
        $out['order_retention_days'] = max( 0, (int) ( $input['order_retention_days'] ?? 0 ) );
        $out['membership_retention_days'] = max( 0, (int) ( $input['membership_retention_days'] ?? 0 ) );
        return $out;
    }

    public function page_members(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        global $wpdb;
        $mems_table  = Database::mems_table();
        $plans_table = Database::plans_table();

        if ( isset( $_POST['awg_assign_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['awg_assign_plan_nonce'] ) ), 'awg_assign_plan' ) ) {
            $uid     = isset( $_POST['awg_uid'] ) ? (int) wp_unslash( (string) $_POST['awg_uid'] ) : 0;
            $plan_id = isset( $_POST['awg_plan_id'] ) ? (int) wp_unslash( (string) $_POST['awg_plan_id'] ) : 0;
            $billing_raw = isset( $_POST['awg_billing'] ) ? wp_unslash( (string) $_POST['awg_billing'] ) : '';
            $billing = in_array( $billing_raw, [ 'monthly', 'yearly', 'free' ], true )
                       ? sanitize_key( $billing_raw )
                       : 'monthly';
            if ( $uid && $plan_id ) {
                $this->memberships->set_user_plan( $uid, $plan_id, $billing );
                echo '<div class="notice notice-success"><p>' . esc_html__( 'Plan updated.', 'authorwings-membership' ) . '</p></div>';
            }
        }

        $members = $wpdb->get_results(
            "SELECT m.*, p.name as plan_name, p.slug as plan_slug, u.display_name, u.user_email
             FROM {$mems_table} m
             LEFT JOIN {$plans_table} p ON p.id = m.plan_id
             LEFT JOIN {$wpdb->users} u ON u.ID = m.user_id
             WHERE m.status IN ('active','cancelled')
             ORDER BY m.id DESC
             LIMIT 100",
            ARRAY_A
        );

        $all_plans = $this->plans->get_all();
        $activity_summary = $this->usage->get_member_activity_summary( 15 );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'AuthorWings Members', 'authorwings-membership' ); ?></h1>
            <?php
            $total_active  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$mems_table} WHERE status = 'active'" );
            $total_paid    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$mems_table} m LEFT JOIN {$plans_table} p ON p.id = m.plan_id WHERE m.status = 'active' AND p.is_free = 0" );
            $total_free    = $total_active - $total_paid;
            ?>
            <div style="display:flex;gap:16px;margin:16px 0;flex-wrap:wrap;">
                <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 24px;min-width:150px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;"><?php echo esc_html( $total_active ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Active Members', 'authorwings-membership' ); ?></div>
                </div>
                <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 24px;min-width:150px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;color:#1D9E75;"><?php echo esc_html( $total_paid ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Paid Members', 'authorwings-membership' ); ?></div>
                </div>
                <div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px 24px;min-width:150px;text-align:center;">
                    <div style="font-size:28px;font-weight:600;color:#475569;"><?php echo esc_html( $total_free ); ?></div>
                    <div style="color:#666;font-size:13px;"><?php esc_html_e( 'Free Members', 'authorwings-membership' ); ?></div>
                </div>
            </div>

            <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:18px;margin:18px 0;">
                <h2 style="margin-top:0;"><?php esc_html_e( 'Member Activity Summary', 'authorwings-membership' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Shows current-month usage and latest recorded AI activity for recently active members.', 'authorwings-membership' ); ?></p>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Member', 'authorwings-membership' ); ?></th>
                            <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                            <th><?php esc_html_e( 'This Month', 'authorwings-membership' ); ?></th>
                            <th><?php esc_html_e( 'Last Activity', 'authorwings-membership' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( empty( $activity_summary ) ) : ?>
                            <tr><td colspan="4"><?php esc_html_e( 'No member activity recorded yet.', 'authorwings-membership' ); ?></td></tr>
                        <?php else : ?>
                            <?php foreach ( $activity_summary as $row ) : ?>
                                <tr>
                                    <td><strong><?php echo esc_html( $row['display_name'] ); ?></strong><br><small><?php echo esc_html( $row['user_email'] ); ?></small></td>
                                    <td><?php echo esc_html( $row['plan_name'] ); ?></td>
                                    <td><?php echo esc_html( (string) $row['month_used'] ); ?></td>
                                    <td><?php echo ! empty( $row['last_activity'] ) ? esc_html( wp_date( 'd M Y g:i a', strtotime( $row['last_activity'] ) ) ) : '—'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Member', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Billing', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Ends', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Quick Assign', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $members ) ) : ?>
                        <tr><td colspan="7"><?php esc_html_e( 'No memberships found yet.', 'authorwings-membership' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $members as $m ) : ?>
                            <tr>
                                <td><?php echo esc_html( $m['id'] ); ?></td>
                                <td><strong><?php echo esc_html( $m['display_name'] ); ?></strong><br><small><?php echo esc_html( $m['user_email'] ); ?></small></td>
                                <td><?php echo esc_html( $m['plan_name'] ?: '—' ); ?></td>
                                <td><?php echo esc_html( ucfirst( $m['billing_cycle'] ) ); ?></td>
                                <td><?php echo esc_html( ucfirst( $m['status'] ) ); ?></td>
                                <td><?php echo ! empty( $m['end_date'] ) ? esc_html( wp_date( 'd M Y', strtotime( $m['end_date'] ) ) ) : '—'; ?></td>
                                <td>
                                    <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                                        <?php wp_nonce_field( 'awg_assign_plan', 'awg_assign_plan_nonce' ); ?>
                                        <input type="hidden" name="awg_uid" value="<?php echo esc_attr( $m['user_id'] ); ?>">
                                        <select name="awg_plan_id">
                                            <?php foreach ( $all_plans as $plan ) : ?>
                                                <option value="<?php echo esc_attr( $plan['id'] ); ?>" <?php selected( (int) $plan['id'], (int) $m['plan_id'] ); ?>><?php echo esc_html( $plan['name'] ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <select name="awg_billing">
                                            <option value="monthly" <?php selected( $m['billing_cycle'], 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'authorwings-membership' ); ?></option>
                                            <option value="yearly" <?php selected( $m['billing_cycle'], 'yearly' ); ?>><?php esc_html_e( 'Yearly', 'authorwings-membership' ); ?></option>
                                            <option value="free" <?php selected( $m['billing_cycle'], 'free' ); ?>><?php esc_html_e( 'Free', 'authorwings-membership' ); ?></option>
                                        </select>
                                        <button class="button button-small" type="submit"><?php esc_html_e( 'Save', 'authorwings-membership' ); ?></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_plans(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }

        $notice = '';
        $editing_plan = null;

        if ( isset( $_POST['awg_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_plan_nonce'] ) ), 'awg_save_plan' ) ) {
            $plan_id = (int) ( $_POST['plan_id'] ?? 0 );
            $features = preg_split( '/
|
|
/', (string) wp_unslash( $_POST['features_text'] ?? '' ) );
            $features = array_values( array_filter( array_map( 'sanitize_text_field', (array) $features ) ) );

            $limits = [
                'ai_generations_per_month' => isset( $_POST['limit_ai_generations'] ) ? (int) $_POST['limit_ai_generations'] : 0,
                'tools_access'             => sanitize_key( $_POST['limit_tools_access'] ?? 'free' ),
                'team_seats'               => isset( $_POST['limit_team_seats'] ) ? max( 0, (int) $_POST['limit_team_seats'] ) : 0,
            ];

            $plan_payload = [
                'id'                      => $plan_id,
                'name'                    => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
                'slug'                    => sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) ),
                'description'             => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
                'price_monthly'           => (float) ( $_POST['price_monthly'] ?? 0 ),
                'price_yearly'            => (float) ( $_POST['price_yearly'] ?? 0 ),
                'currency'                => sanitize_text_field( wp_unslash( $_POST['currency'] ?? 'USD' ) ),
                'is_free'                 => ! empty( $_POST['is_free'] ) ? 1 : 0,
                'is_active'               => ! empty( $_POST['is_active'] ) ? 1 : 0,
                'sort_order'              => (int) ( $_POST['sort_order'] ?? 0 ),
                'features'                => $features,
                'limits'                  => $limits,
                'stripe_monthly_price_id' => sanitize_text_field( wp_unslash( $_POST['stripe_monthly_price_id'] ?? '' ) ),
                'stripe_yearly_price_id'  => sanitize_text_field( wp_unslash( $_POST['stripe_yearly_price_id'] ?? '' ) ),
            ];

            if ( $plan_payload['name'] && $plan_payload['slug'] ) {
                $saved_id = $this->plans->save_plan( $plan_payload );
                $editing_plan = $this->plans->get( $saved_id );
                $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Plan saved.', 'authorwings-membership' ) . '</p></div>';
            } else {
                $notice = '<div class="notice notice-error"><p>' . esc_html__( 'Plan name and slug are required.', 'authorwings-membership' ) . '</p></div>';
            }
        }

        if ( ! $editing_plan && isset( $_GET['edit_plan'] ) ) {
            $editing_plan = $this->plans->get( (int) $_GET['edit_plan'] );
        }

        if ( ! $editing_plan ) {
            $editing_plan = [
                'id'                      => 0,
                'name'                    => '',
                'slug'                    => '',
                'description'             => '',
                'price_monthly'           => '0.00',
                'price_yearly'            => '0.00',
                'currency'                => 'USD',
                'is_free'                 => 0,
                'is_active'               => 1,
                'sort_order'              => 0,
                'features'                => [],
                'limits'                  => [
                    'ai_generations_per_month' => 0,
                    'tools_access'             => 'free',
                    'team_seats'               => 0,
                ],
                'stripe_monthly_price_id' => '',
                'stripe_yearly_price_id'  => '',
            ];
        }

        $plans = $this->plans->get_all_for_admin();
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Membership Plans', 'authorwings-membership' ); ?></h1>
            <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

            <div style="display:grid;grid-template-columns:minmax(320px,430px) 1fr;gap:22px;align-items:start;">
                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:18px;">
                    <h2 style="margin-top:0;"><?php echo $editing_plan['id'] ? esc_html__( 'Edit Plan', 'authorwings-membership' ) : esc_html__( 'Add Plan', 'authorwings-membership' ); ?></h2>
                    <form method="post">
                        <?php wp_nonce_field( 'awg_save_plan', 'awg_plan_nonce' ); ?>
                        <input type="hidden" name="plan_id" value="<?php echo esc_attr( $editing_plan['id'] ); ?>">
                        <table class="form-table" role="presentation">
                            <tr><th><label for="awg-plan-name"><?php esc_html_e( 'Plan Name', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-name" class="regular-text" type="text" name="name" value="<?php echo esc_attr( $editing_plan['name'] ); ?>" required></td></tr>
                            <tr><th><label for="awg-plan-slug"><?php esc_html_e( 'Slug', 'authorwings-membership' ); ?></label></th><td><input id="awg-plan-slug" class="regular-text" type="text" name="slug" value="<?php echo esc_attr( $editing_plan['slug'] ); ?>" required><p class="description"><?php esc_html_e( 'Used for access checks and upgrade URLs.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-desc"><?php esc_html_e( 'Description', 'authorwings-membership' ); ?></label></th><td><textarea id="awg-plan-desc" class="large-text" rows="3" name="description"><?php echo esc_textarea( $editing_plan['description'] ); ?></textarea></td></tr>
                            <tr><th><?php esc_html_e( 'Monthly Price', 'authorwings-membership' ); ?></th><td><input type="number" step="0.01" min="0" name="price_monthly" value="<?php echo esc_attr( $editing_plan['price_monthly'] ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Yearly Price', 'authorwings-membership' ); ?></th><td><input type="number" step="0.01" min="0" name="price_yearly" value="<?php echo esc_attr( $editing_plan['price_yearly'] ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Currency', 'authorwings-membership' ); ?></th><td><input class="small-text" type="text" maxlength="10" name="currency" value="<?php echo esc_attr( $editing_plan['currency'] ?? 'USD' ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Usage Limit', 'authorwings-membership' ); ?></th><td><input type="number" min="-1" name="limit_ai_generations" value="<?php echo esc_attr( (int) ( $editing_plan['limits']['ai_generations_per_month'] ?? 0 ) ); ?>"><p class="description"><?php esc_html_e( 'Use -1 for unlimited monthly AI generations.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><?php esc_html_e( 'Tools Access Level', 'authorwings-membership' ); ?></th><td><select name="limit_tools_access"><option value="free" <?php selected( $editing_plan['limits']['tools_access'] ?? 'free', 'free' ); ?>>Free</option><option value="basic" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'basic' ); ?>>Basic</option><option value="pro" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'pro' ); ?>>Pro</option><option value="publisher" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'publisher' ); ?>>Publisher</option></select></td></tr>
                            <tr><th><?php esc_html_e( 'Team Seats', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="limit_team_seats" value="<?php echo esc_attr( (int) ( $editing_plan['limits']['team_seats'] ?? 0 ) ); ?>"></td></tr>
                            <tr><th><label for="awg-plan-features"><?php esc_html_e( 'Features', 'authorwings-membership' ); ?></label></th><td><textarea id="awg-plan-features" class="large-text code" rows="8" name="features_text"><?php echo esc_textarea( implode( "
", (array) $editing_plan['features'] ) ); ?></textarea><p class="description"><?php esc_html_e( 'One feature per line.', 'authorwings-membership' ); ?></p></td></tr>
                            <tr><th><?php esc_html_e( 'Stripe Monthly Price ID', 'authorwings-membership' ); ?></th><td><input class="regular-text" type="text" name="stripe_monthly_price_id" value="<?php echo esc_attr( $editing_plan['stripe_monthly_price_id'] ?? '' ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Stripe Yearly Price ID', 'authorwings-membership' ); ?></th><td><input class="regular-text" type="text" name="stripe_yearly_price_id" value="<?php echo esc_attr( $editing_plan['stripe_yearly_price_id'] ?? '' ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Sort Order', 'authorwings-membership' ); ?></th><td><input type="number" name="sort_order" value="<?php echo esc_attr( (int) $editing_plan['sort_order'] ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th><td><label><input type="checkbox" name="is_active" value="1" <?php checked( ! empty( $editing_plan['is_active'] ) ); ?>> <?php esc_html_e( 'Active', 'authorwings-membership' ); ?></label><br><label><input type="checkbox" name="is_free" value="1" <?php checked( ! empty( $editing_plan['is_free'] ) ); ?>> <?php esc_html_e( 'Free plan', 'authorwings-membership' ); ?></label></td></tr>
                        </table>
                        <p>
                            <button type="submit" class="button button-primary"><?php esc_html_e( 'Save Plan', 'authorwings-membership' ); ?></button>
                            <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-plans' ) ); ?>"><?php esc_html_e( 'Add New', 'authorwings-membership' ); ?></a>
                        </p>
                    </form>
                </div>

                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:18px;">
                    <h2 style="margin-top:0;"><?php esc_html_e( 'All Plans', 'authorwings-membership' ); ?></h2>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th><?php esc_html_e( 'Plan', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Prices', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Limits', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Stripe IDs', 'authorwings-membership' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( empty( $plans ) ) : ?>
                                <tr><td colspan="6"><?php esc_html_e( 'No plans found.', 'authorwings-membership' ); ?></td></tr>
                            <?php else : ?>
                                <?php foreach ( $plans as $plan ) : ?>
                                    <tr>
                                        <td><?php echo esc_html( $plan['id'] ); ?></td>
                                        <td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-plans&edit_plan=' . (int) $plan['id'] ) ); ?>"><?php echo esc_html( $plan['name'] ); ?></a></strong><br><code><?php echo esc_html( $plan['slug'] ); ?></code></td>
                                        <td>
                                            <?php if ( ! empty( $plan['is_free'] ) ) : ?>
                                                <?php esc_html_e( 'Free', 'authorwings-membership' ); ?>
                                            <?php else : ?>
                                                $<?php echo esc_html( number_format( (float) $plan['price_monthly'], 2 ) ); ?> / <?php esc_html_e( 'month', 'authorwings-membership' ); ?><br>
                                                $<?php echo esc_html( number_format( (float) $plan['price_yearly'], 2 ) ); ?> / <?php esc_html_e( 'year', 'authorwings-membership' ); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php
                                            $limit = (int) ( $plan['limits']['ai_generations_per_month'] ?? 0 );
                                            echo esc_html__( 'AI:', 'authorwings-membership' ) . ' ' . esc_html( $limit < 0 ? 'Unlimited' : $limit . '/month' );
                                            echo '<br>' . esc_html__( 'Access:', 'authorwings-membership' ) . ' ' . esc_html( ucfirst( (string) ( $plan['limits']['tools_access'] ?? 'free' ) ) );
                                            if ( ! empty( $plan['limits']['team_seats'] ) ) {
                                                echo '<br>' . esc_html__( 'Seats:', 'authorwings-membership' ) . ' ' . esc_html( (int) $plan['limits']['team_seats'] );
                                            }
                                            ?>
                                        </td>
                                        <td><small><?php echo esc_html( $plan['stripe_monthly_price_id'] ?: '—' ); ?><br><?php echo esc_html( $plan['stripe_yearly_price_id'] ?: '—' ); ?></small></td>
                                        <td><?php echo ! empty( $plan['is_active'] ) ? esc_html__( 'Active', 'authorwings-membership' ) : esc_html__( 'Inactive', 'authorwings-membership' ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public function page_orders(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        global $wpdb;
        $table  = Database::orders_table();
        $orders = $wpdb->get_results(
            "SELECT o.*, u.display_name, u.user_email FROM {$table} o
             LEFT JOIN {$wpdb->users} u ON u.ID = o.user_id
             ORDER BY o.id DESC LIMIT 100",
            ARRAY_A
        );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Service Orders', 'authorwings-membership' ); ?></h1>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Service', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'User', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Notes', 'authorwings-membership' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'authorwings-membership' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $orders ) ) : ?>
                        <tr><td colspan="6"><?php esc_html_e( 'No orders yet.', 'authorwings-membership' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $orders as $o ) : ?>
                            <tr>
                                <td><?php echo esc_html( $o['id'] ); ?></td>
                                <td><strong><?php echo esc_html( $o['service_name'] ); ?></strong></td>
                                <td><?php echo esc_html( $o['display_name'] ); ?><br><small><?php echo esc_html( $o['user_email'] ); ?></small></td>
                                <td>
                                    <span style="background:<?php echo $o['status'] === 'pending' ? '#fff3cd' : '#d4edda'; ?>;padding:2px 8px;border-radius:3px;font-size:12px;">
                                        <?php echo esc_html( ucfirst( $o['status'] ) ); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html( wp_trim_words( $o['notes'], 15 ) ); ?></td>
                                <td><?php echo esc_html( wp_date( 'd M Y', strtotime( $o['created_at'] ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $s = get_option( Plugin::OPT, [] );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'AuthorWings Membership Settings', 'authorwings-membership' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'awg_mem_settings_group' ); ?>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Admin Notification Email', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="email" name="<?php echo esc_attr( Plugin::OPT ); ?>[notify_admin_email]"
                                   value="<?php echo esc_attr( $s['notify_admin_email'] ?? get_option( 'admin_email' ) ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Secret Key', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_secret_key]"
                                   value="<?php echo esc_attr( $s['stripe_secret_key'] ?? '' ); ?>"
                                   class="regular-text" autocomplete="off">
                            <p class="description"><?php esc_html_e( 'Your Stripe secret key (sk_live_... or sk_test_...)', 'authorwings-membership' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Publishable Key', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_public_key]"
                                   value="<?php echo esc_attr( $s['stripe_public_key'] ?? '' ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Webhook Secret', 'authorwings-membership' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_webhook_secret]"
                                   value="<?php echo esc_attr( $s['stripe_webhook_secret'] ?? '' ); ?>"
                                   class="regular-text" autocomplete="off">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Dashboard Page', 'authorwings-membership' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[dashboard_page_id]',
                                'selected'         => (int) ( $s['dashboard_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (member-dashboard)', 'authorwings-membership' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Pricing Page', 'authorwings-membership' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[pricing_page_id]',
                                'selected'         => (int) ( $s['pricing_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (pricing)', 'authorwings-membership' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Enable sanitized error logging', 'authorwings-membership' ); ?></th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr( Plugin::OPT ); ?>[enable_error_logging]" value="1" <?php checked( ! empty( $s['enable_error_logging'] ) ); ?>> <?php esc_html_e( 'Keep billing and membership errors in an internal log without exposing secrets.', 'authorwings-membership' ); ?></label></td>
                    </tr>
                    <tr><th><?php esc_html_e( 'Error log retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[log_retention_days]" value="<?php echo esc_attr( $s['log_retention_days'] ?? 30 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps logs until manually cleared. Positive values remove older logs during daily cleanup.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Usage retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[usage_retention_days]" value="<?php echo esc_attr( $s['usage_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps usage records indefinitely.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Service order retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[order_retention_days]" value="<?php echo esc_attr( $s['order_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps order records indefinitely.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Cancelled membership retention (days)', 'authorwings-membership' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[membership_retention_days]" value="<?php echo esc_attr( $s['membership_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'Only cancelled, expired, or erased membership rows are auto-removed. 0 disables automatic deletion.', 'authorwings-membership' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Stored data summary', 'authorwings-membership' ); ?></th><td><p class="description"><?php esc_html_e( 'This plugin stores membership plan records, Stripe customer and subscription identifiers, usage counts, service order notes, and team-seat invite data.', 'authorwings-membership' ); ?></p></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function ajax_assign_plan(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 403 );
        }
        $uid     = (int) ( $_POST['user_id'] ?? 0 );
        $plan_id = (int) ( $_POST['plan_id'] ?? 0 );
        $billing = sanitize_text_field( $_POST['billing'] ?? 'monthly' );
        if ( ! $uid || ! $plan_id ) {
            wp_send_json_error( [ 'message' => 'Missing params' ] );
        }
        $this->memberships->set_user_plan( $uid, $plan_id, $billing );
        wp_send_json_success( [ 'message' => 'Plan updated.' ] );
    }

    public function ajax_get_stats(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Unauthorized' ], 403 );
        }
        global $wpdb;
        $mt = Database::mems_table();
        $pt = Database::plans_table();
        $ut = Database::usage_table();
        $period = Usage::current_period();

        $total_members = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$mt} WHERE status='active'" );
        $paid_members  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$mt} m LEFT JOIN {$pt} p ON p.id=m.plan_id WHERE m.status='active' AND p.is_free=0" );
        $total_gen     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(used) FROM {$ut} WHERE period=%s AND service_slug='ai_generation'", $period ) );

        wp_send_json_success( [
            'total_members' => $total_members,
            'paid_members'  => $paid_members,
            'free_members'  => $total_members - $paid_members,
            'generations'   => $total_gen,
            'period'        => $period,
        ] );
    }
}
